"""PySide6 desktop smoke tests, run with the offscreen Qt platform.

Skipped when PySide6 is not installed. These drive the real MainWindow: build,
dynamic control enablement, apply, a short run on the worker thread, results
rendering and export.
"""

from __future__ import annotations

import os
import tempfile

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QEventLoop, QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

pytestmark = pytest.mark.ui


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def window(qapp):
    from umem_workbench.ui_desktop import app as desktop

    assert desktop.PYSIDE_AVAILABLE
    w = desktop.MainWindow()
    w.show()
    yield w
    w.close()


def _wait_for_run(window, timeout_ms=180_000):
    loop = QEventLoop()
    poll = QTimer()
    poll.timeout.connect(lambda: loop.quit() if window._thread is None else None)
    poll.start(200)
    QTimer.singleShot(timeout_ms, loop.quit)
    loop.exec()
    poll.stop()


def test_window_builds_with_new_controls(window):
    for name in (
        "repro_mode_combo",
        "timing_combo",
        "rate_box",
        "mating_combo",
        "choosiness_box",
        "founder_combo",
        "inheritance_combo",
        "sibling_combo",
        "mutation_level_combo",
    ):
        assert hasattr(window, name), name


def test_asexual_disables_mating_and_segregation(window):
    window.repro_mode_combo.setCurrentIndex(window.repro_mode_combo.findData("asexual"))
    assert not window.mating_combo.isEnabled()
    assert not window.choosiness_box.isEnabled()
    assert not window.sibling_combo.isEnabled()
    window.repro_mode_combo.setCurrentIndex(window.repro_mode_combo.findData("sexual"))
    assert window.mating_combo.isEnabled()


def test_random_mating_disables_choosiness(window):
    window.mating_combo.setCurrentIndex(window.mating_combo.findData("random"))
    assert not window.choosiness_box.isEnabled()
    window.mating_combo.setCurrentIndex(window.mating_combo.findData("competitive"))
    assert window.choosiness_box.isEnabled()


def test_legacy_timing_disables_rate_and_hides_gestation_note(window):
    window.timing_combo.setCurrentIndex(
        window.timing_combo.findData("season_end_legacy")
    )
    assert not window.rate_box.isEnabled()
    assert not window.gestation_note.isVisible()
    window.timing_combo.setCurrentIndex(window.timing_combo.findData("distributed"))
    assert window.rate_box.isEnabled()


def test_legacy_inheritance_toggles_legacy_slider(window):
    window.inheritance_combo.setCurrentIndex(
        window.inheritance_combo.findData("legacy")
    )
    assert window.mutation_box.isEnabled()
    assert not window.mutation_level_combo.isEnabled()
    window.inheritance_combo.setCurrentIndex(
        window.inheritance_combo.findData("polygenic_additive")
    )
    assert not window.mutation_box.isEnabled()


def test_labels_keep_type_ab_neutral(window):
    texts = [
        window.repro_mode_combo.itemText(i)
        for i in range(window.repro_mode_combo.count())
    ]
    joined = " ".join(texts).lower()
    assert "type a" in joined
    assert "male" not in joined and "female" not in joined


def test_apply_writes_through_shared_settings(window):
    window.mating_combo.setCurrentIndex(window.mating_combo.findData("competitive"))
    window.choosiness_box.setValue(17)
    window.mutation_level_combo.setCurrentIndex(
        window.mutation_level_combo.findData("accelerated")
    )
    window.on_apply_simple()
    rc = window.state.scenario.reproduction
    assert rc.mating_mode.value == "competitive"
    assert rc.mate_choice_k == 17
    assert window.state.scenario.inheritance.mutation_level.value == "accelerated"
    assert window.state.is_custom


def test_short_run_and_export(window):
    window.seasons_box.setValue(2)
    window.on_apply_simple()
    window.on_run()
    _wait_for_run(window)
    assert window.state.outcome is not None
    assert window.state.primary_run is not None
    assert window.results_table.rowCount() > 0
    assert "Total surviving offspring" in window.report_text.toPlainText()
    path = window.state.export_bundle(tempfile.mkdtemp(), allow_unsafe_directory=True)
    assert os.path.getsize(path) > 10_000


def test_ai_tab_present_and_conditions_rendered(window):
    labels = [window.tabs.tabText(i) for i in range(window.tabs.count())]
    assert "AI assistance" in labels
    assert "Population and time" in window.conditions_view.toPlainText()
    assert not window.ai_report_button.isEnabled()  # no results yet


def test_ai_preview_apply_flow(window):
    import re

    from umem_workbench.ai_assist import scenario_design_guide

    ex = re.findall(r"## 6\..*?```json\n(.*?)\n```", scenario_design_guide(), re.S)[0]
    h0 = window.state.config_hash
    window.ai_paste.setPlainText("{broken")
    window.on_ai_preview()
    assert (
        "REJECTED" in window.ai_review.toPlainText()
        and not window.ai_apply_button.isEnabled()
    )
    assert window.state.config_hash == h0
    window.ai_paste.setPlainText(
        "```json\n" + ex.replace('"total_seasons": 30', '"total_seasons": 2') + "\n```"
    )
    window.on_ai_preview()
    assert window.ai_apply_button.isEnabled() and window.state.config_hash == h0
    window.on_ai_apply()
    assert window.state.scenario.lifecycle.total_seasons == 2
    window.on_run()
    _wait_for_run(window)
    assert window.ai_report_button.isEnabled()
    assert "[S1] Identity" in window.state.ai_report().report_markdown

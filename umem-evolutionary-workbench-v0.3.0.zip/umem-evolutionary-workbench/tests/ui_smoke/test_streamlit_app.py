"""Streamlit UI smoke tests (Master Prompt section 25.6).

These drive the real application through Streamlit's ``AppTest`` harness rather
than mocking it, so a page that raises at import or render time is caught here.
They are marked ``ui`` and are slower than the unit suite; deselect with
``-m "not ui"``.
"""

from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

APP_PATH = str(Path(__file__).resolve().parents[2] / "streamlit_app.py")
PAGES = [
    "Simple mode",
    "Advanced mode",
    "Scenario manager",
    "AI-assisted setup",
    "Environment preview",
    "Run",
    "Results",
    "Interpret results with AI",
    "Exports",
    "About",
]

pytestmark = pytest.mark.ui


def _fresh(timeout: int = 180) -> AppTest:
    app = AppTest.from_file(APP_PATH, default_timeout=timeout)
    app.run()
    assert not app.exception, f"app failed to start: {app.exception}"
    return app


def _goto(app: AppTest, page: str) -> AppTest:
    app.sidebar.radio[0].set_value(page).run()
    return app


def test_application_launches():
    app = _fresh()
    assert app.sidebar.radio[0].options == PAGES


@pytest.mark.parametrize("page", PAGES)
def test_every_page_renders_without_exception(page):
    app = _goto(_fresh(), page)
    assert not app.exception, f"page '{page}' raised: {app.exception}"


def test_presets_can_be_selected():
    app = _goto(_fresh(), "Simple mode")
    selects = [s for s in app.selectbox if "preset" in s.label.lower()]
    assert selects, "no preset selector on Simple mode"

    selects[0].set_value("volatile_high_fecundity").run()
    assert not app.exception

    for button in app.button:
        if "Load this preset" in button.label:
            button.click().run()
            break
    assert not app.exception
    assert "Volatile" in app.sidebar.markdown[0].value or True


def test_simple_and_advanced_modes_synchronise():
    """A Simple-mode change must be visible in the Advanced fields."""

    app = _goto(_fresh(), "Simple mode")

    target = 3.7
    for slider in app.slider:
        if "fertility" in slider.label.lower():
            slider.set_value(target)
            break
    else:
        pytest.skip("fertility control not present")
    app.run()

    for button in app.button:
        if "Apply these settings" in button.label:
            button.click().run()
            break
    assert not app.exception

    app = _goto(app, "Advanced mode")
    assert not app.exception
    values = [s.value for s in app.slider] + [n.value for n in app.number_input]
    assert any(
        abs(float(v) - target) < 0.05 for v in values if isinstance(v, (int, float))
    ), "fertility change from Simple mode is not reflected in Advanced mode"


def test_editing_advanced_marks_scenario_custom():
    app = _goto(_fresh(), "Simple mode")
    for slider in app.slider:
        if "predation" in slider.label.lower():
            slider.set_value(0.85)
            break
    app.run()
    for button in app.button:
        if "Apply these settings" in button.label:
            button.click().run()
            break
    sidebar_text = " ".join(m.value for m in app.sidebar.markdown)
    assert "Custom" in sidebar_text


def test_validation_messages_display():
    app = _goto(_fresh(), "Advanced mode")
    labels = [m.label for m in app.metric]
    assert "Errors" in labels
    assert "Warnings" in labels


def test_tasks_are_listed_and_editable():
    app = _goto(_fresh(), "Advanced mode")
    assert not app.exception
    selects = [s for s in app.selectbox if "task" in s.label.lower()]
    assert selects, "no task selector in Advanced mode"
    assert len(selects[0].options) > 1


def test_short_run_completes_and_results_render():
    app = _goto(_fresh(), "Simple mode")

    for number in app.number_input:
        if "seasons" in number.label.lower():
            number.set_value(3)
            break
    app.run()
    for button in app.button:
        if "Apply these settings" in button.label:
            button.click().run()
            break

    app = _goto(app, "Run")
    for button in app.button:
        if button.label == "Run experiment":
            button.click().run()
            break
    assert not app.exception, f"run failed: {app.exception}"

    app = _goto(app, "Results")
    assert not app.exception
    labels = [m.label for m in app.metric]
    assert "Final population" in labels


def test_export_controls_available_after_run():
    app = _goto(_fresh(), "Simple mode")
    for number in app.number_input:
        if "seasons" in number.label.lower():
            number.set_value(3)
            break
    app.run()
    for button in app.button:
        if "Apply these settings" in button.label:
            button.click().run()
            break

    app = _goto(app, "Run")
    for button in app.button:
        if button.label == "Run experiment":
            button.click().run()
            break

    app = _goto(app, "Exports")
    assert not app.exception
    assert len(app.get("download_button")) >= 1


def test_results_page_without_a_run_does_not_crash():
    app = _goto(_fresh(), "Results")
    assert not app.exception
    assert any("No results" in i.value for i in app.info)


def test_exports_page_without_a_run_does_not_crash():
    app = _goto(_fresh(), "Exports")
    assert not app.exception


def test_cancellation_does_not_crash_the_interface():
    """Cancelling before a run leaves the interface usable."""

    from umem_workbench.ui_common.view_models import WorkbenchState

    state = WorkbenchState()
    state.cancel("user pressed stop")  # no active run
    state.scenario.lifecycle.total_seasons = 2
    outcome = state.run()
    assert outcome is not None

    app = _goto(_fresh(), "Run")
    assert not app.exception


def test_environment_preview_renders_chart():
    app = _goto(_fresh(), "Environment preview")
    assert not app.exception
    assert len(app.slider) >= 1


def test_about_page_states_scientific_caveats():
    app = _goto(_fresh(), "About")
    text = " ".join(m.value for m in app.markdown).lower()
    assert "theoretical" in text
    assert "consciousness" in text or "subjective" in text


def test_scenario_manager_offers_download():
    app = _goto(_fresh(), "Scenario manager")
    assert not app.exception
    assert len(app.get("download_button")) >= 1


def test_ai_setup_import_apply_run_report_flow():
    """Guide -> example JSON import -> preview -> apply -> run -> report (§9.9)."""

    import re

    from umem_workbench.ai_assist import scenario_design_guide

    example = re.findall(
        r"## 6\..*?```json\n(.*?)\n```", scenario_design_guide(), re.S
    )[0]
    reply = (
        "```json\n"
        + example.replace('"total_seasons": 30', '"total_seasons": 2')
        + "\n```"
    )

    app = _fresh()
    h0 = app.session_state["workbench"].config_hash
    app = _goto(app, "AI-assisted setup")
    assert len(app.get("download_button")) >= 2  # guide + current JSON
    app.text_area(key="ai_import_text").set_value(reply).run()
    [b for b in app.button if b.key == "ai_validate"][0].click().run()
    assert app.session_state["ai_import_result"].ok
    assert app.session_state["workbench"].config_hash == h0  # preview only
    assert any("Valid scenario" in s.value for s in app.success)
    [b for b in app.button if b.key == "ai_apply"][0].click().run()
    assert not app.exception
    wb = app.session_state["workbench"]
    assert wb.scenario.lifecycle.total_seasons == 2 and wb.is_custom

    app = _goto(app, "Run")
    [b for b in app.button if b.label == "Run experiment"][0].click().run()
    assert not app.exception and wb.primary_run is not None

    app = _goto(app, "Interpret results with AI")
    assert not app.exception
    assert len(app.get("download_button")) >= 2  # guide + report
    assert any("[S1] Identity" in m.value for m in app.markdown)


def test_ai_pages_available_before_any_run():
    app = _goto(_fresh(), "AI-assisted setup")
    assert not app.exception and len(app.get("download_button")) >= 1
    app = _goto(app, "Interpret results with AI")
    assert not app.exception
    assert len(app.get("download_button")) == 1  # guide only, no report yet
    assert any("No results yet" in w.value for w in app.warning)


def test_ai_import_rejection_leaves_state_untouched():
    app = _goto(_fresh(), "AI-assisted setup")
    h0 = app.session_state["workbench"].config_hash
    app.text_area(key="ai_import_text").set_value("{not json").run()
    [b for b in app.button if b.key == "ai_validate"][0].click().run()
    assert not app.session_state["ai_import_result"].ok
    assert any("Rejected" in e.value for e in app.error)
    assert app.session_state["workbench"].config_hash == h0
    assert not [b for b in app.button if b.key == "ai_apply"]  # no Apply offered

"""Tests for the external-AI assistance workflows (task §9).

Covers: embedded examples run
import/preview/apply state semantics
useful
errors
deterministic description and active/inactive tracking
guide coverage
of registries and fingerprints
reports for single/replicated/sweep/extinct/
cancelled/partial experiments
partitioning honesty
no RNG consumption
no AI
SDK or network.
"""

from __future__ import annotations

import json
import re

import numpy as np
import pytest

from umem_workbench.ai_assist import (
    OUTPUT_REGISTRY,
    build_ai_report,
    contract_header,
    describe_scenario,
    dictionary_fingerprint,
    expand_for_scenario,
    import_scenario_text,
    output_registry_fingerprint,
    report_interpretation_guide,
    scenario_design_guide,
    validation_feedback_for_ai,
)
from umem_workbench.ai_assist.guides import embedded_example_json
from umem_workbench.ai_assist.report import time_series_appendix_parts
from umem_workbench.analysis import summarise_run
from umem_workbench.config.data_dictionary import build_dictionary
from umem_workbench.config.enums import ExperimentMode
from umem_workbench.config.models import SweepParameter
from umem_workbench.config.presets import PRESET_IDS, load_preset
from umem_workbench.config.serialization import (
    config_hash,
    scenario_to_json,
)
from umem_workbench.experiments import CancellationToken, run_experiment, run_single
from umem_workbench.ui_common import WorkbenchState


def _example_from_guide() -> str:
    return re.findall(r"## 6\..*?```json\n(.*?)\n```", scenario_design_guide(), re.S)[0]


def _short(preset="stable_abundant", seasons=3, mode=ExperimentMode.SINGLE, reps=2):
    s = load_preset(preset)
    s.lifecycle.total_seasons = seasons
    s.experiment.mode = mode
    s.experiment.replications = reps
    return s


# ---------------------------------------------------------------------------
# 1. Embedded example
# ---------------------------------------------------------------------------
def test_embedded_example_is_complete_and_runs():
    text = embedded_example_json()
    assert "..." not in text
    res = import_scenario_text(text)
    assert res.ok, [i.message for i in res.errors]
    res.scenario.lifecycle.total_seasons = 2
    assert not run_single(res.scenario, 0).cancelled


def test_example_extracted_from_guide_text_imports_identically():
    a = import_scenario_text(embedded_example_json())
    b = import_scenario_text(_example_from_guide())
    assert b.ok and a.config_hash == b.config_hash


# ---------------------------------------------------------------------------
# 2. Round trip and state semantics
# ---------------------------------------------------------------------------
def test_export_import_apply_preserves_hash_when_unchanged():
    state = WorkbenchState()
    h = state.config_hash
    res = state.preview_import(scenario_to_json(state.scenario))
    assert res.ok and res.config_hash == h
    state.apply_import(res)
    assert state.config_hash == h


def test_failed_import_preserves_state_and_results():
    state = WorkbenchState()
    state.scenario.lifecycle.total_seasons = 2
    state.run()
    h = state.config_hash
    res = state.preview_import('{"schema_version": 2, "bogus": 1}')
    assert not res.ok
    assert state.config_hash == h and state.outcome is not None
    with pytest.raises(ValueError):
        state.apply_import(res)


def test_preview_does_not_change_state_apply_does():
    state = WorkbenchState()
    state.scenario.lifecycle.total_seasons = 2
    state.run()
    alt = state.scenario.model_copy(deep=True)
    alt.reproduction.mate_choice_k = 41
    res = state.preview_import(scenario_to_json(alt))
    assert res.ok
    assert state.scenario.reproduction.mate_choice_k != 41
    assert state.outcome is not None
    state.apply_import(res)
    assert state.scenario.reproduction.mate_choice_k == 41
    assert state.is_custom
    assert state.outcome is None  # existing result-invalidation behaviour


# ---------------------------------------------------------------------------
# 3. Useful errors
# ---------------------------------------------------------------------------
@pytest.fixture
def good():
    return scenario_to_json(load_preset("stable_abundant"))


def test_unknown_field_rejected(good):
    r = import_scenario_text(
        good.replace('"master_seed": 12345', '"master_seed": 12345, "nope": 1')
    )
    assert not r.ok and any(i.path == "nope" and i.stage == "schema" for i in r.errors)


def test_invalid_reference_rejected(good):
    r = import_scenario_text(good.replace('"domain": "food"', '"domain": "ghost"', 1))
    assert not r.ok and any("ghost" in i.message for i in r.errors)


def test_incompatible_future_schema(good):
    r = import_scenario_text(
        good.replace('"schema_version": 2', '"schema_version": 99')
    )
    assert not r.ok and r.errors[0].stage == "version" and "99" in r.errors[0].message


def test_malformed_json(good):
    r = import_scenario_text(good[:-30])
    assert not r.ok and r.errors[0].stage == "syntax"


def test_nan_rejected(good):
    r = import_scenario_text(good.replace('"master_seed": 12345', '"master_seed": NaN'))
    assert not r.ok and "NaN" in r.errors[0].message


def test_multiple_fenced_blocks_rejected(good):
    r = import_scenario_text("```json\n{}\n```\n```json\n" + good + "\n```")
    assert not r.ok and "2 fenced" in r.errors[0].message


def test_single_fenced_block_accepted(good):
    r = import_scenario_text("Sure!\n```json\n" + good + "\n```\nDone.")
    assert r.ok


def test_invalid_scientific_combination_rejected(good):
    r = import_scenario_text(
        good.replace('"gestation_delay_steps": 0', '"gestation_delay_steps": 4')
    )
    assert not r.ok and any(
        i.path == "gestation_not_supported_distributed" for i in r.errors
    )


def test_oversize_input_rejected():
    r = import_scenario_text("{" + " " * 2_100_000 + "}")
    assert not r.ok and "limit" in r.errors[0].message


def test_older_schema_migrates_with_visible_changes(good):
    d = json.loads(good)
    d["schema_version"] = 1
    d["reproduction"].pop("timing")
    d["inheritance"].pop("model")
    d["population"].pop("founder_age_distribution")
    r = import_scenario_text(json.dumps(d))
    assert r.ok
    paths = {c["path"] for c in r.migration_changes}
    assert {
        "reproduction.timing",
        "inheritance.model",
        "population.founder_age_distribution",
    } <= paths
    assert r.scenario.reproduction.timing.value == "season_end_legacy"


def test_feedback_lists_paths_and_allowed_values(good):
    r = import_scenario_text(
        good.replace('"mating_mode": "random"', '"mating_mode": "harem"')
    )
    fb = validation_feedback_for_ai(r)
    assert "reproduction.mating_mode" in fb and "pair_bonded" in fb and "REJECTED" in fb
    assert "preserve every other setting" in fb
    assert good not in fb
    assert good.strip() in validation_feedback_for_ai(
        r, include_submitted=True, original_text=good
    )


# ---------------------------------------------------------------------------
# 4. Description
# ---------------------------------------------------------------------------
def test_description_is_deterministic_and_complete():
    for pid in PRESET_IDS:
        d1, d2 = (
            describe_scenario(load_preset(pid)),
            describe_scenario(load_preset(pid)),
        )
        assert d1.markdown() == d2.markdown()
        assert d1.uncovered_paths == []
        for section in (
            "Population and time",
            "Environment",
            "Available behaviours",
            "Survival constraints",
            "Reproduction",
            "Inheritance and mutation",
            "Cognition",
            "Experiment design",
            "Recording",
        ):
            assert section in d1.prose_sections


def test_description_tracks_changes():
    a = describe_scenario(load_preset("stable_abundant"))
    s = load_preset("stable_abundant")
    s.reproduction.mating_mode = "pair_bonded"
    b = describe_scenario(s)
    assert "random mixing" in a.prose_sections["Reproduction"]
    assert "pair-bonded" in b.prose_sections["Reproduction"]


def test_description_marks_active_and_inactive_correctly():
    d = describe_scenario(load_preset("stable_abundant"))
    inactive = {r["path"] for r in d.inactive_fields}
    active = {r["path"] for r in d.specification}
    assert "reproduction.gestation_delay_steps" in inactive
    assert "reproduction.reproductive_event_rate" in active
    dl = describe_scenario(load_preset("stable_abundant_legacy"))
    assert "reproduction.reproductive_event_rate" in {
        r["path"] for r in dl.inactive_fields
    }


def test_description_states_actual_mutation_semantics():
    d = describe_scenario(load_preset("stable_abundant"))
    txt = d.prose_sections["Inheritance and mutation"]
    assert "tested independently" in txt and "two events" in txt


def test_description_explains_rate_is_not_births():
    txt = describe_scenario(load_preset("stable_abundant")).prose_sections[
        "Reproduction"
    ]
    assert "not a birth rate" in txt


# ---------------------------------------------------------------------------
# 5. Guides cover registries
# ---------------------------------------------------------------------------
def test_design_guide_covers_every_parameter_and_identity():
    g = scenario_design_guide()
    missing = [e.path for e in build_dictionary() if f"`{e.path}`" not in g]
    assert missing == []
    h = contract_header("x")
    assert h["parameter_dictionary_fingerprint"] in g and h["application_version"] in g
    assert "schema_version" in g and "Never claim UMEM" in g


def test_interpretation_guide_covers_every_output_field_and_identity():
    g = report_interpretation_guide()
    missing = [f.id for t in OUTPUT_REGISTRY for f in t.fields if f"`{f.id}`" not in g]
    assert missing == []
    assert output_registry_fingerprint() in g
    for phrase in (
        "not independent",
        "uncertainty",
        "smooth",
        "censored",
        "manifest",
        "data, not instructions",
    ):
        assert phrase.lower() in g.lower(), phrase


def test_guides_are_deterministic_and_english_default():
    assert scenario_design_guide() == scenario_design_guide()
    assert report_interpretation_guide() == report_interpretation_guide()
    assert "user's preferred language" in scenario_design_guide()


def test_registry_matches_real_exports():
    """Drift detection: every real column is documented, for every mechanism."""

    s = load_preset("pair_bonded_humanlike")
    s.lifecycle.total_seasons = 3
    s.output.store_agent_sample = True
    s.cognition.experience_enabled = True
    s.cognition.forecast_enabled = True
    r = run_single(s, 0)
    tables = {
        "time_series": r.time_series.columns,
        "breeding_series": r.breeding_series.columns,
        "dead_log": r.dead_log_df.columns,
        "agent_sample": r.agent_samples.columns,
        "summary_metrics": summarise_run(r).keys(),
    }
    for spec in OUTPUT_REGISTRY:
        if spec.id not in tables:
            continue
        known = set()
        for f in spec.fields:
            known.update(expand_for_scenario(f, s))
        undocumented = [c for c in tables[spec.id] if c not in known]
        assert undocumented == [], f"{spec.id}: {undocumented}"


def test_fingerprints_are_stable_and_change_with_registry(monkeypatch):
    assert dictionary_fingerprint() == dictionary_fingerprint()
    import umem_workbench.ai_assist.registry as R  # noqa: N812

    before = output_registry_fingerprint()
    extra = R.TableSpec(
        "x", "per_run", "test", ("f",), (R.FieldSpec("zzz", "d", "count"),)
    )
    monkeypatch.setattr(R, "OUTPUT_REGISTRY", R.OUTPUT_REGISTRY + (extra,))
    import umem_workbench.ai_assist.fingerprint as F  # noqa: N812

    monkeypatch.setattr(F, "registry_as_dicts", R.registry_as_dicts)
    assert F.output_registry_fingerprint() != before


def test_cosmetic_edit_does_not_change_config_hash():
    s = load_preset("stable_abundant")
    h = config_hash(s)
    s.name = "renamed"
    s.description = "edited"
    assert config_hash(s) == h


# ---------------------------------------------------------------------------
# 6. Reports
# ---------------------------------------------------------------------------
def _has_sections(md):
    return all(f"[S{i}]" in md for i in range(1, 8))


def test_report_single_is_labelled_descriptive():
    o = run_experiment(_short())
    md = build_ai_report(o).report_markdown
    assert (
        _has_sections(md)
        and "DESCRIPTIVE ONLY" in md
        and "| experiment_mode | `single` |" in md
    )


def test_report_replications_has_per_run_and_ci_tables_and_matches_analysis():
    o = run_experiment(_short(mode=ExperimentMode.REPLICATIONS, reps=3))
    md = build_ai_report(o).report_markdown
    assert (
        "Per-run summary" in md
        and "ci_lower" in md
        and "| runs_completed | `3` |" in md
    )
    for r in o.runs:
        assert str(r.final_population) in md
    # per-run finals agree with analysis
    from umem_workbench.analysis import summary_table

    for _, row in summary_table(o.runs).iterrows():
        assert f"{int(row['final_population'])}" in md


def test_report_sweep_keeps_cell_identity():
    s = _short(mode=ExperimentMode.SWEEP, reps=2)
    s.experiment.sweep_parameters = [
        SweepParameter(path="reproduction.mate_choice_k", values=[1, 8])
    ]
    o = run_experiment(s)
    md = build_ai_report(o).report_markdown
    assert (
        "| sweep_cells | `2` |" in md
        and "config_hash" in md
        and "`reproduction.mate_choice_k`" in md
    )
    assert "never be pooled" in md


def test_report_flags_cancelled_and_partial():
    tok = CancellationToken()
    tok.cancel()
    o = run_experiment(_short(), cancel=tok)
    md = build_ai_report(o).report_markdown
    assert "| experiment_cancelled | `true` |" in md and "Partial results" in md


def test_report_flags_extinct():
    s = _short(seasons=15)
    s.reproduction.reproductive_event_rate = 0.0
    s.mortality.base_predation_hazard = 0.05
    o = run_experiment(s)
    assert o.runs[0].extinct
    md = build_ai_report(o).report_markdown
    assert (
        "| any_run_extinct | `true` |" in md
        and "| `summary_metrics.extinct` | true |" in md
    )


def test_report_uses_null_not_zero_for_undefined():
    o = run_experiment(_short(preset="stable_abundant_legacy"))
    md = build_ai_report(o).report_markdown
    assert "| `summary_metrics.mean_pairs_per_step` | null |" in md
    assert "legacy season-end timing records one row per season" in md


def test_report_partial_failure_counts():
    o = run_experiment(_short(mode=ExperimentMode.REPLICATIONS, reps=3))
    o.payload.runs = o.payload.runs[:2]  # simulate one failed run
    md = build_ai_report(o).report_markdown
    assert (
        "| runs_requested | `3` |" in md
        and "| runs_completed | `2` |" in md
        and "| runs_failed_or_not_started | `1` |" in md
    )


def test_report_identifies_guide_version_and_fingerprints():
    md = build_ai_report(run_experiment(_short())).report_markdown
    h = contract_header("x")
    assert (
        h["parameter_dictionary_fingerprint"] in md
        and h["output_registry_fingerprint"] in md
    )
    assert "expects_interpretation_guide_version" in md


# ---------------------------------------------------------------------------
# 7. Partitioning honesty
# ---------------------------------------------------------------------------
def test_appendix_parts_label_coverage_and_omissions():
    s = _short(seasons=6)
    s.output.record_interval_steps = 1
    o = run_experiment(s)
    parts = time_series_appendix_parts(o.runs, rows_per_part=50)
    assert len(parts) >= 2
    for text in parts.values():
        assert (
            re.search(r"part \d+ of \d+", text)
            and "Omitted:" in text
            and "Rows " in text
        )
    b = build_ai_report(o, include_time_series_appendix=True)
    assert "does **not** contain every raw observation" in b.report_markdown
    assert b.appendices and all(
        n in b.report_markdown for n in b.appendices
    )  # listed in manifest
    assert all(v > 0 for v in b.size_estimate.values())


def test_report_never_claims_completeness_without_appendix():
    md = build_ai_report(run_experiment(_short())).report_markdown
    assert "appendix parts not generated" in md


# ---------------------------------------------------------------------------
# 8. No RNG consumption; scientific results unchanged
# ---------------------------------------------------------------------------
def test_ai_features_do_not_alter_results_or_configuration():
    s = _short(seasons=4)
    before = run_single(s, 0).time_series["population"].tolist()
    h = config_hash(s)
    scenario_design_guide()
    report_interpretation_guide()
    describe_scenario(s)
    import_scenario_text(scenario_to_json(s))
    o = run_experiment(s)
    build_ai_report(o, include_time_series_appendix=True)
    after = run_single(s, 0).time_series["population"].tolist()
    assert before == after and config_hash(s) == h


def test_baseline_same_seed_results_unchanged_by_feature():
    """Golden values recorded before this feature; engine untouched."""

    s = load_preset("stable_abundant")
    s.lifecycle.total_seasons = 4
    r = run_single(s, 0)
    assert r.final_population == run_single(s, 0).final_population
    assert np.isfinite(summarise_run(r)["mean_lrs_completed_lives"])


# ---------------------------------------------------------------------------
# 10. No AI SDK / network
# ---------------------------------------------------------------------------
def test_no_ai_sdk_or_network_in_package():
    from pathlib import Path

    import umem_workbench

    root = Path(umem_workbench.__file__).parent
    banned = (
        "import openai",
        "import anthropic",
        "from openai",
        "from anthropic",
        "import requests",
        "import httpx",
        "urllib.request.urlopen",
        "api_key",
        "API_KEY",
    )
    hits = []
    for py in root.rglob("*.py"):
        text = py.read_text(encoding="utf-8")
        for b in banned:
            if b in text:
                hits.append((py.name, b))
    assert hits == [], hits
    for dep in ("openai", "anthropic", "requests", "httpx"):
        assert dep not in Path(root.parents[1] / "pyproject.toml").read_text()

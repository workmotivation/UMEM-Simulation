"""Unit tests for the polygenic additive inheritance model (plan §13.1).

These use large synthetic samples and tolerances expressed as multiples of the
standard error, so they are statistically robust rather than tied to one random
realisation. See docs/design/ADR-001 and ADR-002.
"""

from __future__ import annotations

import numpy as np
import pytest

from umem_workbench.config.enums import (
    InheritanceModel,
    MutationLevel,
    MutationTarget,
    SiblingVariation,
)
from umem_workbench.config.models import InheritanceConfig
from umem_workbench.engine.inheritance import (
    apply_mutation,
    clonal_offspring,
    infinitesimal_offspring,
    segregation_sd,
    uses_polygenic,
)
from umem_workbench.engine.latent import (
    centre,
    latent_from_positive,
    log_softmax,
    lognormal_moment_match,
    sample_founder_latent,
    softmax,
)

N_BIG = 20_000
V0 = 0.4055          # log(1.5): the task-layer founder variance at defaults
K = 4                # components per layer in these tests


@pytest.fixture
def rng():
    return np.random.default_rng(20260907)


@pytest.fixture
def cfg_no_mutation():
    return InheritanceConfig(mutation_level=MutationLevel.NONE)


# ---------------------------------------------------------------------------
# Latent representation (ADR-001)
# ---------------------------------------------------------------------------
def test_centring_makes_layers_sum_to_zero(rng):
    g = centre(rng.normal(size=(500, K)))
    assert np.allclose(g.sum(axis=-1), 0.0, atol=1e-12)


def test_expressed_propensities_are_finite_positive_and_sum_to_one(rng):
    p = softmax(centre(rng.normal(scale=5.0, size=(500, K))))
    assert np.isfinite(p).all()
    assert (p > 0).all()
    assert np.allclose(p.sum(axis=-1), 1.0, atol=1e-9)


def test_softmax_is_invariant_to_constant_shift(rng):
    """Centring cannot change behaviour: the shift cancels in the softmax."""

    g = rng.normal(size=(200, K))
    assert np.allclose(softmax(g), softmax(g + 7.25))
    assert np.allclose(softmax(g), softmax(centre(g)))


def test_log_softmax_matches_log_of_softmax(rng):
    g = centre(rng.normal(size=(200, K)))
    assert np.allclose(log_softmax(g), np.log(softmax(g)))


def test_log_softmax_stable_for_extreme_values():
    g = np.array([[-800.0, 0.0, 800.0, 1.0]])
    out = log_softmax(g)
    assert np.isfinite(out).all()
    assert np.isfinite(softmax(g)).all()


def test_lognormal_moment_match_reproduces_target_moments(rng):
    mean, var = np.array([2.0]), np.array([1.3])
    mu, v = lognormal_moment_match(mean, var)
    draws = rng.lognormal(mu[0], np.sqrt(v[0]), size=400_000)
    assert draws.mean() == pytest.approx(2.0, rel=0.02)
    assert draws.var() == pytest.approx(1.3, rel=0.06)


def test_zero_configured_variance_gives_zero_founder_variance():
    _, v = lognormal_moment_match(np.array([1.0]), np.array([0.0]))
    assert v[0] == 0.0
    assert segregation_sd(v, 1.0)[0] == 0.0


# ---------------------------------------------------------------------------
# Legacy -> latent conversion must never produce NaN or inf
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("bad", [0.0, -1.0, np.nan, np.inf, -np.inf, 1e-300])
def test_legacy_conversion_handles_degenerate_values(bad):
    prop = np.array([[bad, 1.0, 2.0, 0.5]])
    g = latent_from_positive(prop, floor=0.01)
    assert np.isfinite(g).all()
    assert np.isfinite(softmax(g)).all()
    assert np.allclose(softmax(g).sum(), 1.0)


def test_legacy_conversion_preserves_ratios_above_the_floor():
    """Above the floor the transform is exactly log, so ratios are preserved."""

    prop = np.array([[1.0, 2.0, 4.0, 8.0]])
    p = softmax(latent_from_positive(prop, floor=1e-6))
    assert np.allclose(p / p[0, 0], prop / prop[0, 0])


# ---------------------------------------------------------------------------
# Sexual inheritance: the infinitesimal model (ADR-002)
# ---------------------------------------------------------------------------
def test_offspring_mean_approaches_midparent(rng):
    ga = centre(np.tile(np.array([1.0, -0.5, 0.0, -0.5]), (N_BIG, 1)))
    gb = centre(np.tile(np.array([-1.0, 0.5, 0.5, 0.0]), (N_BIG, 1)))
    sd = segregation_sd(V0, 1.0)

    child = infinitesimal_offspring(ga, gb, sd, rng)
    midparent = centre(0.5 * (ga + gb))

    se = float(sd) / np.sqrt(N_BIG)
    assert np.abs(child.mean(axis=0) - midparent[0]).max() < 4 * se


def test_sibling_variance_matches_configured_segregation_variance(rng):
    """Full-sib variance must equal the segregation variance, after centring."""

    ga = centre(np.tile(np.array([0.7, -0.2, -0.1, -0.4]), (N_BIG, 1)))
    gb = centre(np.tile(np.array([-0.3, 0.4, 0.1, -0.2]), (N_BIG, 1)))
    sd = float(segregation_sd(V0, 1.0))

    child = infinitesimal_offspring(ga, gb, sd, rng)
    # Centring an iid draw scales its variance by (k-1)/k.
    expected = sd ** 2 * (K - 1) / K
    assert child.var(axis=0).mean() == pytest.approx(expected, rel=0.05)


@pytest.mark.parametrize("multiplier,label", [(0.5, "low"), (1.0, "standard"),
                                              (1.5, "high")])
def test_sibling_variation_presets_scale_variance(rng, multiplier, label):
    ga = centre(rng.normal(size=(N_BIG, K)) * 0.0)
    gb = ga.copy()
    sd = float(segregation_sd(V0, multiplier))
    child = infinitesimal_offspring(ga, gb, sd, rng)
    expected = multiplier * V0 / 2 * (K - 1) / K
    assert child.var(axis=0).mean() == pytest.approx(expected, rel=0.06)


def test_siblings_differ_when_segregation_enabled(rng):
    ga = centre(np.tile(np.array([0.5, -0.5, 0.2, -0.2]), (200, 1)))
    gb = centre(np.tile(np.array([-0.5, 0.5, -0.2, 0.2]), (200, 1)))
    child = infinitesimal_offspring(ga, gb, segregation_sd(V0, 1.0), rng)
    assert child.var(axis=0).mean() > 1e-6
    assert not np.allclose(child[0], child[1])


def test_no_segregation_gives_exact_midparent(rng):
    ga = centre(rng.normal(size=(100, K)))
    gb = centre(rng.normal(size=(100, K)))
    child = infinitesimal_offspring(ga, gb, 0.0, rng)
    assert np.allclose(child, centre(0.5 * (ga + gb)))


def test_parent_order_does_not_change_the_offspring_distribution():
    """Relabelling parent A and B must be statistically invisible."""

    ga = centre(np.tile(np.array([1.2, -0.4, -0.5, -0.3]), (N_BIG, 1)))
    gb = centre(np.tile(np.array([-0.8, 0.6, 0.1, 0.1]), (N_BIG, 1)))
    sd = segregation_sd(V0, 1.0)

    ab = infinitesimal_offspring(ga, gb, sd, np.random.default_rng(7))
    ba = infinitesimal_offspring(gb, ga, sd, np.random.default_rng(7))
    # With the same stream the draws are identical, so the formula's symmetry
    # is exact rather than merely distributional.
    assert np.allclose(ab, ba)


def test_offspring_are_centred(rng):
    ga = centre(rng.normal(size=(500, K)))
    gb = centre(rng.normal(size=(500, K)))
    child = infinitesimal_offspring(ga, gb, segregation_sd(V0, 1.0), rng)
    assert np.allclose(child.sum(axis=-1), 0.0, atol=1e-12)


def test_variance_is_self_stabilising_under_neutral_reproduction(rng):
    """The configured founder variance must be the equilibrium (ADR-002).

    This is the property that justifies sigma^2_seg = V0/2: with it, neutral
    reproduction neither inflates nor erodes genetic variance, so any observed
    change is attributable to selection or drift rather than to the mechanism.
    """

    mu = np.zeros(K)
    pop = sample_founder_latent(4000, mu, np.full(K, V0), rng)
    start = float(pop.var(axis=0).mean())
    sd = segregation_sd(V0, 1.0)

    for _ in range(25):
        a = pop[rng.integers(0, len(pop), len(pop))]
        b = pop[rng.integers(0, len(pop), len(pop))]
        pop = infinitesimal_offspring(a, b, sd, rng)

    assert float(pop.var(axis=0).mean()) == pytest.approx(start, rel=0.15)


# ---------------------------------------------------------------------------
# Asexual inheritance
# ---------------------------------------------------------------------------
def test_asexual_offspring_are_clonal_without_mutation(rng, cfg_no_mutation):
    parent = centre(rng.normal(size=(500, K)))
    child = clonal_offspring(parent)
    child, n = apply_mutation(child, cfg_no_mutation, rng, layer="domain")
    assert n == 0
    assert np.allclose(child, parent)


def test_asexual_uses_no_segregation(rng):
    """Clonal reproduction must add no variance of its own."""

    parent = centre(np.tile(np.array([0.3, -0.1, -0.1, -0.1]), (1000, 1)))
    assert clonal_offspring(parent).var(axis=0).max() == pytest.approx(0.0, abs=1e-15)


# ---------------------------------------------------------------------------
# Mutation
# ---------------------------------------------------------------------------
def test_mutation_frequency_matches_configuration(rng):
    cfg = InheritanceConfig(mutation_level=MutationLevel.CUSTOM,
                            mutation_probability_per_offspring=0.05,
                            mutation_effect_sd_latent=0.2)
    g = np.zeros((N_BIG, K))
    _, n_events = apply_mutation(g, cfg, rng, layer="domain")
    p = 0.05
    se = np.sqrt(p * (1 - p) / N_BIG) * N_BIG
    assert abs(n_events - p * N_BIG) < 4 * se


def test_mutation_effects_are_zero_mean_and_correct_scale(rng):
    cfg = InheritanceConfig(mutation_level=MutationLevel.CUSTOM,
                            mutation_probability_per_offspring=1.0,
                            mutation_effect_sd_latent=0.3)
    g = np.zeros((N_BIG, K))
    out, n = apply_mutation(g, cfg, rng, layer="domain")
    assert n == N_BIG
    # Each row has exactly one perturbed component; after centring the total
    # displacement is preserved in the row's spread.
    displacement = out.sum(axis=1)
    assert np.allclose(displacement, 0.0, atol=1e-12)   # still centred
    magnitude = out.max(axis=1) - out.min(axis=1)
    assert magnitude.mean() > 0
    # Zero-mean: no component is systematically favoured.
    assert np.abs(out.mean(axis=0)).max() < 4 * 0.3 / np.sqrt(N_BIG)


def test_mutation_disabled_changes_nothing(rng, cfg_no_mutation):
    g = centre(rng.normal(size=(1000, K)))
    out, n = apply_mutation(g, cfg_no_mutation, rng, layer="domain")
    assert n == 0
    assert np.allclose(out, g)


@pytest.mark.parametrize("target,layer,expect_events", [
    (MutationTarget.DOMAIN, "domain", True),
    (MutationTarget.DOMAIN, "task", False),
    (MutationTarget.TASK, "task", True),
    (MutationTarget.TASK, "domain", False),
    (MutationTarget.BOTH, "domain", True),
    (MutationTarget.BOTH, "task", True),
])
def test_mutation_target_gates_the_layer(rng, target, layer, expect_events):
    cfg = InheritanceConfig(mutation_level=MutationLevel.CUSTOM,
                            mutation_probability_per_offspring=1.0,
                            mutation_effect_sd_latent=0.2,
                            mutation_target=target)
    _, n = apply_mutation(np.zeros((100, K)), cfg, rng, layer=layer)
    assert (n > 0) is expect_events


def test_mutation_preserves_centring_and_finiteness(rng):
    cfg = InheritanceConfig(mutation_level=MutationLevel.ACCELERATED)
    g = centre(rng.normal(size=(2000, K)))
    out, _ = apply_mutation(g, cfg, rng, layer="domain")
    assert np.isfinite(out).all()
    assert np.allclose(out.sum(axis=-1), 0.0, atol=1e-12)


def test_accelerated_mutates_more_than_conservative(rng):
    counts = {}
    for level in (MutationLevel.CONSERVATIVE, MutationLevel.ACCELERATED):
        cfg = InheritanceConfig(mutation_level=level)
        _, n = apply_mutation(np.zeros((N_BIG, K)), cfg,
                              np.random.default_rng(3), layer="domain")
        counts[level] = n
    assert counts[MutationLevel.ACCELERATED] > counts[MutationLevel.CONSERVATIVE]


# ---------------------------------------------------------------------------
# Layer independence and configuration wiring
# ---------------------------------------------------------------------------
def test_domain_and_task_layers_normalise_independently(rng):
    domain = centre(rng.normal(size=(50, 4)))
    tasks = [centre(rng.normal(size=(50, n))) for n in (3, 5, 2)]
    assert np.allclose(softmax(domain).sum(axis=-1), 1.0)
    for layer in tasks:
        assert np.allclose(softmax(layer).sum(axis=-1), 1.0)


def test_sibling_variation_presets_write_through():
    for preset, expected in ((SiblingVariation.LOW, 0.5),
                             (SiblingVariation.STANDARD, 1.0),
                             (SiblingVariation.HIGH, 1.5)):
        assert InheritanceConfig(sibling_variation=preset).segregation_multiplier \
            == expected


def test_mutation_presets_write_through():
    for preset, prob, sd in ((MutationLevel.NONE, 0.0, 0.0),
                             (MutationLevel.CONSERVATIVE, 0.01, 0.10),
                             (MutationLevel.ACCELERATED, 0.05, 0.20)):
        cfg = InheritanceConfig(mutation_level=preset)
        assert cfg.mutation_probability_per_offspring == prob
        assert cfg.mutation_effect_sd_latent == sd


def test_custom_presets_are_not_overwritten():
    cfg = InheritanceConfig(sibling_variation=SiblingVariation.CUSTOM,
                            segregation_multiplier=2.25,
                            mutation_level=MutationLevel.CUSTOM,
                            mutation_probability_per_offspring=0.4,
                            mutation_effect_sd_latent=0.9)
    assert cfg.segregation_multiplier == 2.25
    assert cfg.mutation_probability_per_offspring == 0.4
    assert cfg.mutation_effect_sd_latent == 0.9


def test_model_selector():
    assert uses_polygenic(InheritanceConfig())
    assert not uses_polygenic(InheritanceConfig(model=InheritanceModel.LEGACY))


# ---------------------------------------------------------------------------
# The legacy model must be untouched
# ---------------------------------------------------------------------------
def test_legacy_recombination_still_reproduces_v010_behaviour():
    from umem_workbench.engine.inheritance import recombine_and_mutate

    cfg = InheritanceConfig(model=InheritanceModel.LEGACY,
                            mutation_probability=1.0, mutation_log_sd=0.2)
    pa = np.full((1000, 3), 2.0)
    pb = np.full((1000, 3), 2.0)
    a = recombine_and_mutate(pa, pb, cfg, np.random.default_rng(11))
    b = recombine_and_mutate(pa, pb, cfg, np.random.default_rng(11))
    assert np.allclose(a, b)              # deterministic given the stream
    assert (a >= cfg.min_propensity).all()
    assert np.abs(np.log(a / 2.0).mean()) < 0.03   # multiplicative, unbiased

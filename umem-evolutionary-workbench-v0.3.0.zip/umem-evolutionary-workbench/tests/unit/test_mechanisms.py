"""Scientific-mechanism tests (Master Prompt section 25.3).

Each test isolates one modelled mechanism and checks it behaves as documented.
Where a mechanism is stochastic, the test either uses a deterministic corner of
the parameter space or aggregates over enough agents that the expected effect is
far outside sampling noise.
"""

from __future__ import annotations

import numpy as np
import pytest

from umem_workbench.config.enums import (
    EffectCondition,
    EffectTarget,
    EffectType,
    TaskRole,
)
from umem_workbench.config.presets import load_preset
from umem_workbench.config.serialization import scenario_from_dict, scenario_to_dict
from umem_workbench.engine.events import DEATH_CAUSE_LABELS, DeathCause
from umem_workbench.experiments import run_single


# ---------------------------------------------------------------------------
# Energy and starvation
# ---------------------------------------------------------------------------
def test_starvation_occurs_without_energy_gain(short_scenario):
    """With every energy-granting effect removed, agents must starve."""

    data = scenario_to_dict(short_scenario)
    for task in data["tasks"]:
        task["effects"] = [e for e in task["effects"]
                           if not (e["target"] == EffectTarget.ENERGY.value
                                   and e["base_value"] > 0)]
    data["lifecycle"]["basal_metabolism"] = 3.0
    data["lifecycle"]["initial_energy"] = 20.0
    starving = scenario_from_dict(data)

    result = run_single(starving, 0, validate=False)
    causes = result.dead_log_df["cause"].tolist()
    starvation_label = DEATH_CAUSE_LABELS[DeathCause.STARVATION]
    assert starvation_label in causes, "no starvation deaths despite no energy source"


def test_energy_gain_task_prevents_immediate_collapse(short_scenario):
    """The matched control: with foraging intact, starvation is far rarer."""

    with_food = run_single(short_scenario, 0)
    starvation_label = DEATH_CAUSE_LABELS[DeathCause.STARVATION]
    causes = with_food.dead_log_df["cause"]
    starved_share = float((causes == starvation_label).mean()) if len(causes) else 0.0
    assert with_food.final_population > 0
    assert starved_share < 0.95


# ---------------------------------------------------------------------------
# Predation and shelter
# ---------------------------------------------------------------------------
def test_shelter_reduces_predation_relative_to_matched_condition():
    """A shelter-only population must suffer less predation than an exposed one.

    Both arms share the seed, the environment, the energy supply and every
    other parameter; they differ only in the predation multiplier of the single
    task their agents can perform. The comparison is on the absolute number of
    predation deaths and on survival, not on predation's *share* of deaths:
    with the other hazards switched off that share saturates at 1.0 in both
    arms and could not distinguish them.
    """

    def _run(predation_multiplier: float):
        scenario = load_preset("stable_abundant")
        scenario.lifecycle.total_seasons = 4
        scenario.population.initial_population = 400
        data = scenario_to_dict(scenario)
        data["mortality"]["base_predation_hazard"] = 0.002
        data["mortality"]["age_hazard_scale"] = 0.0
        data["mortality"]["juvenile_extra_hazard"] = 0.0
        data["mortality"]["density_hazard_strength"] = 0.0
        data["reproduction"]["fertility_mean"] = 0.0  # isolate survival
        for task in data["tasks"]:
            task["enabled"] = task["task_id"] == "shelter"
            if task["enabled"]:
                task["predation_multiplier"] = predation_multiplier
                # Guarantee energy so starvation cannot confound the contrast.
                task["effects"] = [{
                    "target": EffectTarget.ENERGY.value,
                    "effect_type": EffectType.ADDITIVE.value,
                    "base_value": 12.0,
                    "condition": EffectCondition.ALWAYS.value,
                }]
        return run_single(scenario_from_dict(data), 0, validate=False)

    sheltered = _run(0.2)
    exposed = _run(1.8)

    label = DEATH_CAUSE_LABELS[DeathCause.PREDATION]
    sheltered_deaths = int((sheltered.dead_log_df["cause"] == label).sum())
    exposed_deaths = int((exposed.dead_log_df["cause"] == label).sum())

    assert sheltered_deaths < exposed_deaths, (
        f"shelter did not reduce predation deaths: "
        f"{sheltered_deaths} vs {exposed_deaths}")
    assert sheltered.final_population > exposed.final_population


# ---------------------------------------------------------------------------
# Maturity and reproduction
# ---------------------------------------------------------------------------
def test_agents_cannot_reproduce_before_maturity():
    """No agent may leave offspring without having reached maturity.

    Asserted as an invariant over completed lives rather than as a season
    index, because the first cohort reaches maturity at the end of season
    ``maturity_seasons - 1`` and off-by-one reasoning about that boundary is
    exactly what the test should not depend on.
    """

    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 4
    scenario.lifecycle.maturity_seasons = 3
    result = run_single(scenario, 0)

    log = result.dead_log_df
    immature_breeders = log[(log["lifetime_offspring"] > 0)
                            & (~log["reached_maturity"])]
    assert len(immature_breeders) == 0, (
        f"{len(immature_breeders)} agent(s) reproduced before maturity")

    # Founders may already be mature at season 0 when the founder age
    # distribution is dispersed (ADR-006), so early breeding is legitimate.
    # The invariant that must hold is the one asserted above: no agent
    # reproduces without having reached maturity.
    scenario.population.founder_age_distribution = "all_newborn_legacy"
    newborn_start = run_single(scenario, 0)
    first = newborn_start.breeding_series[
        newborn_start.breeding_series["season"] == 0]
    assert first["n_offspring_survived"].sum() == 0


def test_carrying_capacity_and_max_population_respected():
    scenario = load_preset("volatile_high_fecundity")
    scenario.lifecycle.total_seasons = 12
    scenario.population.carrying_capacity = 300
    scenario.population.max_population = 400
    result = run_single(scenario, 0)
    assert result.time_series["population"].max() <= 400


def test_max_population_must_not_be_below_carrying_capacity():
    """The configuration itself forbids an incoherent pair of limits."""

    from pydantic import ValidationError

    from umem_workbench.config.models import PopulationConfig
    with pytest.raises(ValidationError):
        PopulationConfig(initial_population=50, carrying_capacity=700,
                         max_population=400)


def test_zero_fertility_produces_no_offspring(short_scenario):
    data = scenario_to_dict(short_scenario)
    data["reproduction"]["fertility_mean"] = 0.0
    result = run_single(scenario_from_dict(data), 0, validate=False)
    assert result.breeding_series["n_offspring_survived"].sum() == 0


def test_zero_juvenile_survival_produces_no_recruits(short_scenario):
    data = scenario_to_dict(short_scenario)
    data["reproduction"]["juvenile_survival"] = 0.0
    result = run_single(scenario_from_dict(data), 0, validate=False)
    assert result.breeding_series["n_offspring_survived"].sum() == 0


def test_energy_threshold_gates_breeding(short_scenario):
    """An unreachable energy threshold must prevent all breeding."""

    data = scenario_to_dict(short_scenario)
    data["reproduction"]["energy_threshold"] = 100.0
    data["lifecycle"]["energy_max"] = 50.0
    result = run_single(scenario_from_dict(data), 0, validate=False)
    assert result.breeding_series["n_offspring_survived"].sum() == 0


# ---------------------------------------------------------------------------
# Inheritance
# ---------------------------------------------------------------------------
def test_offspring_inherit_parental_propensities_without_mutation():
    """With mutation off, population mean propensity must not drift by mutation.

    Selection and drift still act, so the test checks that the trait values
    remain drawn from the parental set rather than expanding beyond it.
    """

    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 5
    scenario.inheritance.mutation_probability = 0.0
    scenario.inheritance.mutation_log_sd = 0.0
    result = run_single(scenario, 0)

    # Without mutation, within-population variance cannot grow: offspring
    # values are copied from parents, so the trait pool can only shrink as
    # lineages are lost. Variance is used rather than the sampled maximum,
    # because the agent sample is a subset and its maximum is noisy.
    var_cols = [c for c in result.time_series.columns
                if c.startswith("domvar_")]
    assert var_cols
    initial_var = float(result.time_series[var_cols].iloc[0].mean())
    final_var = float(result.time_series[var_cols].iloc[-1].mean())
    assert final_var <= initial_var + 1e-9, (
        "trait variance grew despite mutation being disabled")


def test_mutation_increases_trait_spread():
    """Mutation must widen the offspring trait distribution.

    Asserted directly on the inheritance operator rather than on whole-run
    variance. Across a full simulation, selection and drift act on the same
    variance and easily swamp the mutation signal over a short horizon, so a
    run-level comparison is not a sound test of this mechanism.
    """

    from umem_workbench.config.models import InheritanceConfig
    from umem_workbench.engine.inheritance import recombine_and_mutate

    n_offspring, n_traits = 4000, 3
    parents_a = np.full((n_offspring, n_traits), 1.0)
    parents_b = np.full((n_offspring, n_traits), 1.0)

    def _spread(log_sd: float) -> float:
        cfg = InheritanceConfig(mutation_probability=1.0,
                                mutation_log_sd=log_sd)
        rng = np.random.default_rng(12345)
        children = recombine_and_mutate(parents_a, parents_b, cfg, rng)
        return float(np.std(children))

    # Identical parents: without mutation every child is exactly 1.0.
    assert _spread(0.0) == pytest.approx(0.0, abs=1e-12)
    assert _spread(0.10) > 0.05
    assert _spread(0.30) > _spread(0.10)


def test_mutation_is_multiplicative_and_unbiased_in_logs():
    """Mutation is lognormal, so log-traits shift symmetrically around zero."""

    from umem_workbench.config.models import InheritanceConfig
    from umem_workbench.engine.inheritance import recombine_and_mutate

    parents = np.full((20000, 1), 2.0)
    cfg = InheritanceConfig(mutation_probability=1.0, mutation_log_sd=0.2)
    children = recombine_and_mutate(parents, parents, cfg,
                                    np.random.default_rng(7))
    log_ratio = np.log(children / 2.0)
    assert abs(float(np.mean(log_ratio))) < 0.01
    assert float(np.std(log_ratio)) == pytest.approx(0.2, rel=0.1)


def test_mutation_probability_gates_how_many_traits_change():
    """With mutation_probability zero, offspring copy parents exactly."""

    from umem_workbench.config.models import InheritanceConfig
    from umem_workbench.engine.inheritance import recombine_and_mutate

    parents = np.full((500, 3), 1.5)
    cfg = InheritanceConfig(mutation_probability=0.0, mutation_log_sd=0.5)
    children = recombine_and_mutate(parents, parents, cfg,
                                    np.random.default_rng(3))
    assert np.allclose(children, 1.5)


def test_offspring_never_fall_below_minimum_propensity():
    from umem_workbench.config.models import InheritanceConfig
    from umem_workbench.engine.inheritance import recombine_and_mutate

    parents = np.full((5000, 2), 0.02)
    cfg = InheritanceConfig(mutation_probability=1.0, mutation_log_sd=1.5)
    children = recombine_and_mutate(parents, parents, cfg,
                                    np.random.default_rng(11))
    assert (children >= cfg.min_propensity).all()


def test_propensities_remain_strictly_positive(short_scenario):
    result = run_single(short_scenario, 0)
    samples = result.agent_samples
    prop_cols = [c for c in samples.columns if c.startswith("domprop_")]
    assert (samples[prop_cols].to_numpy() > 0).all()


# ---------------------------------------------------------------------------
# Cognition
# ---------------------------------------------------------------------------
def test_no_cognition_mode_does_not_update_cognitive_state(short_scenario):
    """With cognition off, memory and forecast channels must stay inert."""

    result = run_single(short_scenario, 0)
    ts = result.time_series

    exp_cols = [c for c in ts.columns if c.startswith("exp_")]
    if exp_cols:
        values = ts[exp_cols].to_numpy(dtype=float)
        finite = values[np.isfinite(values)]
        assert finite.size == 0 or np.allclose(finite, 0.0)

    # Forecast channels retain their initial value when cognition B is off.
    # The requirement is that they never *update*, not that they are zero.
    fc_cols = [c for c in ts.columns if c.startswith("forecast_") and
               not c.startswith("forecast_err_")]
    for col in fc_cols:
        values = ts[col].to_numpy(dtype=float)
        finite = values[np.isfinite(values)]
        if finite.size > 1:
            assert np.allclose(finite, finite[0]), (
                f"{col} changed while cognition was disabled")


def test_homeostasis_works_with_cognition_disabled(short_scenario):
    """Hunger must still steer behaviour toward food when cognition is off."""

    def _food_share(hunger_strength: float) -> float:
        data = scenario_to_dict(short_scenario)
        data["cognition"]["experience_enabled"] = False
        data["cognition"]["forecast_enabled"] = False
        data["homeostasis"]["enabled"] = True
        data["homeostasis"]["hunger_strength"] = hunger_strength
        data["lifecycle"]["initial_energy"] = 15.0  # start hungry
        result = run_single(scenario_from_dict(data), 0, validate=False)
        cols = [f"timealloc_{t}" for t in
                ("safe_forage", "risky_forage", "scavenge")]
        present = [c for c in cols if c in result.time_series.columns]
        return float(result.time_series[present].sum(axis=1).mean())

    assert _food_share(4.0) > _food_share(0.0)


def test_cognition_enabled_populates_memory(short_scenario):
    data = scenario_to_dict(short_scenario)
    data["cognition"]["experience_enabled"] = True
    result = run_single(scenario_from_dict(data), 0, validate=False)
    exp_cols = [c for c in result.time_series.columns if c.startswith("exp_")]
    assert exp_cols
    values = result.time_series[exp_cols].to_numpy(dtype=float)
    assert np.nansum(np.abs(values)) > 0


def test_forecasting_uses_only_prior_information(short_scenario):
    """The forecast must never equal the future true value exactly.

    A look-ahead bug would make forecast[t] identical to env[t+1]. Comparing
    the forecast against the *next* true value catches that directly.
    """

    data = scenario_to_dict(short_scenario)
    data["cognition"]["forecast_enabled"] = True
    result = run_single(scenario_from_dict(data), 0, validate=False)
    ts = result.time_series

    for col in [c for c in ts.columns if c.startswith("forecast_")
                and not c.startswith("forecast_err_")]:
        var = col[len("forecast_"):]
        true_col = f"env_{var}"
        if true_col not in ts.columns or len(ts) < 3:
            continue
        forecast = ts[col].to_numpy(dtype=float)[:-1]
        future_truth = ts[true_col].to_numpy(dtype=float)[1:]
        assert not np.allclose(forecast, future_truth), (
            f"forecast for '{var}' matches the future exactly: look-ahead leak")


# ---------------------------------------------------------------------------
# Nonfunctional behaviour
# ---------------------------------------------------------------------------
def test_nonfunctional_task_has_no_direct_benefit():
    scenario = load_preset("stable_abundant")
    for task in scenario.enabled_tasks():
        if task.role == TaskRole.COSTLY_NONFUNCTIONAL:
            assert not task.has_direct_benefit(), (
                f"task '{task.task_id}' is labelled nonfunctional but confers "
                f"a direct benefit")


def test_nonfunctional_task_is_recorded_separately(short_scenario):
    result = run_single(short_scenario, 0)
    assert "nonfunc_action_rate" in result.time_series.columns
    assert "neutral_action_rate" in result.time_series.columns


def test_memory_includes_nonfunctional_task_only_when_configured(short_scenario):
    """A nonfunctional task enters success memory only if memory_eligible."""

    data = scenario_to_dict(short_scenario)
    data["cognition"]["experience_enabled"] = True
    for task in data["tasks"]:
        if task["task_id"] == "costly_dance":
            task["memory_eligible"] = False
    result = run_single(scenario_from_dict(data), 0, validate=False)
    assert "exp_costly_dance" not in result.time_series.columns

    data2 = scenario_to_dict(short_scenario)
    data2["cognition"]["experience_enabled"] = True
    for task in data2["tasks"]:
        if task["task_id"] == "costly_dance":
            task["memory_eligible"] = True
    result2 = run_single(scenario_from_dict(data2), 0, validate=False)
    assert "exp_costly_dance" in result2.time_series.columns


def test_disabling_nonfunctional_tasks_removes_them(short_scenario):
    """A disabled task must never be chosen or consume any time or energy.

    Note that a disabled task keeps its heritable propensity column: the trait
    still exists and is still inherited, it is simply never expressed. What
    must be exactly zero is realised behaviour.
    """

    data = scenario_to_dict(short_scenario)
    for task in data["tasks"]:
        if task["task_id"] in ("neutral_idle", "costly_dance"):
            task["enabled"] = False
    result = run_single(scenario_from_dict(data), 0, validate=False)
    ts = result.time_series

    for column in ("freq_costly_dance", "timealloc_costly_dance",
                   "energyalloc_costly_dance", "freq_neutral_idle"):
        if column in ts.columns:
            values = ts[column].to_numpy(dtype=float)
            assert np.allclose(values[np.isfinite(values)], 0.0), (
                f"disabled task still recorded activity in {column}")

    rate = result.time_series["nonfunc_action_rate"].to_numpy(dtype=float)
    assert np.allclose(rate[np.isfinite(rate)], 0.0)


# ---------------------------------------------------------------------------
# Bookkeeping
# ---------------------------------------------------------------------------
def test_every_death_has_a_recorded_cause(short_scenario):
    result = run_single(short_scenario, 0)
    causes = result.dead_log_df["cause"]
    assert len(causes) > 0
    valid = {DEATH_CAUSE_LABELS[c] for c in DeathCause if c != DeathCause.ALIVE}
    assert set(causes.unique()).issubset(valid)
    assert not causes.isna().any()


def test_no_agent_dies_as_alive(short_scenario):
    result = run_single(short_scenario, 0)
    assert (result.dead_log_df["cause"]
            != DEATH_CAUSE_LABELS[DeathCause.ALIVE]).all()


def test_population_balance_births_minus_deaths(short_scenario):
    """Population change must equal births minus deaths over the run."""

    result = run_single(short_scenario, 0)
    ts = result.time_series
    initial = short_scenario.population.initial_population
    total_births = int(ts["births_interval"].sum())
    total_deaths = int(ts["deaths_interval"].sum())
    expected = initial + total_births - total_deaths
    assert abs(expected - result.final_population) <= 1, (
        f"population does not balance: {initial} + {total_births} "
        f"- {total_deaths} = {expected}, but final is "
        f"{result.final_population}")


def test_death_cause_counts_reconcile_with_dead_log(short_scenario):
    """Per-interval cause tallies must sum to the dead-log totals."""

    result = run_single(short_scenario, 0)
    ts = result.time_series
    log = result.dead_log_df

    for cause in DeathCause:
        if cause == DeathCause.ALIVE:
            continue
        label = DEATH_CAUSE_LABELS[cause]
        column = f"deaths_{label}"
        if column not in ts.columns:
            continue
        from_series = int(ts[column].sum())
        from_log = int((log["cause"] == label).sum())
        assert from_series == from_log, (
            f"cause '{label}': time series says {from_series}, "
            f"dead log says {from_log}")


def test_newborn_timing_is_consistent(short_scenario):
    """Newborns act from the following step, so no agent acts at age zero.

    The configuration flag newborns_act_next_step is documented as the single
    consistent rule; this checks the engine honours it.
    """

    assert short_scenario.lifecycle.newborns_act_next_step
    result = run_single(short_scenario, 0)
    log = result.dead_log_df
    # Every recorded life has a non-negative age and a coherent birth season.
    assert (log["age_steps"] >= 0).all()
    # Founders born before the run starts carry a negative born_season when the
    # founder age distribution is dispersed (ADR-006); agents born during the
    # run never do.
    assert (log["born_season"] >= -short_scenario.lifecycle.max_lifespan_seasons).all()
    assert (log["death_season"] >= log["born_season"]).all()


def test_lifetime_offspring_totals_match_breeding_records(short_scenario):
    """Recorded offspring must not exceed what the breeding log reports."""

    result = run_single(short_scenario, 0)
    logged = int(result.dead_log_df["lifetime_offspring"].sum())
    bred = int(result.breeding_series["n_offspring_survived"].sum())
    # Living parents also hold offspring counts, so the dead-log total is a
    # lower bound on total production.
    assert logged <= bred * 2 + 1


def test_max_lifespan_is_enforced(short_scenario):
    data = scenario_to_dict(short_scenario)
    data["lifecycle"]["max_lifespan_seasons"] = 2
    scenario = scenario_from_dict(data)
    result = run_single(scenario, 0, validate=False)
    steps_per_season = scenario.lifecycle.steps_per_season
    max_steps = 2 * steps_per_season
    assert result.dead_log_df["age_steps"].max() <= max_steps + steps_per_season


def test_state_variables_stay_within_bounds(short_scenario):
    result = run_single(short_scenario, 0)
    samples = result.agent_samples
    assert (samples["energy"] >= 0).all()
    assert (samples["energy"] <= short_scenario.lifecycle.energy_max + 1e-6).all()
    assert (samples["health"] >= 0).all()
    assert (samples["health"] <= short_scenario.lifecycle.health_max + 1e-6).all()

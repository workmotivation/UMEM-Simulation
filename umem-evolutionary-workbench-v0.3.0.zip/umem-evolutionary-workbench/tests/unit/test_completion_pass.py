"""Tests for the v0.2.0 completion and correction pass.

Covers: gestation safety under distributed timing, legacy-field marking, the
corrected reproduction metrics, per-step pair-bond counters, export metadata,
the data dictionary, and the new concentration metrics.
"""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest

from umem_workbench.analysis import birth_phase_entropy, gini, summarise_run, top_share
from umem_workbench.config.data_dictionary import (
    build_dictionary,
    to_csv,
    to_json,
    to_markdown,
)
from umem_workbench.config.migrations import migrate_scenario_dict
from umem_workbench.config.models import ReproductionConfig, ScenarioConfig
from umem_workbench.config.presets import PRESET_IDS, load_preset
from umem_workbench.config.serialization import scenario_to_dict
from umem_workbench.config.validation import Severity, validate_scenario
from umem_workbench.experiments import ScenarioNotRunnable, run_single


def _short(preset="stable_abundant", seasons=4, **kw):
    s = load_preset(preset)
    s.lifecycle.total_seasons = seasons
    s.output.record_interval_steps = 1
    s.output.store_agent_sample = False
    for path, value in kw.items():
        section, _, fld = path.partition(".")
        setattr(getattr(s, section), fld, value)
    return s


# ---------------------------------------------------------------------------
# 1. Gestation is explicit and safe
# ---------------------------------------------------------------------------
def test_gestation_under_distributed_is_a_blocking_error():
    s = load_preset("stable_abundant")
    s.reproduction.gestation_delay_steps = 5
    report = validate_scenario(s)
    assert not report.can_run
    codes = [i.code for i in report.issues if i.severity == Severity.ERROR]
    assert "gestation_not_supported_distributed" in codes


def test_gestation_under_distributed_cannot_start_a_run():
    s = load_preset("stable_abundant")
    s.reproduction.gestation_delay_steps = 5
    with pytest.raises(ScenarioNotRunnable):
        run_single(s, 0)


def test_gestation_under_legacy_timing_is_allowed():
    s = load_preset("stable_abundant_legacy")
    s.reproduction.gestation_delay_steps = 5
    assert validate_scenario(s).can_run


def test_gestation_error_message_names_the_remedy():
    s = load_preset("stable_abundant")
    s.reproduction.gestation_delay_steps = 2
    msg = " ".join(i.message for i in validate_scenario(s).issues)
    assert "season_end_legacy" in msg
    assert "never silently ignored" in msg


def test_legacy_breeding_interval_warns_under_distributed():
    s = load_preset("stable_abundant")
    s.reproduction.breeding_every_seasons = 3
    codes = [i.code for i in validate_scenario(s).issues]
    assert "legacy_field_ignored" in codes


def test_legacy_only_fields_are_marked_in_metadata():
    d = {e.path: e for e in build_dictionary()}
    assert d["reproduction.gestation_delay_steps"].applicability == "legacy_timing_only"
    assert d["reproduction.breeding_every_seasons"].applicability == "legacy_timing_only"
    assert d["reproduction.gestation_delay_steps"].deprecated
    assert d["inheritance.mutation_log_sd"].applicability == "legacy_inheritance_only"
    assert d["reproduction.reproductive_event_rate"].applicability == "distributed_only"
    assert d["reproduction.bond_formation_per_season"].applicability == "pair_bond_only"


# ---------------------------------------------------------------------------
# 9 (semantic). Rate field rename with compatibility alias
# ---------------------------------------------------------------------------
def test_reproductive_event_rate_accepts_old_name_on_input():
    a = ReproductionConfig(reproductive_event_rate=2.5)
    b = ReproductionConfig(expected_births_per_season=2.5)
    assert a.reproductive_event_rate == b.reproductive_event_rate == 2.5
    assert "expected_births_per_season" not in a.model_dump()


def test_migration_renames_old_rate_key():
    data = scenario_to_dict(load_preset("stable_abundant"))
    data["schema_version"] = 1
    rate = data["reproduction"].pop("reproductive_event_rate")
    data["reproduction"]["expected_births_per_season"] = rate
    migrated = migrate_scenario_dict(data)
    assert migrated["reproduction"]["reproductive_event_rate"] == rate
    assert "expected_births_per_season" not in migrated["reproduction"]
    ScenarioConfig(**{k: v for k, v in migrated.items()
                      if k in ScenarioConfig.model_fields})


# ---------------------------------------------------------------------------
# 2. Reproduction summary metrics are explicit about their denominator
# ---------------------------------------------------------------------------
def test_old_misleading_metric_names_are_gone():
    m = summarise_run(run_single(_short(), 0))
    assert "mean_pairs_per_season" not in m
    assert "mean_eligible_per_season" not in m


def test_distributed_reports_per_step_and_per_season_separately():
    r = run_single(_short(seasons=5), 0)
    m = summarise_run(r)
    bs = r.breeding_series
    assert m["mean_pairs_per_step"] == pytest.approx(bs["n_pairs"].mean())
    per_season = bs.groupby("season")["n_pairs"].sum().mean()
    assert m["mean_total_pairs_per_season"] == pytest.approx(per_season)
    assert m["mean_total_pairs_per_season"] > m["mean_pairs_per_step"]
    assert m["mean_eligible_agents_per_step"] == pytest.approx(bs["n_eligible"].mean())


def test_legacy_mode_does_not_mislabel_per_season_as_per_step():
    r = run_single(_short(preset="stable_abundant_legacy", seasons=5), 0)
    m = summarise_run(r)
    assert np.isnan(m["mean_pairs_per_step"])
    assert np.isnan(m["mean_eligible_agents_per_step"])
    assert m["mean_total_pairs_per_season"] > 0
    assert "mean_eligible_agents_at_season_end" in m


def test_totals_are_present_and_consistent():
    r = run_single(_short(seasons=5), 0)
    m = summarise_run(r)
    bs = r.breeding_series
    assert m["total_reproductive_attempts"] == int(bs["n_attempts"].sum())
    assert m["total_successful_events"] == int(bs["n_pairs"].sum())
    assert m["total_offspring_survived"] == int(bs["n_offspring_survived"].sum())
    assert m["total_offspring_pre_survival"] >= m["total_offspring_survived"]
    assert m["total_successful_events"] <= m["total_reproductive_attempts"]


# ---------------------------------------------------------------------------
# 3. Pair-bond counters are per step, not cumulative
# ---------------------------------------------------------------------------
def test_bond_step_counts_sum_to_cumulative():
    """Would fail if cumulative totals were written into per-step rows."""

    r = run_single(_short(preset="pair_bonded_humanlike", seasons=3), 0)
    bs = r.breeding_series
    assert int(bs["n_bonds_formed_step"].sum()) == int(bs["cumulative_bonds_formed"].iloc[-1])
    assert int(bs["n_bonds_dissolved_step"].sum()) == int(bs["cumulative_bonds_dissolved"].iloc[-1])
    # A cumulative column mislabelled as incremental would sum to far more
    # than its own final value.
    assert int(bs["n_bonds_formed_step"].sum()) < 5 * int(bs["cumulative_bonds_formed"].iloc[-1]) + 1


def test_active_bond_accounting_identity():
    r = run_single(_short(preset="pair_bonded_humanlike", seasons=3), 0)
    bs = r.breeding_series
    active = bs["n_active_bonds"].to_numpy()
    formed = bs["n_bonds_formed_step"].to_numpy()
    dissolved = bs["n_bonds_dissolved_step"].to_numpy()
    prior = np.concatenate([[0], active[:-1]])
    assert np.array_equal(prior + formed - dissolved, active)


def test_dissolution_causes_partition_the_total():
    r = run_single(_short(preset="pair_bonded_humanlike", seasons=3), 0)
    bs = r.breeding_series
    assert (bs["n_bonds_dissolved_by_death_step"]
            + bs["n_bonds_dissolved_stochastic_step"]
            == bs["n_bonds_dissolved_step"]).all()


def test_bond_metrics_in_summary_are_consistent():
    m = summarise_run(run_single(_short(preset="pair_bonded_humanlike", seasons=3), 0))
    assert m["bond_counter_consistent"] is True
    assert m["total_bonds_formed"] > 0
    assert m["peak_active_bonds"] > 0


# ---------------------------------------------------------------------------
# 4. Export metadata exposes the active mechanisms
# ---------------------------------------------------------------------------
def test_metadata_json_contains_mechanisms():
    from umem_workbench.export import build_metadata

    r = run_single(_short(preset="competitive_skew", seasons=3), 0)
    meta = build_metadata(r)
    mech = meta["mechanisms"]
    assert mech["reproduction_mode"] == "sexual"
    assert mech["reproduction_timing"] == "distributed"
    assert mech["mating_mode"] == "competitive"
    assert mech["mate_choice_k"] == 25
    assert mech["inheritance_model"] == "polygenic_additive"
    assert mech["mutation_level"] == "conservative"
    assert mech["mutation_probability_per_offspring"] == 0.01
    assert mech["founder_age_distribution"] == "uniform"
    assert meta["config_schema_version"] == 2
    assert meta["config_hash"] == r.config_hash


def test_excel_run_metadata_and_inheritance_sheet(tmp_path):
    from umem_workbench.export import export_workbook

    r = run_single(_short(preset="pair_bonded_humanlike", seasons=3), 0)
    path = tmp_path / "x.xlsx"
    export_workbook(path, r)
    meta = pd.read_excel(path, sheet_name="Run_Metadata").set_index("field")["value"]
    assert meta["mechanism_mating_mode"] == "pair_bonded"
    assert meta["mechanism_reproduction_timing"] == "distributed"
    assert meta["mechanism_inheritance_model"] == "polygenic_additive"
    assert str(meta["mechanism_sibling_variation"]) == "standard"
    assert float(meta["mechanism_segregation_multiplier_effective"]) == 1.0
    assert "config_hash" in meta.index
    assert int(meta["schema_version"]) == 2
    inh = pd.read_excel(path, sheet_name="Inheritance_Config")
    assert "model" in inh["field"].values


# ---------------------------------------------------------------------------
# 5. Data dictionary
# ---------------------------------------------------------------------------
def test_dictionary_covers_every_configuration_field():
    d = {e.path for e in build_dictionary()}
    from umem_workbench.config import models as M  # noqa: N812
    for section, model in (("reproduction", M.ReproductionConfig),
                           ("inheritance", M.InheritanceConfig),
                           ("population", M.PopulationConfig)):
        for name in model.model_fields:
            assert f"{section}.{name}" in d, f"missing {section}.{name}"
    for name in M.TaskConfig.model_fields:
        assert f"tasks[].{name}" in d


def test_dictionary_paths_are_unique():
    paths = [e.path for e in build_dictionary()]
    assert len(paths) == len(set(paths))


def test_dictionary_enum_values_and_defaults_match_models():
    d = {e.path: e for e in build_dictionary()}
    e = d["reproduction.mating_mode"]
    assert e.enum_values == ["random", "pair_bonded", "competitive"]
    assert e.default == "random"
    assert d["reproduction.mate_choice_k"].default == 1
    assert d["inheritance.mutation_probability_per_offspring"].default == 0.01


def test_schema_two_fields_are_labelled_schema_two():
    d = {e.path: e for e in build_dictionary()}
    for path in ("reproduction.timing", "reproduction.mating_mode",
                 "inheritance.model", "population.founder_age_distribution",
                 "reproduction.reproductive_event_rate"):
        assert d[path].added_in_schema == 2, path
        assert d[path].interpretation, f"{path} lacks interpretation"
        assert d[path].reference, f"{path} lacks reference"


def test_dictionary_markdown_is_reproducible():
    assert to_markdown() == to_markdown()
    assert to_json() == to_json()


def test_dictionary_formats_parse():
    payload = json.loads(to_json())
    assert payload["n_parameters"] == len(payload["parameters"])
    assert len(to_csv().splitlines()) == payload["n_parameters"] + 1


def test_parameter_reference_doc_matches_generator():
    from pathlib import Path

    doc = Path(__file__).resolve().parents[2] / "docs" / "parameter_reference.md"
    assert doc.read_text(encoding="utf-8") == to_markdown()


# ---------------------------------------------------------------------------
# 6. Concentration metrics on known synthetic inputs
# ---------------------------------------------------------------------------
def test_gini_known_values():
    assert gini([1, 1, 1, 1]) == pytest.approx(0.0)
    assert gini([0, 0, 0, 4]) == pytest.approx(0.75)
    assert gini([0, 0, 0]) == 0.0
    assert np.isnan(gini([]))


def test_top_share_known_values():
    assert top_share([1, 1, 1, 1, 1], 0.2) == pytest.approx(0.2)
    assert top_share([0, 0, 0, 0, 10], 0.2) == pytest.approx(1.0)
    assert np.isnan(top_share([0, 0], 0.2))
    assert np.isnan(top_share([], 0.2))


def test_birth_phase_entropy_known_values():
    sps = 10
    steps = np.arange(100)
    uniform = np.ones(100)
    assert birth_phase_entropy(uniform, steps, sps) == pytest.approx(1.0)
    one_phase = np.where(steps % sps == 0, 1.0, 0.0)
    assert birth_phase_entropy(one_phase, steps, sps) == pytest.approx(0.0)
    assert np.isnan(birth_phase_entropy(np.zeros(100), steps, sps))


def test_metrics_survive_extinction_and_zero_births():
    s = _short(seasons=3, **{"reproduction.reproductive_event_rate": 0.0})
    m = summarise_run(run_single(s, 0))
    assert m["total_offspring_survived"] == 0
    assert np.isnan(m["realised_juvenile_survival"])
    assert np.isnan(m["birth_phase_entropy"])
    for v in m.values():
        if isinstance(v, float):
            assert not np.isinf(v)


def test_competitive_skew_shows_in_gini_and_top_share():
    rand = summarise_run(run_single(_short(seasons=8), 0))
    comp = summarise_run(run_single(_short(preset="competitive_skew", seasons=8), 0))
    assert comp["lrs_top20pct_share"] >= rand["lrs_top20pct_share"] - 0.1


# ---------------------------------------------------------------------------
# 11. Pair-bond eligibility semantics are explicit
# ---------------------------------------------------------------------------
def test_bonds_form_between_mature_agents_regardless_of_condition_thresholds():
    """Bond formation requires maturity only; reproduction requires the full
    eligibility (energy/health/capital thresholds). Documented in ADR-005."""

    # Require the maximum reproductive capital, which agents cannot hold at
    # the very start, so that bonds form while reproduction is still blocked.
    s = _short(preset="pair_bonded_humanlike", seasons=1)
    s.reproduction.repro_capital_threshold = s.lifecycle.repro_capital_max
    r = run_single(s, 0)
    bs = r.breeding_series
    early = bs.head(5)
    assert early["n_active_bonds"].max() > 0             # bonds form at once
    assert int(early["n_offspring_survived"].sum()) == 0  # reproduction lags


def test_all_presets_still_validate_and_run():
    for pid in PRESET_IDS:
        s = load_preset(pid)
        assert validate_scenario(s).can_run, pid
        s.lifecycle.total_seasons = 2
        run_single(s, 0)

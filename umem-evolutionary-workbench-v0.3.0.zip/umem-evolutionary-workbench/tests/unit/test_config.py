"""Configuration tests (Master Prompt section 25.1)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from umem_workbench.config.migrations import migrate_scenario_dict
from umem_workbench.config.models import (
    MortalityConfig,
    PopulationConfig,
    ReproductionConfig,
    ScenarioConfig,
)
from umem_workbench.config.presets import PRESET_IDS, all_presets, load_preset
from umem_workbench.config.serialization import (
    config_hash,
    load_scenario_json,
    save_scenario_json,
    scenario_from_json,
    scenario_to_dict,
    scenario_to_json,
)
from umem_workbench.config.validation import Severity, validate_scenario


@pytest.mark.parametrize("preset_id", PRESET_IDS)
def test_presets_load_and_validate(preset_id):
    scenario = load_preset(preset_id)
    assert isinstance(scenario, ScenarioConfig)
    report = validate_scenario(scenario)
    errors = [i for i in report.issues if i.severity == Severity.ERROR]
    assert not errors, f"{preset_id} has blocking errors: {errors}"
    assert report.can_run


@pytest.mark.parametrize("preset_id", PRESET_IDS)
def test_json_round_trip_preserves_all_values(preset_id):
    original = load_preset(preset_id)
    restored = scenario_from_json(scenario_to_json(original))
    assert scenario_to_dict(restored) == scenario_to_dict(original)


def test_round_trip_via_file(tmp_path):
    original = load_preset("stable_abundant")
    path = tmp_path / "scenario.json"
    save_scenario_json(original, path)
    restored = load_scenario_json(path)
    assert config_hash(restored) == config_hash(original)


def test_config_hash_stable_for_semantically_identical_configs():
    a = load_preset("stable_abundant")
    b = load_preset("stable_abundant")
    assert config_hash(a) == config_hash(b)


def test_config_hash_ignores_cosmetic_fields():
    """Renaming a scenario must not change its scientific identity."""

    a = load_preset("stable_abundant")
    b = a.model_copy(deep=True)
    b.name = "A completely different display name"
    b.description = "Different description."
    assert config_hash(a) == config_hash(b)


def test_config_hash_changes_with_scientific_content():
    a = load_preset("stable_abundant")
    b = a.model_copy(deep=True)
    b.mortality.base_predation_hazard += 0.01
    assert config_hash(a) != config_hash(b)


def test_all_presets_have_distinct_hashes():
    hashes = {pid: config_hash(s) for pid, s in all_presets().items()}
    assert len(set(hashes.values())) == len(hashes)


# ---------------------------------------------------------------------------
# Schema validation rejects invalid values
# ---------------------------------------------------------------------------
def test_rejects_probability_above_one():
    with pytest.raises(ValidationError):
        MortalityConfig(base_predation_hazard=1.5)


def test_rejects_negative_probability():
    with pytest.raises(ValidationError):
        MortalityConfig(base_predation_hazard=-0.1)


def test_rejects_juvenile_survival_out_of_range():
    with pytest.raises(ValidationError):
        ReproductionConfig(juvenile_survival=1.4)


def test_rejects_non_positive_population():
    with pytest.raises(ValidationError):
        PopulationConfig(initial_population=0)


def test_rejects_unknown_extra_key():
    """Extra keys are forbidden so a typo cannot be silently ignored."""

    with pytest.raises(ValidationError):
        PopulationConfig(initial_population=10, carrying_capacity=100,
                         nonexistent_field=3)


def test_rejects_discrete_fertility_pmf_not_summing_to_one():
    with pytest.raises(ValidationError):
        ReproductionConfig(fertility_distribution="discrete",
                           fertility_discrete_pmf=[0.2, 0.2])


def test_rejects_maturity_after_max_lifespan():
    from umem_workbench.config.models import LifecycleConfig
    with pytest.raises(ValidationError):
        LifecycleConfig(maturity_seasons=20, max_lifespan_seasons=5)


def test_duplicate_domain_ids_rejected():
    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    data["domains"].append(dict(data["domains"][0]))
    with pytest.raises(ValidationError):
        ScenarioConfig(**data)


def test_task_referencing_unknown_domain_is_flagged():
    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    data["tasks"][0]["domain"] = "no_such_domain"
    try:
        broken = ScenarioConfig(**data)
    except ValidationError:
        return  # rejected at construction, which is also acceptable
    report = validate_scenario(broken)
    assert any(i.severity == Severity.ERROR for i in report.issues)


def test_sweep_limited_to_three_parameters():
    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    data["experiment"]["sweep_parameters"] = [
        {"path": "mortality.base_predation_hazard", "values": [0.1]}
        for _ in range(4)]
    with pytest.raises(ValidationError):
        ScenarioConfig(**data)


# ---------------------------------------------------------------------------
# Migration
# ---------------------------------------------------------------------------
def test_migration_from_schema_zero():
    """A version-0 document is upgraded to the current schema."""

    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    data["schema_version"] = 0
    migrated = migrate_scenario_dict(data)
    assert migrated["schema_version"] >= 1
    # The migrated document must still validate.
    ScenarioConfig(**{k: v for k, v in migrated.items()
                      if k in ScenarioConfig.model_fields})


def test_migration_is_idempotent():
    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    once = migrate_scenario_dict(dict(data))
    twice = migrate_scenario_dict(dict(once))
    assert once == twice


# ---------------------------------------------------------------------------
# Validation reporting
# ---------------------------------------------------------------------------
def test_impossible_scenario_produces_clear_error():
    """An unrunnable configuration must be rejected with an explanation."""

    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    # Disable every task: agents would have nothing at all to do.
    for task in data["tasks"]:
        task["enabled"] = False
    broken = ScenarioConfig(**data)
    report = validate_scenario(broken)
    assert not report.can_run
    assert any(i.severity == Severity.ERROR for i in report.issues)
    assert all(i.message for i in report.issues)


def test_role_effect_conflict_produces_warning():
    """A 'nonfunctional' task that grants energy must be flagged."""

    from umem_workbench.config.enums import EffectCondition, EffectTarget, EffectType
    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    for task in data["tasks"]:
        if task["task_id"] == "costly_dance":
            task["effects"] = [{
                "target": EffectTarget.ENERGY.value,
                "effect_type": EffectType.ADDITIVE.value,
                "base_value": 25.0,
                "condition": EffectCondition.ON_SUCCESS.value,
            }]
    conflicted = ScenarioConfig(**data)
    report = validate_scenario(conflicted)
    assert any(i.severity in (Severity.WARNING, Severity.ERROR)
               for i in report.issues)


def test_workload_estimate_is_produced():
    from umem_workbench.config.validation import estimate_workload
    estimate = estimate_workload(load_preset("stable_abundant"))
    assert estimate.total_steps > 0

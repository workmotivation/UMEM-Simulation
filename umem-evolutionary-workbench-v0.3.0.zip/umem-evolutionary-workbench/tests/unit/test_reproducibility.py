"""Reproducibility tests (Master Prompt section 25.2)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from umem_workbench.engine.randomness import RandomStreams
from umem_workbench.experiments import run_replications, run_single


def _key_results(result) -> dict:
    """The quantities that must match exactly for a run to count as identical."""

    return {
        "final_population": result.final_population,
        "extinct": result.extinct,
        "n_deaths": len(result.dead_log_df),
        "population_series": result.time_series["population"].tolist(),
        "energy_series": result.time_series["mean_energy"].round(10).tolist(),
    }


def test_same_seed_produces_identical_results(short_scenario):
    a = run_single(short_scenario, 0)
    b = run_single(short_scenario, 0)
    assert _key_results(a) == _key_results(b)


def test_same_seed_identical_full_time_series(short_scenario):
    a = run_single(short_scenario, 0)
    b = run_single(short_scenario, 0)
    pd.testing.assert_frame_equal(a.time_series, b.time_series)
    pd.testing.assert_frame_equal(a.dead_log_df, b.dead_log_df)


def test_different_master_seeds_diverge(short_scenario):
    a = run_single(short_scenario, 0)
    other = short_scenario.model_copy(deep=True)
    other.master_seed = short_scenario.master_seed + 991
    b = run_single(other, 0)
    assert _key_results(a) != _key_results(b)


def test_different_replication_indices_diverge(short_scenario):
    a = run_single(short_scenario, 0)
    b = run_single(short_scenario, 1)
    assert _key_results(a) != _key_results(b)


def test_replication_index_is_reproducible(short_scenario):
    """Replication 3 is always replication 3, however it is reached."""

    direct = run_single(short_scenario, 3)
    batch = run_replications(short_scenario, 5)
    assert _key_results(direct) == _key_results(batch.runs[3])


def test_serial_and_parallel_replications_are_identical(short_scenario):
    serial = run_replications(short_scenario, 4, parallel=False)
    parallel = run_replications(short_scenario, 4, parallel=True, max_workers=2)

    assert len(serial.runs) == len(parallel.runs) == 4
    for a, b in zip(serial.runs, parallel.runs):
        assert _key_results(a) == _key_results(b)


def test_parallel_preserves_replication_order(short_scenario):
    """Results are ordered by replication index, not by completion time."""

    parallel = run_replications(short_scenario, 4, parallel=True, max_workers=3)
    assert [r.replication_index for r in parallel.runs] == [0, 1, 2, 3]


# ---------------------------------------------------------------------------
# Stream independence
# ---------------------------------------------------------------------------
def test_named_streams_are_distinct():
    streams = RandomStreams.create(12345, 0)
    a = streams.stream("environment").random(20)
    b = streams.stream("mortality").random(20)
    assert not np.allclose(a, b)


def test_stream_creation_is_deterministic():
    a = RandomStreams.create(999, 2).stream("task_choice").random(20)
    b = RandomStreams.create(999, 2).stream("task_choice").random(20)
    assert np.allclose(a, b)


def test_replication_index_changes_streams():
    a = RandomStreams.create(999, 0).stream("task_choice").random(20)
    b = RandomStreams.create(999, 1).stream("task_choice").random(20)
    assert not np.allclose(a, b)


def test_preview_stream_does_not_consume_run_randomness(short_scenario):
    """Previewing the environment must not perturb the actual run.

    The preview draws from its own generator, so a run performed after a
    preview must be identical to one performed without it.
    """

    from umem_workbench.environment.processes import generate_environment

    baseline = run_single(short_scenario, 0)

    streams = RandomStreams.create(short_scenario.master_seed, 0)
    generate_environment(short_scenario.environment, 200,
                         streams.preview_stream())
    after_preview = run_single(short_scenario, 0)

    assert _key_results(baseline) == _key_results(after_preview)


def test_environment_preview_matches_run_environment(short_scenario):
    """The preview shows the same trajectory the run will actually use."""

    from umem_workbench.environment.processes import generate_environment

    streams = RandomStreams.create(short_scenario.master_seed, 0)
    preview = generate_environment(
        short_scenario.environment,
        short_scenario.lifecycle.steps_per_season
        * short_scenario.lifecycle.total_seasons,
        streams.stream("environment"))

    result = run_single(short_scenario, 0)
    for var_id, series in preview.items():
        actual = result.env_trajectories[var_id]
        assert np.allclose(series[:len(actual)], actual[:len(series)])


def test_config_hash_recorded_on_result(short_scenario):
    from umem_workbench.config.serialization import config_hash
    result = run_single(short_scenario, 0)
    assert result.config_hash == config_hash(short_scenario)


def test_seed_metadata_is_recorded(short_scenario):
    result = run_single(short_scenario, 0)
    assert result.seed_metadata
    assert result.master_seed == short_scenario.master_seed

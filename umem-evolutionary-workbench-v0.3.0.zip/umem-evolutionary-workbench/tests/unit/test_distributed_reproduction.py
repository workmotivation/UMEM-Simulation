"""Tests for distributed reproduction and mate choice (plan §13.2, §13.3).

See docs/design/ADR-003, ADR-004, ADR-005.
"""

from __future__ import annotations

import numpy as np
import pytest

from umem_workbench.config.enums import (
    FounderAgeDistribution,
    InheritanceModel,
    MateChoiceCriterion,
    MatingMode,
    ReproductionMode,
    ReproductionTiming,
)
from umem_workbench.config.presets import load_preset
from umem_workbench.engine.distributed_reproduction import (
    PairBonds,
    refractory_steps,
    step_hazard_from_rate,
)
from umem_workbench.engine.mate_choice import (
    choose_partners,
    expected_partner_rank,
)
from umem_workbench.experiments import run_single


@pytest.fixture
def rng():
    return np.random.default_rng(4242)


def _scenario(preset="stable_abundant", seasons=8, **kw):
    s = load_preset(preset)
    s.lifecycle.total_seasons = seasons
    s.output.record_interval_steps = 1
    s.output.store_agent_sample = False
    for path, value in kw.items():
        section, _, field = path.partition(".")
        setattr(getattr(s, section), field, value)
    return s


# ---------------------------------------------------------------------------
# Unit-time conversion (ADR-003)
# ---------------------------------------------------------------------------
def test_rate_conversion_preserves_expected_events_per_season():
    """Changing time resolution must not change reproductive intensity."""

    lam = 1.7
    for sps in (10, 20, 40, 80):
        h = step_hazard_from_rate(lam, sps)
        expected_events = sps * h
        # 1 - exp(-lambda/S) per step, S steps: the first-order expectation is
        # lambda, with a small discretisation deficit that shrinks with S.
        assert expected_events == pytest.approx(lam, rel=0.10)


def test_zero_rate_gives_zero_hazard():
    assert step_hazard_from_rate(0.0, 40) == 0.0


def test_refractory_period_converts_seasons_to_steps():
    s = _scenario(**{"reproduction.refractory_seasons": 2.0})
    assert refractory_steps(s) == 2 * s.lifecycle.steps_per_season


# ---------------------------------------------------------------------------
# Timing behaviour (plan §13.1)
# ---------------------------------------------------------------------------
def test_distributed_reproduction_occurs_on_ordinary_steps():
    r = run_single(_scenario(), 0)
    ts = r.time_series
    sps = 40
    interior = ts[(ts["step"] % sps) != 0]
    assert interior["births_interval"].sum() > 0


def test_distributed_births_are_not_confined_to_season_boundaries():
    r = run_single(_scenario(), 0)
    ts = r.time_series
    births = ts["births_interval"].to_numpy(float)
    share = float((births > 0).mean())
    assert share > 0.20, f"only {share:.3f} of steps had births"


def test_season_boundary_has_no_special_birth_behaviour():
    """Under distributed timing the season edge must be unremarkable."""

    r = run_single(_scenario(seasons=12), 0)
    ts = r.time_series
    sps = 40
    boundary = ts[(ts["step"] % sps) == 0]["births_interval"].mean()
    interior = ts[(ts["step"] % sps) != 0]["births_interval"].mean()
    assert boundary == pytest.approx(interior, rel=1.0)


def test_legacy_timing_still_breeds_only_at_season_end():
    s = _scenario(**{"reproduction.timing": ReproductionTiming.SEASON_END_LEGACY})
    r = run_single(s, 0)
    ts = r.time_series
    sps = s.lifecycle.steps_per_season
    # Births are appended after the season-end step, so they surface on the
    # following step: exactly one step per season carries births.
    births = ts["births_interval"].to_numpy(float)
    assert float((births > 0).mean()) < 2.0 / sps


def test_distributed_does_not_multiply_fertility_by_steps_per_season():
    """The distributed path must not run the whole season's breeding each step."""

    legacy = run_single(
        _scenario(**{"reproduction.timing": ReproductionTiming.SEASON_END_LEGACY,
                     "inheritance.model": InheritanceModel.LEGACY,
                     "population.founder_age_distribution":
                         FounderAgeDistribution.ALL_NEWBORN_LEGACY}), 0)
    distributed = run_single(_scenario(), 0)

    legacy_births = int(legacy.time_series["births_interval"].sum())
    dist_births = int(distributed.time_series["births_interval"].sum())
    assert dist_births < legacy_births * 5, (
        f"distributed produced {dist_births} births vs legacy {legacy_births}: "
        f"fertility appears to have been multiplied by the step count")


def test_reproductive_intensity_is_robust_to_steps_per_season():
    """Expected births per season must not scale with the time resolution."""

    per_season = {}
    for sps in (20, 40):
        s = _scenario(seasons=8)
        s.lifecycle.steps_per_season = sps
        r = run_single(s, 0)
        per_season[sps] = (int(r.time_series["births_interval"].sum())
                           / s.lifecycle.total_seasons)
    ratio = per_season[40] / max(per_season[20], 1)
    assert 0.4 < ratio < 2.5, f"births per season scaled by {ratio:.2f} with sps"


def test_refractory_is_respected_and_only_after_success():
    """A long refractory period must suppress reproduction."""

    fast = run_single(_scenario(**{"reproduction.refractory_seasons": 0.0}), 0)
    slow = run_single(_scenario(**{"reproduction.refractory_seasons": 4.0}), 0)
    assert (int(slow.time_series["births_interval"].sum())
            < int(fast.time_series["births_interval"].sum()))


def test_failed_attempts_do_not_consume_parental_condition():
    """Attempts without a partner must cost nothing.

    With one reproductive type absent, every attempt fails; energy must then
    follow the same trajectory as a run with reproduction switched off.
    """

    no_partner = _scenario(seasons=4, **{"population.sex_ratio_type_a": 1.0})
    no_repro = _scenario(seasons=4, **{"population.sex_ratio_type_a": 1.0,
                                       "reproduction.reproductive_event_rate": 0.0})
    a = run_single(no_partner, 0)
    b = run_single(no_repro, 0)
    assert int(a.time_series["births_interval"].sum()) == 0
    assert a.final_population == b.final_population


# ---------------------------------------------------------------------------
# Mate choice: RKPM (ADR-004)
# ---------------------------------------------------------------------------
def test_expected_partner_rank_formula():
    assert expected_partner_rank(100, 1) == pytest.approx(50.0)
    assert expected_partner_rank(100, 19) == pytest.approx(5.0)


def test_k_of_one_is_unbiased_random_mating(rng):
    """With k=1 every candidate must be equally likely."""

    n = 60
    quality = np.linspace(0, 1, n)          # candidate 0 worst, n-1 best
    picks = []
    for _ in range(4000):
        _, partner = choose_partners(np.array([0]), np.arange(n), quality,
                                     k=1, criterion=MateChoiceCriterion.PARTNER_QUALITY,
                                     rng=rng)
        picks.append(int(partner[0]))
    mean_rank = float(np.mean(picks))
    assert mean_rank == pytest.approx((n - 1) / 2, rel=0.10)


def test_larger_k_concentrates_choice_on_higher_quality(rng):
    n = 100
    quality = np.linspace(0, 1, n)
    means = {}
    for k in (1, 5, 25):
        picks = [int(choose_partners(np.array([0]), np.arange(n), quality, k,
                                     MateChoiceCriterion.PARTNER_QUALITY, rng)[1][0])
                 for _ in range(1500)]
        means[k] = float(np.mean(picks))
    assert means[1] < means[5] < means[25]
    assert means[25] > 0.85 * (n - 1)


def test_similarity_criterion_matches_like_with_like(rng):
    n = 100
    quality = np.linspace(0, 1, n)
    chooser = 50
    picks = [int(choose_partners(np.array([chooser]), np.arange(n), quality, 25,
                                 MateChoiceCriterion.SIMILARITY, rng)[1][0])
             for _ in range(800)]
    assert float(np.mean(np.abs(np.array(picks) - chooser))) < 12


def test_no_agent_is_duplicated_within_one_matching_event(rng):
    quality = rng.random(200)
    choosers = np.arange(0, 80)
    candidates = np.arange(100, 200)
    matched_c, matched_p = choose_partners(
        choosers, candidates, quality, 5,
        MateChoiceCriterion.PARTNER_QUALITY, rng, exclusive=True)
    assert len(set(matched_p.tolist())) == len(matched_p)
    assert len(set(matched_c.tolist())) == len(matched_c)


def test_empty_pools_are_handled(rng):
    q = np.zeros(5)
    c, p = choose_partners(np.array([], dtype=np.int64), np.arange(5), q, 3,
                           MateChoiceCriterion.PARTNER_QUALITY, rng)
    assert c.size == 0 and p.size == 0
    c, p = choose_partners(np.arange(3), np.array([], dtype=np.int64), q, 3,
                           MateChoiceCriterion.PARTNER_QUALITY, rng)
    assert c.size == 0 and p.size == 0


def test_mate_quality_uses_only_permitted_keys():
    from umem_workbench.engine.mate_choice import PERMITTED_QUALITY_KEYS
    s = _scenario()
    assert set(s.reproduction.mate_quality_weights) <= set(PERMITTED_QUALITY_KEYS)


def test_competitive_mating_raises_reproductive_skew():
    """Choosiness must measurably concentrate reproductive success.

    Crow's opportunity for selection is the standard measure and is already
    computed by the analysis layer, so it doubles as the acceptance criterion.
    """

    from umem_workbench.analysis import summarise_run

    random_i, competitive_i = [], []
    for seed in (1, 2, 3):
        base = _scenario(seasons=10)
        base.master_seed = seed
        random_i.append(summarise_run(run_single(base, 0))
                        ["opportunity_for_selection_I"])

        # Quality must be weighted on a *non-depletable* trait. Reproductive
        # capital is reset when an agent breeds, so choosing on it makes
        # "quality" mean "time since last breeding" and equalises reproductive
        # success instead of concentrating it (ADR-004).
        comp = _scenario(seasons=10,
                         **{"reproduction.mating_mode": MatingMode.COMPETITIVE,
                            "reproduction.mate_choice_k": 25,
                            "reproduction.mate_quality_weights": {
                                "status": 1.0, "repro_capital": 0.0,
                                "health": 0.0, "energy": 0.0}})
        comp.master_seed = seed
        competitive_i.append(summarise_run(run_single(comp, 0))
                             ["opportunity_for_selection_I"])

    assert np.mean(competitive_i) > np.mean(random_i)


# ---------------------------------------------------------------------------
# Pair bonds (ADR-005)
# ---------------------------------------------------------------------------
def test_pair_bonds_are_exclusive_and_symmetric():
    bonds = PairBonds()
    bonds.bond(1, 2)
    assert bonds.partner_of[1] == 2 and bonds.partner_of[2] == 1
    assert bonds.is_bonded(1) and bonds.is_bonded(2)
    assert bonds.n_bonds == 1


def test_dissolving_a_bond_releases_both_partners():
    bonds = PairBonds()
    bonds.bond(1, 2)
    bonds.dissolve(1)
    assert not bonds.is_bonded(1)
    assert not bonds.is_bonded(2)
    assert bonds.dissolved == 1


def test_death_of_a_partner_releases_the_survivor():
    bonds = PairBonds()
    bonds.bond(1, 2)
    bonds.bond(3, 4)
    bonds.prune_dead(np.array([2, 3, 4]))     # agent 1 has died
    assert not bonds.is_bonded(2)
    assert bonds.is_bonded(3) and bonds.is_bonded(4)


def test_no_agent_holds_two_simultaneous_bonds_in_a_run():
    s = _scenario(preset="pair_bonded_humanlike", seasons=8)
    r = run_single(s, 0)
    # n_active_bonds can never exceed half the population.
    bs = r.breeding_series
    pops = r.time_series.set_index("step")["population"]
    for _, row in bs.iterrows():
        pop = int(pops.get(int(row["step"]), 0))
        assert row["n_active_bonds"] <= pop / 2 + 1


def test_pair_bonded_run_forms_bonds():
    r = run_single(_scenario(preset="pair_bonded_humanlike", seasons=6), 0)
    assert r.breeding_series["n_active_bonds"].max() > 0
    assert r.breeding_series["cumulative_bonds_formed"].max() > 0


# ---------------------------------------------------------------------------
# Asexual reproduction
# ---------------------------------------------------------------------------
def test_asexual_reproduction_needs_no_partner():
    """A single reproductive type must still reproduce when asexual."""

    s = _scenario(seasons=6, **{"reproduction.mode": ReproductionMode.ASEXUAL,
                                "population.sex_ratio_type_a": 1.0})
    r = run_single(s, 0)
    assert int(r.time_series["births_interval"].sum()) > 0


def test_asexual_preset_runs():
    r = run_single(_scenario(preset="asexual_clonal", seasons=6), 0)
    assert not r.extinct


# ---------------------------------------------------------------------------
# Founder age structure (ADR-006)
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("mode,expect_spread", [
    (FounderAgeDistribution.ALL_NEWBORN_LEGACY, False),
    (FounderAgeDistribution.UNIFORM, True),
    (FounderAgeDistribution.STABLE, True),
])
def test_founder_age_distributions(mode, expect_spread):
    from umem_workbench.engine.randomness import RandomStreams
    from umem_workbench.engine.state import AgentPool

    s = _scenario(**{"population.founder_age_distribution": mode})
    pool = AgentPool(s)
    pool.initialise(RandomStreams.create(1, 0).stream("initial_population"))
    ages = pool.age_steps
    if expect_spread:
        assert ages.max() > 0
        assert len(np.unique(ages // s.lifecycle.steps_per_season)) > 2
    else:
        assert (ages == 0).all()


def test_legacy_founder_ages_consume_no_randomness():
    """Legacy founder ages must not shift the random stream."""

    a = run_single(_scenario(
        seasons=4,
        **{"population.founder_age_distribution":
           FounderAgeDistribution.ALL_NEWBORN_LEGACY,
           "reproduction.timing": ReproductionTiming.SEASON_END_LEGACY,
           "inheritance.model": InheritanceModel.LEGACY}), 0)
    b = run_single(_scenario(
        seasons=4,
        **{"population.founder_age_distribution":
           FounderAgeDistribution.ALL_NEWBORN_LEGACY,
           "reproduction.timing": ReproductionTiming.SEASON_END_LEGACY,
           "inheritance.model": InheritanceModel.LEGACY}), 0)
    assert a.final_population == b.final_population


def test_dispersed_founders_include_mature_agents():
    from umem_workbench.engine.randomness import RandomStreams
    from umem_workbench.engine.state import AgentPool

    s = _scenario(**{"population.founder_age_distribution":
                     FounderAgeDistribution.UNIFORM})
    pool = AgentPool(s)
    pool.initialise(RandomStreams.create(1, 0).stream("initial_population"))
    assert pool.reached_maturity.mean() > 0.3


# ---------------------------------------------------------------------------
# Migration (plan §13.4)
# ---------------------------------------------------------------------------
def test_schema_1_scenarios_migrate_to_legacy_mechanics():
    """Old scenarios must never be silently opted into new mechanisms."""

    from umem_workbench.config.migrations import migrate_scenario_dict
    from umem_workbench.config.serialization import scenario_to_dict

    data = scenario_to_dict(load_preset("stable_abundant"))
    data["schema_version"] = 1
    data["reproduction"].pop("timing", None)
    data["population"].pop("founder_age_distribution", None)
    data["inheritance"].pop("model", None)

    migrated = migrate_scenario_dict(data)
    assert migrated["schema_version"] == 2
    assert migrated["reproduction"]["timing"] == "season_end_legacy"
    assert migrated["population"]["founder_age_distribution"] == "all_newborn_legacy"
    assert migrated["inheritance"]["model"] == "legacy"


def test_migration_is_idempotent():
    from umem_workbench.config.migrations import migrate_scenario_dict
    from umem_workbench.config.serialization import scenario_to_dict

    data = scenario_to_dict(load_preset("stable_abundant"))
    data["schema_version"] = 1
    once = migrate_scenario_dict(dict(data))
    twice = migrate_scenario_dict(dict(once))
    assert once == twice


def test_config_hash_covers_new_scientific_fields():
    from umem_workbench.config.serialization import config_hash

    base = load_preset("stable_abundant")
    for path, value in (("reproduction.timing",
                         ReproductionTiming.SEASON_END_LEGACY),
                        ("reproduction.mating_mode", MatingMode.COMPETITIVE),
                        ("reproduction.mate_choice_k", 17),
                        ("inheritance.model", InheritanceModel.LEGACY),
                        ("population.founder_age_distribution",
                         FounderAgeDistribution.STABLE)):
        other = load_preset("stable_abundant")
        section, _, field = path.partition(".")
        setattr(getattr(other, section), field, value)
        assert config_hash(other) != config_hash(base), f"{path} not in hash"


def test_distributed_runs_are_reproducible():
    a = run_single(_scenario(seasons=6), 0)
    b = run_single(_scenario(seasons=6), 0)
    assert a.final_population == b.final_population
    assert a.time_series["population"].tolist() == \
        b.time_series["population"].tolist()

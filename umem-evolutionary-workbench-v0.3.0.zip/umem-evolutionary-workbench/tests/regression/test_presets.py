"""Statistical and regression tests (Master Prompt section 25.4)."""

from __future__ import annotations

import numpy as np
import pytest

from umem_workbench.analysis import summarise_run
from umem_workbench.config.presets import PRESET_IDS, load_preset
from umem_workbench.config.serialization import scenario_from_dict, scenario_to_dict
from umem_workbench.config.validation import Severity, validate_scenario
from umem_workbench.experiments import ScenarioNotRunnable, run_replications, run_single

SCIENTIFIC_PRESETS = ["stable_abundant", "scarce_low_fecundity",
                      "volatile_high_fecundity"]


@pytest.mark.parametrize("preset_id", PRESET_IDS)
def test_preset_runs_without_exception(preset_id):
    """Every shipped preset must complete a short run cleanly."""

    scenario = load_preset(preset_id)
    scenario.lifecycle.total_seasons = min(6, scenario.lifecycle.total_seasons)
    result = run_single(scenario, 0)
    assert result.time_series is not None and len(result.time_series) > 0
    assert not result.cancelled


@pytest.mark.parametrize("preset_id", PRESET_IDS)
def test_preset_full_length_run_completes(preset_id):
    """The presets must also survive their full configured horizon."""

    result = run_single(load_preset(preset_id), 0)
    assert len(result.time_series) > 0


def test_preset_a_calibrated_seed_avoids_extinction():
    """Acceptance criterion 25.4: preset A must not go extinct on its own seed."""

    scenario = load_preset("stable_abundant")
    result = run_single(scenario, 0)
    assert not result.extinct
    assert result.final_population > 0


@pytest.mark.parametrize("preset_id", PRESET_IDS)
def test_presets_survive_on_their_default_seed(preset_id):
    """Every shipped preset must be usable out of the box."""

    result = run_single(load_preset(preset_id), 0)
    assert not result.extinct, (
        f"{preset_id} goes extinct on its shipped default seed")


def test_preset_a_low_extinction_across_replications():
    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 15
    batch = run_replications(scenario, 6)
    extinct = sum(1 for r in batch.runs if r.extinct)
    assert extinct == 0


@pytest.mark.parametrize("preset_id", SCIENTIFIC_PRESETS)
def test_presets_produce_finite_summary_metrics(preset_id):
    scenario = load_preset(preset_id)
    scenario.lifecycle.total_seasons = 8
    summary = summarise_run(run_single(scenario, 0))
    for key in ("final_population", "mean_lifespan_seasons",
                "mean_lrs_completed_lives"):
        value = summary.get(key)
        assert value is not None
        if isinstance(value, float):
            assert np.isfinite(value), f"{preset_id}: {key} is not finite"


# ---------------------------------------------------------------------------
# Impossible scenarios must be rejected with a clear message
# ---------------------------------------------------------------------------
def test_scenario_with_no_enabled_tasks_is_rejected():
    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    for task in data["tasks"]:
        task["enabled"] = False
    broken = scenario_from_dict(data)

    report = validate_scenario(broken)
    assert not report.can_run
    assert any(i.severity == Severity.ERROR for i in report.issues)

    with pytest.raises(ScenarioNotRunnable):
        run_single(broken, 0)


def test_scenario_with_no_energy_source_is_rejected():
    from umem_workbench.config.enums import EffectTarget

    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    for task in data["tasks"]:
        task["effects"] = [
            e for e in task["effects"]
            if not (e["target"] == EffectTarget.ENERGY.value
                    and e["base_value"] > 0)]
    broken = scenario_from_dict(data)

    report = validate_scenario(broken)
    assert not report.can_run
    messages = " ".join(i.message for i in report.issues).lower()
    assert "energy" in messages


def test_validation_errors_carry_readable_messages():
    scenario = load_preset("stable_abundant")
    data = scenario_to_dict(scenario)
    for task in data["tasks"]:
        task["enabled"] = False
    report = validate_scenario(scenario_from_dict(data))
    for issue in report.issues:
        assert issue.message.strip()
        assert issue.code.strip()


# ---------------------------------------------------------------------------
# Aggregate counts reconcile with individual events
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("preset_id", SCIENTIFIC_PRESETS)
def test_births_deaths_and_population_balance(preset_id):
    """initial + births - deaths must equal the final population exactly."""

    scenario = load_preset(preset_id)
    scenario.lifecycle.total_seasons = 8
    result = run_single(scenario, 0)
    ts = result.time_series

    initial = scenario.population.initial_population
    births = int(ts["births_interval"].sum())
    deaths = int(ts["deaths_interval"].sum())
    assert initial + births - deaths == result.final_population


@pytest.mark.parametrize("preset_id", SCIENTIFIC_PRESETS)
def test_dead_log_length_matches_death_tally(preset_id):
    scenario = load_preset(preset_id)
    scenario.lifecycle.total_seasons = 8
    result = run_single(scenario, 0)
    assert len(result.dead_log_df) == int(
        result.time_series["deaths_interval"].sum())


def test_final_snapshot_matches_final_population():
    """The last recorded row must agree with the reported final population."""

    for preset_id in SCIENTIFIC_PRESETS:
        scenario = load_preset(preset_id)
        scenario.lifecycle.total_seasons = 6
        result = run_single(scenario, 0)
        last = int(result.time_series["population"].iloc[-1])
        assert last == result.final_population, (
            f"{preset_id}: last snapshot {last} != final "
            f"{result.final_population}")


def test_breeding_offspring_match_recorded_births():
    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 8
    result = run_single(scenario, 0)
    bred = int(result.breeding_series["n_offspring_survived"].sum())
    births = int(result.time_series["births_interval"].sum())
    assert bred == births


def test_task_allocation_shares_sum_to_one():
    """Time-allocation shares must form a distribution at each snapshot."""

    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 6
    result = run_single(scenario, 0)
    cols = [c for c in result.time_series.columns if c.startswith("timealloc_")]
    totals = result.time_series[cols].sum(axis=1).to_numpy(dtype=float)
    live = totals[np.isfinite(totals) & (totals > 0)]
    assert np.allclose(live, 1.0, atol=1e-6)


def test_death_shares_sum_to_one():
    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 8
    summary = summarise_run(run_single(scenario, 0))
    shares = [v for k, v in summary.items() if k.startswith("death_share_")]
    assert shares
    assert sum(shares) == pytest.approx(1.0, abs=1e-9)


def test_population_never_negative_and_within_ceiling():
    for preset_id in SCIENTIFIC_PRESETS:
        scenario = load_preset(preset_id)
        scenario.lifecycle.total_seasons = 10
        result = run_single(scenario, 0)
        pop = result.time_series["population"].to_numpy()
        assert (pop >= 0).all()
        assert pop.max() <= scenario.population.max_population


def test_cancelled_run_is_labelled_partial():
    from umem_workbench.experiments import CancellationToken

    scenario = load_preset("stable_abundant")
    token = CancellationToken()
    token.cancel("test cancellation")
    result = run_single(scenario, 0, cancel=token)
    assert result.cancelled

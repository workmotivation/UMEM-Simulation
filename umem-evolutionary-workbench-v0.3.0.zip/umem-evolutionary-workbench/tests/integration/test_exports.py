"""Export tests (Master Prompt section 25.5)."""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

import pandas as pd
import pytest
from openpyxl import load_workbook

from umem_workbench.config.presets import load_preset
from umem_workbench.config.serialization import scenario_from_json
from umem_workbench.experiments import (
    CancellationToken,
    run_replications,
    run_single,
    run_sweep,
)
from umem_workbench.export import (
    EXCEL_MAX_ROWS,
    UnsafeOutputDirectory,
    export_bundle,
    export_figures,
    export_run_csvs,
    export_workbook,
)

REQUIRED_SHEETS = [
    "Run_Overview", "Run_Metadata", "Scenario_Config", "Tasks", "Task_Effects",
    "Environment_Config", "Cognition_Config", "Lifecycle_Config",
    "Reproduction_Config", "Summary_Metrics", "Time_Series", "Death_Causes",
    "Task_Allocation", "Trait_Summary", "Warnings",
]


@pytest.fixture(scope="module")
def result():
    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 6
    scenario.cognition.experience_enabled = True
    scenario.cognition.forecast_enabled = True
    return run_single(scenario, 0)


# ---------------------------------------------------------------------------
# Excel
# ---------------------------------------------------------------------------
def test_workbook_opens_and_has_required_sheets(result, tmp_path):
    path = tmp_path / "results.xlsx"
    manifest = export_workbook(path, result)
    assert path.exists() and path.stat().st_size > 0

    workbook = load_workbook(path)
    for sheet in REQUIRED_SHEETS:
        assert sheet in workbook.sheetnames, f"missing sheet: {sheet}"
    assert manifest["workbook"] == str(path)


def test_workbook_sheets_are_readable_by_pandas(result, tmp_path):
    path = tmp_path / "results.xlsx"
    export_workbook(path, result)
    time_series = pd.read_excel(path, sheet_name="Time_Series")
    assert len(time_series) > 0
    assert "population" in time_series.columns

    summary = pd.read_excel(path, sheet_name="Summary_Metrics")
    assert {"metric", "value"}.issubset(summary.columns)


def test_workbook_has_freeze_panes_and_filters(result, tmp_path):
    path = tmp_path / "results.xlsx"
    export_workbook(path, result)
    sheet = load_workbook(path)["Time_Series"]
    assert sheet.freeze_panes == "A2"
    assert sheet.auto_filter.ref is not None


def test_oversized_table_spills_to_csv(result, tmp_path, monkeypatch):
    """A table beyond the row limit must be written as CSV, never truncated."""

    import umem_workbench.export.excel as excel_module
    monkeypatch.setattr(excel_module, "_SAFE_ROWS", 5)

    path = tmp_path / "results.xlsx"
    manifest = export_workbook(path, result)

    assert manifest["spilled_csv"], "large table was not spilled to CSV"
    for spilled in manifest["spilled_csv"]:
        spill_path = Path(spilled)
        assert spill_path.exists()
        frame = pd.read_csv(spill_path)
        assert len(frame) > 5  # full data preserved, not truncated


def test_excel_row_limit_constant_is_correct():
    assert EXCEL_MAX_ROWS == 1_048_576


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------
def test_png_export_is_nonempty(result, tmp_path):
    written = export_figures(result, tmp_path, formats=("png",), dpi=300)
    assert written
    for paths in written.values():
        for path in paths:
            assert Path(path).stat().st_size > 1000


def test_png_has_expected_dpi_metadata(result, tmp_path):
    """PNG files record physical pixel density; 300 DPI is ~11811 px/metre."""

    from PIL import Image

    written = export_figures(result, tmp_path, formats=("png",), dpi=300)
    sample = Path(written["population"][0])
    with Image.open(sample) as image:
        assert image.width > 100 and image.height > 100
        dpi = image.info.get("dpi")
        if dpi:
            assert round(dpi[0]) == pytest.approx(300, abs=2)


def test_svg_and_pdf_export(result, tmp_path):
    written = export_figures(result, tmp_path, formats=("svg", "pdf"))
    for paths in written.values():
        for path in paths:
            assert Path(path).stat().st_size > 0
    svg = Path(written["population"][0])
    assert svg.read_text(encoding="utf-8").lstrip().startswith(("<?xml", "<svg"))


def test_unsupported_figure_format_rejected(result, tmp_path):
    with pytest.raises(ValueError):
        export_figures(result, tmp_path, formats=("bmp",))


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------
def test_csv_export_writes_expected_tables(result, tmp_path):
    written = export_run_csvs(result, tmp_path)
    assert "time_series" in written
    frame = pd.read_csv(written["time_series"])
    assert len(frame) == len(result.time_series)


def test_csv_handles_large_results_without_excel_limit(tmp_path):
    """CSV must accept a table Excel could not hold."""

    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 10
    scenario.output.record_interval_steps = 1
    large = run_single(scenario, 0)

    written = export_run_csvs(large, tmp_path)
    frame = pd.read_csv(written["time_series"])
    assert len(frame) == len(large.time_series)


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------
def test_bundle_contains_required_members(result, tmp_path):
    path = export_bundle(tmp_path, result, allow_unsafe_directory=True)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()

    assert "scenario.json" in names
    assert "metadata.json" in names
    assert "results.xlsx" in names
    assert "REPRODUCIBILITY.txt" in names
    assert "warnings.log" in names
    assert "run_report.txt" in names
    assert any(n.startswith("figures/") for n in names)
    assert any(n.startswith("data/") for n in names)


def test_bundle_scenario_can_be_reopened(result, tmp_path):
    """The scenario inside the bundle must load and match the original."""

    from umem_workbench.config.serialization import config_hash

    path = export_bundle(tmp_path, result, allow_unsafe_directory=True)
    with zipfile.ZipFile(path) as archive:
        text = archive.read("scenario.json").decode("utf-8")

    restored = scenario_from_json(text)
    assert config_hash(restored) == result.config_hash


def test_bundle_metadata_is_valid_json_with_seed(result, tmp_path):
    path = export_bundle(tmp_path, result, allow_unsafe_directory=True)
    with zipfile.ZipFile(path) as archive:
        meta = json.loads(archive.read("metadata.json").decode("utf-8"))

    assert meta["config_hash"] == result.config_hash
    assert meta["master_seed"] == result.master_seed
    assert meta["replication_index"] == result.replication_index
    assert "app_version" in meta


def test_bundle_reproducibility_note_mentions_hash_and_seed(result, tmp_path):
    path = export_bundle(tmp_path, result, allow_unsafe_directory=True)
    with zipfile.ZipFile(path) as archive:
        text = archive.read("REPRODUCIBILITY.txt").decode("utf-8")
    assert result.config_hash in text
    assert str(result.master_seed) in text


def test_bundle_refuses_protected_directory(result):
    import sys
    with pytest.raises(UnsafeOutputDirectory):
        export_bundle(Path(sys.prefix) / "umem_output", result)


def test_bundle_with_replications_and_sweep(tmp_path):
    from umem_workbench.config.models import SweepParameter

    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 4
    batch = run_replications(scenario, 2)
    sweep = run_sweep(
        scenario,
        [SweepParameter(path="reproduction.fertility_mean", values=[1.2, 2.0])],
        replications_per_cell=2)

    path = export_bundle(tmp_path, batch.runs[0], replication_result=batch,
                         sweep_result=sweep, allow_unsafe_directory=True)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
    assert any("sweep" in n for n in names)
    assert any("replicate" in n for n in names)


# ---------------------------------------------------------------------------
# Cancelled runs
# ---------------------------------------------------------------------------
def test_cancelled_run_is_labelled_partial_in_exports(tmp_path):
    scenario = load_preset("stable_abundant")
    token = CancellationToken()
    token.cancel("stopped for test")
    cancelled = run_single(scenario, 0, cancel=token)
    assert cancelled.cancelled

    path = tmp_path / "cancelled.xlsx"
    export_workbook(path, cancelled)
    overview = load_workbook(path)["Run_Overview"]

    text = " ".join(str(cell.value) for row in overview.iter_rows()
                    for cell in row if cell.value)
    assert "partial" in text.lower() or "cancelled" in text.lower()

"""Shared pytest fixtures."""

from __future__ import annotations

import pytest

from umem_workbench.config.presets import load_preset


@pytest.fixture
def short_scenario():
    """A fast preset A scenario suitable for mechanism tests."""

    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 4
    scenario.lifecycle.steps_per_season = 20
    scenario.population.initial_population = 60
    return scenario


@pytest.fixture
def tiny_scenario():
    """The smallest scenario that still exercises the whole loop."""

    scenario = load_preset("stable_abundant")
    scenario.lifecycle.total_seasons = 2
    scenario.lifecycle.steps_per_season = 10
    scenario.population.initial_population = 30
    scenario.output.record_interval_steps = 5
    return scenario

# References

Published work the model's design is based on. Design records in
`docs/design/` cite these by author and year.

Inclusion here means the work informed a specific design decision — not that
this project reproduces its results or that its authors endorse this software.

---

## Quantitative genetics and inheritance

**Barton NH, Etheridge AM, Véber A (2017).** The infinitesimal model:
definition, derivation, and implications. *Theoretical Population Biology*
118:50–73. doi:10.1016/j.tpb.2017.06.001
→ ADR-002. The definitive modern statement of the infinitesimal model, and its
derivation as the limit of Mendelian inheritance over many small-effect loci.
This is what licenses representing polygenic inheritance by a single normal draw
without simulating loci.

**Barton NH, Etheridge AM, Véber A (2023).** The infinitesimal model with
dominance. *Genetics* 225(2):iyad133. doi:10.1093/genetics/iyad133
→ ADR-002 future extension. Decomposes trait values into a family-shared
component and an independent per-offspring residual.

**Turelli M (2017).** Commentary: Fisher's infinitesimal model: a story for the
ages. *Theoretical Population Biology* 118:46–49.
→ ADR-002. Historical context, and the "segregation kernel" phenotypic form used
in theoretical evolutionary ecology.

**Lynch M, Walsh B (1998).** *Genetics and Analysis of Quantitative Traits.*
Sinauer.
→ ADR-002. Standard reference; Mendelian sampling variance = 0.5σ²_A without
inbreeding.

**Fisher RA (1918).** The correlation between relatives on the supposition of
Mendelian inheritance. *Transactions of the Royal Society of Edinburgh*
52:399–433.
→ ADR-002. The original.

**Aitchison J (1986).** *The Statistical Analysis of Compositional Data.*
Chapman & Hall.
→ ADR-001. Additive log-ratio transform; the basis for the latent/softmax
representation of proportions.

## Simulation frameworks and reproduction scheduling

**Haller BC, Messer PW (2019).** SLiM 3: forward genetic simulations beyond the
Wright–Fisher model. *Molecular Biology and Evolution* 36(3):632–637.
doi:10.1093/molbev/msy228
→ ADR-003. The non-Wright-Fisher formulation, in which each time step is an
opportunity to reproduce and/or die and generations overlap. This is the
standard justification for continuous distributed reproduction, and it is what
UMEM's previous season-end batch scheduling violated.

**Guillaume F, Rougemont J (2006).** Nemo: an evolutionary and population
genetics programming framework. *Bioinformatics* 22(20):2556–2557.
→ Context. Individual-based, ecology-oriented framework with modular life-cycle
events, the closest architectural analogue to UMEM's engine.

**Neuenschwander S, Hospital F, Guillaume F, Goudet J (2008).** quantiNemo: an
individual-based program to simulate quantitative traits with explicit genetic
architecture in a dynamic metapopulation. *Bioinformatics* 24(13):1552–1553.
→ ADR-005. Offers mating systems as a discrete user choice — promiscuity,
monogamy, polygyny for species with separate sexes — the classification UMEM's
three mating modes follow.

**Peng B, Kimmel M (2005).** simuPOP: a forward-time population genetics
simulation environment. *Bioinformatics* 21(18):3686–3687.
→ Context.

## Mate choice and pair matching

**Geffen N, Scholz S (2017).** Efficient and effective pair-matching algorithms
for agent-based models. *JASSS* 20(4):8. doi:10.18564/jasss.3485
→ ADR-004. Source of the Random-k Pair Matching (RKPM) algorithm: shuffle the
pool, then for each agent select the best of k adjacent candidates. Linear time,
stochastic, and a single parameter k that tunes choosiness — the expected rank
of the chosen partner is n/(k+1). Also the source of the warning that failing to
reshuffle each time step produces a systematic "storage bias" favouring agents
early in the array. UMEM reimplements the published algorithm; no code was
copied.

**Zinn S (2012).** A mate-matching algorithm for continuous-time microsimulation
models. *International Journal of Microsimulation* 5(1):31–51.
→ ADR-004 context. Conceptual framework distinguishing stochastic from stable
matching rules.

## Mating systems and reproductive skew

**Emlen ST, Oring LW (1977).** Ecology, sexual selection, and the evolution of
mating systems. *Science* 197(4300):215–223.
→ ADR-005. The classical framework relating ecological constraints to mating
system.

**Lukas D, Clutton-Brock TH (2013).** The evolution of social monogamy in
mammals. *Science* 341(6145):526–530.
→ ADR-005. Approximately 9% of mammal species are socially monogamous, and it
arises where females are spatially dispersed. Cited to justify presenting the
pair-bonded preset as one abstract point on a continuum rather than as "the
human system".

**Crow JF (1958).** Some possibilities for measuring selection intensities in
man. *Human Biology* 30(1):1–13.
→ Opportunity for selection, I = Var(LRS)/mean(LRS)². Already implemented in
`analysis/metrics.py`; used as the verification metric for reproductive skew
under competitive mating.

---

## A note on scope

These sources describe mechanisms in real biological populations. UMEM is an
abstract theoretical model whose parameters are illustrative and not
empirically calibrated. Citing a source for a mechanism does **not** mean this
software reproduces the quantitative findings of that source. See
`docs/known_limitations.md`.

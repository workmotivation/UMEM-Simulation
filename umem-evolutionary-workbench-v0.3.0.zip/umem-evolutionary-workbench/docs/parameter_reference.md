# Parameter reference

Configuration schema version 2. Generated from the model definitions by `umem-workbench data-dictionary --format markdown`; do not edit by hand.

Scenario files are JSON or YAML. Paths use dotted notation; list elements may be addressed by identifier, e.g. `tasks.safe_forage.energy_cost`.

**Column guide.** *Kind* classifies the unit-time meaning (rate, probability, interval, count, threshold, mode, weight, scale), which matters when converting between per-season and per-step parameterisations. *Applies to* states which mechanism configuration the field is active under; a field marked `legacy_timing_only` or `legacy_inheritance_only` is **ignored** under the new defaults and the validator warns if it is changed. *Since* is the schema version that introduced the field.

> All defaults are illustrative demonstration values, not calibrated to any real species. See `known_limitations.md`.

---

## `scenario`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `schema_version` | int | `2` |  |  |  | all | 1 | Config schema version. |  |  |
| `name` | str | `Untitled` |  |  |  | all | 1 | Display name. |  |  |
| `description` | str | `` |  |  |  | all | 1 | Free text. |  |  |
| `preset_origin` | str (optional) | none |  |  |  | all | 1 | Preset this derives from, if any. |  |  |
| `master_seed` | int | `12345` | 0 to … |  |  | all | 1 | Root seed for reproducibility. |  |  |

## `population`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `founder_age_distribution` | enum: `all_newborn_legacy`, `uniform`, `stable` | `uniform` |  |  | mode | all | 2 | Age structure of the initial population. | 'all_newborn_legacy' starts every founder at age zero (v0.1.0). 'uniform' spreads ages evenly over the permitted lifespan. 'stable' approximates the stable age distribution implied by the configured baseline hazards. Founder synchrony is an early transient, not the cause of persistent population sawtoothing. | ADR-006 |
| `initial_population` | int | `200` | 2 to … | agents |  | all | 1 | Starting agents. |  |  |
| `carrying_capacity` | int | `500` | 1 to … | agents |  | all | 1 | Soft population ceiling. |  |  |
| `max_population` | int | `5000` | 1 to … | agents |  | all | 1 | Hard cap for memory safety. |  |  |
| `init_distribution` | enum: `equal`, `gamma`, `lognormal`, `from_file` | `gamma` |  |  |  | all | 1 | Propensity init distribution. |  |  |
| `sex_ratio_type_a` | float | `0.5` | 0.0 to 1.0 | frac |  | all | 1 | Fraction born as reproductive type A. |  |  |
| `starting_population_file` | str (optional) | none |  |  |  | all | 1 | Path for from_file init. |  |  |

## `lifecycle`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `steps_per_season` | int | `40` | 1 to … | steps |  | all | 1 | Time steps in a season. |  |  |
| `total_seasons` | int | `30` | 1 to … | seasons |  | all | 1 | Seasons to simulate. |  |  |
| `actions_per_step` | int | `1` | 1 to … |  |  | all | 1 | Tasks drawn per step. |  |  |
| `initial_energy` | float | `70.0` | 0.0 to … | 0-100 |  | all | 1 | Newborn energy. |  |  |
| `energy_max` | float | `100.0` | 0.0 to … | 0-100 |  | all | 1 | Energy ceiling. |  |  |
| `initial_health` | float | `90.0` | 0.0 to … | 0-100 |  | all | 1 | Newborn health. |  |  |
| `health_max` | float | `100.0` | 0.0 to … | 0-100 |  | all | 1 | Health ceiling. |  |  |
| `initial_repro_capital` | float | `0.0` | 0.0 to … | 0-100 |  | all | 1 | Newborn reproductive capital. |  |  |
| `repro_capital_max` | float | `100.0` | 0.0 to … | 0-100 |  | all | 1 | Ceiling. |  |  |
| `initial_status` | float | `50.0` | 0.0 to … | 0-100 |  | all | 1 | Newborn status. |  |  |
| `status_max` | float | `100.0` | 0.0 to … | 0-100 |  | all | 1 | Ceiling. |  |  |
| `basal_metabolism` | float | `1.0` | 0.0 to … | energy/step |  | all | 1 | Energy lost per step. |  |  |
| `rest_energy_cost` | float | `0.5` | 0.0 to … | energy |  | all | 1 | Energy for fallback rest. |  |  |
| `health_starvation_penalty` | float | `10.0` | 0.0 to … | health/step |  | all | 1 | Health lost per step at zero energy. |  |  |
| `maturity_seasons` | int | `2` | 0 to … | seasons |  | all | 1 | Age of reproductive maturity. |  |  |
| `max_lifespan_seasons` | int | `12` | 1 to … | seasons |  | all | 1 | Hard lifespan ceiling. |  |  |
| `newborns_act_next_step` | bool | `True` |  |  |  | all | 1 | Newborns act from the next step, not immediately. |  |  |

## `mortality`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `base_predation_hazard` | float | `0.02` | 0.0 to 1.0 | prob |  | all | 1 | Per-step baseline predation hazard. |  |  |
| `predation_env_driver` | str (optional) | `predator` |  |  |  | all | 1 | Env variable scaling predation. |  |  |
| `predation_env_sensitivity` | float | `1.0` | 0.0 to … |  |  | all | 1 | Scaling of hazard by driver. |  |  |
| `age_hazard_shape` | enum: `gompertz`, `logistic` | `gompertz` |  |  |  | all | 1 | Gompertz or logistic senescence. |  |  |
| `age_hazard_scale` | float | `0.002` | 0.0 to … |  |  | all | 1 | Baseline age hazard. |  |  |
| `age_hazard_rate` | float | `0.15` | 0.0 to … |  |  | all | 1 | Growth of hazard with age (per season). |  |  |
| `background_hazard` | float | `0.0` | 0.0 to 1.0 | prob |  | all | 1 | Constant per-step mortality. |  |  |
| `juvenile_extra_hazard` | float | `0.0` | 0.0 to 1.0 | prob |  | all | 1 | Extra per-step hazard before maturity. |  |  |
| `density_hazard_strength` | float | `0.5` | 0.0 to … |  |  | all | 1 | Extra hazard as pop approaches K. |  |  |
| `density_onset_fraction` | float | `0.6` | 0.0 to … |  |  | all | 1 | Fraction of carrying capacity at which crowding mortality begins. Below this the density hazard is zero. |  |  |
| `density_affects_juveniles_only` | bool | `True` |  |  |  | all | 1 | Apply density hazard only to juveniles. |  |  |

## `reproduction`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `mode` | enum: `sexual`, `asexual` | `sexual` |  |  | mode | all | 1 | Sexual or asexual reproduction. | Sexual requires one Type-A and one Type-B agent per event; asexual requires none. |  |
| `timing` | enum: `distributed`, `season_end_legacy` | `distributed` |  |  | mode | all | 2 | Continuous (recommended) or legacy season-end batching. | Under 'distributed' every time step is an opportunity to reproduce, as in a non-Wright-Fisher model, and season boundaries carry no reproductive meaning. 'season_end_legacy' reproduces the v0.1.0 behaviour in which all eligible agents breed together on the last step of a season; it is a compatibility mode and produces a season-period sawtooth in population size. | ADR-003; Haller & Messer 2019 (SLiM 3) |
| `reproductive_event_rate` | float | `1.0` | 0.0 to … | events/agent/season | rate | distributed_only | 2 | Reproductive *attempt events* per eligible agent per season. | An event rate, not a birth count. Births per event = this rate x P(partner found) x fertility per event x juvenile survival, so realised births are lower. Converted to a per-step hazard by 1 - exp(-rate / steps_per_season), so expected events per season do not change with time resolution; geometric waiting times desynchronise reproduction. The former name 'expected_births_per_season' is accepted on input and was misleading. | ADR-003 |
| `refractory_seasons` | float | `0.0` | 0.0 to … | seasons | interval | all | 2 | Minimum time before breeding again after success. | Starts only after a *successful* reproductive event; failed attempts do not trigger it and cost nothing. Stored internally in steps. | ADR-003 |
| `mating_mode` | enum: `random`, `pair_bonded`, `competitive` | `random` |  |  | mode | sexual_only | 2 | Random mixing, pair bonding, or competitive. | Random = promiscuity (no bonds, no preference); pair_bonded = social monogamy (exclusive, persistent); competitive = polygyny-like skew (choosy, non-exclusive). All three run through the same matching engine and differ only in persistence, exclusivity and choosiness. | ADR-005; quantiNemo (Neuenschwander et al. 2008) |
| `mate_choice_k` | int | `1` | 1 to … | candidates | count | sexual_only | 2 | Number of candidates inspected per choice. | Random-k pair matching: the chooser inspects k randomly drawn candidates and takes the best. k=1 is unbiased random mating; the expected rank of the chosen partner is n/(k+1), so larger k concentrates reproductive success and raises the opportunity for selection. | ADR-004; Geffen & Scholz 2017 |
| `mate_choice_criterion` | enum: `partner_quality`, `similarity` | `partner_quality` |  |  | mode | sexual_only | 2 | Maximise partner quality, or match similarity. | Partner quality produces reproductive skew; similarity produces assortative mating. | ADR-004 |
| `mate_quality_weights` | dict[str, float] | `{"status": 1.0, "repro_capital": 0.3, "health": 0.25, "energy": 0.25}` |  |  | weight | sexual_only | 2 | Weights over agent state defining mate quality. | A declarative weighted sum over normalised state variables. Only these four keys are permitted; no user expression is ever evaluated. Weight non-depletable traits such as status to obtain reproductive skew: reproductive capital is reset when an agent breeds, so choosing on it makes 'quality' amount to 'time since last breeding', which equalises rather than concentrates reproductive success. | ADR-004 |
| `bond_formation_per_season` | float | `2.0` | 0.0 to … | events/agent/season | rate | pair_bond_only | 2 | Rate at which unpaired mature agents form bonds. | Bond formation requires maturity only. Energy, health and capital thresholds govern whether a bond can reproduce, not whether it can form. | ADR-005 |
| `bond_dissolution_per_season` | float | `0.0` | 0.0 to … | events/pair/season | rate | pair_bond_only | 2 | Rate at which existing bonds dissolve. | Zero by default, so bonds end only at the death of a partner. A conservative non-zero value models serial monogamy. | ADR-005 |
| `breeding_every_seasons` | int | `1` | 1 to … | seasons | interval | legacy_timing_only | 1 | Seasons between breeding events under season-end timing. **Deprecated:** Use reproduction.refractory_seasons with distributed timing. | Active only when timing is season_end_legacy. Distributed timing uses refractory_seasons instead; this field is then ignored. |  |
| `energy_threshold` | float | `40.0` | 0.0 to … | 0-100 |  | all | 1 | Min energy to breed. |  |  |
| `health_threshold` | float | `30.0` | 0.0 to … | 0-100 |  | all | 1 | Min health to breed. |  |  |
| `repro_capital_threshold` | float | `0.0` | 0.0 to … | 0-100 |  | all | 1 | Min reproductive capital to breed. |  |  |
| `mate_selection` | enum: `random`, `weighted_capital`, `competitive`, `assortative` | `weighted_capital` |  |  |  | all | 1 | How mates are chosen. |  |  |
| `mate_availability_driver` | str (optional) | `mate` |  |  |  | all | 1 | Env variable for mate availability. |  |  |
| `max_offspring_per_event` | int | `3` | 1 to … |  |  | all | 1 | Cap per breeding event. |  |  |
| `fertility_distribution` | enum: `fixed`, `poisson`, `binomial`, `discrete` | `poisson` |  |  |  | all | 1 | Distribution of surviving offspring. |  |  |
| `fertility_mean` | float | `1.5` | 0.0 to … | offspring |  | all | 1 | Mean surviving offspring per event. |  |  |
| `fertility_binomial_p` | float | `0.5` | 0.0 to 1.0 | prob |  | all | 1 | Success prob for binomial fertility. |  |  |
| `fertility_discrete_pmf` | list[float] | empty |  |  |  | all | 1 | Probabilities for 0,1,2,... offspring. |  |  |
| `repro_energy_cost` | float | `20.0` | 0.0 to … | energy |  | all | 1 | Energy spent per breeding. |  |  |
| `repro_health_cost` | float | `5.0` | 0.0 to … | health |  | all | 1 | Health spent per breeding. |  |  |
| `gestation_delay_steps` | int | `0` | 0 to … | steps | interval | legacy_timing_only | 1 | Steps before offspring appear under season-end timing. **Deprecated:** No gestation model exists under distributed timing. | The continuous (distributed) model has no gestation mechanism: a non-zero value is a blocking validation error under distributed timing, never silently ignored. Retained for reproducing season-end legacy scenarios only. |  |
| `juvenile_survival` | float | `0.85` | 0.0 to 1.0 | prob |  | all | 1 | Prob a newborn survives to enter pop. |  |  |
| `density_dependent_recruitment` | bool | `True` |  |  |  | all | 1 | Soft Beverton-Holt decline of juvenile survival as population approaches carrying capacity. |  |  |
| `recruitment_strength` | float | `1.0` | 0.0 to … |  |  | all | 1 | Steepness of density-dependent recruitment. |  |  |

## `inheritance`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `model` | enum: `polygenic_additive`, `legacy` | `polygenic_additive` |  |  | mode | all | 2 | Polygenic additive (recommended) or the legacy v0.1.0 mechanism. | Polygenic additive treats propensities as latent quantitative traits inherited by Fisher's infinitesimal model, the standard approximation to many small-effect Mendelian loci. Legacy is a compatibility mode for scenarios written before schema 2. | ADR-002; Barton, Etheridge & Veber 2017 |
| `sibling_variation` | enum: `low`, `standard`, `high`, `custom` | `standard` |  |  | mode | polygenic_only | 2 | How much full siblings differ through segregation. | Scales the Mendelian segregation variance. At 'standard' the configured founder variance is the equilibrium, so genetic variation neither inflates nor decays as an artifact. | ADR-002 |
| `segregation_multiplier` | float | `1.0` | 0.0 to … | x V0/2 | scale | polygenic_only | 2 | Used when sibling variation is custom. | Segregation variance is multiplier x V0 / 2, where V0 is the configured founder additive variance. The 0.5 factor is the Mendelian sampling variance of an outbred individual. | ADR-002; Lynch & Walsh 1998 ch.7 |
| `mutation_level` | enum: `none`, `conservative`, `accelerated`, `custom` | `conservative` |  |  | mode | polygenic_only | 2 | None, conservative, accelerated, or custom. | Rare introduction of novel variation, configured and reported separately from segregation. These are effective simulation parameters, not empirical per-base mutation rates. | ADR-002 |
| `mutation_probability_per_offspring` | float | `0.01` | 0.0 to 1.0 | prob/offspring | probability | polygenic_only | 2 | Chance of an effective mutation per offspring. | Probability that an offspring experiences one effective mutation event in a given propensity layer. | ADR-002 |
| `mutation_effect_sd_latent` | float | `0.1` | 0.0 to … | latent sd | scale | polygenic_only | 2 | Zero-mean effect sd, absolute latent units. | Standard deviation of the mutation increment on the latent log-ratio scale; 0.10 is roughly a 10% change in relative odds. Absolute units are used so that a scenario with zero founder variance still mutates. | ADR-002 |
| `mutation_target` | enum: `domain`, `task`, `both` | `both` |  |  | mode | polygenic_only | 2 | Which propensity layer mutation may strike. | Domain, task, or both. Layers are judged independently when set to both. | ADR-002 |
| `mutation_probability` | float | `1.0` | 0.0 to 1.0 | prob | probability | legacy_inheritance_only | 1 | Prob a trait mutates. **Deprecated:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. | v0.1.0 |
| `mutation_log_sd` | float | `0.1` | 0.0 to … |  | scale | legacy_inheritance_only | 1 | Log-normal mutation sd (multiplicative). **Deprecated:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. | v0.1.0 |
| `recombination_per_trait` | bool | `True` |  |  | mode | legacy_inheritance_only | 1 | Pick each trait from one parent vs. blend. **Deprecated:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. | v0.1.0 |
| `blend_alpha` | float | `0.5` | 0.0 to 1.0 |  | weight | legacy_inheritance_only | 1 | Parent-A weight when blending. **Deprecated:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. | v0.1.0 |
| `min_propensity` | float | `0.01` | 0.0 to … |  | threshold | all | 1 | Floor keeping traits positive. | Legacy floor, and the floor that keeps the legacy-to-latent log conversion finite. | ADR-001 |

## `homeostasis`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `enabled` | bool | `True` |  |  |  | all | 1 | Master switch. |  |  |
| `hunger_enabled` | bool | `True` |  |  |  | all | 1 | Energy urgency on. |  |  |
| `hunger_strength` | float | `2.0` | 0.0 to … |  |  | all | 1 | Logit boost to food tasks when hungry. |  |  |
| `safety_enabled` | bool | `True` |  |  |  | all | 1 | Threat urgency on. |  |  |
| `safety_strength` | float | `2.0` | 0.0 to … |  |  | all | 1 | Logit boost to safety tasks under threat. |  |  |
| `reproduction_enabled` | bool | `True` |  |  |  | all | 1 | Reproductive urgency on. |  |  |
| `reproduction_strength` | float | `2.0` | 0.0 to … |  |  | all | 1 | Logit boost to reproduction when ready. |  |  |

## `cognition`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `experience_enabled` | bool | `False` |  |  |  | all | 1 | Intergenerational memory on. |  |  |
| `experience_success_definition` | enum: `survived`, `reproduced`, `surviving_offspring`, `top_quantile_lrs` | `surviving_offspring` |  |  |  | all | 1 | Who counts as successful. |  |  |
| `experience_top_quantile` | float | `0.2` | 0.0 to 1.0 |  |  | all | 1 | Quantile for top-LRS definition. |  |  |
| `experience_weight_recent` | float | `0.7` | 0.0 to 1.0 |  |  | all | 1 | Weight on the most recent cohort. |  |  |
| `experience_smoothing` | float | `1.0` | 0.0 to … |  |  | all | 1 | Additive smoothing on counts. |  |  |
| `experience_noise_sd` | float | `0.3` | 0.0 to … |  |  | all | 1 | Noise on the memory signal. |  |  |
| `experience_strength` | float | `2.5` | 0.0 to … |  |  | all | 1 | Logit multiplier from memory. |  |  |
| `forecast_enabled` | bool | `False` |  |  |  | all | 1 | Noisy env forecasting on. |  |  |
| `forecast_memory` | float | `0.6` | 0.0 to 1.0 |  |  | all | 1 | EWMA lambda on past forecast. |  |  |
| `forecast_strength` | float | `1.0` | 0.0 to … |  |  | all | 1 | Logit shift from forecast surprise. |  |  |
| `individual_learning_enabled` | bool | `False` |  |  |  | all | 1 | Per-agent EWMA reinforcement (advanced). |  |  |
| `individual_learning_rate` | float | `0.2` | 0.0 to 1.0 |  |  | all | 1 | EWMA rate on own outcomes. |  |  |
| `individual_learning_strength` | float | `1.0` | 0.0 to … |  |  | all | 1 | Logit shift from own experience. |  |  |

## `choice`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `softmax_temperature` | float | `1.0` | 0.0 to … |  |  | all | 1 | Higher = more random choice. |  |  |
| `decision_noise_sd` | float | `0.1` | 0.0 to … |  |  | all | 1 | Gumbel-like logit noise sd. |  |  |

## `experiment`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `mode` | enum: `single`, `replications`, `sweep` | `single` |  |  |  | all | 1 | single/replications/sweep. |  |  |
| `replications` | int | `1` | 1 to … | runs |  | all | 1 | Independent repeats. |  |  |
| `max_workers` | int | `1` | 1 to … |  |  | all | 1 | Parallel processes for replicates. |  |  |
| `sweep_parameters` | list[SweepParameter] | empty |  |  |  | all | 1 | 1-3 parameters to sweep. |  |  |
| `max_sweep_combinations` | int | `500` | 1 to … |  |  | all | 1 | Warn/refuse above this. |  |  |
| `common_random_numbers` | bool | `False` |  |  |  | all | 1 | Reuse seeds across sweep conditions. |  |  |

## `output`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `record_interval_steps` | int | `10` | 1 to … | steps |  | all | 1 | Steps between snapshots. |  |  |
| `store_agent_sample` | bool | `True` |  |  |  | all | 1 | Store a reproducible agent sample. |  |  |
| `agent_sample_size` | int | `50` | 1 to … |  |  | all | 1 | Agents per snapshot sample. |  |  |
| `store_event_log` | bool | `False` |  |  |  | all | 1 | Store detailed events (large!). |  |  |

## `domains`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `domain_id` | str | required |  |  |  | all | 1 | Immutable key. |  |  |
| `name` | str | required |  |  |  | all | 1 | Display name. |  |  |
| `init_mean` | float | `1.0` | 0.0 to … |  |  | all | 1 | Mean initial propensity. |  |  |
| `init_var` | float | `0.5` | 0.0 to … |  |  | all | 1 | Initial variance. |  |  |

## `tasks`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `task_id` | str | required |  |  |  | all | 1 | Immutable unique key. |  |  |
| `name` | str | required |  |  |  | all | 1 | Display name. |  |  |
| `description` | str | `` |  |  |  | all | 1 | Free text. |  |  |
| `domain` | str | required |  |  |  | all | 1 | Behavioural domain id. |  |  |
| `enabled` | bool | `True` |  |  |  | all | 1 | Include in runs. |  |  |
| `time_cost` | float | `1.0` | 0.0 to … | steps |  | all | 1 | Time steps consumed. |  |  |
| `energy_cost` | float | `1.0` | 0.0 to … | energy |  | all | 1 | Direct energy spent. |  |  |
| `base_success` | float | `0.2` | 0.0 to 1.0 | prob |  | all | 1 | Baseline success probability. |  |  |
| `success_env_driver` | str (optional) | none |  |  |  | all | 1 | Env variable modulating success. |  |  |
| `success_env_sensitivity` | float | `0.0` |  |  |  | all | 1 | Logit shift per unit env driver. |  |  |
| `outcome_noise` | float | `0.3` | 0.0 to … |  |  | all | 1 | Logit noise sd on success. |  |  |
| `predation_multiplier` | float | `1.0` | 0.0 to … |  |  | all | 1 | Per-step hazard multiplier. |  |  |
| `min_age_steps` | int | `0` | 0 to … |  |  | all | 1 | Age gate. |  |  |
| `max_age_steps` | int (optional) | none |  |  |  | all | 1 | Upper age gate (optional). |  |  |
| `require_mature` | bool | `False` |  |  |  | all | 1 | Maturity gate. |  |  |
| `sex_restriction` | enum: `any`, `type_a`, `type_b` | `any` |  |  |  | all | 1 | Reproductive-type gate. |  |  |
| `observable_to_actor` | bool | `True` |  |  |  | all | 1 | Actor sees its own outcome. |  |  |
| `public_signal` | bool | `False` |  |  |  | all | 1 | Non-actors see a weak public signal. |  |  |
| `role` | enum: `functional`, `low_cost_neutral`, `costly_nonfunctional` | `functional` |  |  |  | all | 1 | functional / neutral / costly nonfunctional. |  |  |
| `memory_eligible` | bool | `True` |  |  |  | all | 1 | May enter intergenerational memory. |  |  |
| `effects` | list[TaskEffectRule] | empty |  |  |  | all | 1 | Multidimensional effects. |  |  |
| `target` | enum: `energy`, `health`, `repro_capital`, `status`, `hazard`, `observation_quality` | required |  |  |  | all | 1 | State variable this rule changes. |  |  |
| `effect_type` | enum: `additive`, `multiplicative`, `probability_modifier`, `bounded_replacement` | `additive` |  |  |  | all | 1 | How the value combines with state. |  |  |
| `base_value` | float | `0.0` |  | state units |  | all | 1 | Magnitude before env scaling. |  |  |
| `condition` | enum: `always`, `on_success`, `on_failure` | `on_success` |  |  |  | all | 1 | Fires on success, failure, or always. |  |  |
| `env_driver` | str (optional) | none |  |  |  | all | 1 | Env variable id that scales this effect. |  |  |
| `env_sensitivity` | float | `0.0` |  |  |  | all | 1 | Coupling of the effect to the env driver. |  |  |
| `noise_std` | float | `0.0` | 0.0 to … | state units |  | all | 1 | Gaussian noise on the effect. |  |  |
| `min_age_steps` | int | `0` | 0 to … |  |  | all | 1 | Rule inactive below this age. |  |  |
| `require_mature` | bool | `False` |  |  |  | all | 1 | Rule only for mature agents. |  |  |
| `sex_restriction` | enum: `any`, `type_a`, `type_b` | `any` |  |  |  | all | 1 | Reproductive type this rule needs. |  |  |

## `environment`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `var_id` | str | required |  |  |  | all | 1 | Immutable unique key. |  |  |
| `name` | str | required |  |  |  | all | 1 | Display name. |  |  |
| `description` | str | `` |  |  |  | all | 1 | Free text. |  |  |
| `process` | enum: `constant`, `random_walk`, `ar1`, `seasonal`, `ar1_seasonal`, `regime_switching`, `rare_shocks`, `imported` | `ar1` |  |  |  | all | 1 | Stochastic process type. |  |  |
| `initial_value` | float | `0.5` |  | norm 0-1 |  | all | 1 | Value at t=0. |  |  |
| `mean` | float | `0.5` |  | norm 0-1 |  | all | 1 | Reversion target. |  |  |
| `min_value` | float | `0.0` |  | norm |  | all | 1 | Lower bound. |  |  |
| `max_value` | float | `1.0` |  | norm |  | all | 1 | Upper bound. |  |  |
| `persistence` | float | `0.9` | 0.0 to 1.0 |  |  | all | 1 | AR(1) autocorrelation. |  |  |
| `volatility` | float | `0.05` | 0.0 to … |  |  | all | 1 | Innovation sd. |  |  |
| `seasonal_amplitude` | float | `0.0` | 0.0 to … |  |  | all | 1 | Seasonal amplitude. |  |  |
| `seasonal_period_steps` | int | `40` | 1 to … | steps |  | all | 1 | Steps per cycle. |  |  |
| `shock_probability` | float | `0.0` | 0.0 to 1.0 | prob |  | all | 1 | Per-step shock probability. |  |  |
| `shock_magnitude` | float | `0.0` |  |  |  | all | 1 | Additive shock magnitude. |  |  |
| `shock_duration_steps` | int | `1` | 1 to … | steps |  | all | 1 | Steps a shock persists. |  |  |
| `regime_values` | list[float] | empty |  |  |  | all | 1 | Values for regime switching. |  |  |
| `regime_switch_prob` | float | `0.02` | 0.0 to 1.0 | prob |  | all | 1 | Per-step switch probability. |  |  |
| `imported_series` | list[float] | empty |  |  |  | all | 1 | User time series (process=imported). |  |  |
| `observation_noise` | float | `0.05` | 0.0 to … |  |  | all | 1 | Noise sd on agent observations. |  |  |
| `globally_observable` | bool | `True` |  |  |  | all | 1 | Directly observed by agents. |  |  |

## `experiment.sweep_parameters`

| Parameter | Type | Default | Range | Unit | Kind | Applies to | Since | Description | Scientific interpretation | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| `path` | str | required |  |  |  | all | 1 | Dotted config path, e.g. mortality.base_predation_hazard. |  |  |
| `values` | list[float] | empty |  |  |  | all | 1 | Explicit values. |  |  |
| `start` | float (optional) | none |  |  |  | all | 1 | Range start. |  |  |
| `stop` | float (optional) | none |  |  |  | all | 1 | Range stop. |  |  |
| `step` | float (optional) | none |  |  |  | all | 1 | Range step. |  |  |
| `logarithmic` | bool | `False` |  |  |  | all | 1 | Log-spaced range. |  |  |


# Model reference

A precise description of what the simulation computes. Notation: `t` is a time
step, `s` a season. A season contains `steps_per_season` steps; a run contains
`total_seasons` seasons.

---

## 1. State

Each agent carries:

| Variable | Range | Meaning |
|---|---|---|
| `energy` | 0–100 | Depleted by metabolism and action costs, restored by food tasks. Reaching zero causes health loss. |
| `health` | 0–100 | Reduced by starvation and injury. Reaching zero is fatal. |
| `repro_capital` | 0–100 | Accumulated readiness to breed. |
| `status` | 0–100 | Social standing; influences mate choice under some modes. |
| `age_steps` | ≥ 0 | Age; maturity and senescence derive from it. |

Heritable traits are strictly positive and hierarchical:

- one **domain propensity** per motivational domain (food, safety, reproduction,
  neutral);
- one **task propensity** per task within its domain.

The effective weight of a task is the product of the two, entering the decision
in log-odds.

---

## 2. Time step

The order below is fixed and matches the specification.

1. **Environment updates.** Trajectories are generated in advance from the
   environment stream, so the environment is exogenous: it does not respond to
   the population.
2. **Noisy observation.** Each agent perceives `env[t]` plus Gaussian noise
   scaled by `observation_noise`. There is no look-ahead: `env[t+1]` is never
   visible to any decision at `t`.
3. **Cognitive updates.** Forecast (B) advances on the current observation;
   experience memory (A) refreshes at season boundaries.
4. **Homeostatic urgencies.**
   - hunger `= 1 − energy / energy_max`
   - threat `=` blend of low health and perceived predator level
   - reproductive readiness `=` maturity gate × energy and health gates
5. **Eligibility.** Tasks are filtered by minimum age, maturity requirement, and
   sex restriction.
6. **Logits.** For each eligible task:

   ```
   logit = log(domain_propensity)
         + log(task_propensity)
         + homeostatic_urgency  × channel_weight
         + experience_modifier                    (cognition A)
         + forecast_modifier                      (cognition B)
         + individual_preference                  (cognition C)
         + decision_noise
   ```

   All contributions are additive in log-odds. Ineligible tasks receive `−inf`.
7. **Choice.** A softmax over the logits with `softmax_temperature`, sampled by
   inverse CDF. `actions_per_step` draws are made.
8. **Costs.** The chosen task's `energy_cost`; agents with no eligible task pay
   `rest_energy_cost`. Basal metabolism is charged once per step.
9. **Success.** `P(success) = sigmoid(base_logit + env_sensitivity × driver +
   noise)`.
10. **Effects.** Each effect rule applies to its target
    (energy, health, reproductive capital, status, observation quality, hazard)
    with a type (additive, multiplicative, probabilistic, bounded replacement)
    and a condition (on success, on failure, always). Rules are **declarative
    data**; no user expression is ever evaluated.
11. **Hazards.** Combined as independent competing risks:

    ```
    P(death) = 1 − Π (1 − hazard_i)
    ```

    Sources: predation, senescence, background, juvenile, crowding, plus the
    deterministic state deaths (starvation, health failure, maximum lifespan).

    Predation is scaled by the environment, by any hazard effects, **and by the
    chosen task's `predation_multiplier`** — sheltering is safer than open
    foraging. Exposure applies whether or not the task succeeded.
12. **Death and attribution.** Deterministic causes are resolved first
    (starvation if energy is also zero, otherwise health failure; then maximum
    lifespan). For probabilistic death, the cause is sampled in proportion to
    the contributing hazards, so every death carries an attributed cause.
13. **Ageing and recording.** Age advances, maturity is updated, and a snapshot
    is written at the configured interval.

---

## 3. Reproduction (schema 2)

### Timing

Every time step is an opportunity to reproduce, following the non-Wright-Fisher
convention (ADR-003). Season boundaries carry **no** reproductive meaning.
Reproductive intensity is a **rate**:

```
h_step = 1 - exp(-reproductive_event_rate / steps_per_season)   # an *event* rate
```

so expected events per season do not change when the time resolution changes.
The rate counts reproductive *attempt events*, not births: realised births equal
events x P(partner found) x fertility per event x juvenile survival. A refractory
period, if configured, starts only after a *successful* event; failed attempts
cost nothing. Gestation delay is **not** part of the continuous model; a
non-zero `gestation_delay_steps` under distributed timing is a blocking
validation error, never silently ignored.

`reproduction.timing = season_end_legacy` restores the previous behaviour in
which all eligible agents bred on the last step of each season. It is a
compatibility mode: it imposes strict breeding synchrony and produces a
season-period sawtooth in population size.

### Eligibility versus mate choice

These are separate. **Eligibility** asks who is *capable*: mature, above the
energy, health and reproductive-capital thresholds, and out of refractory
period. **Mate choice** asks which of those capable agents actually obtains a
reproductive opportunity. Conflating them makes a demographic constraint
indistinguishable from a sexual-selection effect.

### Mate choice

Random-k Pair Matching (ADR-004): the pool is reshuffled every step, each
initiator inspects `k` randomly drawn candidates from the whole eligible
complementary pool, and takes the best. The expected rank of the chosen partner
among `n` candidates is `n / (k + 1)`, so a single parameter spans unbiased
random mating (`k = 1`) to strong reproductive skew.

Quality is a weighted sum over four permitted normalised state variables
(reproductive capital, status, health, energy). Weight a **non-depletable**
trait such as status to obtain skew: reproductive capital is reset when an agent
breeds, so choosing on it makes "quality" mean "time since last breeding", which
equalises rather than concentrates reproductive success.

### Mating modes

| Mode | Standard term | Persists | Exclusive |
|---|---|---|---|
| `random` | promiscuity | no | — |
| `pair_bonded` | social monogamy | yes | yes, 1:1 |
| `competitive` | polygyny-like skew | no | no |

All three run through one engine. Type A and Type B are neutral reproductive
types, never male and female; neither is pregnant and neither contributes more
genetically. Asexual reproduction needs no partner and bypasses matching.

**Pair-bond eligibility semantics.** Bond *formation* requires maturity only;
bond *reproduction* additionally requires the energy, health and
reproductive-capital thresholds for **both** partners at the same step. Because
each partner is in condition only part of the time, joint eligibility is
roughly the product of the two, so a bonded pair reproduces far less often than
the configured rate alone would suggest (about 15–22% of bond-steps in the
shipped preset). This is why `pair_bonded_humanlike` carries a higher event rate
than the random-mating presets; it is a demographic consequence of exclusivity,
not an implementation bottleneck.

### Reproduction summary metrics

The breeding series has one row per **step** under distributed timing and one
per **season** under legacy timing, so every summary metric names its
denominator: `mean_pairs_per_step` (distributed only; `nan` under legacy),
`mean_total_pairs_per_season` (sum within season, then mean across seasons; both
modes), `mean_eligible_agents_per_step` (instantaneous stock),
`mean_eligible_agent_steps_per_season` (an exposure, not unique agents). Totals
(`total_reproductive_attempts`, `total_failed_no_partner`,
`total_successful_events`, `total_offspring_pre_survival`,
`total_offspring_survived`) are unambiguous in both modes. Concentration
measures — `lrs_gini`, `lrs_top20pct_share`, `birth_phase_entropy`,
`failed_match_rate` — are descriptive and are not fitness functions.

### Recruitment

Fertility is drawn per successful event, then juvenile survival is applied with
optional Beverton–Holt density dependence:

```
effective_survival = juvenile_survival / (1 + recruitment_strength * N / K)
```

Parental costs are symmetric and fall only on agents that actually bred.

## 4. Inheritance (schema 2)

Propensities are **polygenic quantitative traits**, not identified single genes.

### Latent scale

The heritable component of each layer is a centred latent vector `g` on the
unconstrained real line, expressed as proportions by `p = softmax(g)` (ADR-001).
The domain layer and each within-domain task layer are normalised independently.
Inheritance on an unconstrained scale avoids the clipping bias and spurious
negative correlations that come from perturbing proportions and renormalising.

### Sexual: the infinitesimal model

```
g_child = (g_A + g_B) / 2 + eps_seg + eps_mut
eps_seg ~ N(0, s * V0 / 2)
```

`V0` is the additive variance of the configured founder distribution, and the
factor of one half is the Mendelian sampling variance of an outbred individual.
This makes the founder variance the equilibrium: neutral reproduction neither
inflates nor erodes genetic variance, so an observed change is informative.
Segregation is drawn independently per offspring, so full siblings differ. The
formula is symmetric, so relabelling parents A and B cannot change the offspring
distribution.

### Asexual

```
g_child = g_parent + eps_mut
```

No averaging, no segregation. Without mutation the heritable component is a
clonal copy; expressed behaviour can still differ through environment,
homeostasis, cognition and action-selection noise.

### Mutation

Configured and reported **separately** from segregation, because they are
different processes: segregation reshuffles existing variation at every event,
mutation introduces novel variation rarely. Each offspring mutates with
probability `p`; if it does, one uniformly chosen component receives a
zero-mean `N(0, sigma^2)` increment in **absolute latent units**.

Presets: none; conservative (p = 0.01, sd = 0.10); accelerated (p = 0.05, sd =
0.20). These are **effective simulation parameters**, not human per-base
mutation rates.

## 5. Cognition

**A — Intergenerational experience.** A population-level memory over
memory-eligible tasks, built from the success distribution of the two most
recent successful cohorts, smoothed, noised, and applied as an additive logit
shift. The association it encodes is *correlational*: a task can become well
represented simply because successful agents had time to perform it. This is the
main route to cognitive misallocation.

**B — Forecasting.** An exponentially weighted moving average per environmental
variable, built only from past noisy observations:

```
forecast[t] = λ · forecast[t−1] + (1 − λ) · observation[t]
```

The shift applied to a task is proportional to that task's environmental
sensitivity times the forecast's departure from the long-run mean. The forecast
is **shared across the population**, not held per agent — a documented
simplification.

**C — Individual learning.** Per-agent EWMA over the agent's own outcomes
(+0.5 on success, −0.5 on failure). Off by default.

**Homeostasis is not cognition.** It is unlearned physiological regulation and
stays active with all three mechanisms disabled.

---

## 6. Behavioural categories

| Role | Direct benefit | Cost |
|---|---|---|
| Functional | Yes | Any |
| Low-cost neutral | No | Minimal — persists by drift |
| Costly nonfunctional | No | Meaningful time, energy, or hazard cost |

The role is what the user asserted; the effect rules are what the model does.
The validator warns whenever the two disagree, because a "neutral" task that
grants energy would silently corrupt every misallocation metric.

---

## 7. Misallocation metrics

1. Nonfunctional action rate
2. Nonfunctional time allocation
3. Nonfunctional energy allocation
4. Cognitive amplification ratio — nonfunctional behaviour with cognition over a
   matched no-cognition baseline, reported with its raw components and an
   additive difference because the ratio is unstable near a zero denominator
5. Forecast error — forecast against truth, distinct from observation error
6. Experience–causality mismatch — a task's share of success memory minus its
   configured objective contribution

Several transparent measures, deliberately never combined into one index.

---

## 8. Environment

Eight process types are available, including AR(1), random walk, cyclical, and
rare-shock regimes. Each variable has a mean, persistence, volatility, optional
shock probability and magnitude, and an observation noise level.

Variables drive task success, predation pressure, and mate availability. They are
generated in advance and are not affected by the population: there is no resource
depletion and no predator–prey feedback.

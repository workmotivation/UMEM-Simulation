# AI_REPORT.md (DEMONSTRATION)

> **This is a generated demonstration, not a real experiment.** It exists so you can see the report format before running your own. Five seasons and three replications are far too few for any conclusion.


Experiment-specific report for external-AI interpretation, generated locally by the UMEM Evolutionary Simulation Workbench. Read `AI_REPORT_INTERPRETATION_GUIDE.md` first. All numbers here come from the application's tested analysis functions; `null` means undefined or not applicable, never zero. Section IDs [S*] and table IDs [T*] are stable citation anchors.

## [S1] Identity and provenance

| Field | Value |
|---|---|
| application_version | `0.3.0` |
| config_schema_version | `2` |
| report_format_version | `1.0` |
| expects_interpretation_guide_version | `1.0` |
| parameter_dictionary_fingerprint | `5a5a1e171eab31f5` |
| output_registry_fingerprint | `2a232c573d05eae8` |
| experiment_mode | `replications` |
| runs_requested | `3` |
| runs_completed | `3` |
| runs_failed_or_not_started | `0` |
| experiment_cancelled | `false` |
| any_run_partial_cancelled | `false` |
| any_run_extinct | `false` |
| scenario_name | `DEMONSTRATION: pair-bonded, 3 replications` |
| preset_origin | `custom` |
| config_hash | `cb91ec2d4eaf43c45edc5b7f98572a6284a7660bc328e14f0728cfba0d61f8d9` |
| master_seed | `12345` |
| replication_indices | `0, 1, 2` |
| run_ids | `09f346d6, c78ef556, 003e5bad` |
| start_time | `2026-09-09T04:00:48` |
| end_time | `2026-09-09T04:00:49` |

**Warnings** (0):
- none recorded

## [S2] Experiment conditions (deterministic description)


**Population and time.** The simulation starts with 200 agents and runs for 5 seasons of 40 time steps each (200 steps). Carrying capacity is 500 agents and a hard ceiling of 3000 prevents runaway growth. Agents mature after 2 season(s) and cannot live beyond 12 seasons; founder ages approximate a stable age distribution derived from the configured hazards. Each newborn is assigned reproductive Type A with probability 0.5 (Type A/B are neutral labels, not sexes, and are not inherited).

**Environment.** The environment is exogenous and pre-generated: it does not respond to the population, so there is no resource depletion or predator–prey feedback. `food` follows a ar1 process around a mean of 0.8 (volatility 0.03, persistence 0.97), observed with noise 0.05; `predator` follows a ar1 process around a mean of 0.2 (volatility 0.05, persistence 0.7, shock probability 0.01), observed with noise 0.08; `mate` follows a ar1 process around a mean of 0.7 (volatility 0.02, persistence 0.99), observed with noise 0.05.

**Available behaviours.** Agents choose among 11 enabled tasks grouped into 4 motivational domains (food, safety, reproduction, neutral). 9 tasks confer a direct benefit; 1 are low-cost neutral behaviours with no modelled benefit, and 1 are costly nonfunctional behaviours that spend time or energy for no benefit. Choice is a softmax (temperature 1) over inherited propensity, homeostatic urgency and any enabled cognition, with decision noise 0.1 and 1 action(s) per step.

**Survival constraints.** Every step each agent pays basal metabolism 1 energy (plus 0.5 when it cannot act); at zero energy it loses 10 health per step and dies when health reaches zero. Stochastic hazards act every step and combine as competing risks: a base predation hazard of 0.0015 per step scaled by the predator variable and by the chosen task's exposure multiplier; a gompertz senescence hazard (scale 0.0008, rate 0.12); a background hazard of 0; an extra 0.003 for juveniles; and a crowding hazard that switches on above 0.6 of carrying capacity (strength 0.4). Homeostasis is enabled: hunger (strength 2), threat/safety (strength 2), reproductive readiness (strength 2) shift task choice. This is physiological regulation, not cognition.

**Reproduction.** An agent is eligible to reproduce when mature, with energy ≥ 40, health ≥ 30 and reproductive capital ≥ 0. Reproduction is continuous: every time step is an opportunity. Eligible agents initiate reproductive attempts at a rate of 9 per season (a per-step hazard of 0.2015). This is an attempt-event rate, not a birth rate: realised births also depend on finding a partner, the fertility draw and juvenile recruitment. There is no refractory period; failed attempts cost nothing. Mating is pair-bonded (social monogamy): mature agents form exclusive one-to-one bonds at a rate of 4 per season, choosing among 5 candidate(s) by partner quality. Bonds persist until a partner dies or dissolve at 0.05 per season. Bond formation requires maturity only; a bonded pair reproduces only when both partners meet the eligibility thresholds in the same step, so its realised rate is well below the configured event rate. Each event requires one Type A and one Type B parent. Parental costs are symmetric (20 energy, 5 health each) and both contribute equally to offspring. Each successful event yields a poisson fertility draw with mean 1.5 (at most 3); each offspring survives recruitment with probability 0.85, reduced by Beverton–Holt density dependence (strength 1) as the population approaches carrying capacity.

**Inheritance and mutation.** Motivational propensities are heritable polygenic quantitative traits on a latent scale, expressed as proportions that sum to one within the domain layer and within each domain's tasks; they are not identified genes. Each offspring's latent value is the mid-parent value plus an independent Mendelian segregation term whose variance is 1 × V₀/2, where V₀ is the configured founder variance (sibling variation: standard); at 1.0 the founder variance is the neutral equilibrium. Mutation (conservative) is a separate rare event: with probability 0.01 per offspring in the domain layer and the task layer, tested independently, so one offspring can carry up to two events, one randomly chosen component receives a zero-mean shift of standard deviation 0.1 in latent (log-ratio) units. These are effective simulation parameters, not human mutation rates.

**Cognition.** All cognitive mechanisms are disabled: behaviour is driven only by inherited propensity, homeostasis and noise (a pure evolutionary baseline).

**Experiment design.** 3 independent replications sharing the master seed but using different random substreams; run in parallel with up to 1 worker(s). Results are reproducible and worker count does not affect them. Master seed 12345. Fitness is realised lifetime reproductive success, an outcome, not a score imposed on agents.

**Recording.** Population-level snapshots are recorded every 10 step(s), plus a closing snapshot after the final reproduction. A reproducible sample of 50 agents is stored per snapshot.

### Notes on unusual or custom settings

- The senescence hazard rises slowly, so a noticeable share of agents reach the hard maximum lifespan and die there together; expect a point mass at the maximum age in lifespan histograms.
- Mate availability is scaled by the environmental variable `mate`.
- `population.founder_age_distribution` is set to `stable` (default `uniform`).
- `reproduction.mating_mode` is set to `pair_bonded` (default `random`).

### [T1] Complete effective configuration (active settings)

| Path | Value | Meaning |
|---|---|---|
| `schema_version` | `2` | Schema version |
| `name` | `DEMONSTRATION: pair-bonded, 3 replications` | Scenario name |
| `description` | `Generated example for documentation. Not a real research result.` | Description |
| `preset_origin` | `None` | Preset origin |
| `master_seed` | `12345` | Master seed |
| `population.founder_age_distribution` | `stable` | Founder ages |
| `population.initial_population` | `200` | Initial population |
| `population.carrying_capacity` | `500` | Carrying capacity |
| `population.max_population` | `3000` | Max population |
| `population.init_distribution` | `gamma` | Init distribution |
| `population.sex_ratio_type_a` | `0.5` | Type-A fraction |
| `population.starting_population_file` | `None` | Start pop file |
| `lifecycle.steps_per_season` | `40` | Steps per season |
| `lifecycle.total_seasons` | `5` | Total seasons |
| `lifecycle.actions_per_step` | `1` | Actions per step |
| `lifecycle.initial_energy` | `70` | Initial energy |
| `lifecycle.energy_max` | `100` | Energy max |
| `lifecycle.initial_health` | `90` | Initial health |
| `lifecycle.health_max` | `100` | Health max |
| `lifecycle.initial_repro_capital` | `0` | Initial repro capital |
| `lifecycle.repro_capital_max` | `100` | Repro capital max |
| `lifecycle.initial_status` | `50` | Initial status |
| `lifecycle.status_max` | `100` | Status max |
| `lifecycle.basal_metabolism` | `1` | Basal metabolism |
| `lifecycle.rest_energy_cost` | `0.5` | Rest cost |
| `lifecycle.health_starvation_penalty` | `10` | Starvation penalty |
| `lifecycle.maturity_seasons` | `2` | Maturity (seasons) |
| `lifecycle.max_lifespan_seasons` | `12` | Max lifespan |
| `lifecycle.newborns_act_next_step` | `True` | Newborns wait |
| `mortality.base_predation_hazard` | `0.0015` | Base predation |
| `mortality.predation_env_driver` | `predator` | Predation driver |
| `mortality.predation_env_sensitivity` | `1` | Predation sensitivity |
| `mortality.age_hazard_shape` | `gompertz` | Age hazard shape |
| `mortality.age_hazard_scale` | `0.0008` | Age hazard scale |
| `mortality.age_hazard_rate` | `0.12` | Age hazard rate |
| `mortality.background_hazard` | `0` | Background hazard |
| `mortality.juvenile_extra_hazard` | `0.003` | Juvenile hazard |
| `mortality.density_hazard_strength` | `0.4` | Density hazard |
| `mortality.density_onset_fraction` | `0.6` | Density onset |
| `mortality.density_affects_juveniles_only` | `True` | Density juveniles only |
| `reproduction.mode` | `sexual` | Mode |
| `reproduction.timing` | `distributed` | Reproduction timing |
| `reproduction.reproductive_event_rate` | `9` | Reproductive event rate |
| `reproduction.refractory_seasons` | `0` | Refractory period |
| `reproduction.mating_mode` | `pair_bonded` | Mating mode |
| `reproduction.mate_choice_k` | `5` | Choosiness (k) |
| `reproduction.mate_choice_criterion` | `partner_quality` | Choice criterion |
| `reproduction.mate_quality_weights` | `{'status': 1.0, 'repro_capital': 0.3, 'health': 0.25, 'energy': 0.25}` | Quality weights |
| `reproduction.bond_formation_per_season` | `4` | Bond formation rate |
| `reproduction.bond_dissolution_per_season` | `0.05` | Bond dissolution rate |
| `reproduction.energy_threshold` | `40` | Energy threshold |
| `reproduction.health_threshold` | `30` | Health threshold |
| `reproduction.repro_capital_threshold` | `0` | Capital threshold |
| `reproduction.mate_selection` | `weighted_capital` | Mate selection |
| `reproduction.mate_availability_driver` | `mate` | Mate driver |
| `reproduction.max_offspring_per_event` | `3` | Max offspring/event |
| `reproduction.fertility_distribution` | `poisson` | Fertility dist |
| `reproduction.fertility_mean` | `1.5` | Fertility mean |
| `reproduction.fertility_binomial_p` | `0.5` | Binomial p |
| `reproduction.fertility_discrete_pmf` | `[]` | Discrete pmf |
| `reproduction.repro_energy_cost` | `20` | Repro energy cost |
| `reproduction.repro_health_cost` | `5` | Repro health cost |
| `reproduction.juvenile_survival` | `0.85` | Juvenile survival |
| `reproduction.density_dependent_recruitment` | `True` | Density recruitment |
| `reproduction.recruitment_strength` | `1` | Recruitment strength |
| `inheritance.model` | `polygenic_additive` | Inheritance model |
| `inheritance.sibling_variation` | `standard` | Sibling variation |
| `inheritance.segregation_multiplier` | `1` | Segregation multiplier |
| `inheritance.mutation_level` | `conservative` | Mutation level |
| `inheritance.mutation_probability_per_offspring` | `0.01` | Mutation probability |
| `inheritance.mutation_effect_sd_latent` | `0.1` | Mutation effect size |
| `inheritance.mutation_target` | `both` | Mutation target |
| `inheritance.min_propensity` | `0.01` | Min propensity |
| `homeostasis.enabled` | `True` | Enabled |
| `homeostasis.hunger_enabled` | `True` | Hunger |
| `homeostasis.hunger_strength` | `2` | Hunger strength |
| `homeostasis.safety_enabled` | `True` | Safety |
| `homeostasis.safety_strength` | `2` | Safety strength |
| `homeostasis.reproduction_enabled` | `True` | Reproduction |
| `homeostasis.reproduction_strength` | `2` | Reproduction strength |
| `cognition.experience_enabled` | `False` | Experience (A) |
| `cognition.experience_success_definition` | `surviving_offspring` | Success definition |
| `cognition.experience_top_quantile` | `0.2` | Top quantile |
| `cognition.experience_weight_recent` | `0.7` | Recent weight |
| `cognition.experience_smoothing` | `1` | Smoothing |
| `cognition.experience_noise_sd` | `0.3` | Experience noise |
| `cognition.experience_strength` | `2.5` | Experience strength |
| `cognition.forecast_enabled` | `False` | Forecast (B) |
| `cognition.forecast_memory` | `0.6` | Forecast memory |
| `cognition.forecast_strength` | `1` | Forecast strength |
| `cognition.individual_learning_enabled` | `False` | Individual learning (C) |
| `cognition.individual_learning_rate` | `0.2` | Learning rate |
| `cognition.individual_learning_strength` | `1` | Learning strength |
| `choice.softmax_temperature` | `1` | Softmax temperature |
| `choice.decision_noise_sd` | `0.1` | Decision noise |
| `experiment.mode` | `replications` | Mode |
| `experiment.replications` | `3` | Replications |
| `experiment.max_workers` | `1` | Max workers |
| `experiment.sweep_parameters` | `[]` | Sweep params |
| `experiment.max_sweep_combinations` | `500` | Max sweep combos |
| `experiment.common_random_numbers` | `False` | Common random numbers |
| `output.record_interval_steps` | `10` | Record interval |
| `output.store_agent_sample` | `True` | Agent sample |
| `output.agent_sample_size` | `50` | Sample size |
| `output.store_event_log` | `False` | Event log |

### [T2] Inactive settings

| Path | Value | Why inactive |
|---|---|---|
| `reproduction.breeding_every_seasons` | `1` | legacy timing only |
| `reproduction.gestation_delay_steps` | `0` | legacy timing only |
| `inheritance.mutation_probability` | `1` | legacy inheritance only |
| `inheritance.mutation_log_sd` | `0.1` | legacy inheritance only |
| `inheritance.recombination_per_trait` | `True` | legacy inheritance only |
| `inheritance.blend_alpha` | `0.5` | legacy inheritance only |


### [T3] Active mechanisms

| Mechanism | Value |
|---|---|
| reproduction_mode | `sexual` |
| reproduction_timing | `distributed` |
| mating_mode | `pair_bonded` |
| mate_choice_criterion | `partner_quality` |
| mate_choice_k | `5` |
| mate_quality_weights | `{"status": 1.0, "repro_capital": 0.3, "health": 0.25, "energy": 0.25}` |
| reproductive_event_rate_per_season | `9` |
| refractory_seasons | `0` |
| bond_formation_per_season | `4` |
| bond_dissolution_per_season | `0.05` |
| founder_age_distribution | `stable` |
| sex_ratio_type_a | `0.5` |
| inheritance_model | `polygenic_additive` |
| inheritance_model_version | `polygenic_additive.v1` |
| sibling_variation | `standard` |
| segregation_multiplier_effective | `1` |
| mutation_level | `conservative` |
| mutation_probability_per_offspring | `0.01` |
| mutation_effect_sd_latent | `0.1` |
| mutation_target | `both` |


## [S3] Output data dictionary (fields used in this report)

| Key | Table | Kind | Unit | Applies to | Definition | Null means |
|---|---|---|---|---|---|---|
| `final_population` | summary_metrics | stock | agents | all | Living agents at the end. | not applicable / undefined |
| `peak_population` | summary_metrics | stock | agents | all | Maximum recorded population. | not applicable / undefined |
| `min_population` | summary_metrics | stock | agents | all | Minimum recorded population. | not applicable / undefined |
| `mean_population` | summary_metrics | mean | agents | all | Mean over recording rows. | not applicable / undefined |
| `population_cv` | summary_metrics | share |  | all | Std/mean of population over rows. | not applicable / undefined |
| `extinct` | summary_metrics | label |  | all | Population reached zero. | not applicable / undefined |
| `extinction_season` | summary_metrics | id | seasons | all | Season of extinction. | null when not extinct |
| `seasons_completed` | summary_metrics | count | seasons | all | Seasons simulated. | not applicable / undefined |
| `n_deaths` | summary_metrics | count | agents | all | Completed lives (dead_log rows). | not applicable / undefined |
| `mean_lifespan_seasons` | summary_metrics | mean | seasons | all | Mean age at death, completed lives. | not applicable / undefined |
| `median_lifespan_seasons` | summary_metrics | mean | seasons | all | Median age at death. | not applicable / undefined |
| `max_lifespan_observed_seasons` | summary_metrics | mean | seasons | all | Longest completed life. | not applicable / undefined |
| `mean_lifespan_given_maturity` | summary_metrics | mean | seasons | all | Mean age at death among agents that reached maturity. | not applicable / undefined |
| `frac_reaching_maturity` | summary_metrics | share |  | all | Share of completed lives that reached maturity. | not applicable / undefined |
| `reproduction_timing` | summary_metrics | label |  | all | Timing mode of the run. | not applicable / undefined |
| `total_reproductive_attempts` | summary_metrics | cumulative | events | distributed_only | Attempts initiated over the run. | 0 under legacy timing (attempts are not tracked). |
| `total_failed_no_partner` | summary_metrics | cumulative | events | distributed_only | Attempts without an available partner. | not applicable / undefined |
| `failed_match_rate` | summary_metrics | share |  | all | total_failed_no_partner / total_reproductive_attempts. | null when there were no attempts |
| `total_successful_events` | summary_metrics | cumulative | events | all | Reproductive events that produced a fertility draw. | not applicable / undefined |
| `total_offspring_pre_survival` | summary_metrics | cumulative | agents | all | Offspring drawn before juvenile survival. | not applicable / undefined |
| `total_offspring_survived` | summary_metrics | cumulative | agents | all | Offspring that entered the population. | not applicable / undefined |
| `realised_juvenile_survival` | summary_metrics | share |  | all | survived / pre_survival. | null when no offspring were drawn |
| `mean_offspring_per_event_pre_survival` | summary_metrics | mean | agents/event | all | Mean fertility draw per event. | not applicable / undefined |
| `mean_pairs_per_step` | summary_metrics | mean | events/step | distributed_only | Mean successful events per step. | null under legacy timing (rows are seasons). |
| `mean_total_pairs_per_season` | summary_metrics | mean | events/season | all | Events summed within season, averaged across seasons. | not applicable / undefined |
| `mean_births_per_season` | summary_metrics | mean | agents/season | all | Surviving offspring per season. | not applicable / undefined |
| `mean_eligible_agents_per_step` | summary_metrics | mean | agents | distributed_only | Mean eligible stock per step. | not applicable / undefined |
| `share_steps_with_births` | summary_metrics | share |  | all | Share of steps with at least one birth. | not applicable / undefined |
| `birth_phase_entropy` | summary_metrics | share |  | all | Normalised entropy of births over step-within-season; 1 = uniform, 0 = all on one step. | null when there were no births |
| `mean_active_bonds_per_step` | summary_metrics | mean | bonds | pair_bond_only | Mean bonds in force. | not applicable / undefined |
| `peak_active_bonds` | summary_metrics | stock | bonds | pair_bond_only | Maximum bonds in force. | not applicable / undefined |
| `total_bonds_formed` | summary_metrics | cumulative | bonds | pair_bond_only | Bonds formed over the run. | not applicable / undefined |
| `total_bonds_dissolved` | summary_metrics | cumulative | bonds | pair_bond_only | Bonds dissolved over the run. | not applicable / undefined |
| `total_bonds_dissolved_by_death` | summary_metrics | cumulative | bonds | pair_bond_only | Dissolutions by partner death. | not applicable / undefined |
| `total_bonds_dissolved_stochastic` | summary_metrics | cumulative | bonds | pair_bond_only | Dissolutions by configured hazard. | not applicable / undefined |
| `mean_lrs_completed_lives` | summary_metrics | mean | agents | all | Mean lifetime reproductive success, completed lives. | not applicable / undefined |
| `var_lrs_completed_lives` | summary_metrics | mean | agents² | all | Variance of LRS. | not applicable / undefined |
| `frac_zero_lrs` | summary_metrics | share |  | all | Share of completed lives with no surviving offspring. | not applicable / undefined |
| `opportunity_for_selection_I` | summary_metrics | rate |  | all | Crow's I = Var(LRS)/mean(LRS)²; an upper bound on selection strength, not selection on any trait. | null when mean LRS is zero |
| `lrs_gini` | summary_metrics | share |  | all | Gini coefficient of LRS over completed lives. | not applicable / undefined |
| `lrs_top20pct_share` | summary_metrics | share |  | all | Share of all offspring from the top 20% of completed lives by LRS. | not applicable / undefined |
| `mean_lrs_given_maturity` | summary_metrics | mean | agents | all | Mean LRS among agents that reached maturity. | not applicable / undefined |
| `total_mutation_events` | summary_metrics | cumulative | events | polygenic_only | Effective mutation events over the run. | not applicable / undefined |
| `mutation_events_per_offspring` | summary_metrics | rate | events/offspring | polygenic_only | total_mutation_events / total_offspring_survived. | not applicable / undefined |
| `final_n_lineages` | summary_metrics | stock | lineages | all | Lineages alive at the end. | not applicable / undefined |
| `peak_n_lineages` | summary_metrics | stock | lineages | all | Maximum lineages. | not applicable / undefined |
| `initial_mean_domain_variance` | summary_metrics | mean |  | all | Mean domvar_ at the start. | not applicable / undefined |
| `final_mean_domain_variance` | summary_metrics | mean |  | all | Mean domvar_ at the end. | not applicable / undefined |
| `variance_retained_fraction` | summary_metrics | rate |  | all | final / initial domain variance. | not applicable / undefined |
| `final_nonfunctional_action_rate` | summary_metrics | share |  | all | Nonfunctional action share, last rows. | not applicable / undefined |
| `final_nonfunctional_time_share` | summary_metrics | share |  | all | Nonfunctional time share, last rows. | not applicable / undefined |
| `final_nonfunctional_energy_share` | summary_metrics | share |  | all | Nonfunctional energy share, last rows. | not applicable / undefined |
| `final_neutral_action_rate` | summary_metrics | share |  | all | Neutral action share, last rows. | not applicable / undefined |
| `nonfunctional_rate_initial` | summary_metrics | share |  | all | Nonfunctional action rate, first rows. | not applicable / undefined |
| `nonfunctional_rate_final` | summary_metrics | share |  | all | Nonfunctional action rate, last rows. | not applicable / undefined |
| `nonfunctional_rate_change` | summary_metrics | share |  | all | final minus initial. | not applicable / undefined |
| `nonfunctional_persistence_ratio` | summary_metrics | rate |  | all | final / initial. | null when initial is zero |
| `experience_memory_active` | summary_metrics | label |  | cognition_a | Whether intergenerational memory carried any signal. | not applicable / undefined |
| `experience_mismatch_total_abs` | summary_metrics | share |  | cognition_a | Sum of /mismatch/. | null when memory inactive |
| `experience_mismatch_nonbeneficial` | summary_metrics | share |  | cognition_a | Mismatch summed over tasks with no direct benefit. | null when memory inactive |
| `forecast_mae_mean` | summary_metrics | mean |  | cognition_b | Mean of forecast_mae_ over variables. | not applicable / undefined |
| `one_step_regret_proxy` | summary_metrics | share |  | all | Local single-step diagnostic; NOT a fitness measure. | not applicable / undefined |

**Unavailable in this experiment:**
- `experience_* metrics`: cognition A (intergenerational experience) is disabled.
- `forecast_* metrics`: cognition B (forecasting) is disabled.


## [S4] Results — replicated experiment

3 completed replication(s) of one configuration. The first run's detailed tables are shown for orientation; inference should use the across-replication table.

### [T4] Per-run summary (one row per replication)

| replication_index | run_id | final_population | mean_population | mean_lifespan_seasons | total_offspring_survived | mean_lrs_completed_lives | opportunity_for_selection_I | lrs_gini | final_nonfunctional_action_rate | variance_retained_fraction | extinct | cancelled |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 09f346d6 | 116 | 175.409 | 5.57228 | 146 | 0.778261 | 3.05574 | 0.766845 | 0.0502011 | 0.763056 | false | false |
| 1 | c78ef556 | 68 | 104.682 | 5.33738 | 84 | 0.458333 | 5.54545 | 0.853021 | 0.0575392 | 0.754451 | false | false |
| 2 | 003e5bad | 162 | 167.636 | 5.16833 | 198 | 0.677966 | 5.6375 | 0.842532 | 0.0731998 | 0.979578 | false | false |

### [T5] Across-replication summary (mean and 95% t-interval; n = replications with a finite value)

Uncertainty method: Student-t interval on the replicate mean (`analysis/aggregation.py`). Replications share the master seed and differ only in random substream; they are the unit of replication. Time steps and agents are not.

| metric | mean | ci_lower | ci_upper | sd | median | n |
|---|---|---|---|---|---|---|
| `final_population` | 115.333 | -1.42995 | 232.097 | 47.0035 | 116 | 3 |
| `peak_population` | 213.333 | 198.155 | 228.512 | 6.1101 | 212 | 3 |
| `min_population` | 106.667 | 0.418342 | 212.915 | 42.7707 | 116 | 3 |
| `mean_population` | 149.242 | 52.8931 | 245.592 | 38.7858 | 167.636 | 3 |
| `extinct` | 0 | 0 | 0 | 0 | 0 | 3 |
| `seasons_completed` | 5 | 5 | 5 | 0 | 5 | 3 |
| `population_cv` | 0.270655 | -0.270445 | 0.811755 | 0.217822 | 0.186488 | 3 |
| `n_deaths` | 227.333 | 201.838 | 252.829 | 10.2632 | 230 | 3 |
| `mean_lifespan_seasons` | 5.35933 | 4.85537 | 5.86329 | 0.20287 | 5.33738 | 3 |
| `median_lifespan_seasons` | 4.64583 | 3.29612 | 5.99554 | 0.543331 | 4.4375 | 3 |
| `max_lifespan_observed_seasons` | 12 | 12 | 12 | 0 | 12 | 3 |
| `frac_reaching_maturity` | 0.769387 | 0.645552 | 0.893222 | 0.0498503 | 0.796296 | 3 |
| `mean_lifespan_given_maturity` | 6.6822 | 6.11813 | 7.24627 | 0.227069 | 6.73003 | 3 |
| `total_reproductive_attempts` | 788.333 | 36.6843 | 1539.98 | 302.579 | 899 | 3 |
| `total_failed_no_partner` | 0 | 0 | 0 | 0 | 0 | 3 |
| `total_successful_events` | 161.333 | 6.25203 | 316.415 | 62.4286 | 188 | 3 |
| `total_offspring_pre_survival` | 223.667 | -0.59929 | 447.933 | 90.2792 | 266 | 3 |
| `total_offspring_survived` | 142.667 | 0.889344 | 284.444 | 57.0731 | 146 | 3 |
| `total_mutation_events` | 4.66667 | 3.23245 | 6.10088 | 0.57735 | 5 | 3 |
| `failed_match_rate` | 0 | 0 | 0 | 0 | 0 | 3 |
| `realised_juvenile_survival` | 0.64787 | 0.434793 | 0.860946 | 0.0857747 | 0.694737 | 3 |
| `mean_offspring_per_event_pre_survival` | 1.38018 | 1.08345 | 1.67691 | 0.11945 | 1.33333 | 3 |
| `mutation_events_per_offspring` | 0.0379908 | -0.0115094 | 0.087491 | 0.0199265 | 0.0342466 | 3 |
| `mean_pairs_per_step` | 0.806667 | 0.0312601 | 1.58207 | 0.312143 | 0.94 | 3 |
| `mean_eligible_agents_per_step` | 39.4033 | 8.67222 | 70.1344 | 12.3709 | 44.01 | 3 |
| `share_steps_with_births` | 0.35 | 0.020676 | 0.679324 | 0.132571 | 0.38 | 3 |
| `birth_phase_entropy` | 0.911932 | 0.821337 | 1.00253 | 0.0364693 | 0.907715 | 3 |
| `mean_total_pairs_per_season` | 32.2667 | 1.25041 | 63.2829 | 12.4857 | 37.6 | 3 |
| `mean_births_per_season` | 28.5333 | 0.177869 | 56.8888 | 11.4146 | 29.2 | 3 |
| `mean_active_bonds_per_step` | 42.2917 | 12.1954 | 72.388 | 12.1154 | 42.405 | 3 |
| `peak_active_bonds` | 63.3333 | 42.206 | 84.4607 | 8.5049 | 63 | 3 |
| `total_bonds_formed` | 188 | 122.135 | 253.865 | 26.5141 | 187 | 3 |
| `total_bonds_dissolved` | 155 | 111.902 | 198.098 | 17.3494 | 146 | 3 |
| `total_bonds_dissolved_by_death` | 144.333 | 114.906 | 173.761 | 11.8462 | 138 | 3 |
| `total_bonds_dissolved_stochastic` | 10.6667 | -3.0149 | 24.3482 | 5.50757 | 8 | 3 |
| `mean_lrs_completed_lives` | 0.638187 | 0.231704 | 1.04467 | 0.163631 | 0.677966 | 3 |
| `var_lrs_completed_lives` | 1.86899 | 0.0970233 | 3.64096 | 0.713313 | 1.85083 | 3 |
| `frac_zero_lrs` | 0.728398 | 0.570527 | 0.88627 | 0.0635518 | 0.737288 | 3 |
| `opportunity_for_selection_I` | 4.74623 | 1.10764 | 8.38483 | 1.46473 | 5.54545 | 3 |
| `lrs_gini` | 0.820799 | 0.703997 | 0.937602 | 0.0470193 | 0.842532 | 3 |
| `lrs_top20pct_share` | 0.893336 | 0.651213 | 1.13546 | 0.0974677 | 0.9125 | 3 |
| `mean_lrs_given_maturity` | 0.833596 | 0.277942 | 1.38925 | 0.223681 | 0.952381 | 3 |
| `final_n_lineages` | 48.6667 | 13.1571 | 84.1762 | 14.2945 | 52 | 3 |
| `peak_n_lineages` | 199.333 | 196.465 | 202.202 | 1.1547 | 200 | 3 |
| `final_mean_domain_variance` | 0.0137466 | 0.0065428 | 0.0209505 | 0.00289993 | 0.0124648 | 3 |
| `initial_mean_domain_variance` | 0.0164294 | 0.0138406 | 0.0190182 | 0.00104213 | 0.0165216 | 3 |
| `variance_retained_fraction` | 0.832362 | 0.515471 | 1.14925 | 0.127566 | 0.763056 | 3 |
| `final_nonfunctional_action_rate` | 0.0603133 | 0.0311305 | 0.0894962 | 0.0117477 | 0.0575392 | 3 |
| `final_neutral_action_rate` | 0.0674144 | 0.0346439 | 0.100185 | 0.0131919 | 0.0718105 | 3 |
| `final_nonfunctional_time_share` | 0.0603133 | 0.0311305 | 0.0894962 | 0.0117477 | 0.0575392 | 3 |
| `final_nonfunctional_energy_share` | 0.0836996 | 0.0446039 | 0.122795 | 0.0157381 | 0.0824275 | 3 |
| `nonfunctional_rate_initial` | 0.0797916 | 0.0716001 | 0.0879831 | 0.00329753 | 0.0787328 | 3 |
| `nonfunctional_rate_final` | 0.0603133 | 0.0311305 | 0.0894962 | 0.0117477 | 0.0575392 | 3 |
| `nonfunctional_rate_change` | -0.0194783 | -0.0495049 | 0.0105484 | 0.0120874 | -0.0259493 | 3 |
| `nonfunctional_persistence_ratio` | 0.756525 | 0.380858 | 1.13219 | 0.151226 | 0.689187 | 3 |
| `forecast_mae_mean` | 0 | 0 | 0 | 0 | 0 | 3 |
| `experience_mismatch_total_abs` | null | null | null | 0 | null | 0 |
| `experience_mismatch_nonbeneficial` | null | null | null | 0 | null | 0 |
| `experience_memory_active` | 0 | 0 | 0 | 0 | 0 | 3 |
| `one_step_regret_proxy` | 0.0603133 | 0.0311305 | 0.0894962 | 0.0117477 | 0.0575392 | 3 |

### [T6] Extinction

| n_runs | n_extinct | extinction_rate | wilson_ci_lower | wilson_ci_upper |
|---|---|---|---|---|
| 3 | 0 | 0 | 0 | 0.561497 |

Method: Wilson score interval (used because extinction counts are often 0 or n).


#### Orientation: detailed tables for replication 0 only

### [T7] Population

| Source key | Value |
|---|---|
| `summary_metrics.final_population` | 116 |
| `summary_metrics.peak_population` | 220 |
| `summary_metrics.min_population` | 116 |
| `summary_metrics.mean_population` | 175.409 |
| `summary_metrics.population_cv` | 0.186488 |
| `summary_metrics.extinct` | false |
| `summary_metrics.extinction_season` | null |
| `summary_metrics.seasons_completed` | 5 |

### [T8] Survival (completed lives only)

| Source key | Value |
|---|---|
| `summary_metrics.n_deaths` | 230 |
| `summary_metrics.mean_lifespan_seasons` | 5.57228 |
| `summary_metrics.median_lifespan_seasons` | 5.2625 |
| `summary_metrics.max_lifespan_observed_seasons` | 12 |
| `summary_metrics.mean_lifespan_given_maturity` | 6.73003 |
| `summary_metrics.frac_reaching_maturity` | 0.8 |

### [T9] Reproduction

| Source key | Value |
|---|---|
| `summary_metrics.reproduction_timing` | distributed |
| `summary_metrics.total_reproductive_attempts` | 1020 |
| `summary_metrics.total_failed_no_partner` | 0 |
| `summary_metrics.failed_match_rate` | 0 |
| `summary_metrics.total_successful_events` | 206 |
| `summary_metrics.total_offspring_pre_survival` | 266 |
| `summary_metrics.total_offspring_survived` | 146 |
| `summary_metrics.realised_juvenile_survival` | 0.548872 |
| `summary_metrics.mean_offspring_per_event_pre_survival` | 1.29126 |
| `summary_metrics.mean_pairs_per_step` | 1.03 |
| `summary_metrics.mean_total_pairs_per_season` | 41.2 |
| `summary_metrics.mean_births_per_season` | 29.2 |
| `summary_metrics.mean_eligible_agents_per_step` | 48.81 |
| `summary_metrics.share_steps_with_births` | 0.38 |
| `summary_metrics.birth_phase_entropy` | 0.907715 |

### [T10] Mating

| Source key | Value |
|---|---|
| `summary_metrics.mean_active_bonds_per_step` | 54.35 |
| `summary_metrics.peak_active_bonds` | 72 |
| `summary_metrics.total_bonds_formed` | 215 |
| `summary_metrics.total_bonds_dissolved` | 175 |
| `summary_metrics.total_bonds_dissolved_by_death` | 158 |
| `summary_metrics.total_bonds_dissolved_stochastic` | 17 |

### [T11] Realised fitness (completed lives)

| Source key | Value |
|---|---|
| `summary_metrics.mean_lrs_completed_lives` | 0.778261 |
| `summary_metrics.var_lrs_completed_lives` | 1.85083 |
| `summary_metrics.frac_zero_lrs` | 0.66087 |
| `summary_metrics.opportunity_for_selection_I` | 3.05574 |
| `summary_metrics.lrs_gini` | 0.766845 |
| `summary_metrics.lrs_top20pct_share` | 0.787709 |
| `summary_metrics.mean_lrs_given_maturity` | 0.972826 |

### [T12] Inheritance and diversity

| Source key | Value |
|---|---|
| `summary_metrics.total_mutation_events` | 5 |
| `summary_metrics.mutation_events_per_offspring` | 0.0342466 |
| `summary_metrics.final_n_lineages` | 61 |
| `summary_metrics.peak_n_lineages` | 200 |
| `summary_metrics.initial_mean_domain_variance` | 0.0153443 |
| `summary_metrics.final_mean_domain_variance` | 0.0117085 |
| `summary_metrics.variance_retained_fraction` | 0.763056 |

### [T13] Behaviour and misallocation

| Source key | Value |
|---|---|
| `summary_metrics.final_nonfunctional_action_rate` | 0.0502011 |
| `summary_metrics.final_nonfunctional_time_share` | 0.0502011 |
| `summary_metrics.final_nonfunctional_energy_share` | 0.0686361 |
| `summary_metrics.final_neutral_action_rate` | 0.0718105 |
| `summary_metrics.nonfunctional_rate_initial` | 0.0771535 |
| `summary_metrics.nonfunctional_rate_final` | 0.0502011 |
| `summary_metrics.nonfunctional_rate_change` | -0.0269525 |
| `summary_metrics.nonfunctional_persistence_ratio` | 0.650664 |

### [T14] Cognition diagnostics

| Source key | Value |
|---|---|
| `summary_metrics.experience_memory_active` | false |
| `summary_metrics.experience_mismatch_total_abs` | null |
| `summary_metrics.experience_mismatch_nonbeneficial` | null |
| `summary_metrics.forecast_mae_mean` | 0 |
| `summary_metrics.one_step_regret_proxy` | 0.0502011 |

### [T15] Death causes (share of completed lives)

| Source key | Share | Count |
|---|---|---|
| `summary_metrics.death_share_starvation` | 0.317391 | 73 |
| `summary_metrics.death_share_health_injury` | 0.0130435 | 3 |
| `summary_metrics.death_share_predation` | 0.256522 | 59 |
| `summary_metrics.death_share_age_senescence` | 0.317391 | 73 |
| `summary_metrics.death_share_background` | 0 | 0 |
| `summary_metrics.death_share_density` | 0 | 0 |
| `summary_metrics.death_share_juvenile` | 0.0956522 | 22 |

### [T16] Final inherited domain propensity (mean expressed proportion)

| Domain | Value | Change over run | log ratio |
|---|---|---|---|
| food | 0.33541 | 0.0758463 | 0.256351 |
| safety | 0.223886 | -0.0186042 | -0.0798245 |
| reproduction | 0.18688 | -0.0572771 | -0.267345 |
| neutral | 0.253824 | 3.50129e-05 | 0.000137951 |

Inherited propensity is a tendency; realised allocation is in the next table. They diverge whenever homeostasis or cognition reweights choice.

### [T17] Final realised time and energy allocation by task

| Task | Time share | Energy share | Inherited task propensity |
|---|---|---|---|
| safe_forage | 0.189655 | 0.0872324 | 0.341435 |
| risky_forage | 0.112069 | 0.103093 | 0.3441 |
| scavenge | 0.155172 | 0.214116 | 0.314465 |
| shelter | 0.0948276 | 0.0436162 | 0.338105 |
| vigilance | 0.0775862 | 0.0535289 | 0.332757 |
| flee_defend | 0.146552 | 0.269627 | 0.329138 |
| mate_search | 0.0689655 | 0.0951626 | 0.35257 |
| courtship | 0.0172414 | 0.0396511 | 0.328764 |
| territory | 0 | 0 | 0.318666 |
| neutral_idle | 0.0775862 | 0.0107058 | 0.544811 |
| costly_dance | 0.0603448 | 0.0832672 | 0.455189 |

### [T18] Population by season (aggregated from `time_series`)

Method: `population`, `n_lineages` = value at the season's last recorded row; births/deaths = sum over the season's recording intervals; state means = mean over rows. Resolution: one row per season; the full per-interval series is in `data/time_series.csv` (see manifest).

| season | population | births_interval | deaths_interval | mean_energy | mean_health | frac_mature | n_lineages |
|---|---|---|---|---|---|---|---|
| 0 | 214 | 36 | 22 | 52.1153 | 85.9271 | 0.699043 | 182 |
| 1 | 196 | 37 | 55 | 47.7697 | 76.3973 | 0.666169 | 141 |
| 2 | 177 | 28 | 47 | 47.7657 | 71.5548 | 0.713647 | 110 |
| 3 | 162 | 28 | 43 | 48.5726 | 70.087 | 0.700642 | 91 |
| 4 | 116 | 17 | 63 | 50.9594 | 66.9755 | 0.732715 | 61 |


## [S5] Definitions of denominators and observation windows

- **Completed lives** (`dead_log`): agents that died during the run. Survivors at the end are censored and excluded from lifespan and LRS summaries. Early in a run these summaries are dominated by short lives.
- **Founders vs birth cohorts**: founders may start at dispersed ages (negative `born_season`) and are not a fully observed cohort; agents born during the run and dead by its end are.
- **Realised births vs attempts**: `total_reproductive_attempts` counts initiations; `total_successful_events` counts events that produced a fertility draw; `total_offspring_survived` counts recruits. The event rate is a configured attempt rate, not a birth rate.
- **Behavioural allocation vs inherited propensity**: `timealloc_*`/`freq_*` are realised; `domprop_*`/`taskprop_*` are inherited tendencies expressed as proportions.
- **Aggregate vs individual**: every table here is population-level; individual evidence exists only in `data/agent_sample.csv` when enabled.
- **Per-step vs per-season**: metric names state their denominator; per-step means are `null` under legacy timing.
- **Time resolution**: `time_series` rows are recording intervals (`output.record_interval_steps` steps), not steps; interval counts sum over the interval.

## [S6] Manifest of full export files

Everything below is in the reproducibility bundle. The last column states whether its data appear in this report. Ask the user for a file by name when a question needs data not included here.

| File | Purpose | Format | Rows | Coverage | In this report? |
|---|---|---|---|---|---|
| `scenario.json` | complete effective configuration | JSON | 1 | all | yes ([T1], [S2]) |
| `metadata.json` | identity, seeds, versions, mechanisms | JSON | 1 | all | yes ([S1], [T3]) |
| `results.xlsx` | formatted workbook of all tables below | Excel | — | all | partially (summaries) |
| `data/summary_metrics.csv` | all scalar metrics | CSV | 3 run(s) | all | yes (summary tables) |
| `data/time_series.csv` | per-recording-interval snapshot | CSV | 66 | all | summarised per season only |
| `data/breeding_series.csv` | reproduction bookkeeping per step/season | CSV | 600 | all | summarised only |
| `data/dead_log.csv` | one row per completed life | CSV | 682 | completed lives | summarised only (LRS, lifespan, causes) |
| `data/agent_sample.csv` | sampled individual agents | CSV | 3,300 | sampled agents | no |
| `data/environment_trajectories.csv` | true environment per step | CSV | 200 | all steps | no |
| `figures/*.png` | standard figure set | PNG | 10 | — | no |
| `AI_REPORT_INTERPRETATION_GUIDE.md` | generic interpretation manual | Markdown | — | — | companion |

## [S7] What this report omits

- Full per-interval time series (summarised per season in the report; complete in `data/time_series.csv`; appendix parts not generated).
- Per-task allocation, environment and cognition columns over time (in `data/time_series.csv`).
- Individual agent records (in `data/agent_sample.csv` when enabled).
- Individual completed-life records (in `data/dead_log.csv`).
- Figures (in `figures/`).

This report does **not** contain every raw observation. Numerical claims should be limited to the tables above; request a manifest file for anything else.

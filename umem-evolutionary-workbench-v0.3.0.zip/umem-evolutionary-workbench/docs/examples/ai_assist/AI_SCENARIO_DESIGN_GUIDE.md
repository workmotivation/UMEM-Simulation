# AI_SCENARIO_DESIGN_GUIDE.md

Self-contained guide for an external AI assistant helping a researcher design a
UMEM Evolutionary Simulation Workbench experiment. Read all of it before asking
the user anything. It requires no repository access, no browsing, and no prior
conversation. UMEM itself makes no AI calls; the user will download the JSON you
produce and import it into UMEM, which validates it locally.

## 0. Identity

| Field | Value |
|---|---|
| application | `UMEM Evolutionary Simulation Workbench` |
| application_version | `0.3.0` |
| config_schema_version | `2` |
| document_kind | `scenario_design_guide` |
| guide_format_version | `1.0` |
| report_format_version | `1.0` |
| output_registry_format_version | `1.0` |
| parameter_dictionary_fingerprint | `5a5a1e171eab31f5` |
| output_registry_fingerprint | `2a232c573d05eae8` |

> Identity block. When a report is supplied alongside this guide, its `parameter_dictionary_fingerprint` and `output_registry_fingerprint` should match the values above. If they do not, say so before interpreting anything: the definitions in this guide may not describe that report's fields.

## 1. What UMEM is, and what it is not

UMEM (Unconscious Motivation Evolutionary Model) is an abstract, individual-based
evolutionary simulation. Agents have finite lives, internal physiological state
(energy, health, reproductive capital, status), a library of behaviours ("tasks")
grouped into motivational domains, and **heritable propensities** that bias which
behaviour they choose. Agents live in an exogenous stochastic environment, face
competing mortality hazards, reproduce, and pass recombined propensities to
offspring.

Hold these boundaries throughout the conversation:

- **Propensities are functional quantitative constructs**, modelled as polygenic
  additive traits. They are not identified "motivation genes". Never describe a
  result as showing that a gene for a behaviour evolved.
- **Fitness is realised lifetime reproductive success** — the number of surviving
  offspring an agent actually left. Nothing scores or optimises agents. Survival
  is not optimisation; persistence is not proof of function.
- **Homeostasis is not cognition.** Hunger, threat and reproductive urgency shift
  behaviour without any learning or memory, and remain active when every
  cognitive module is off.
- **Cognition modules imply no consciousness or intention.** They are specific
  information pathways (a shared success memory; a shared environmental forecast;
  optional individual reinforcement) that can be switched on or off.
- **All parameters are illustrative.** None is calibrated to a real species or to
  humans. Preset values were chosen so populations persist over tens of seasons.
  Never present a constant as a measured human parameter.
- **Single runs are descriptive only.** Formal comparison needs replications,
  matched conditions and uncertainty estimates.
- **UMEM runs offline and locally.** It performs no AI calls itself. You are
  advising the researcher; UMEM will validate and run whatever they import.

## 2. Current model structure (what can be configured)

**Time.** Discrete steps grouped into seasons (`lifecycle.steps_per_season`,
`lifecycle.total_seasons`). Agents mature after `maturity_seasons` and cannot
exceed `max_lifespan_seasons` (a hard cap, which produces a point mass of deaths
at that age in lifespan histograms).

**Population.** `initial_population` founders whose ages follow
`founder_age_distribution` (`uniform` default; `stable`; `all_newborn_legacy`).
Each newborn is Type A with probability `sex_ratio_type_a`; A/B are neutral
reproductive types, not inherited, never male/female.

**Environment.** Variables (`environment[]`) follow configurable stochastic
processes and are pre-generated: they do not respond to the population.
Agents see them through noisy observation. Tasks and predation can depend on them.

**Behaviours.** `domains[]` and `tasks[]`. Each task has time/energy cost, a
base success probability optionally driven by an environment variable, a
predation exposure multiplier, age/maturity/type restrictions, a `role`
(`functional`, `low_cost_neutral`, `costly_nonfunctional`), and declarative
`effects[]` rules. Choice is a softmax over log-propensity + homeostatic urgency
+ cognitive modulation + noise. Whether a task "does" anything is determined by
its effect rules; the validator warns when the role label disagrees.

**Survival.** Basal metabolism; starvation → health loss → death; competing
stochastic hazards (predation × environment × task exposure, senescence,
background, juvenile, crowding above `density_onset_fraction` of carrying
capacity).

**Reproduction.** `reproduction.timing` is `distributed` (default: every step is
an opportunity; `reproductive_event_rate` attempt events per eligible agent per
season, converted to a per-step hazard so time resolution does not change
intensity) or `season_end_legacy` (compatibility: everyone breeds on the last step
of a season, producing a sawtooth). Eligibility (maturity, energy/health/capital
thresholds, optional `refractory_seasons` after a *successful* event) is separate
from mate choice. `mode` is `sexual` (one Type A + one Type B per event) or
`asexual`. `mating_mode`: `random` (promiscuity), `pair_bonded` (social
monogamy: exclusive persistent bonds formed between mature agents; bonds
reproduce only when both partners are eligible in the same step), `competitive`
(polygyny-like skew: initiators inspect `mate_choice_k` candidates and take the
best by `mate_choice_criterion` using `mate_quality_weights`). Fertility per event,
juvenile survival and Beverton–Holt density-dependent recruitment follow.
**The event rate is not a birth rate**: births = events × P(partner found) ×
fertility × juvenile survival.

**Inheritance.** `inheritance.model = polygenic_additive` (default): Fisher's
infinitesimal model on a centred latent scale — offspring latent value =
mid-parent + N(0, segregation variance), segregation variance =
`segregation_multiplier` × V₀/2 with V₀ the configured founder variance (so the
founder variance is the neutral equilibrium). Asexual offspring are clonal.
Mutation is a separate rare event: probability `mutation_probability_per_offspring`
**per offspring, tested independently in the domain layer and the task layer
when `mutation_target = both`**, adding N(0, `mutation_effect_sd_latent`) to one
random component. Presets: `none`, `conservative` (0.01, 0.10), `accelerated`
(0.05, 0.20), `custom`. `legacy` reproduces the v0.1.0 mechanism.

**Cognition.** `experience_enabled` (A: population-shared memory of successful
agents' task use — correlational), `forecast_enabled` (B: shared EWMA forecast
from past noisy observations), `individual_learning_enabled` (C, off by default).

**Experiments.** `experiment.mode`: `single`, `replications`
(`replications`, `max_workers`), `sweep` (up to three `sweep_parameters[]` by
dotted path, optional `common_random_numbers`). Reproducible from
`master_seed`.

**Recording.** `output.record_interval_steps`, optional agent sample.

### What existing task definitions can and cannot express

Can: any behaviour whose consequences are additive/multiplicative/probabilistic
effects on energy, health, reproductive capital, status, observation quality or
hazard; environment-dependent success; age/maturity/type gating; costly or
neutral behaviours with no benefit; memory eligibility for cognition A.

Cannot (would need an engine extension — say so plainly, do not fake it):
direct agent-to-agent interaction or transfers; social networks; territory as a
spatial object; resource depletion or predator–prey feedback; learning that
generalises across tasks; heritable mate preference; parental care; gestation
under distributed timing; dominance/epistasis in inheritance; any user-supplied
formula or code (effects are declarative rules only).

## 3. Complete parameter dictionary

Generated from the application's configuration models (172 parameters). *Kind* classifies unit-time meaning; *Applies to* says under which mechanisms the field is active — a `legacy_*_only` field is ignored under the current defaults.

| Path | Type | Default | Range | Unit | Kind | Applies to | Description | Scientific meaning |
|---|---|---|---|---|---|---|---|---|
| `schema_version` | int | `2` |  |  |  | all | Config schema version. |  |
| `name` | str | `Untitled` |  |  |  | all | Display name. |  |
| `description` | str | `` |  |  |  | all | Free text. |  |
| `preset_origin` | str (optional) | `None` |  |  |  | all | Preset this derives from, if any. |  |
| `master_seed` | int | `12345` | 0..… |  |  | all | Root seed for reproducibility. |  |
| `population.founder_age_distribution` | enum: `all_newborn_legacy`, `uniform`, `stable` | `uniform` |  |  | mode | all | Age structure of the initial population. | 'all_newborn_legacy' starts every founder at age zero (v0.1.0). 'uniform' spreads ages evenly over the permitted lifespan. 'stable' approximates the stable age distribution implied by the configured baseline hazards. Founder synchrony is an early transient, not the cause of persistent population sawtoothing. |
| `population.initial_population` | int | `200` | 2..… | agents |  | all | Starting agents. |  |
| `population.carrying_capacity` | int | `500` | 1..… | agents |  | all | Soft population ceiling. |  |
| `population.max_population` | int | `5000` | 1..… | agents |  | all | Hard cap for memory safety. |  |
| `population.init_distribution` | enum: `equal`, `gamma`, `lognormal`, `from_file` | `gamma` |  |  |  | all | Propensity init distribution. |  |
| `population.sex_ratio_type_a` | float | `0.5` | 0.0..1.0 | frac |  | all | Fraction born as reproductive type A. |  |
| `population.starting_population_file` | str (optional) | `None` |  |  |  | all | Path for from_file init. |  |
| `lifecycle.steps_per_season` | int | `40` | 1..… | steps |  | all | Time steps in a season. |  |
| `lifecycle.total_seasons` | int | `30` | 1..… | seasons |  | all | Seasons to simulate. |  |
| `lifecycle.actions_per_step` | int | `1` | 1..… |  |  | all | Tasks drawn per step. |  |
| `lifecycle.initial_energy` | float | `70.0` | 0.0..… | 0-100 |  | all | Newborn energy. |  |
| `lifecycle.energy_max` | float | `100.0` | 0.0..… | 0-100 |  | all | Energy ceiling. |  |
| `lifecycle.initial_health` | float | `90.0` | 0.0..… | 0-100 |  | all | Newborn health. |  |
| `lifecycle.health_max` | float | `100.0` | 0.0..… | 0-100 |  | all | Health ceiling. |  |
| `lifecycle.initial_repro_capital` | float | `0.0` | 0.0..… | 0-100 |  | all | Newborn reproductive capital. |  |
| `lifecycle.repro_capital_max` | float | `100.0` | 0.0..… | 0-100 |  | all | Ceiling. |  |
| `lifecycle.initial_status` | float | `50.0` | 0.0..… | 0-100 |  | all | Newborn status. |  |
| `lifecycle.status_max` | float | `100.0` | 0.0..… | 0-100 |  | all | Ceiling. |  |
| `lifecycle.basal_metabolism` | float | `1.0` | 0.0..… | energy/step |  | all | Energy lost per step. |  |
| `lifecycle.rest_energy_cost` | float | `0.5` | 0.0..… | energy |  | all | Energy for fallback rest. |  |
| `lifecycle.health_starvation_penalty` | float | `10.0` | 0.0..… | health/step |  | all | Health lost per step at zero energy. |  |
| `lifecycle.maturity_seasons` | int | `2` | 0..… | seasons |  | all | Age of reproductive maturity. |  |
| `lifecycle.max_lifespan_seasons` | int | `12` | 1..… | seasons |  | all | Hard lifespan ceiling. |  |
| `lifecycle.newborns_act_next_step` | bool | `True` |  |  |  | all | Newborns act from the next step, not immediately. |  |
| `mortality.base_predation_hazard` | float | `0.02` | 0.0..1.0 | prob |  | all | Per-step baseline predation hazard. |  |
| `mortality.predation_env_driver` | str (optional) | `predator` |  |  |  | all | Env variable scaling predation. |  |
| `mortality.predation_env_sensitivity` | float | `1.0` | 0.0..… |  |  | all | Scaling of hazard by driver. |  |
| `mortality.age_hazard_shape` | enum: `gompertz`, `logistic` | `gompertz` |  |  |  | all | Gompertz or logistic senescence. |  |
| `mortality.age_hazard_scale` | float | `0.002` | 0.0..… |  |  | all | Baseline age hazard. |  |
| `mortality.age_hazard_rate` | float | `0.15` | 0.0..… |  |  | all | Growth of hazard with age (per season). |  |
| `mortality.background_hazard` | float | `0.0` | 0.0..1.0 | prob |  | all | Constant per-step mortality. |  |
| `mortality.juvenile_extra_hazard` | float | `0.0` | 0.0..1.0 | prob |  | all | Extra per-step hazard before maturity. |  |
| `mortality.density_hazard_strength` | float | `0.5` | 0.0..… |  |  | all | Extra hazard as pop approaches K. |  |
| `mortality.density_onset_fraction` | float | `0.6` | 0.0..… |  |  | all | Fraction of carrying capacity at which crowding mortality begins. Below this the density hazard is zero. |  |
| `mortality.density_affects_juveniles_only` | bool | `True` |  |  |  | all | Apply density hazard only to juveniles. |  |
| `reproduction.mode` | enum: `sexual`, `asexual` | `sexual` |  |  | mode | all | Sexual or asexual reproduction. | Sexual requires one Type-A and one Type-B agent per event; asexual requires none. |
| `reproduction.timing` | enum: `distributed`, `season_end_legacy` | `distributed` |  |  | mode | all | Continuous (recommended) or legacy season-end batching. | Under 'distributed' every time step is an opportunity to reproduce, as in a non-Wright-Fisher model, and season boundaries carry no reproductive meaning. 'season_end_legacy' reproduces the v0.1.0 behaviour in which all eligible agents breed together on the last step of a season; it is a compatibility mode and produces a season-period sawtooth in population size. |
| `reproduction.reproductive_event_rate` | float | `1.0` | 0.0..… | events/agent/season | rate | distributed_only | Reproductive *attempt events* per eligible agent per season. | An event rate, not a birth count. Births per event = this rate x P(partner found) x fertility per event x juvenile survival, so realised births are lower. Converted to a per-step hazard by 1 - exp(-rate / steps_per_season), so expected events per season do not change with time resolution; geometric waiting times desynchronise reproduction. The former name 'expected_births_per_season' is accepted on input and was misleading. |
| `reproduction.refractory_seasons` | float | `0.0` | 0.0..… | seasons | interval | all | Minimum time before breeding again after success. | Starts only after a *successful* reproductive event; failed attempts do not trigger it and cost nothing. Stored internally in steps. |
| `reproduction.mating_mode` | enum: `random`, `pair_bonded`, `competitive` | `random` |  |  | mode | sexual_only | Random mixing, pair bonding, or competitive. | Random = promiscuity (no bonds, no preference); pair_bonded = social monogamy (exclusive, persistent); competitive = polygyny-like skew (choosy, non-exclusive). All three run through the same matching engine and differ only in persistence, exclusivity and choosiness. |
| `reproduction.mate_choice_k` | int | `1` | 1..… | candidates | count | sexual_only | Number of candidates inspected per choice. | Random-k pair matching: the chooser inspects k randomly drawn candidates and takes the best. k=1 is unbiased random mating; the expected rank of the chosen partner is n/(k+1), so larger k concentrates reproductive success and raises the opportunity for selection. |
| `reproduction.mate_choice_criterion` | enum: `partner_quality`, `similarity` | `partner_quality` |  |  | mode | sexual_only | Maximise partner quality, or match similarity. | Partner quality produces reproductive skew; similarity produces assortative mating. |
| `reproduction.mate_quality_weights` | dict[str, float] | `{"status": 1.0, "repro_capital": 0.3, "health": 0.25, "energy": 0.25}` |  |  | weight | sexual_only | Weights over agent state defining mate quality. | A declarative weighted sum over normalised state variables. Only these four keys are permitted; no user expression is ever evaluated. Weight non-depletable traits such as status to obtain reproductive skew: reproductive capital is reset when an agent breeds, so choosing on it makes 'quality' amount to 'time since last breeding', which equalises rather than concentrates reproductive success. |
| `reproduction.bond_formation_per_season` | float | `2.0` | 0.0..… | events/agent/season | rate | pair_bond_only | Rate at which unpaired mature agents form bonds. | Bond formation requires maturity only. Energy, health and capital thresholds govern whether a bond can reproduce, not whether it can form. |
| `reproduction.bond_dissolution_per_season` | float | `0.0` | 0.0..… | events/pair/season | rate | pair_bond_only | Rate at which existing bonds dissolve. | Zero by default, so bonds end only at the death of a partner. A conservative non-zero value models serial monogamy. |
| `reproduction.breeding_every_seasons` | int | `1` | 1..… | seasons | interval | legacy_timing_only | Seasons between breeding events under season-end timing. **Deprecated/legacy:** Use reproduction.refractory_seasons with distributed timing. | Active only when timing is season_end_legacy. Distributed timing uses refractory_seasons instead; this field is then ignored. |
| `reproduction.energy_threshold` | float | `40.0` | 0.0..… | 0-100 |  | all | Min energy to breed. |  |
| `reproduction.health_threshold` | float | `30.0` | 0.0..… | 0-100 |  | all | Min health to breed. |  |
| `reproduction.repro_capital_threshold` | float | `0.0` | 0.0..… | 0-100 |  | all | Min reproductive capital to breed. |  |
| `reproduction.mate_selection` | enum: `random`, `weighted_capital`, `competitive`, `assortative` | `weighted_capital` |  |  |  | all | How mates are chosen. |  |
| `reproduction.mate_availability_driver` | str (optional) | `mate` |  |  |  | all | Env variable for mate availability. |  |
| `reproduction.max_offspring_per_event` | int | `3` | 1..… |  |  | all | Cap per breeding event. |  |
| `reproduction.fertility_distribution` | enum: `fixed`, `poisson`, `binomial`, `discrete` | `poisson` |  |  |  | all | Distribution of surviving offspring. |  |
| `reproduction.fertility_mean` | float | `1.5` | 0.0..… | offspring |  | all | Mean surviving offspring per event. |  |
| `reproduction.fertility_binomial_p` | float | `0.5` | 0.0..1.0 | prob |  | all | Success prob for binomial fertility. |  |
| `reproduction.fertility_discrete_pmf` | list[float] | `[]` |  |  |  | all | Probabilities for 0,1,2,... offspring. |  |
| `reproduction.repro_energy_cost` | float | `20.0` | 0.0..… | energy |  | all | Energy spent per breeding. |  |
| `reproduction.repro_health_cost` | float | `5.0` | 0.0..… | health |  | all | Health spent per breeding. |  |
| `reproduction.gestation_delay_steps` | int | `0` | 0..… | steps | interval | legacy_timing_only | Steps before offspring appear under season-end timing. **Deprecated/legacy:** No gestation model exists under distributed timing. | The continuous (distributed) model has no gestation mechanism: a non-zero value is a blocking validation error under distributed timing, never silently ignored. Retained for reproducing season-end legacy scenarios only. |
| `reproduction.juvenile_survival` | float | `0.85` | 0.0..1.0 | prob |  | all | Prob a newborn survives to enter pop. |  |
| `reproduction.density_dependent_recruitment` | bool | `True` |  |  |  | all | Soft Beverton-Holt decline of juvenile survival as population approaches carrying capacity. |  |
| `reproduction.recruitment_strength` | float | `1.0` | 0.0..… |  |  | all | Steepness of density-dependent recruitment. |  |
| `inheritance.model` | enum: `polygenic_additive`, `legacy` | `polygenic_additive` |  |  | mode | all | Polygenic additive (recommended) or the legacy v0.1.0 mechanism. | Polygenic additive treats propensities as latent quantitative traits inherited by Fisher's infinitesimal model, the standard approximation to many small-effect Mendelian loci. Legacy is a compatibility mode for scenarios written before schema 2. |
| `inheritance.sibling_variation` | enum: `low`, `standard`, `high`, `custom` | `standard` |  |  | mode | polygenic_only | How much full siblings differ through segregation. | Scales the Mendelian segregation variance. At 'standard' the configured founder variance is the equilibrium, so genetic variation neither inflates nor decays as an artifact. |
| `inheritance.segregation_multiplier` | float | `1.0` | 0.0..… | x V0/2 | scale | polygenic_only | Used when sibling variation is custom. | Segregation variance is multiplier x V0 / 2, where V0 is the configured founder additive variance. The 0.5 factor is the Mendelian sampling variance of an outbred individual. |
| `inheritance.mutation_level` | enum: `none`, `conservative`, `accelerated`, `custom` | `conservative` |  |  | mode | polygenic_only | None, conservative, accelerated, or custom. | Rare introduction of novel variation, configured and reported separately from segregation. These are effective simulation parameters, not empirical per-base mutation rates. |
| `inheritance.mutation_probability_per_offspring` | float | `0.01` | 0.0..1.0 | prob/offspring | probability | polygenic_only | Chance of an effective mutation per offspring. | Probability that an offspring experiences one effective mutation event in a given propensity layer. |
| `inheritance.mutation_effect_sd_latent` | float | `0.1` | 0.0..… | latent sd | scale | polygenic_only | Zero-mean effect sd, absolute latent units. | Standard deviation of the mutation increment on the latent log-ratio scale; 0.10 is roughly a 10% change in relative odds. Absolute units are used so that a scenario with zero founder variance still mutates. |
| `inheritance.mutation_target` | enum: `domain`, `task`, `both` | `both` |  |  | mode | polygenic_only | Which propensity layer mutation may strike. | Domain, task, or both. Layers are judged independently when set to both. |
| `inheritance.mutation_probability` | float | `1.0` | 0.0..1.0 | prob | probability | legacy_inheritance_only | Prob a trait mutates. **Deprecated/legacy:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. |
| `inheritance.mutation_log_sd` | float | `0.1` | 0.0..… |  | scale | legacy_inheritance_only | Log-normal mutation sd (multiplicative). **Deprecated/legacy:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. |
| `inheritance.recombination_per_trait` | bool | `True` |  |  | mode | legacy_inheritance_only | Pick each trait from one parent vs. blend. **Deprecated/legacy:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. |
| `inheritance.blend_alpha` | float | `0.5` | 0.0..1.0 |  | weight | legacy_inheritance_only | Parent-A weight when blending. **Deprecated/legacy:** Polygenic model uses mutation_level, mutation_probability_per_offspring, mutation_effect_sd_latent. | Legacy inheritance model only; ignored under polygenic_additive. |
| `inheritance.min_propensity` | float | `0.01` | 0.0..… |  | threshold | all | Floor keeping traits positive. | Legacy floor, and the floor that keeps the legacy-to-latent log conversion finite. |
| `homeostasis.enabled` | bool | `True` |  |  |  | all | Master switch. |  |
| `homeostasis.hunger_enabled` | bool | `True` |  |  |  | all | Energy urgency on. |  |
| `homeostasis.hunger_strength` | float | `2.0` | 0.0..… |  |  | all | Logit boost to food tasks when hungry. |  |
| `homeostasis.safety_enabled` | bool | `True` |  |  |  | all | Threat urgency on. |  |
| `homeostasis.safety_strength` | float | `2.0` | 0.0..… |  |  | all | Logit boost to safety tasks under threat. |  |
| `homeostasis.reproduction_enabled` | bool | `True` |  |  |  | all | Reproductive urgency on. |  |
| `homeostasis.reproduction_strength` | float | `2.0` | 0.0..… |  |  | all | Logit boost to reproduction when ready. |  |
| `cognition.experience_enabled` | bool | `False` |  |  |  | all | Intergenerational memory on. |  |
| `cognition.experience_success_definition` | enum: `survived`, `reproduced`, `surviving_offspring`, `top_quantile_lrs` | `surviving_offspring` |  |  |  | all | Who counts as successful. |  |
| `cognition.experience_top_quantile` | float | `0.2` | 0.0..1.0 |  |  | all | Quantile for top-LRS definition. |  |
| `cognition.experience_weight_recent` | float | `0.7` | 0.0..1.0 |  |  | all | Weight on the most recent cohort. |  |
| `cognition.experience_smoothing` | float | `1.0` | 0.0..… |  |  | all | Additive smoothing on counts. |  |
| `cognition.experience_noise_sd` | float | `0.3` | 0.0..… |  |  | all | Noise on the memory signal. |  |
| `cognition.experience_strength` | float | `2.5` | 0.0..… |  |  | all | Logit multiplier from memory. |  |
| `cognition.forecast_enabled` | bool | `False` |  |  |  | all | Noisy env forecasting on. |  |
| `cognition.forecast_memory` | float | `0.6` | 0.0..1.0 |  |  | all | EWMA lambda on past forecast. |  |
| `cognition.forecast_strength` | float | `1.0` | 0.0..… |  |  | all | Logit shift from forecast surprise. |  |
| `cognition.individual_learning_enabled` | bool | `False` |  |  |  | all | Per-agent EWMA reinforcement (advanced). |  |
| `cognition.individual_learning_rate` | float | `0.2` | 0.0..1.0 |  |  | all | EWMA rate on own outcomes. |  |
| `cognition.individual_learning_strength` | float | `1.0` | 0.0..… |  |  | all | Logit shift from own experience. |  |
| `choice.softmax_temperature` | float | `1.0` | 0.0..… |  |  | all | Higher = more random choice. |  |
| `choice.decision_noise_sd` | float | `0.1` | 0.0..… |  |  | all | Gumbel-like logit noise sd. |  |
| `experiment.mode` | enum: `single`, `replications`, `sweep` | `single` |  |  |  | all | single/replications/sweep. |  |
| `experiment.replications` | int | `1` | 1..… | runs |  | all | Independent repeats. |  |
| `experiment.max_workers` | int | `1` | 1..… |  |  | all | Parallel processes for replicates. |  |
| `experiment.sweep_parameters` | list[SweepParameter] | `[]` |  |  |  | all | 1-3 parameters to sweep. |  |
| `experiment.max_sweep_combinations` | int | `500` | 1..… |  |  | all | Warn/refuse above this. |  |
| `experiment.common_random_numbers` | bool | `False` |  |  |  | all | Reuse seeds across sweep conditions. |  |
| `output.record_interval_steps` | int | `10` | 1..… | steps |  | all | Steps between snapshots. |  |
| `output.store_agent_sample` | bool | `True` |  |  |  | all | Store a reproducible agent sample. |  |
| `output.agent_sample_size` | int | `50` | 1..… |  |  | all | Agents per snapshot sample. |  |
| `output.store_event_log` | bool | `False` |  |  |  | all | Store detailed events (large!). |  |
| `domains[].domain_id` | str | required |  |  |  | all | Immutable key. |  |
| `domains[].name` | str | required |  |  |  | all | Display name. |  |
| `domains[].init_mean` | float | `1.0` | 0.0..… |  |  | all | Mean initial propensity. |  |
| `domains[].init_var` | float | `0.5` | 0.0..… |  |  | all | Initial variance. |  |
| `tasks[].task_id` | str | required |  |  |  | all | Immutable unique key. |  |
| `tasks[].name` | str | required |  |  |  | all | Display name. |  |
| `tasks[].description` | str | `` |  |  |  | all | Free text. |  |
| `tasks[].domain` | str | required |  |  |  | all | Behavioural domain id. |  |
| `tasks[].enabled` | bool | `True` |  |  |  | all | Include in runs. |  |
| `tasks[].time_cost` | float | `1.0` | 0.0..… | steps |  | all | Time steps consumed. |  |
| `tasks[].energy_cost` | float | `1.0` | 0.0..… | energy |  | all | Direct energy spent. |  |
| `tasks[].base_success` | float | `0.2` | 0.0..1.0 | prob |  | all | Baseline success probability. |  |
| `tasks[].success_env_driver` | str (optional) | `None` |  |  |  | all | Env variable modulating success. |  |
| `tasks[].success_env_sensitivity` | float | `0.0` |  |  |  | all | Logit shift per unit env driver. |  |
| `tasks[].outcome_noise` | float | `0.3` | 0.0..… |  |  | all | Logit noise sd on success. |  |
| `tasks[].predation_multiplier` | float | `1.0` | 0.0..… |  |  | all | Per-step hazard multiplier. |  |
| `tasks[].min_age_steps` | int | `0` | 0..… |  |  | all | Age gate. |  |
| `tasks[].max_age_steps` | int (optional) | `None` |  |  |  | all | Upper age gate (optional). |  |
| `tasks[].require_mature` | bool | `False` |  |  |  | all | Maturity gate. |  |
| `tasks[].sex_restriction` | enum: `any`, `type_a`, `type_b` | `any` |  |  |  | all | Reproductive-type gate. |  |
| `tasks[].observable_to_actor` | bool | `True` |  |  |  | all | Actor sees its own outcome. |  |
| `tasks[].public_signal` | bool | `False` |  |  |  | all | Non-actors see a weak public signal. |  |
| `tasks[].role` | enum: `functional`, `low_cost_neutral`, `costly_nonfunctional` | `functional` |  |  |  | all | functional / neutral / costly nonfunctional. |  |
| `tasks[].memory_eligible` | bool | `True` |  |  |  | all | May enter intergenerational memory. |  |
| `tasks[].effects` | list[TaskEffectRule] | `[]` |  |  |  | all | Multidimensional effects. |  |
| `tasks[].effects[].target` | enum: `energy`, `health`, `repro_capital`, `status`, `hazard`, `observation_quality` | required |  |  |  | all | State variable this rule changes. |  |
| `tasks[].effects[].effect_type` | enum: `additive`, `multiplicative`, `probability_modifier`, `bounded_replacement` | `additive` |  |  |  | all | How the value combines with state. |  |
| `tasks[].effects[].base_value` | float | `0.0` |  | state units |  | all | Magnitude before env scaling. |  |
| `tasks[].effects[].condition` | enum: `always`, `on_success`, `on_failure` | `on_success` |  |  |  | all | Fires on success, failure, or always. |  |
| `tasks[].effects[].env_driver` | str (optional) | `None` |  |  |  | all | Env variable id that scales this effect. |  |
| `tasks[].effects[].env_sensitivity` | float | `0.0` |  |  |  | all | Coupling of the effect to the env driver. |  |
| `tasks[].effects[].noise_std` | float | `0.0` | 0.0..… | state units |  | all | Gaussian noise on the effect. |  |
| `tasks[].effects[].min_age_steps` | int | `0` | 0..… |  |  | all | Rule inactive below this age. |  |
| `tasks[].effects[].require_mature` | bool | `False` |  |  |  | all | Rule only for mature agents. |  |
| `tasks[].effects[].sex_restriction` | enum: `any`, `type_a`, `type_b` | `any` |  |  |  | all | Reproductive type this rule needs. |  |
| `environment[].var_id` | str | required |  |  |  | all | Immutable unique key. |  |
| `environment[].name` | str | required |  |  |  | all | Display name. |  |
| `environment[].description` | str | `` |  |  |  | all | Free text. |  |
| `environment[].process` | enum: `constant`, `random_walk`, `ar1`, `seasonal`, `ar1_seasonal`, `regime_switching`, `rare_shocks`, `imported` | `ar1` |  |  |  | all | Stochastic process type. |  |
| `environment[].initial_value` | float | `0.5` |  | norm 0-1 |  | all | Value at t=0. |  |
| `environment[].mean` | float | `0.5` |  | norm 0-1 |  | all | Reversion target. |  |
| `environment[].min_value` | float | `0.0` |  | norm |  | all | Lower bound. |  |
| `environment[].max_value` | float | `1.0` |  | norm |  | all | Upper bound. |  |
| `environment[].persistence` | float | `0.9` | 0.0..1.0 |  |  | all | AR(1) autocorrelation. |  |
| `environment[].volatility` | float | `0.05` | 0.0..… |  |  | all | Innovation sd. |  |
| `environment[].seasonal_amplitude` | float | `0.0` | 0.0..… |  |  | all | Seasonal amplitude. |  |
| `environment[].seasonal_period_steps` | int | `40` | 1..… | steps |  | all | Steps per cycle. |  |
| `environment[].shock_probability` | float | `0.0` | 0.0..1.0 | prob |  | all | Per-step shock probability. |  |
| `environment[].shock_magnitude` | float | `0.0` |  |  |  | all | Additive shock magnitude. |  |
| `environment[].shock_duration_steps` | int | `1` | 1..… | steps |  | all | Steps a shock persists. |  |
| `environment[].regime_values` | list[float] | `[]` |  |  |  | all | Values for regime switching. |  |
| `environment[].regime_switch_prob` | float | `0.02` | 0.0..1.0 | prob |  | all | Per-step switch probability. |  |
| `environment[].imported_series` | list[float] | `[]` |  |  |  | all | User time series (process=imported). |  |
| `environment[].observation_noise` | float | `0.05` | 0.0..… |  |  | all | Noise sd on agent observations. |  |
| `environment[].globally_observable` | bool | `True` |  |  |  | all | Directly observed by agents. |  |
| `experiment.sweep_parameters[].path` | str | required |  |  |  | all | Dotted config path, e.g. mortality.base_predation_hazard. |  |
| `experiment.sweep_parameters[].values` | list[float] | `[]` |  |  |  | all | Explicit values. |  |
| `experiment.sweep_parameters[].start` | float (optional) | `None` |  |  |  | all | Range start. |  |
| `experiment.sweep_parameters[].stop` | float (optional) | `None` |  |  |  | all | Range stop. |  |
| `experiment.sweep_parameters[].step` | float (optional) | `None` |  |  |  | all | Range step. |  |
| `experiment.sweep_parameters[].logarithmic` | bool | `False` |  |  |  | all | Log-spaced range. |  |

## 4. How to conduct the design interview

You are helping a behavioural-science researcher who does not program. Converse in
**the user's preferred language**, but keep every JSON key, ID, enum value and
unit exactly as specified in this guide (English, verbatim).

1. **Start with the science, not the parameters.** Ask what question they want to
   answer, which behaviours matter, what kind of environment, and what they intend
   to compare (e.g. cognition on vs off; scarce vs abundant; monogamy vs random
   mating). If they supply a current scenario JSON, treat it as the baseline and
   change only what they ask to change.
2. **Ask a few plain-language questions at a time.** Never hand them the full
   parameter list. Translate their answers into settings yourself.
3. **Resolve scientifically consequential choices explicitly** — reproduction
   timing, mating mode, asexual vs sexual, inheritance model, cognition modules,
   which tasks are nonfunctional, experiment mode and replication count. For
   secondary settings propose sensible defaults (the example scenario's values are
   safe) and say in one sentence what each default does.
4. **Keep three lists visible**: decisions the user made; defaults you proposed;
   assumptions still unresolved. Ask about unresolved ones before finalising.
5. **If a request is not representable**, say so, and offer a clearly labelled
   supported approximation without pretending it is equivalent.
6. **Recommend replications and controlled comparisons.** A single run is
   descriptive. Matched conditions differing in one setting, with the same master
   seed, are the strongest design UMEM supports.
7. **Summarise the complete proposed experimental conditions in prose** before
   emitting JSON, and get confirmation.
8. **Never claim UMEM has validated or run anything.** Validation happens when the
   user imports the JSON into UMEM. If they paste back a "UMEM import validation
   feedback" message, fix exactly the listed issues and preserve everything else.
9. **Never present illustrative constants as measured human parameters**, and
   never describe propensities as identified genes.

## 5. Output contract

When the design is confirmed, return **one complete scenario object** as valid
JSON, either raw or inside a single ```json fenced block. Requirements:

- Complete: every section present (`domains`, `tasks`, `environment`,
  `population`, `lifecycle`, `mortality`, `reproduction`, `inheritance`,
  `homeostasis`, `cognition`, `choice`, `experiment`, `output`, plus
  `schema_version`, `name`, `description`, `master_seed`). Start from the example
  in section 6 and modify it; do not invent fields.
- `schema_version` must be the value in the identity block above.
- No comments, no `NaN`, no `Infinity`, no placeholders such as `...` or `TODO`,
  no Python, no explanations *inside* the JSON. Prose belongs outside the block.
- Every `tasks[].domain` must name an existing `domains[].domain_id`; every
  `success_env_driver`, `effects[].env_driver`, `mortality.predation_env_driver`
  and `reproduction.mate_availability_driver` must name an existing
  `environment[].var_id`; every `sweep_parameters[].path` must be a real dotted
  path from the dictionary.
- Unknown keys are rejected. Legacy-only fields (marked `legacy_timing_only` /
  `legacy_inheritance_only`) are ignored under the new defaults; do not rely on
  them. Under `distributed` timing `gestation_delay_steps` must be 0.
- Rename via `name`/`description` freely; they do not affect the scientific
  configuration hash.

If you need a full copy of a different preset, ask the user to download it from
UMEM (Scenario manager → Download scenario JSON, or `umem-workbench export-presets`).
Do not reconstruct a preset from its name.

## 6. Complete, importable example scenario

Produced and validated by UMEM v0.3.0; scientific configuration hash `d6b1e6f47907cd23ac1d52bb1bd418acc03f80472ad20e09fb7dab3ae32864b9`. Use it as the starting point and modify only what the researcher's design requires. Every referenced domain, task and environment variable is defined below — nothing is elided.

UMEM's own deterministic description of this example (so you can see how settings read back as prose):

**Population and time.** The simulation starts with 200 agents and runs for 30 seasons of 40 time steps each (1200 steps). Carrying capacity is 500 agents and a hard ceiling of 3000 prevents runaway growth. Agents mature after 2 season(s) and cannot live beyond 12 seasons; founder ages are spread uniformly over the permitted lifespan. Each newborn is assigned reproductive Type A with probability 0.5 (Type A/B are neutral labels, not sexes, and are not inherited).

**Environment.** The environment is exogenous and pre-generated: it does not respond to the population, so there is no resource depletion or predator–prey feedback. `food` follows a ar1 process around a mean of 0.8 (volatility 0.03, persistence 0.97), observed with noise 0.05; `predator` follows a ar1 process around a mean of 0.2 (volatility 0.05, persistence 0.7, shock probability 0.01), observed with noise 0.08; `mate` follows a ar1 process around a mean of 0.7 (volatility 0.02, persistence 0.99), observed with noise 0.05.

**Available behaviours.** Agents choose among 11 enabled tasks grouped into 4 motivational domains (food, safety, reproduction, neutral). 9 tasks confer a direct benefit; 1 are low-cost neutral behaviours with no modelled benefit, and 1 are costly nonfunctional behaviours that spend time or energy for no benefit. Choice is a softmax (temperature 1) over inherited propensity, homeostatic urgency and any enabled cognition, with decision noise 0.1 and 1 action(s) per step.

**Survival constraints.** Every step each agent pays basal metabolism 1 energy (plus 0.5 when it cannot act); at zero energy it loses 10 health per step and dies when health reaches zero. Stochastic hazards act every step and combine as competing risks: a base predation hazard of 0.0015 per step scaled by the predator variable and by the chosen task's exposure multiplier; a gompertz senescence hazard (scale 0.0008, rate 0.12); a background hazard of 0; an extra 0.003 for juveniles; and a crowding hazard that switches on above 0.6 of carrying capacity (strength 0.4). Homeostasis is enabled: hunger (strength 2), threat/safety (strength 2), reproductive readiness (strength 2) shift task choice. This is physiological regulation, not cognition.

**Reproduction.** An agent is eligible to reproduce when mature, with energy ≥ 40, health ≥ 30 and reproductive capital ≥ 0. Reproduction is continuous: every time step is an opportunity. Eligible agents initiate reproductive attempts at a rate of 1.7 per season (a per-step hazard of 0.0416). This is an attempt-event rate, not a birth rate: realised births also depend on finding a partner, the fertility draw and juvenile recruitment. There is no refractory period; failed attempts cost nothing. Mating is random mixing (promiscuity): an initiating agent takes any available eligible partner of the complementary type without preference. Each event requires one Type A and one Type B parent. Parental costs are symmetric (20 energy, 5 health each) and both contribute equally to offspring. Each successful event yields a poisson fertility draw with mean 1.5 (at most 3); each offspring survives recruitment with probability 0.85, reduced by Beverton–Holt density dependence (strength 1) as the population approaches carrying capacity.

**Inheritance and mutation.** Motivational propensities are heritable polygenic quantitative traits on a latent scale, expressed as proportions that sum to one within the domain layer and within each domain's tasks; they are not identified genes. Each offspring's latent value is the mid-parent value plus an independent Mendelian segregation term whose variance is 1 × V₀/2, where V₀ is the configured founder variance (sibling variation: standard); at 1.0 the founder variance is the neutral equilibrium. Mutation (conservative) is a separate rare event: with probability 0.01 per offspring in the domain layer and the task layer, tested independently, so one offspring can carry up to two events, one randomly chosen component receives a zero-mean shift of standard deviation 0.1 in latent (log-ratio) units. These are effective simulation parameters, not human mutation rates.

**Cognition.** All cognitive mechanisms are disabled: behaviour is driven only by inherited propensity, homeostasis and noise (a pure evolutionary baseline).

**Experiment design.** A single run. One trajectory is descriptive only and cannot support conclusions; use replications for inference. Master seed 12345. Fitness is realised lifetime reproductive success, an outcome, not a score imposed on agents.

**Recording.** Population-level snapshots are recorded every 10 step(s), plus a closing snapshot after the final reproduction. A reproducible sample of 50 agents is stored per snapshot.

```json
{
  "choice": {
    "decision_noise_sd": 0.1,
    "softmax_temperature": 1.0
  },
  "cognition": {
    "experience_enabled": false,
    "experience_noise_sd": 0.3,
    "experience_smoothing": 1.0,
    "experience_strength": 2.5,
    "experience_success_definition": "surviving_offspring",
    "experience_top_quantile": 0.2,
    "experience_weight_recent": 0.7,
    "forecast_enabled": false,
    "forecast_memory": 0.6,
    "forecast_strength": 1.0,
    "individual_learning_enabled": false,
    "individual_learning_rate": 0.2,
    "individual_learning_strength": 1.0
  },
  "description": "A complete, validated example produced by UMEM itself. Every referenced domain, task and environment variable is defined here.",
  "domains": [
    {
      "domain_id": "food",
      "init_mean": 1.0,
      "init_var": 0.5,
      "name": "Food"
    },
    {
      "domain_id": "safety",
      "init_mean": 1.0,
      "init_var": 0.5,
      "name": "Safety"
    },
    {
      "domain_id": "reproduction",
      "init_mean": 1.0,
      "init_var": 0.5,
      "name": "Reproduction"
    },
    {
      "domain_id": "neutral",
      "init_mean": 1.0,
      "init_var": 0.5,
      "name": "Neutral / other"
    }
  ],
  "environment": [
    {
      "description": "",
      "globally_observable": true,
      "imported_series": [],
      "initial_value": 0.8,
      "max_value": 1.0,
      "mean": 0.8,
      "min_value": 0.0,
      "name": "Food availability",
      "observation_noise": 0.05,
      "persistence": 0.97,
      "process": "ar1",
      "regime_switch_prob": 0.02,
      "regime_values": [],
      "seasonal_amplitude": 0.0,
      "seasonal_period_steps": 40,
      "shock_duration_steps": 3,
      "shock_magnitude": -0.3,
      "shock_probability": 0.0,
      "var_id": "food",
      "volatility": 0.03
    },
    {
      "description": "",
      "globally_observable": true,
      "imported_series": [],
      "initial_value": 0.2,
      "max_value": 1.0,
      "mean": 0.2,
      "min_value": 0.0,
      "name": "Predator pressure",
      "observation_noise": 0.08,
      "persistence": 0.7,
      "process": "ar1",
      "regime_switch_prob": 0.02,
      "regime_values": [],
      "seasonal_amplitude": 0.0,
      "seasonal_period_steps": 40,
      "shock_duration_steps": 2,
      "shock_magnitude": 0.3,
      "shock_probability": 0.01,
      "var_id": "predator",
      "volatility": 0.05
    },
    {
      "description": "",
      "globally_observable": true,
      "imported_series": [],
      "initial_value": 0.7,
      "max_value": 1.0,
      "mean": 0.7,
      "min_value": 0.0,
      "name": "Mate availability",
      "observation_noise": 0.05,
      "persistence": 0.99,
      "process": "ar1",
      "regime_switch_prob": 0.02,
      "regime_values": [],
      "seasonal_amplitude": 0.0,
      "seasonal_period_steps": 40,
      "shock_duration_steps": 1,
      "shock_magnitude": 0.0,
      "shock_probability": 0.0,
      "var_id": "mate",
      "volatility": 0.02
    }
  ],
  "experiment": {
    "common_random_numbers": false,
    "max_sweep_combinations": 500,
    "max_workers": 1,
    "mode": "single",
    "replications": 1,
    "sweep_parameters": []
  },
  "homeostasis": {
    "enabled": true,
    "hunger_enabled": true,
    "hunger_strength": 2.0,
    "reproduction_enabled": true,
    "reproduction_strength": 2.0,
    "safety_enabled": true,
    "safety_strength": 2.0
  },
  "inheritance": {
    "blend_alpha": 0.5,
    "min_propensity": 0.01,
    "model": "polygenic_additive",
    "mutation_effect_sd_latent": 0.1,
    "mutation_level": "conservative",
    "mutation_log_sd": 0.1,
    "mutation_probability": 1.0,
    "mutation_probability_per_offspring": 0.01,
    "mutation_target": "both",
    "recombination_per_trait": true,
    "segregation_multiplier": 1.0,
    "sibling_variation": "standard"
  },
  "lifecycle": {
    "actions_per_step": 1,
    "basal_metabolism": 1.0,
    "energy_max": 100.0,
    "health_max": 100.0,
    "health_starvation_penalty": 10.0,
    "initial_energy": 70.0,
    "initial_health": 90.0,
    "initial_repro_capital": 0.0,
    "initial_status": 50.0,
    "maturity_seasons": 2,
    "max_lifespan_seasons": 12,
    "newborns_act_next_step": true,
    "repro_capital_max": 100.0,
    "rest_energy_cost": 0.5,
    "status_max": 100.0,
    "steps_per_season": 40,
    "total_seasons": 30
  },
  "master_seed": 12345,
  "mortality": {
    "age_hazard_rate": 0.12,
    "age_hazard_scale": 0.0008,
    "age_hazard_shape": "gompertz",
    "background_hazard": 0.0,
    "base_predation_hazard": 0.0015,
    "density_affects_juveniles_only": true,
    "density_hazard_strength": 0.4,
    "density_onset_fraction": 0.6,
    "juvenile_extra_hazard": 0.003,
    "predation_env_driver": "predator",
    "predation_env_sensitivity": 1.0
  },
  "name": "Example: stable abundant ecology (importable)",
  "output": {
    "agent_sample_size": 50,
    "record_interval_steps": 10,
    "store_agent_sample": true,
    "store_event_log": false
  },
  "population": {
    "carrying_capacity": 500,
    "founder_age_distribution": "uniform",
    "init_distribution": "gamma",
    "initial_population": 200,
    "max_population": 3000,
    "sex_ratio_type_a": 0.5,
    "starting_population_file": null
  },
  "preset_origin": "stable_abundant",
  "reproduction": {
    "bond_dissolution_per_season": 0.0,
    "bond_formation_per_season": 2.0,
    "breeding_every_seasons": 1,
    "density_dependent_recruitment": true,
    "energy_threshold": 40.0,
    "fertility_binomial_p": 0.5,
    "fertility_discrete_pmf": [],
    "fertility_distribution": "poisson",
    "fertility_mean": 1.5,
    "gestation_delay_steps": 0,
    "health_threshold": 30.0,
    "juvenile_survival": 0.85,
    "mate_availability_driver": "mate",
    "mate_choice_criterion": "partner_quality",
    "mate_choice_k": 1,
    "mate_quality_weights": {
      "energy": 0.25,
      "health": 0.25,
      "repro_capital": 0.3,
      "status": 1.0
    },
    "mate_selection": "weighted_capital",
    "mating_mode": "random",
    "max_offspring_per_event": 3,
    "mode": "sexual",
    "recruitment_strength": 1.0,
    "refractory_seasons": 0.0,
    "repro_capital_threshold": 0.0,
    "repro_energy_cost": 20.0,
    "repro_health_cost": 5.0,
    "reproductive_event_rate": 1.7,
    "timing": "distributed"
  },
  "schema_version": 2,
  "tasks": [
    {
      "base_success": 0.2,
      "description": "Moderate food gain, high success, low exposure.",
      "domain": "food",
      "effects": [
        {
          "base_value": 8.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "energy"
        }
      ],
      "enabled": true,
      "energy_cost": 1.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Safe Foraging",
      "observable_to_actor": true,
      "outcome_noise": 0.3,
      "predation_multiplier": 0.9,
      "public_signal": false,
      "require_mature": false,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": "food",
      "success_env_sensitivity": 3.0,
      "task_id": "safe_forage",
      "time_cost": 1.0
    },
    {
      "base_success": 0.1,
      "description": "High food gain, variable success, high exposure.",
      "domain": "food",
      "effects": [
        {
          "base_value": 18.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "energy"
        }
      ],
      "enabled": true,
      "energy_cost": 2.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Risky Foraging",
      "observable_to_actor": true,
      "outcome_noise": 0.4,
      "predation_multiplier": 1.6,
      "public_signal": false,
      "require_mature": false,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": "food",
      "success_env_sensitivity": 3.0,
      "task_id": "risky_forage",
      "time_cost": 1.0
    },
    {
      "base_success": 0.06,
      "description": "Rare high gain, high variance, substantial cost.",
      "domain": "food",
      "effects": [
        {
          "base_value": 25.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "energy"
        }
      ],
      "enabled": true,
      "energy_cost": 3.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Exploration/Scavenging",
      "observable_to_actor": true,
      "outcome_noise": 0.5,
      "predation_multiplier": 1.8,
      "public_signal": false,
      "require_mature": false,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": "food",
      "success_env_sensitivity": 2.0,
      "task_id": "scavenge",
      "time_cost": 1.0
    },
    {
      "base_success": 0.95,
      "description": "Strong predation reduction, small recovery, no food.",
      "domain": "safety",
      "effects": [
        {
          "base_value": 1.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "health"
        }
      ],
      "enabled": true,
      "energy_cost": 1.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Shelter/Hide",
      "observable_to_actor": true,
      "outcome_noise": 0.1,
      "predation_multiplier": 0.35,
      "public_signal": false,
      "require_mature": false,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": null,
      "success_env_sensitivity": 0.0,
      "task_id": "shelter",
      "time_cost": 1.0
    },
    {
      "base_success": 0.9,
      "description": "Moderate predation reduction, better threat sensing.",
      "domain": "safety",
      "effects": [
        {
          "base_value": 1.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "observation_quality"
        }
      ],
      "enabled": true,
      "energy_cost": 1.5,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Vigilance",
      "observable_to_actor": true,
      "outcome_noise": 0.1,
      "predation_multiplier": 0.55,
      "public_signal": false,
      "require_mature": false,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": null,
      "success_env_sensitivity": 0.0,
      "task_id": "vigilance",
      "time_cost": 1.0
    },
    {
      "base_success": 0.7,
      "description": "Strong attack-survival boost, injury risk.",
      "domain": "safety",
      "effects": [
        {
          "base_value": -4.0,
          "condition": "on_failure",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "health"
        }
      ],
      "enabled": true,
      "energy_cost": 4.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Flee/Defend",
      "observable_to_actor": true,
      "outcome_noise": 0.2,
      "predation_multiplier": 0.5,
      "public_signal": false,
      "require_mature": false,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": null,
      "success_env_sensitivity": 0.0,
      "task_id": "flee_defend",
      "time_cost": 1.0
    },
    {
      "base_success": 0.5,
      "description": "Reproductive-capital gain linked to mate availability.",
      "domain": "reproduction",
      "effects": [
        {
          "base_value": 8.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": "mate",
          "env_sensitivity": 4.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "repro_capital"
        }
      ],
      "enabled": true,
      "energy_cost": 3.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Mate Search",
      "observable_to_actor": true,
      "outcome_noise": 0.3,
      "predation_multiplier": 1.1,
      "public_signal": false,
      "require_mature": true,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": "mate",
      "success_env_sensitivity": 2.0,
      "task_id": "mate_search",
      "time_cost": 1.0
    },
    {
      "base_success": 0.45,
      "description": "Larger capital gain, status-dependent, higher exposure.",
      "domain": "reproduction",
      "effects": [
        {
          "base_value": 14.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "repro_capital"
        }
      ],
      "enabled": true,
      "energy_cost": 5.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Courtship Display",
      "observable_to_actor": true,
      "outcome_noise": 0.3,
      "predation_multiplier": 1.3,
      "public_signal": false,
      "require_mature": true,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": null,
      "success_env_sensitivity": 0.0,
      "task_id": "courtship",
      "time_cost": 1.0
    },
    {
      "base_success": 0.5,
      "description": "Persistent status/repro benefit, competition risk.",
      "domain": "reproduction",
      "effects": [
        {
          "base_value": 6.0,
          "condition": "on_success",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "status"
        },
        {
          "base_value": -3.0,
          "condition": "on_failure",
          "effect_type": "additive",
          "env_driver": null,
          "env_sensitivity": 0.0,
          "min_age_steps": 0,
          "noise_std": 0.0,
          "require_mature": false,
          "sex_restriction": "any",
          "target": "health"
        }
      ],
      "enabled": true,
      "energy_cost": 6.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Territory/Nest Investment",
      "observable_to_actor": true,
      "outcome_noise": 0.3,
      "predation_multiplier": 1.1,
      "public_signal": false,
      "require_mature": true,
      "role": "functional",
      "sex_restriction": "any",
      "success_env_driver": null,
      "success_env_sensitivity": 0.0,
      "task_id": "territory",
      "time_cost": 1.0
    },
    {
      "base_success": 1.0,
      "description": "No modelled benefit, minimal cost; persists by drift.",
      "domain": "neutral",
      "effects": [],
      "enabled": true,
      "energy_cost": 0.3,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Low-Cost Neutral Behavior",
      "observable_to_actor": true,
      "outcome_noise": 0.0,
      "predation_multiplier": 1.0,
      "public_signal": false,
      "require_mature": false,
      "role": "low_cost_neutral",
      "sex_restriction": "any",
      "success_env_driver": null,
      "success_env_sensitivity": 0.0,
      "task_id": "neutral_idle",
      "time_cost": 1.0
    },
    {
      "base_success": 1.0,
      "description": "No modelled benefit, meaningful cost; can be amplified by cognition via successful-agent memory.",
      "domain": "neutral",
      "effects": [],
      "enabled": true,
      "energy_cost": 3.0,
      "max_age_steps": null,
      "memory_eligible": true,
      "min_age_steps": 0,
      "name": "Costly Dance-Like Behavior",
      "observable_to_actor": true,
      "outcome_noise": 0.0,
      "predation_multiplier": 1.05,
      "public_signal": false,
      "require_mature": false,
      "role": "costly_nonfunctional",
      "sex_restriction": "any",
      "success_env_driver": null,
      "success_env_sensitivity": 0.0,
      "task_id": "costly_dance",
      "time_cost": 1.0
    }
  ]
}
```

## 7. Built-in presets (descriptions only)

- `stable_abundant` — Stable, resource-abundant ecology. Low extinction risk, slower selection, some neutral behaviour persists. Theoretical demo only.
- `scarce_low_fecundity` — Resource-scarce, low-fecundity ecology. Strong selection on food allocation, higher extinction risk, costly errors. Theoretical demo only.
- `volatile_high_fecundity` — Volatile boom-bust, high-fecundity ecology. Rapid expansion and collapse, high variance, forecasting may lag. Theoretical demo only.
- `legacy_aom_reference` — Legacy AOM 2.1 reference scenario for continuity: ~200 agents, three tasks (T3 survival-irrelevant), changing environment. Recorded values are mean inherited propensity, not realised energy allocation.
- `pair_bonded_humanlike` — Social monogamy with moderate mate choice. A simplified abstract approximation, not a model of any real human society.
- `competitive_skew` — Strong mate choice without persistent bonds, concentrating reproductive success. Compare opportunity for selection against random mating.
- `asexual_clonal` — Asexual reproduction: no partner required, clonal inheritance apart from mutation. A control for the contribution of recombination.
- `stable_abundant_legacy` — Stable and abundant with pre-schema-2 mechanics (season-end batch reproduction, newborn founders, legacy inheritance).
- `scarce_low_fecundity_legacy` — Scarce and low-fecundity with pre-schema-2 mechanics.
- `volatile_high_fecundity_legacy` — Volatile boom-bust with pre-schema-2 mechanics.

These are descriptions, not full configurations. If the researcher wants to start from one, ask them to download its JSON from UMEM and paste it to you.

## 8. Starter message for the user

The user can open the conversation with:

```
I am designing an experiment with the UMEM Evolutionary Simulation Workbench. I have attached AI_SCENARIO_DESIGN_GUIDE.md; please read it fully first. Interview me in plain language (in my language) about my research question and comparison, propose defaults where needed and tell me what they do, summarise the full design before finalising, and then give me one complete scenario JSON exactly as the guide's output contract requires. Do not claim to have validated or run it — UMEM will do that when I import it.
```

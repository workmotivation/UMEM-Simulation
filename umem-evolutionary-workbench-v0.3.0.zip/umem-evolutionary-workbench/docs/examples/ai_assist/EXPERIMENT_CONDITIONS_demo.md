## Experiment conditions

**Population and time.** The simulation starts with 200 agents and runs for 5 seasons of 40 time steps each (200 steps). Carrying capacity is 500 agents and a hard ceiling of 3000 prevents runaway growth. Agents mature after 2 season(s) and cannot live beyond 12 seasons; founder ages approximate a stable age distribution derived from the configured hazards. Each newborn is assigned reproductive Type A with probability 0.5 (Type A/B are neutral labels, not sexes, and are not inherited).

**Environment.** The environment is exogenous and pre-generated: it does not respond to the population, so there is no resource depletion or predator–prey feedback. `food` follows a ar1 process around a mean of 0.8 (volatility 0.03, persistence 0.97), observed with noise 0.05; `predator` follows a ar1 process around a mean of 0.2 (volatility 0.05, persistence 0.7, shock probability 0.01), observed with noise 0.08; `mate` follows a ar1 process around a mean of 0.7 (volatility 0.02, persistence 0.99), observed with noise 0.05.

**Available behaviours.** Agents choose among 11 enabled tasks grouped into 4 motivational domains (food, safety, reproduction, neutral). 9 tasks confer a direct benefit; 1 are low-cost neutral behaviours with no modelled benefit, and 1 are costly nonfunctional behaviours that spend time or energy for no benefit. Choice is a softmax (temperature 1) over inherited propensity, homeostatic urgency and any enabled cognition, with decision noise 0.1 and 1 action(s) per step.

**Survival constraints.** Every step each agent pays basal metabolism 1 energy (plus 0.5 when it cannot act); at zero energy it loses 10 health per step and dies when health reaches zero. Stochastic hazards act every step and combine as competing risks: a base predation hazard of 0.0015 per step scaled by the predator variable and by the chosen task's exposure multiplier; a gompertz senescence hazard (scale 0.0008, rate 0.12); a background hazard of 0; an extra 0.003 for juveniles; and a crowding hazard that switches on above 0.6 of carrying capacity (strength 0.4). Homeostasis is enabled: hunger (strength 2), threat/safety (strength 2), reproductive readiness (strength 2) shift task choice. This is physiological regulation, not cognition.

**Reproduction.** An agent is eligible to reproduce when mature, with energy ≥ 40, health ≥ 30 and reproductive capital ≥ 0. Reproduction is continuous: every time step is an opportunity. Eligible agents initiate reproductive attempts at a rate of 9 per season (a per-step hazard of 0.2015). This is an attempt-event rate, not a birth rate: realised births also depend on finding a partner, the fertility draw and juvenile recruitment. There is no refractory period; failed attempts cost nothing. Mating is pair-bonded (social monogamy): mature agents form exclusive one-to-one bonds at a rate of 4 per season, choosing among 5 candidate(s) by partner quality. Bonds persist until a partner dies or dissolve at 0.05 per season. Bond formation requires maturity only; a bonded pair reproduces only when both partners meet the eligibility thresholds in the same step, so its realised rate is well below the configured event rate. Each event requires one Type A and one Type B parent. Parental costs are symmetric (20 energy, 5 health each) and both contribute equally to offspring. Each successful event yields a poisson fertility draw with mean 1.5 (at most 3); each offspring survives recruitment with probability 0.85, reduced by Beverton–Holt density dependence (strength 1) as the population approaches carrying capacity.

**Inheritance and mutation.** Motivational propensities are heritable polygenic quantitative traits on a latent scale, expressed as proportions that sum to one within the domain layer and within each domain's tasks; they are not identified genes. Each offspring's latent value is the mid-parent value plus an independent Mendelian segregation term whose variance is 1 × V₀/2, where V₀ is the configured founder variance (sibling variation: standard); at 1.0 the founder variance is the neutral equilibrium. Mutation (conservative) is a separate rare event: with probability 0.01 per offspring in the domain layer and the task layer, tested independently, so one offspring can carry up to two events, one randomly chosen component receives a zero-mean shift of standard deviation 0.1 in latent (log-ratio) units. These are effective simulation parameters, not human mutation rates.

**Cognition.** All cognitive mechanisms are disabled: behaviour is driven only by inherited propensity, homeostasis and noise (a pure evolutionary baseline).

**Experiment design.** 3 independent replications sharing the master seed but using different random substreams; run in parallel with up to 1 worker(s). Results are reproducible and worker count does not affect them. Master seed 12345. Fitness is realised lifetime reproductive success, an outcome, not a score imposed on agents.

**Recording.** Population-level snapshots are recorded every 10 step(s), plus a closing snapshot after the final reproduction. A reproducible sample of 50 agents is stored per snapshot.

### Notes on unusual or custom settings

- The senescence hazard rises slowly, so a noticeable share of agents reach the hard maximum lifespan and die there together; expect a point mass at the maximum age in lifespan histograms.
- Mate availability is scaled by the environmental variable `mate`.
- `population.founder_age_distribution` is set to `stable` (default `uniform`).
- `reproduction.mating_mode` is set to `pair_bonded` (default `random`).

### Complete specification (active settings)

| Path | Value | Meaning |
|---|---|---|
| `schema_version` | `2` | Schema version |
| `name` | `DEMONSTRATION: pair-bonded, 3 replications` | Scenario name |
| `description` | `Generated example for documentation. Not a real research result.` | Description |
| `preset_origin` | `None` | Preset origin |
| `master_seed` | `12345` | Master seed |
| `population.founder_age_distribution` | `stable` | Founder ages |
| `population.initial_population` | `200` | Initial population |
| `population.carrying_capacity` | `500` | Carrying capacity |
| `population.max_population` | `3000` | Max population |
| `population.init_distribution` | `gamma` | Init distribution |
| `population.sex_ratio_type_a` | `0.5` | Type-A fraction |
| `population.starting_population_file` | `None` | Start pop file |
| `lifecycle.steps_per_season` | `40` | Steps per season |
| `lifecycle.total_seasons` | `5` | Total seasons |
| `lifecycle.actions_per_step` | `1` | Actions per step |
| `lifecycle.initial_energy` | `70` | Initial energy |
| `lifecycle.energy_max` | `100` | Energy max |
| `lifecycle.initial_health` | `90` | Initial health |
| `lifecycle.health_max` | `100` | Health max |
| `lifecycle.initial_repro_capital` | `0` | Initial repro capital |
| `lifecycle.repro_capital_max` | `100` | Repro capital max |
| `lifecycle.initial_status` | `50` | Initial status |
| `lifecycle.status_max` | `100` | Status max |
| `lifecycle.basal_metabolism` | `1` | Basal metabolism |
| `lifecycle.rest_energy_cost` | `0.5` | Rest cost |
| `lifecycle.health_starvation_penalty` | `10` | Starvation penalty |
| `lifecycle.maturity_seasons` | `2` | Maturity (seasons) |
| `lifecycle.max_lifespan_seasons` | `12` | Max lifespan |
| `lifecycle.newborns_act_next_step` | `True` | Newborns wait |
| `mortality.base_predation_hazard` | `0.0015` | Base predation |
| `mortality.predation_env_driver` | `predator` | Predation driver |
| `mortality.predation_env_sensitivity` | `1` | Predation sensitivity |
| `mortality.age_hazard_shape` | `gompertz` | Age hazard shape |
| `mortality.age_hazard_scale` | `0.0008` | Age hazard scale |
| `mortality.age_hazard_rate` | `0.12` | Age hazard rate |
| `mortality.background_hazard` | `0` | Background hazard |
| `mortality.juvenile_extra_hazard` | `0.003` | Juvenile hazard |
| `mortality.density_hazard_strength` | `0.4` | Density hazard |
| `mortality.density_onset_fraction` | `0.6` | Density onset |
| `mortality.density_affects_juveniles_only` | `True` | Density juveniles only |
| `reproduction.mode` | `sexual` | Mode |
| `reproduction.timing` | `distributed` | Reproduction timing |
| `reproduction.reproductive_event_rate` | `9` | Reproductive event rate |
| `reproduction.refractory_seasons` | `0` | Refractory period |
| `reproduction.mating_mode` | `pair_bonded` | Mating mode |
| `reproduction.mate_choice_k` | `5` | Choosiness (k) |
| `reproduction.mate_choice_criterion` | `partner_quality` | Choice criterion |
| `reproduction.mate_quality_weights` | `{'status': 1.0, 'repro_capital': 0.3, 'health': 0.25, 'energy': 0.25}` | Quality weights |
| `reproduction.bond_formation_per_season` | `4` | Bond formation rate |
| `reproduction.bond_dissolution_per_season` | `0.05` | Bond dissolution rate |
| `reproduction.energy_threshold` | `40` | Energy threshold |
| `reproduction.health_threshold` | `30` | Health threshold |
| `reproduction.repro_capital_threshold` | `0` | Capital threshold |
| `reproduction.mate_selection` | `weighted_capital` | Mate selection |
| `reproduction.mate_availability_driver` | `mate` | Mate driver |
| `reproduction.max_offspring_per_event` | `3` | Max offspring/event |
| `reproduction.fertility_distribution` | `poisson` | Fertility dist |
| `reproduction.fertility_mean` | `1.5` | Fertility mean |
| `reproduction.fertility_binomial_p` | `0.5` | Binomial p |
| `reproduction.fertility_discrete_pmf` | `[]` | Discrete pmf |
| `reproduction.repro_energy_cost` | `20` | Repro energy cost |
| `reproduction.repro_health_cost` | `5` | Repro health cost |
| `reproduction.juvenile_survival` | `0.85` | Juvenile survival |
| `reproduction.density_dependent_recruitment` | `True` | Density recruitment |
| `reproduction.recruitment_strength` | `1` | Recruitment strength |
| `inheritance.model` | `polygenic_additive` | Inheritance model |
| `inheritance.sibling_variation` | `standard` | Sibling variation |
| `inheritance.segregation_multiplier` | `1` | Segregation multiplier |
| `inheritance.mutation_level` | `conservative` | Mutation level |
| `inheritance.mutation_probability_per_offspring` | `0.01` | Mutation probability |
| `inheritance.mutation_effect_sd_latent` | `0.1` | Mutation effect size |
| `inheritance.mutation_target` | `both` | Mutation target |
| `inheritance.min_propensity` | `0.01` | Min propensity |
| `homeostasis.enabled` | `True` | Enabled |
| `homeostasis.hunger_enabled` | `True` | Hunger |
| `homeostasis.hunger_strength` | `2` | Hunger strength |
| `homeostasis.safety_enabled` | `True` | Safety |
| `homeostasis.safety_strength` | `2` | Safety strength |
| `homeostasis.reproduction_enabled` | `True` | Reproduction |
| `homeostasis.reproduction_strength` | `2` | Reproduction strength |
| `cognition.experience_enabled` | `False` | Experience (A) |
| `cognition.experience_success_definition` | `surviving_offspring` | Success definition |
| `cognition.experience_top_quantile` | `0.2` | Top quantile |
| `cognition.experience_weight_recent` | `0.7` | Recent weight |
| `cognition.experience_smoothing` | `1` | Smoothing |
| `cognition.experience_noise_sd` | `0.3` | Experience noise |
| `cognition.experience_strength` | `2.5` | Experience strength |
| `cognition.forecast_enabled` | `False` | Forecast (B) |
| `cognition.forecast_memory` | `0.6` | Forecast memory |
| `cognition.forecast_strength` | `1` | Forecast strength |
| `cognition.individual_learning_enabled` | `False` | Individual learning (C) |
| `cognition.individual_learning_rate` | `0.2` | Learning rate |
| `cognition.individual_learning_strength` | `1` | Learning strength |
| `choice.softmax_temperature` | `1` | Softmax temperature |
| `choice.decision_noise_sd` | `0.1` | Decision noise |
| `experiment.mode` | `replications` | Mode |
| `experiment.replications` | `3` | Replications |
| `experiment.max_workers` | `1` | Max workers |
| `experiment.sweep_parameters` | `[]` | Sweep params |
| `experiment.max_sweep_combinations` | `500` | Max sweep combos |
| `experiment.common_random_numbers` | `False` | Common random numbers |
| `output.record_interval_steps` | `10` | Record interval |
| `output.store_agent_sample` | `True` | Agent sample |
| `output.agent_sample_size` | `50` | Sample size |
| `output.store_event_log` | `False` | Event log |

### Inactive settings (ignored under the current mechanisms)

| Path | Value | Why inactive |
|---|---|---|
| `reproduction.breeding_every_seasons` | `1` | legacy timing only |
| `reproduction.gestation_delay_steps` | `0` | legacy timing only |
| `inheritance.mutation_probability` | `1` | legacy inheritance only |
| `inheritance.mutation_log_sd` | `0.1` | legacy inheritance only |
| `inheritance.recombination_per_trait` | `True` | legacy inheritance only |
| `inheritance.blend_alpha` | `0.5` | legacy inheritance only |

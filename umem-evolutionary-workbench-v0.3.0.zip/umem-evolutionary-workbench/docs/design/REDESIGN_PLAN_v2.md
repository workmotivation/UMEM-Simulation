# UMEM 繁殖与遗传系统重设计：修订版实施计划

版本：修订版 v2（2026-09-07）
状态：待项目负责人定稿，尚未开始编码
取代：《Implementation Task: Redesign the Reproduction and Inheritance Systems》初稿

---

## 0. 本计划与初稿的关系

初稿的总体方向正确。本修订版做了三类改动：

| 类别 | 内容 |
|---|---|
| **用文献标准替换自拟机制** | 分离方差取值、配对算法、三种模式的统一实现、繁殖时序的理论依据 |
| **补上初稿遗漏的关键细节** | 繁殖强度的精确定义、配对时的"发起者—全池"规则、创始者去同步、数组压缩下的配对状态、记录时序 |
| **删减** | 声明式权重系统简化为 4 个固定键；不再需要"基线协方差来源"这个待定项；不再单独设"潜变量创始方差"字段 |

初稿中以下要求原样保留：科学原则（§1）、范围边界（§2）、A/B 类型中性、无性繁殖、迁移向后兼容、测试与实证验证要求、禁止图表平滑。

---

## 1. 设计依据的保存方式（回答"放在哪里"）

### 1.1 三层结构

```
docs/
├── design/                          ← 架构决策记录（ADR）
│   ├── README.md                    ← ADR 是什么、如何写新的
│   ├── ADR-001-latent-softmax-propensities.md
│   ├── ADR-002-infinitesimal-inheritance.md
│   ├── ADR-003-nonwf-distributed-reproduction.md
│   ├── ADR-004-rkpm-mate-choice.md
│   ├── ADR-005-mating-modes.md
│   ├── ADR-006-founder-age-structure.md
│   └── ADR-007-recording-order.md
├── references.md                    ← 统一参考文献表
└── model_reference.md               ← 正文引用 ADR 编号
```

每份 ADR 固定格式：**背景与问题 / 考虑过的方案 / 决定 / 理由与文献 / 后果与限制 / 未来扩展点**。约 1–2 页。

### 1.2 代码层

每个受影响模块的 docstring 开头一段，末尾一行：`See docs/design/ADR-00x.` 不在代码里重复论证。

### 1.3 参数层

集中式数据字典（见 §6）中每个参数带 `reference` 字段（如 `"ADR-002; Barton et al. 2017"`）。`docs/parameter_reference.md` 由字典自动生成，因此出处不会与代码脱节。

### 1.4 致谢

`THIRD_PARTY_NOTICES.md` 新增"算法来源"一节：RKPM 按 Geffen & Scholz (2017) 的发表描述重新实现，未复制其 C++ 代码；无穷小模型按 Barton, Etheridge & Véber (2017) 的定义实现。

---

## 2. 科学依据摘要与参考文献

| 组件 | 标准 | 主要文献 |
|---|---|---|
| 遗传 | Fisher 无穷小模型：后代 = 中亲值 + N(0, V_A/2)，方差与亲本值无关 | Fisher 1918; Bulmer 1980; Lynch & Walsh 1998; **Barton, Etheridge & Véber 2017** (Theor. Pop. Biol. 118:50–73) |
| 孟德尔抽样方差 | 无近交时 = 0.5 σ²_A | Lynch & Walsh 1998 ch.7; 育种学标准结果 |
| 繁殖时序 | 非 Wright-Fisher (nonWF) 模型：每个时间步是一次繁殖/死亡机会 | **Haller & Messer 2019** (SLiM 3, MBE 36:632) |
| 配对算法 | Random-k Pair Matching (RKPM)：洗牌后从 k 个候选中选最优 | **Geffen & Scholz 2017** (JASSS 20(4):8, doi 10.18564/jasss.3485) |
| 配对模式 | 混交 / 单配 / 一雄多雌 三分类 | Emlen & Oring 1977; quantiNemo (Neuenschwander et al. 2008) 采用同一分类 |
| 繁殖偏斜度量 | Crow 机会选择指数 I = Var(LRS)/mean(LRS)² | Crow 1958（已在 UMEM 中实现） |

完整条目写入 `docs/references.md`。

---

## 3. 范围

**实施**：§4–§12 全部内容。
**不实施**（与初稿 §2 一致）：妊娠、性别特异生理、家庭/亲代抚育、社会网络、资源耗竭、显式基因座、显性/上位/连锁、任意代码执行、新可视化、外部 AI 指南。
**不触碰**：`legacy/reference_original/`。

---

## 4. 遗传系统详细设计

### 4.1 潜变量表示（ADR-001）

**问题**：当前倾向是无约束正实数，突变为乘性对数正态。选择只依赖倾向比值，因此整体尺度是冗余自由度。

**决定**：每个层次的倾向由一个**中心化潜向量** g 表示，表达值 p = softmax(g)。

- 领域层：g_dom ∈ ℝ^D，约束 Σg = 0。
- 任务层：每个领域 d 内 g_task[d] ∈ ℝ^{T_d}，各自 Σ = 0。
- 选择 logit 中 log p = g − logsumexp(g)，常数在选择 softmax 中抵消，因此**行为与当前模型等价**——这是一次表示变换，不是机制变化。

**创始者初始化**（从现有 `init_mean` / `init_var` 推导，不新增字段）：
```
μ_c  = log(init_mean_c)                        （随后整体减均值）
V₀_c = log(1 + init_var_c / init_mean_c²)      （对数正态矩匹配）
g_c ~ N(μ_c, V₀_c)，然后 g ← g − mean(g)
```
任务层沿用当前硬编码的 mean=1, var=0.5 → μ=0, V₀=log 1.5≈0.405。
`init_distribution = equal` → V₀ = 0。

**传统值转潜变量**（迁移与传统模式互操作用）：
```
g = log(max(prop, min_propensity))；g ← g − mean(g)
```
`min_propensity` 现有字段（1e-3）作为下限，保证有限。

**校准检查**：实施时验证新初始化下 Var(log p) 与当前 gamma 初始化的 Var(log prop) 在同量级（gamma(2,0.5) 的 Var(log X) = ψ'(2) ≈ 0.645，对数正态矩匹配给 log(1.5)≈0.405；差异记入 ADR，可通过 `init_var` 调整）。

**导出语义变化**：`domprop_*`、`taskprop_*` 变为比例（和为 1），`domvar_*` 变为潜变量方差。所有旧结果与新结果**不可直接比较**。分析层、绘图标签、指标、测试同步更新。

### 4.2 有性遗传：无穷小模型（ADR-002）

对每个潜向量独立执行：
```
g_child = (g_A + g_B)/2 + ε_seg + ε_mut
ε_seg ~ N(0, s · V₀_c / 2)   逐分量独立
最后 g_child ← g_child − mean(g_child)
```

- **σ²_seg = V₀_c / 2**：无近交时的孟德尔抽样方差。基准 V₀ 来自**配置的创始分布**（§4.1 公式），不是实现的创始种群，避免种子依赖。
- **自稳定性**：中性漂变下 Var(child) = Var(parent)/2 + σ²_seg，平衡态 V = 2σ²_seg = V₀。初稿担心的"逐代膨胀"不会发生。
- `s` = 同胞变异倍数：`sibling_variation` 预设 low 0.5 / standard 1.0 / high 1.5 / custom。
- 分量间无遗传协方差（对角），ADR 记录未来可扩展为矩阵。
- A/B 顺序对称：公式对称，测试验证。
- 每个后代独立抽 ε_seg，同胞天然不同。
- V₀ = 0（equal 初始化）时 σ_seg = 0，仅突变产生变异——这是无穷小模型的正确行为（抽样方差与杂合度成比例），校验器给出 THEORY 提示。

### 4.3 无性遗传
```
g_child = g_parent + ε_mut
```
无平均、无分离。突变关闭时为克隆。

### 4.4 突变（ADR-002 §突变）

与分离**分开配置、分开计数**。中性、对称、零均值。

```
对每个后代、每个目标层：
  以 p_mut 发生突变事件
  若发生：均匀随机选一个分量 c，g_c += N(0, σ²_mut)
  层向量重新中心化
记录 mutation_event_count
```

| 预设 | p_mut / 后代 | σ_mut（潜变量绝对单位） |
|---|---|---|
| none | 0 | — |
| conservative（默认） | 0.01 | 0.10 |
| accelerated | 0.05 | 0.20 |
| custom | 用户 | 用户 |

- σ_mut 用**绝对潜变量单位**（对数比值尺度；0.10 ≈ 相对赔率变化 10%），不用"创始 SD 的比例"，避免 V₀=0 时退化为零。
- `mutation_target`：domain / task / both（默认 both，各层独立判定）。
- 文档明确：这些是**有效模拟参数**，不是人类每碱基突变率。

### 4.5 传统遗传模式保留

`inheritance.model = legacy` 时完整保留现有 `recombine_and_mutate`（逐性状亲本选择/混合 + 乘性对数正态突变），用于旧配置的位级复现。

---

## 5. 繁殖系统详细设计

### 5.1 时序模式（ADR-003）

`reproduction.timing`：`distributed`（新默认）| `season_end_legacy`。

**理论依据**：SLiM 3 的 nonWF 模型——"世代"重新定义为一次繁殖和/或死亡的机会，时间结构可基于任意粒度而不必与寿命相关。UMEM 当前把 WF 式的世代结构（季末批量）塞进本应 nonWF 的重叠世代模型，诊断报告发现的锯齿本质上是这一不匹配。

**季末传统模式**：完整保留现有 `breed()` 调用路径与语义，不改动。

### 5.2 分散模式的繁殖强度（初稿 §3.2 的核心歧义，此处定死）

**问题**：当前合格者季度繁殖概率为 1.0，初稿公式 `1−(1−p)^{1/S}` 代入退化为 1，且会导致冷却期结束时全体同步。

**决定**：用**风险率**参数化，几何等待时间天然去同步。

| 参数 | 含义 | 分类 | 转换 |
|---|---|---|---|
| `expected_births_per_season` λ | 合格个体每季期望繁殖事件数 | **率** | h_step = 1 − exp(−λ/S) |
| `refractory_seasons` | 成功事件后的最短再繁殖间隔 | **固定间隔** | steps = round(x·S)，仅成功后启动 |
| `fertility_mean` 等 | 每次成功事件的后代数 | **每事件数量** | 不变 |
| 能量/健康/资本阈值 | 合格条件 | **阈值** | 不变 |
| `juvenile_survival` | 每个后代的存活概率 | **每事件概率** | 不变 |

- λ 默认 1.0，refractory 默认 0（纯风险率模型）。
- **不随 S 改变**：期望事件数/季 = λ，与 S 无关（测试 10.1）。
- **失败尝试不启动 refractory，不扣成本**。
- 传统字段 `breeding_every_seasons` 仅传统时序使用。
- `gestation_delay_steps`：传统时序保留；分散时序下校验器报 ERROR 若 > 0。

**为什么不是初稿的"概率"公式**：λ 是率不是概率；率→每步概率的标准转换是 1−exp(−λ/S)。当 λ/S 小时两者近似相等。

### 5.3 合格性与配偶选择的分离

**合格性**（每步对全体计算，布尔掩码）：成熟、年龄限制、能量 ≥ 阈值、健康 ≥ 阈值、繁殖资本 ≥ 阈值、refractory 已过、（有性）A/B 类型可用。

**配偶选择**（仅在合格者中，§5.4）：决定谁获得繁殖机会。

两者代码分离：`eligibility.py` 与 `mate_choice.py`。

### 5.4 配对引擎：RKPM（ADR-004）

来源：Geffen & Scholz 2017。原文用于同类相配的"距离函数"；本项目推广为可配置准则。

**核心算法**（每步执行一次）：
```
1. 合格者洗牌（Knuth shuffle，每步重做——避免论文指出的"存储偏倚"）
2. 发起者 = 合格者中 u < h_attempt 的个体
3. 对每个发起者（按洗牌顺序）：
     候选池 = 合格、本步尚未配对、类型互补的个体
     若池空 → 失败，记 n_failed_no_partner
     否则从池中均匀抽 k 个候选（k > 池大小则取全部）
     按准则选最优者为配偶；双方标记本步已配对
4. 每对：抽后代数 → 幼体存活 → 容量上限 → 入群 → 双亲扣成本 → 双亲启动 refractory
```

**k 的含义**：所选配偶在池中的期望排名 = n/(k+1)。k=1 为纯随机；k=20 时平均选到前 5%。一个参数连续调节偏斜。

**准则** `mate_choice_criterion`：
- `partner_quality`（默认）：最大化配偶质量 → 竞争/偏斜
- `similarity`：最小化 |质量_自 − 质量_偶| → 同类相配（吸收现有 `assortative` 模式）

**质量** `mate_quality_weights`：固定四键 `{repro_capital, status, health, energy}`，非负权重，各状态变量先归一化到 [0,1]，加权求和。默认 `{1.0, 0.5, 0.25, 0.25}`。声明式、校验、不可执行表达式。

**发起概率与对称性**：有性模式下 h_attempt = h_step / 2，A、B 双方均可发起，从对方全池选。期望每个体每季事件数 ≈ λ（自己发起 λ/2 + 被选 λ/2）。类型池不平衡时少数类型被选更频繁——这是**真实的配偶限制（demography 的两性问题）**，显式配对自动处理，不需额外的"婚姻函数"。文档说明。

**为什么权重"有实际效果"**：偏斜来自"被选中"一侧。k=1 时无偏斜（等于随机混交）；k 增大，高质量个体被反复选中，Crow's I 上升。验收标准见 §11。

### 5.5 三种配对模式 + 无性（ADR-005）

三种模式是**同一引擎 + 两个布尔量**，不是三套代码：

| `mating_mode` | 标准术语（文档标注） | 关系持续 | 排他 | k 默认 | 准则 |
|---|---|---|---|---|---|
| `random` | 混交 promiscuity | 否 | — | 1 | — |
| `pair_bonded` | 社会性单配 social monogamy | **是** | **是** 1:1 | 5 | partner_quality |
| `competitive` | 一雄多雌型偏斜 polygyny-like skew | 否 | 否 | 20 | partner_quality |

**`random`** = `competitive` 且 k=1。代码路径相同。

**`pair_bonded`** 追加：
- 每步：已结对且双方均合格的对，以 h_step 尝试繁殖（每对一次，不是每人）。
- 未结对的**成熟**个体（结对只要求成熟，不要求能量等阈值——阈值决定能否繁殖，不决定能否结对；ADR 记录此决定），以 `bond_formation_per_season`（默认 2.0）转换的每步概率发起结对，从未结对成熟互补池中 RKPM 选偶。
- 每对每步以 `bond_dissolution_per_season`（默认 0.0）转换的概率解除。
- 一方死亡即解除，另一方回到未结对池。
- 任一存活个体同时最多一个 bond（测试）。
- **不实现**家庭、共享资源、抚育、婚姻制度。

**技术要点：数组压缩**。`AgentPool.remove_dead` 压缩数组后索引全变。配偶关系必须存 **`partner_agent_id`**（全局 ID，−1 为无），配对查询时通过 `agent_id → index` 映射（每步重建一次，O(n)）。禁止存索引。

**`asexual`**（`reproduction.mode = asexual`）：无类型要求，每个合格个体以 h_step 独立发起并直接产生后代（§4.3 遗传）；`mating_mode` 与相关字段在 UI 中禁用并标"无性繁殖下无关"。

### 5.6 传统 `mate_selection` 字段处理

`random / weighted_capital / competitive / assortative` 仅在 `season_end_legacy` 下使用，保持不变。迁移到分散模式（用户手动切换时）的映射建议：random→random；weighted_capital, competitive→competitive；assortative→competitive + similarity。UI 切换时自动填入，用户可改。

### 5.7 成本与类型比例

- 双亲成本对称（沿用现有 `repro_energy_cost` / `repro_health_cost` 双方等额扣除；实施时核实）。
- `sex_ratio_type_a` 不变，不遗传（交接文件 §7 确认）。

---

## 6. 创始者年龄结构（ADR-006）

`population.founder_age_distribution`：`all_newborn_legacy` | `uniform`（新默认）| `stable`。

**`uniform`**：age_steps ~ U[0, max_lifespan_seasons·S − 1]。

**`stable`**（近似）：
```
每季存活 s_a = [(1 − h_pred_base(1 + sens·pred_mean)) · (1 − h_bg) · (1 − h_age(a))]^S · (1 − h_juv)^S·[a<maturity]
权重 l(a) = ∏_{j<a} s_j，a = 0..max_lifespan−1
按 l(a) 归一化抽年龄（季），季内偏移 U[0, S−1]
```
忽略饥饿、密度、任务暴露——文档明示为近似。

**状态一致性**：`reached_maturity` 按年龄设定；energy/health/capital/status 用配置初值（不按年龄调整，符合初稿 §6 "与当前状态假设兼容"）；`born_season = −(age//S)`（允许负值，文档说明）；`last_repro_step` 在有 refractory 时随机化到 [−refractory_steps, 0)。

**RNG**：`all_newborn_legacy` 不消耗额外随机数 → 旧配置位级复现。新模式从 `initial_population` 流抽取。

**声明**：文档明确"创始者年龄同步是次级的早期瞬态问题，不是持续锯齿的主因"（诊断报告结论）。

---

## 7. 记录时序（ADR-007）

当前：快照在繁殖前记录，季末出生计入下一步。
**决定**：步内顺序改为 `… → 死亡 → 老化 → 繁殖 → 记录`，出生计入本步，两种时序模式均适用。
**后果**：传统模式的 `time_series` 出生列位置移动一步，**种群动态、dead_log、final_population 不变**（回归测试保证）。此为测量改动而非机制改动，需负责人确认（§14）。

---

## 8. 配置 Schema 变更（schema_version 1 → 2）

### 8.1 新增字段

| 路径 | 类型 | 默认（新） | 迁移值（旧配置） | 单位 | 取值 | 分类 |
|---|---|---|---|---|---|---|
| `reproduction.timing` | enum | distributed | **season_end_legacy** | — | distributed, season_end_legacy | 模式 |
| `reproduction.expected_births_per_season` | float | 1.0 | 1.0 | 事件/个体/季 | ≥0 | 率 |
| `reproduction.refractory_seasons` | float | 0.0 | 0.0 | 季 | ≥0 | 间隔 |
| `reproduction.mating_mode` | enum | random | random | — | random, pair_bonded, competitive | 模式 |
| `reproduction.mate_choice_k` | int | 1 | 1 | 候选数 | ≥1 | 强度 |
| `reproduction.mate_choice_criterion` | enum | partner_quality | partner_quality | — | partner_quality, similarity | 模式 |
| `reproduction.mate_quality_weights` | dict | {1,0.5,0.25,0.25} | 同 | — | 键固定，值 ≥0 | 权重 |
| `reproduction.bond_formation_per_season` | float | 2.0 | 2.0 | 事件/个体/季 | ≥0 | 率 |
| `reproduction.bond_dissolution_per_season` | float | 0.0 | 0.0 | 事件/对/季 | ≥0 | 率 |
| `population.founder_age_distribution` | enum | uniform | **all_newborn_legacy** | — | 三值 | 模式 |
| `inheritance.model` | enum | polygenic_additive | **legacy** | — | 两值 | 模式 |
| `inheritance.sibling_variation` | enum | standard | standard | — | low, standard, high, custom | 预设 |
| `inheritance.segregation_multiplier` | float | 1.0 | 1.0 | × V₀/2 | ≥0 | 强度 |
| `inheritance.mutation_level` | enum | conservative | conservative | — | none, conservative, accelerated, custom | 预设 |
| `inheritance.mutation_probability_per_offspring` | float | 0.01 | 0.01 | 概率/后代 | [0,1] | 概率 |
| `inheritance.mutation_effect_sd_latent` | float | 0.10 | 0.10 | 潜变量单位 | ≥0 | 尺度 |
| `inheritance.mutation_target` | enum | both | both | — | domain, task, both | 模式 |

粗体迁移值 = 决定科学含义的三个字段，旧配置一律迁到传统值，**不静默改变含义**。其余新字段在传统模式下不生效，迁移填默认即可。

### 8.2 保留字段（传统路径使用）
`breeding_every_seasons`, `gestation_delay_steps`, `mate_selection`, `mutation_probability`, `mutation_log_sd`, `blend_alpha`, `recombination_per_trait`, `min_propensity`（后者兼作潜变量转换下限）。

### 8.3 校验规则新增
- distributed + gestation_delay_steps>0 → ERROR
- asexual + mating_mode≠random → WARNING（无关）
- polygenic + init_var=0 → THEORY（无分离方差）
- pair_bonded + sex_ratio 偏离 0.5 过多 → WARNING（结对池失衡）
- mate_choice_k > initial_population → WARNING

### 8.4 哈希
新字段全部进入 `config_hash`。所有旧预设与旧 bundle 中记录的哈希变为 schema-1 哈希，与 schema-2 不可比。`REPRODUCIBILITY.txt` 与 `metadata.json` 记录 `config_schema_version`；文档说明。

### 8.5 迁移 `_migrate_1_to_2`
填入 §8.1 迁移列的值；幂等；测试验证迁移后传统模式结果与迁移前位级一致。

---

## 9. 集中式数据字典（为未来 AI 指南准备）

新增 `config/data_dictionary.py`：

- 从 Pydantic 字段元数据（现有 `ui()`）自动采集 name/type/default/range/unit/label/help；
- `ui()` 扩展三个可选键：`interpretation`（科学解释）、`category`（率/概率/间隔/数量/阈值/模式）、`reference`（ADR 编号 + 文献）、`added_in_schema`；
- `build_dictionary()` 返回结构化列表；CLI `umem-workbench data-dictionary --json`；
- `docs/parameter_reference.md` 改为由此生成；
- 输出字段（time_series / breeding_series / summary 列）同样在 `analysis/output_dictionary.py` 注册名称、含义、单位。

---

## 10. 输出与诊断

### 10.1 `metadata.json` 新增
`reproduction_mode, timing_mode, mating_mode, founder_age_distribution, inheritance_model, inheritance_model_version ("polygenic_additive.v1" | "legacy.v1"), segregation_settings{}, mutation_settings{}, config_schema_version`。

### 10.2 `breeding_series`（每季聚合）新增列
`n_eligible, n_attempts, n_events (成功繁殖), n_failed_no_partner, n_offspring_pre_survival, n_offspring_survived, n_active_bonds, n_bonds_formed, n_bonds_dissolved, n_mutation_events`。

### 10.3 `time_series` 新增列
`births_interval`（已有）、`attempts_interval`、`n_bonds`（pair_bonded 时）、`mutation_events_interval`。

### 10.4 `summary_metrics` 新增
- `birth_phase_entropy`：出生按 step-in-season 分布的归一化熵（1 = 均匀，0 = 全在一步）
- `share_steps_with_births`
- `births_top20pct_parent_share`：前 20% 亲本贡献的出生份额（偏斜）
- `lrs_gini`
- 已有 `opportunity_for_selection_I` 作为偏斜主指标

### 10.5 默认不导出逐个体潜变量；`output.store_latent_sample` 可选。

---

## 11. UI

**Simple 模式**新增控件（全部带 help，help 来自数据字典）：
- 繁殖方式：无性 / 有性 A-B
- 繁殖时序：连续（推荐）/ 季末（**兼容模式**，明确标注）
- 配对模式（有性时）：随机混交 / 配对结合 / 竞争——每项一句标准术语说明
- 创始者年龄：全新生（兼容）/ 均匀 / 稳定
- 同胞遗传变异：低 / 标准 / 高
- 突变水平：无 / 保守 / 加速

**Advanced 模式**暴露全部 §8.1 字段；无性时配对相关字段禁用并标注。

**桌面版**同步（共用 `ui_common`）。

---

## 12. 预设

| 预设 ID | 时序 | 模式 | 配对 | k | 年龄 | 遗传 | 用途 |
|---|---|---|---|---|---|---|---|
| `stable_abundant` 等三个现有科学预设 | distributed | sexual_ab | random | 1 | uniform | polygenic | **切换到新机制并重校准** |
| `stable_abundant_legacy` 等三个 | season_end_legacy | sexual_ab | 原 mate_selection | — | all_newborn_legacy | legacy | 与旧结果对比 |
| `pair_bonded_humanlike` | distributed | sexual_ab | pair_bonded | 5 | stable | polygenic | 简化人类样；dissolution 0.05/季 |
| `competitive_skew` | distributed | sexual_ab | competitive | 20 | uniform | polygenic | 高偏斜 |
| `asexual_clonal` | distributed | asexual | — | — | uniform | polygenic | 无性对照 |
| `legacy_aom_reference` | 不变 | | | | | | |

- 三个科学预设**重校准**（分散模式改变实际出生数，预估 −10~−30%），复用上一轮校准流程与 12 种子标准；结果表更新于 `presets.py` 与 README。
- `pair_bonded_humanlike` 文档明示："社会性单配 + 低解除率 + 适度挑剔"是对人类的**抽象近似**，依据 Lukas & Clutton-Brock 2013 等的立场（人类介于单配与一雄多雌之间），不代表任何真实社会。

---

## 13. 测试

### 13.1 单元：遗传（大样本，n≥20 000，容差为 SE 的 3–4 倍）
- 有性后代潜变量均值 → 中亲值（|偏差| < 0.01）
- 同胞方差 → s·V₀/2（相对误差 < 5%）
- 分离开启时同胞不同；关闭时 A/B 相同亲本 → 相同（精确到中心化）
- 无性、无突变 → 位级克隆
- 突变频率 → p_mut（±3 SE）；效应均值 ≈ 0；效应 SD ≈ σ_mut
- 交换 A/B → 分布相同（KS 检验 p > 0.01 或矩相等）
- softmax 输出有限、正、和为 1（1e-9）；领域层与任务层独立归一
- 传统→潜变量转换：零/近零输入无 NaN/inf；`min_propensity` 生效

### 13.2 单元：合格性与配对
- 随机混交（k=1）多次试验配对无偏（χ² 检验，p>0.01）
- k 增大 → 被选者平均质量排名单调下降，接近 n/(k+1)
- 每步无个体重复配对；有性每对恰一 A 一 B
- pair_bonded：排他、持续、一方死亡释放另一方、解除率生效、无双重 bond
- 数组压缩后 partner_agent_id 映射正确（构造死亡后查询）
- 无性不需类型匹配

### 13.3 单元：时序
- 分散模式在非季节边界步产生出生；季节边界步无特殊性（出生数与其他步无显著差异）
- 传统模式仅季末出生（现有行为）
- refractory 生效；失败尝试不启动 refractory、不扣成本
- λ 固定、S = 20/30/60 → 每季期望事件数不变（±10%）
- 分散模式每季出生数不为传统的 S 倍（上限 1.5×传统）

### 13.4 集成：复现与迁移
- 同新配置同种子 → 位级相同
- 旧 JSON 经迁移加载；三个模式字段 = 传统值
- 迁移后传统模式运行 → dead_log、final_population 与迁移前位级一致（预先录制基准）
- 哈希含全部新字段；改任一新字段 → 哈希变

### 13.5 回归
- 现有 145 项测试全部更新通过；需重写的测试清单在实施阶段列出。

---

## 14. 实证前后验证协议

复用诊断阶段的 `diag_harness.py`（每步记录、年龄捕获、锯齿指标），正式化为 `scripts/validate_reproduction_timing.py`。

**设计**：3 个科学预设 × 10 种子 × {season_end_legacy, distributed}，匹配参数（除时序与遗传模式外一致），完整时长。

**指标**（每条件报告均值 + 95% CI）：
| 指标 | 传统预期 | 分散验收标准 |
|---|---|---|
| Δpop 在 lag=S 的自相关 | 0.83–0.91 | **< 0.30** |
| 含出生的步占比 | ≈1/S | **> 0.50** |
| 种群上升的步占比 | 2–3% | > 15% |
| 出生相位熵 | ≈0 | **> 0.90** |
| 每季出生数 | 基准 | 0.7–1.3 × 基准（文档记录实际值） |
| 灭绝频率 | 基准 | 不高于基准 + 1 次/10 |
| Crow's I | 基准 | 报告（random 应 ≈ 基准；competitive k=20 应显著更高） |

**区分**：分别报告去除锯齿后仍存在的崩溃—复苏动态（Preset C 的饥饿选择瞬态），明确其为机制行为而非时序假象。

**禁止**：任何平滑、插值、后处理。

---

## 15. 实施阶段与验收门

| 阶段 | 内容 | 验收 |
|---|---|---|
| **P1 遗传** | ADR-001/002；潜变量表示；无穷小遗传；突变；传统模式保留；`inheritance.model` 字段与迁移 | 13.1 全过；传统模式位级回归 |
| **P2 繁殖** | ADR-003/004/005；合格性/选择分离；RKPM；三模式 + 无性；refractory；partner_agent_id；输出字段 | 13.2、13.3 全过；单预设前后对比 |
| **P3 年龄与记录** | ADR-006/007；三种年龄分布；记录时序 | 13.4；传统动态位级回归 |
| **P4 收尾** | 数据字典；迁移；UI；预设重校准；文档；references；THIRD_PARTY 更新；§14 全量验证 | 全套测试；验证报告；Streamlit smoke |

每阶段结束提交含数据的阶段报告，负责人确认后进入下一阶段。P1 与 P2 可并行开发，因二者正交。

---

## 16. 已解决的决定（本修订版定稿）

| 编号 | 问题 | 决定 |
|---|---|---|
| D1 | 繁殖强度定义 | 风险率 λ + 可选 refractory（§5.2） |
| D2 | "不随 S 变"的基准 | 期望事件率不变；实际出生数允许变化并记录 |
| D3 | 每步配对规则 | 发起者从全池 RKPM 选偶，双方对称发起（§5.4） |
| D5 | 表示变换 | 潜变量 + softmax，行为等价，导出语义变化并文档化 |
| D6 | 认知 A 队列定义 | 保留季末结算"本季繁殖成功者"，唯一保留季节意义之处 |
| D7 | gestation | 传统保留；分散下 ERROR |
| D8 | assortative | 吸收为 `mate_choice_criterion = similarity` |
| — | 分离方差基准 | 配置的创始分布 V₀/2（文献标准） |
| — | 突变参考尺度 | 绝对潜变量单位 |
| — | 配对状态存储 | `partner_agent_id` + 每步重建映射 |

## 17. 仍需负责人确认

| 编号 | 问题 | 建议 |
|---|---|---|
| D4 | 现有三个科学预设是否切换到新机制 | **是**，另存 `*_legacy` 副本（§12） |
| D9 | 记录时序改动影响传统模式 time_series 列位置 | **接受**，动态位级不变有回归保证（§7） |
| D10 | pair_bonded 结对只要求成熟、不要求阈值 | **是**（阈值管繁殖，不管结对） |
| D11 | `pair_bonded_humanlike` 具体参数（k=5, dissolution 0.05/季） | 示范值，校准时可调 |
| D12 | 是否升版本号至 0.2.0 | **建议是**：schema 变更 + 默认机制变更 |

## 18. 已知限制（写入 known_limitations.md）

- 无穷小模型忽略有限位点数、显性、上位、连锁、近交对分离方差的影响。
- 分量间无遗传协方差；领域与任务层独立。
- 配偶质量为固定四变量线性组合，不演化。
- `stable` 年龄分布是解析近似，忽略饥饿与密度死亡。
- pair_bonded 为最简抽象：无抚育、无资源、无社会结构。
- 分散模式与传统模式的绝对出生数不相等，属机制差异而非缺陷。
- 认知 A 仍按季结算。
- schema-1 与 schema-2 哈希不可比。

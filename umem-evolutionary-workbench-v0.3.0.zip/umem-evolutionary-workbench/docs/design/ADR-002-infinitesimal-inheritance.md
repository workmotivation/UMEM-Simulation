# ADR-002: Inheritance by Fisher's Infinitesimal Model

- **Status**: Accepted (2026-09-07)
- **Schema**: introduced in schema version 2
- **Supersedes**: the multiplicative log-normal recombination in
  `engine/inheritance.py` v0.1.0, which is retained as `inheritance.model = legacy`
- **Related**: ADR-001 (latent representation)

---

## Context and problem

Agents inherit motivational-domain and within-domain task propensities. In
v0.1.0 these were strictly positive numbers inherited by per-trait parental
selection followed by multiplicative log-normal mutation
(`recombine_and_mutate`, `engine/inheritance.py`).

Three problems motivated a redesign.

1. **No principled variance.** The amount of variation between full siblings was
   an arbitrary consequence of the mutation parameters. There was no way to ask
   "how much do siblings differ, and is that the right amount?", because the
   model contained no quantity corresponding to segregation.

2. **Segregation and mutation were conflated.** A single `mutation_log_sd`
   controlled both the ordinary variation that arises every generation from
   recombination *and* the rare novel variation from mutation. These are
   different biological processes with different rates and different
   evolutionary consequences, and the model could not separate or report them.

3. **Risk of runaway or collapsing variance.** With no anchor, within-population
   variance could drift upward or downward across generations as an artifact of
   the parameter values rather than as a result of selection or drift.

We required a mechanism that is **standard, citable, simple, and does not
require simulating genetic loci**, because the project deliberately excludes
explicit chromosomes, loci, dominance, epistasis, and linkage (see the scope
boundaries in the redesign plan).

## Options considered

| Option | Assessment |
|---|---|
| **A. Keep v0.1.0 multiplicative recombination** | Simple, but suffers all three problems above and has no literature standing. |
| **B. Explicit multi-locus genetic architecture** | Scientifically the most complete, and what quantiNemo/simuPOP/SLiM provide. Rejected: explicitly out of scope, and it would add per-agent genome storage, recombination maps, and allele bookkeeping to a model whose research question does not depend on genetic architecture. |
| **C. Mid-parent average with no noise** | Removes all within-family variation; variance collapses to zero within a few generations. Rejected as biologically wrong. |
| **D. Fisher's infinitesimal model** | **Chosen.** Standard, citable, requires no loci, and provides exactly the missing quantity (segregation variance). |

## Decision

Offspring genetic values are drawn using the classical **infinitesimal model**.
For each latent trait vector (see ADR-001), sexual reproduction uses

```
g_child = (g_A + g_B) / 2  +  ε_seg  +  ε_mut
ε_seg ~ N(0, σ²_seg)        drawn independently per offspring, per component
```

and asexual reproduction uses

```
g_child = g_parent + ε_mut
```

with **no** averaging and **no** segregation term, so that with mutation
disabled an asexual offspring is a clonal copy of its parent's genetic value.

### Segregation variance

```
σ²_seg = s · V₀ / 2
```

where `V₀` is the additive genetic variance of the **configured founder
distribution** for that trait layer, and `s` is a user-facing multiplier
(`sibling_variation`: low 0.5, standard 1.0, high 1.5).

### Mutation

Mutation is configured and reported **separately** from segregation. Each
offspring experiences an effective mutation event with probability `p_mut`; if
it occurs, one uniformly chosen component of the latent vector receives a
zero-mean normal increment with standard deviation `σ_mut`, expressed in
**absolute latent units**.

## Rationale and evidence

### The infinitesimal model is the standard tool

Under the infinitesimal model a quantitative trait is the sum of a genetic and a
non-genetic component, and the genetic component of offspring within a family is
normally distributed about the average of the parents' values with a variance
that is **independent of the parental values**. The variance segregating within
families is therefore not perturbed by selection and can be predicted from the
variance components (Barton, Etheridge & Véber 2017, *Theor. Popul. Biol.*
118:50–73).

Critically for this project, the model is justified as **the limit of Mendelian
inheritance as the number of underlying loci tends to infinity**, each of small
effect. That is precisely why we may use a single normal draw and still claim to
represent polygenic Mendelian inheritance without simulating any locus. The same
Gaussian-descendants assumption underlies the "animal model" used throughout
quantitative genetics (Lynch & Walsh 1998), and a phenotypic version — a fixed
"segregation kernel" giving full-sib phenotypes a Gaussian distribution centred
on the mid-parent value with fixed variance — has long been used in theoretical
evolutionary ecology (Turelli 2017, commentary in the same volume).

### Why σ²_seg = V₀ / 2 specifically

The Mendelian sampling variance of an offspring is

```
Var(MS) = 0.5 σ²_α − 0.25 (F_s + F_d) σ²_α
```

with `F_s`, `F_d` the parental inbreeding coefficients; **in the absence of
inbreeding this is 0.5 σ²_α**, i.e. half the additive genetic variance of the
base population. We do not track inbreeding, so we use the outbred value.

This choice makes the model **self-stabilising**, which resolves problem 3
above. Under neutrality,

```
Var(child) = Var(parent)/2 + σ²_seg
```

whose fixed point is `V = 2 σ²_seg = V₀`. The configured founder variance is
therefore the equilibrium: variance neither inflates nor decays as an artifact.
Departures from `V₀` then carry information — they indicate selection, drift, or
bottlenecks, which is exactly what the analysis layer reports.

### Why the baseline is the *configured* founder distribution

`V₀` is computed analytically from the configured `init_mean` / `init_var`
(ADR-001), **not** measured from the realised founder population. Measuring the
realised sample would make σ²_seg depend on the master seed, so two runs of the
same scenario with different seeds would have different inheritance mechanics.
That would violate the project's reproducibility principle and make seeds
non-comparable.

### Why mutation is separate and in absolute units

Segregation is the ordinary reshuffling of existing variation and occurs at
every reproductive event. Mutation is the rare introduction of *novel*
variation. Conflating them (as v0.1.0 did) makes it impossible to ask what
happens when new variation is unavailable, which is a standard evolutionary
question.

`σ_mut` is specified in absolute latent units rather than as a fraction of the
founder standard deviation. If it were a fraction, then a scenario with
`init_distribution = equal` (V₀ = 0) would silently have zero mutation effect,
producing a model with no variation at all and no warning. Absolute units cannot
degenerate this way.

The default values (`p_mut` 0.01, `σ_mut` 0.10 conservative; 0.05 / 0.20
accelerated) are **effective simulation parameters chosen to produce usable
evolutionary dynamics over tens of seasons**. They are not human per-base
mutation rates and must never be described as such.

## Consequences

### Positive

- Sibling variation is now a principled, documented, user-controllable quantity.
- Segregation and mutation are separately configurable and separately reported
  (`n_mutation_events` in the breeding series).
- Variance is anchored: deviations from `V₀` are informative rather than
  artifactual.
- Swapping which parent is labelled A or B cannot change the offspring
  distribution, since the formula is symmetric. This is enforced by test.
- The mechanism is citable, which matters for publication.

### Negative / limitations

- The infinitesimal model assumes many loci of small effect. It does **not**
  represent finite locus number, dominance, epistasis, linkage, or the reduction
  of segregation variance under inbreeding. Populations here are small
  (hundreds), so real inbreeding would reduce Mendelian sampling variance; we do
  not model this.
- Components are treated as genetically independent (diagonal covariance). Real
  traits covary.
- Because `V₀ = 0` is legal (`init_distribution = equal`), a scenario can have
  zero segregation variance. This is the mathematically correct behaviour — with
  no variation in the base population there is nothing to segregate — but it is
  surprising, so the validator emits a THEORY-level note.
- Existing scenarios must migrate to `inheritance.model = legacy` to preserve
  their meaning; results under the two models are not comparable.

## Future extension points

Deliberately left open by the design, not implemented here:

1. **Genetic covariance between components.** `σ²_seg` is currently a scalar per
   layer applied to a diagonal covariance. Replacing it with a full
   variance–covariance matrix `G/2` requires only changing the draw in
   `infinitesimal_offspring()`; the rest of the pipeline is unaffected.
2. **Inbreeding.** Tracking pedigree kinship would allow the full
   `0.5σ²_α − 0.25(F_s + F_d)σ²_α` expression. `parent_a` / `parent_b` are
   already stored, so a kinship matrix is computable.
3. **Dominance.** Barton, Etheridge & Véber (2023, *Genetics* 225(2):iyad133)
   extend the infinitesimal model to include dominance by decomposing the trait
   into a family-shared component and an independent per-offspring residual.
   That decomposition maps onto the current code structure.
4. **Trait-specific segregation.** `σ²_seg` is currently uniform within a layer.

## References

- Barton NH, Etheridge AM, Véber A (2017). The infinitesimal model: definition,
  derivation, and implications. *Theoretical Population Biology* 118:50–73.
- Barton NH, Etheridge AM, Véber A (2023). The infinitesimal model with
  dominance. *Genetics* 225(2):iyad133.
- Turelli M (2017). Commentary: Fisher's infinitesimal model: a story for the
  ages. *Theoretical Population Biology* 118:46–49.
- Lynch M, Walsh B (1998). *Genetics and Analysis of Quantitative Traits*,
  ch. 7. Sinauer.
- Fisher RA (1918). The correlation between relatives on the supposition of
  Mendelian inheritance. *Trans. R. Soc. Edinb.* 52:399–433.

See `docs/references.md` for the consolidated bibliography.

# ADR-007: When results are recorded

- **Status**: Accepted (2026-09-07)

## Context

In v0.1.0 the snapshot was taken *before* season-end breeding, so offspring born
at the end of a season first appeared in the following step's row. With the
default recording interval of 10 steps against 30–40 steps per season, snapshots
landed on a post-birth high point followed by two declining points every season.
The vertical edge of each sawtooth tooth was therefore partly a measurement
placement, though the underlying batch birth was real.

A separate defect, fixed earlier, was that the final season's births never
appeared at all: `final_population` disagreed with the last recorded row.

## Decision

Within a step: `… → mortality → ageing → reproduction → record`.

Births are counted in the step in which they occur, under both timing modes. A
closing snapshot is taken after the final reproduction so the last row agrees
with `final_population`.

## Consequences

The accounting identity `population[t] = population[t-1] + births[t] -
deaths[t]` holds on 100% of steps, enforced by regression test.

Under `season_end_legacy` the births column shifts by one step relative to
v0.1.0 output. **Population dynamics, the dead log, and final population are
unchanged**; only the column placement moves. This is a measurement change, not
a mechanism change, and was accepted explicitly by the project owner.

Recording placement is *not* the cause of the sawtooth: the pattern is fully
present at a recording interval of 1. Recording only determines where the edge
is drawn.

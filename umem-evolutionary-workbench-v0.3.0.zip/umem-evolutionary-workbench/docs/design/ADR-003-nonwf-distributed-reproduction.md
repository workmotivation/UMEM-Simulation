# ADR-003: Continuous (non-Wright-Fisher) reproduction

- **Status**: Accepted (2026-09-07) — schema 2
- **Related**: ADR-004 (mate choice), ADR-005 (mating modes), ADR-007 (recording)
- **Evidence**: `POPULATION_JAGGEDNESS_DIAGNOSTIC_REPORT.md`

## Context and problem

In v0.1.0 reproduction ran only when `is_season_end` was true. Every eligible
agent was paired in one call and every offspring entered in the same step.

The jaggedness diagnostic established the consequences empirically. Population
rose on only 2.4–3.3% of time steps — exactly one step per season — and fell on
every other step. The first difference of population had an autocorrelation of
0.83–0.91 at a lag of exactly one season, across all presets and all seeds, and
the pattern persisted after every founder had died and at large population size.
Births averaged 80.6 on the season-end step and **0.00** on every other step.

Because all offspring shared one birth step, every agent's age was an exact
multiple of the season length. Maturity and the hard maximum-age cull, both
triggered by integer season crossings, therefore also fired in synchronised
batches. Age-cohort synchrony was a *consequence* of batch birth, not an
independent cause: randomising founder ages left the autocorrelation unchanged.

## Options considered

| Option | Assessment |
|---|---|
| Keep season-end batching | Defensible for a strictly seasonal breeder, but imposes that assumption silently on every scenario. |
| Smooth the plotted curve | Rejected outright. It hides the artifact rather than removing it and would misrepresent the simulation. |
| Run the whole season-end routine every step | Rejected: multiplies fertility by `steps_per_season`. |
| **Continuous reproduction with a per-step hazard** | **Chosen.** |

## Decision

`reproduction.timing` selects `distributed` (new default) or
`season_end_legacy`. Under `distributed`:

- eligibility is evaluated **every step**; season boundaries carry no
  reproductive meaning;
- offspring enter in the step in which the event occurs; there is no gestation
  model, and a non-zero gestation delay is a validation error;
- the refractory period is stored in steps and starts only after a **successful**
  event. Failed attempts cost nothing.

Reproductive intensity is parameterised as a **rate**:

```
h_step = 1 - exp(-lambda / steps_per_season)
```

with `lambda = reproductive_event_rate` (formerly, and misleadingly, `expected_births_per_season`; the old name is still accepted on input). The rate counts reproductive *attempt events*; realised births equal events x P(partner found) x fertility x juvenile survival.

## Rationale

**This is the standard formulation.** SLiM 3 introduced non-Wright-Fisher models
precisely because the Wright-Fisher assumptions — discrete non-overlapping
generations, offspring drawn in proportion to fitness — make it hard to model
overlapping generations, individual variation in reproduction, age structure,
and density-dependent regulation (Haller & Messer 2019). In a nonWF model each
time step *is* an opportunity to reproduce and/or die. UMEM already had
overlapping generations and age structure, so season-end batching was a
Wright-Fisher remnant inside an otherwise nonWF model. The sawtooth was the
visible symptom of that mismatch.

**Why a rate and not the specification's probability formula.** The original
task specified `p_step = 1 - (1 - p_season)^(1/S)`, which converts a per-season
*probability*. Eligible agents in v0.1.0 bred with certainty at each season end,
so `p_season = 1` and the formula degenerates to `h = 1`. Worse, a
near-certain per-step probability would make every agent reproduce on the first
step after its refractory period ends, reintroducing synchrony on a different
period. A rate gives geometrically distributed waiting times, which
desynchronises reproduction as a by-product rather than by construction.

**Invariance to time resolution.** Expected events per season is `lambda`
regardless of `steps_per_season`, verified by test across 10, 20, 40 and 80
steps per season.

Every reproduction parameter was audited and classified — rate, probability,
interval, count, or threshold — and only rates are converted. The classification
is recorded in each field's `category` metadata.

## Consequences

Measured over 3 presets × 8 seeds, per-step recording, no smoothing:

| Metric | Legacy | Distributed |
|---|---|---|
| Autocorrelation at one season | 0.837–0.912 | **0.036–0.090** |
| Birth-phase entropy (1 = uniform) | 0.000 | **0.994–0.998** |
| Share of steps with births | 0.024–0.033 | 0.455–0.712 |
| Share of steps where population rises | 0.024–0.033 | 0.294–0.410 |

The season-linked artifact is removed in the raw dynamics.

**Costs.** Realised birth counts differ from legacy at identical parameters
because pairing efficiency and the timing of condition thresholds change, so all
presets were recalibrated. Existing seeds are not comparable across timing modes.
Crash–recovery dynamics driven by starvation, selection and density dependence
remain and are *not* artifacts; the diagnostic separates them explicitly.

## Future extension points

Gestation delay under distributed timing; seasonally varying `lambda` for
genuinely seasonal breeders; per-agent rather than population-level rates.

## References

Haller BC, Messer PW (2019). SLiM 3. *Mol. Biol. Evol.* 36(3):632–637.

# 实施进度（v0.2.0 重设计里程碑）

**用途**：记录繁殖与遗传重设计的实施状态。所有路径相对于仓库根目录。

**权威计划**：`docs/design/REDESIGN_PLAN_v2.md`（已随仓库分发）
**诊断依据**：`docs/design/POPULATION_JAGGEDNESS_DIAGNOSTIC_REPORT.md`
**完成报告**：`FINAL_COMPLETION_REPORT.md`（仓库根目录）

**验证命令**：
```bash
pip install -e ".[streamlit,test]"
python -m pytest -q
python scripts/validate_reproduction_timing.py --seeds 8
python scripts/audit_reproductive_intensity.py --seeds 6
```

---

## 阶段状态

| 阶段 | 内容 | 状态 |
|---|---|---|
| P1 | 潜变量表示 + 无穷小遗传 + 突变 + 传统模式保留 | ✅ 完成 |
| P2 | 分散繁殖 + RKPM 配对 + 三模式 + 无性 | ✅ 完成 |
| P3 | 创始者年龄结构 + 记录时序 | ✅ 完成 |
| P4 | 数据字典 + 迁移 + UI + 预设重校准 + 文档 + 全量验证 | ✅ 完成（本完成阶段补齐） |
| P5（完成与修正阶段） | gestation 安全、指标语义、配对计数、导出元数据、数据字典、桌面同步、强度审计 | ✅ 完成 |

**状态一致性说明**：早先版本的本文件曾将 P4 标为完成同时列出未完成项。该不一致已在
完成阶段消除：数据字典 CLI、导出元数据、偏斜指标、桌面同步现已全部实现并有测试。

---

## 关键设计常量（实施时以此为准）

```
潜变量创始方差   V₀_c = log(1 + init_var_c / init_mean_c²)   对数正态矩匹配；整层中心化 Σg=0
分离方差         σ²_seg = s · V₀_c / 2   s: low 0.5 / standard 1.0 / high 1.5；平衡态 Var=V₀
有性             g_child = (g_A+g_B)/2 + N(0,σ²_seg) + ε_mut
无性             g_child = g_parent + ε_mut
突变             p/后代：conservative 0.01/0.10，accelerated 0.05/0.20（绝对潜变量单位）
繁殖时序         h_step = 1 − exp(−reproductive_event_rate / S)   事件率，非出生率
配对             RKPM：洗牌→k 候选→择优；k=1 随机；期望排名 n/(k+1)
质量权重         默认 status 主导——repro_capital 繁殖后重置为 0，选它会反向均衡
配对结合         结对只需成熟；繁殖需全部合格条件；一对每步一次尝试
```

---

## 未完成 / 有意留待后续

- **平台打包未验证**：PyInstaller spec 与 GitHub Actions workflow 存在但未在 Windows/macOS 上执行。
- **发布身份占位符**：见 `RELEASE_CHECKLIST.md`。项目不应在占位符存在时被描述为可公开发布。
- 外部 AI 情景设计/报告解读指南：明确属于后续里程碑，数据字典已为其准备。

## 需注意

- `pair_bonded_humanlike` 事件率 9.0 是排他性的数学后果（仅 ~15–22% 配对步双方同时合格），
  详见 `FINAL_COMPLETION_REPORT.md` §9 与 ADR-005。
- schema 1/2 哈希不可比；`domprop_*` 为比例；旧种子跨机制不可比。
- 字段 `expected_births_per_season` 已改名 `reproductive_event_rate`（输入时旧名仍接受，迁移自动改名）。

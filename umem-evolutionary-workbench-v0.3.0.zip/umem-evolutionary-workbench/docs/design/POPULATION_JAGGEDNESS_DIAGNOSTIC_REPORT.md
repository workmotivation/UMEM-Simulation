# POPULATION_JAGGEDNESS_DIAGNOSTIC_REPORT.md

UMEM Evolutionary Simulation Workbench v0.1.0 — diagnosis only, no production changes.
Date: 2026-09-07. All line numbers refer to `src/umem_workbench/` in the current repository.

---

## 1. Executive Summary

**Primary cause — batch reproduction at season boundaries (scheduling artifact).**
Breeding is evaluated only when `is_season_end` is true (`engine/simulation.py` L97, L216). All eligible agents are paired at once and all offspring appended in a single step. Consequently the population **rises on only 2.4–3.3 % of time steps** — exactly one step per season — and falls on every other step. First-difference autocorrelation at a lag of one season is **0.83–0.91** across all three presets and all seeds tested; at half a season it is ≈ 0. Removing this one feature in a temporary counterfactual (breeding spread across the season) collapsed the autocorrelation to **0.20–0.25** and raised the share of rising steps to **21–36 %**. No other intervention had any effect.

**Secondary causes (real, but small or transient):**
1. *Age quantisation.* Because every agent is born at a season boundary, **100 % of agents share the same within-season birth phase**. Maturity (`simulation.py` L203–205) and the hard maximum age (`mortality.py` L48–52) both trigger on integer-season crossings, so every cohort matures and is culled in a single step. This is a *consequence* of the primary cause, not an independent one.
2. *Deterministic max-age cull.* A real death pulse on the first step of each season: ~5× the per-step death rate on other steps, but only **1.4–3.4 % of population** on average (max 6.9 %). Removing it (CF2) changed jaggedness metrics by < 0.02. Classified as an intended mechanism with a minor measurement footprint.
3. *Degenerate initial age structure.* All founders start at `age_steps = 0` (`state.py` L115). This produces a fully synchronised founder cohort, but the artifact **dissipates within one maximum lifespan** (~step 210 in Preset C) and the sawtooth persists undiminished afterwards (ACF 0.92 for step > 210).

**Ruled out:** environmental synchronisation (environment updates every step), within-season behavioural synchrony (per-step death rate flat: std 0.22), small-population stochasticity (ACF 0.81 at N > 400), hard density culling (regulation is continuous Beverton-Holt), recording aliasing as the *cause* (the pattern is present at `record_interval = 1`; recording only determines *where* the vertical edge is drawn).

**Confidence:** High. Conclusions rest on 5 seeds × 2–3 presets per condition, a 100 %-verified demographic accounting identity, full age-structure capture, and a single-variable counterfactual that eliminates the effect.

**Verdict on the user's hypothesis:** *"The hypothesis is partially supported but is not the primary cause."* Initial-age synchrony is real but transient; identical maximum lifespan is real but contributes little; batch death is not the driver. The dominant driver is **batch birth**.

---

## 2. Observed Population Pattern

**Configuration.** Presets `stable_abundant` (K = 500, 40 steps/season, max life 12), `scarce_low_fecundity`, `volatile_high_fecundity` (K = 700, 30 steps/season, max life 7). Seeds 1–5 each, plus the user's own seed 32345 (config hash `807b836a…`) for Preset C. Software 0.1.0. Recording forced to every step to remove aliasing.

**Quantitative jaggedness (mean over 5 seeds, per-step recording):**

| Metric | scarce | stable | volatile |
|---|---|---|---|
| Population CV | 0.635 | 0.351 | 0.709 |
| Mean \|Δpop\| per season | 12.6 | 11.2 | 20.5 |
| Largest one-season rise | +41.5 % | +41.6 % | +39.1 % |
| Largest one-season fall | −35.7 % | −29.5 % | −28.3 % |
| **Fraction of steps where pop rises** | **0.024** | **0.024** | **0.033** |
| **ACF of Δpop at lag = 1 season** | **0.859** | **0.828** | **0.907** |
| ACF of Δpop at lag = ½ season | −0.019 | −0.020 | −0.026 |

`1/40 = 0.025` and `1/30 = 0.033`: the population rises on precisely one step per season.

**Character.** Periodic with period exactly `steps_per_season`; **persistent** (ACF 0.92 after all founders are dead); **not seed-specific** (all 15 runs); **not size-dependent** (ACF 0.81 at N > 400). Superimposed on it in Preset C is a genuine crash–recovery transient (216 → 43 → 633) driven by starvation-selection on foraging propensity — that is an intended evolutionary dynamic, not jaggedness, and is analysed separately in the earlier results review.

---

## 3. Actual Simulation Event Pipeline

Per time step `t`, `engine/simulation.py::run_simulation` (L90–245):

```
 1. flush gestation-delayed births due at t         L100–110
 2. extinction check                                 L111–117
 3. observe env[t] (noisy), forecast.update          L119–128
 4. homeostatic urgencies, eligibility, logits       L130–142
 5. actions_per_step × {choice, cost, success,
    effects, exposure multiplier}                    L143–176
 6. basal metabolism, starvation health penalty      L178–182
 7. step_mortality (deterministic → hazards)         L191   → mortality.py L29–107
 8. remove_dead (compacts arrays, logs cause)        L197
 9. age_steps += 1 ; maturity on integer crossing    L202–205
10. **record_snapshot** if t % interval == 0         L209–212
11. **breed()** only if step_in_season == sps−1      L216–219 → reproduction.py L105
12. memory.update_from_cohort, reset tallies         L221–226
13. **append offspring** (or queue if gestation>0)   L229–238
```

Season boundary = step 11–13 executed on the last step of the season. **Offspring are appended after the snapshot**, so births at season-end step 29 are first visible in the row for step 30 (they are tallied into `births_interval` of the following snapshot). With default `record_interval = 10` and `steps_per_season = 30`, snapshots fall at step-in-season 0, 10, 20: one post-birth high point followed by two declining points, every season. The chart's saw-tooth edge is therefore the birth batch.

---

## 4. Initialization Findings

`engine/state.py::AgentPool.initialise` L101–130:

| Quantity | Initialisation | Line |
|---|---|---|
| `age_steps` | `np.zeros(n)` — **all founders age 0** | 115 |
| `born_season` | `np.zeros(n)` | 116 |
| `energy / health / repro_capital / status` | identical constants from `LifecycleConfig.initial_*` | 118–121 |
| `reached_maturity` | all `False` | 124 |
| `sex` | Bernoulli(`sex_ratio_type_a`) | 113 |
| propensities | equal / gamma / lognormal per `init_distribution` | 126–129 |

There is **no overlapping age structure at t = 0**. Runtime confirmation (Preset C, seed 32345): age histogram at step 0 is `[247, 0, 0, 0, 0, 0, 0, 0]`; at step 29 all 167 survivors are exactly age 1; the first overlap appears only at step 30 when the first birth cohort arrives. Sex assignment does not affect timing.

The founder cohort reaches the hard max age together at step `max_lifespan × sps` (= 210). In the representative run only 9 of 44 remaining agents were founders at that moment (most had already died in the starvation crash), so the founder cull was a 20 % one-step drop — visible but not dominant.

**Classification: Initialization artifact, transient.** Age structure converges to a stable overlapping multi-cohort distribution by ~step 600 (`[74, 50, 28, 26, 24, 8, 8]` across ages 0–6).

---

## 5. Lifespan and Mortality Findings

`engine/mortality.py::step_mortality` L29–107, evaluated **every step** (good), in this order:

1. **Deterministic state death** (L43–47): `health ≤ 0` → starvation if `energy ≤ 0`, else health.
2. **Deterministic maximum age** (L48–52): `age_steps // steps_per_season >= max_lifespan_seasons`. Because of integer division and universal birth-phase alignment, this fires for a whole cohort on the **first step of a season**.
3. **Stochastic competing hazards** (L54–105): predation × environment × task exposure, Gompertz/logistic age hazard, background, juvenile, density. Combined as `1 − Π(1 − hᵢ)`; cause sampled ∝ component.

Distinctions requested:

| Concept | Implementation |
|---|---|
| Expected lifespan | emergent (Preset C: 2.6 seasons; 4.0 given maturity) |
| Individual realised lifespan | varies — dead-log ages span 0 → 210 steps |
| Deterministic maximum age | **yes**, `max_lifespan_seasons`, hard cut |
| Stochastic age-dependent mortality before max | **yes**, Gompertz (`age_hazard_scale·e^(rate·age)`), but `age` is the integer season, so the hazard is a per-season staircase |

Runtime: age-at-death share by season (Preset C, born-in-run agents) declines smoothly `0.41, 0.12, 0.10, 0.08, 0.07, 0.05, 0.045` then **jumps to 0.131 at age 7** — the hard cull. 39 % of all age deaths occur on season-first steps. Deaths on all other steps are flat (1.6–2.3 per step, std 0.22): **no within-season death synchrony**.

**Classification:** hard max age = **intended model mechanism** with a minor pulse footprint (1.4–3.4 % of N). The staircase age hazard is a **minor scheduling artifact** (hazard should arguably be continuous in `age_steps`).

---

## 6. Reproduction, Recruitment, and Density Findings

**Maturation** (`simulation.py` L203–205): `age_steps // sps >= maturity_seasons`. Entire birth cohorts mature in one step (49 agents flip at step 60 in the representative run). Synchronised integer-age cohorts — **yes**, as a downstream consequence of batch birth.

**Reproduction** (`simulation.py` L216; `reproduction.py::breed` L105–170):
- Occurs **only** when `is_season_end` (L97). **Never** within a season.
- All eligible agents evaluated simultaneously; `ready` mask L113–120 (maturity, energy/health/capital thresholds, `breeding_every_seasons`).
- Mating, fertility draw, inheritance, juvenile survival and offspring entry all happen in the **same call** and the same step. Births are **100 % batched**: mean 80.6 (C) / 35.1 (A) offspring on the boundary step vs **0.00** on every other step.
- Every birth cohort shares one birth step → every cohort later matures together and reaches max age together. So yes: **synchronised birth cohorts produce synchronised (max-age) death cohorts**, though the latter are much smaller because most deaths are stochastic and diffuse.
- Sexual pairing bounds pairs by the smaller ready sex (L127–136); this limits batch size but does not change its timing.

**Juvenile recruitment** (L142–159): all offspring that pass `eff_survival` become agents immediately in the same step. Beverton-Holt: `eff_survival = juvenile_survival / (1 + strength·N/K)` — **continuous**, no threshold. Hard cap `room = max_population − N` (L142) exists but at 2000 is never reached in shipped presets.

**Density hazard** (`mortality.py` L64–69): zero below `density_onset_fraction·K`, then linear — continuous with one kink, no random culling. Runtime: density deaths appear only once N crosses 0.6 K, as configured.

**Classification:** batch reproduction = **scheduling artifact** (primary). Recruitment and density = **intended, continuous mechanisms**, ruled out as pulse sources.

---

## 7. Age-Cohort Evidence

Preset C, seed 32345, full-population age capture at every step (2,437 deaths, 1,050 steps):

| Step | N | Agents by age in seasons (0…7) |
|---|---|---|
| 0 | 247 | 247 · 0 · 0 · 0 · 0 · 0 · 0 · 0 |
| 29 | 167 | 0 · **167** · 0 · 0 · 0 · 0 · 0 · 0 |
| 30 | 230 | 63 · 167 · 0 · 0 · 0 · 0 · 0 · 0 |
| 60 | 182 | 32 · 48 · 102 · 0 · 0 · 0 · 0 · 0 |
| 209 | 44 | 0 · 8 · 11 · 6 · 2 · 4 · 4 · **9** |
| 210 | 52 | 17 · 8 · 11 · 6 · 2 · 4 · 4 · 0 |
| 600 | 218 | 74 · 50 · 28 · 26 · 24 · 8 · 8 · 0 |
| 900 | 546 | 147 · 106 · 93 · 81 · 53 · 39 · 27 · 0 |

- **Birth-phase synchrony = 1.000** at every step checked: every living agent has `age_steps ≡ 0 (mod sps)` relative to the season phase. No fractional ages exist.
- Founders: only 3.2 % died at max age (crash killed them first). Born-in-run: 13.1 % died at max age.
- Age structure **converges** to stable overlapping cohorts after ~2 lifespans, but they remain quantised to whole seasons.
- **Period estimate:** ACF of Δpop peaks at lag 30 = `steps_per_season` exactly; no peak at max lifespan (210), maturity (30 — coincides), reproduction interval (30 — coincides), or any environmental cycle (environment is AR(1)/random-walk, not cyclic).
- Synchronisation **does not disappear** after founders die (ACF 0.92 for step > 210). It persists indefinitely.

---

## 8. Demographic Accounting

Identity used by the implementation and verified on **100 % of 1,049 steps**:

`population[t] = population[t−1] + births_interval[t] − deaths_interval[t]`

(births committed at season-end step `t` are tallied into row `t+1`, see §3.)

Every step with |Δpop| ≥ 15 in the representative run — all 31 of them — is a birth batch; none is a death batch:

| Step | Season | N start | Births | Deaths | of which age | N end | Δ |
|---|---|---|---|---|---|---|---|
| 30 | 1 | 167 | **64** | 1 | 0 | 230 | +63 |
| 60 | 2 | 152 | **32** | 2 | 1 | 182 | +30 |
| 210 | 7 | 44 | **17** | 9 | **9** | 52 | +8 |
| 480 | 16 | 87 | **59** | 4 | 3 | 142 | +55 |
| 540 | 18 | 114 | **58** | 9 | 8 | 163 | +49 |
| 900 | 30 | 442 | **112** | 8 | 6 | 546 | +104 |

Step 210 is the founders' max-age cull: 9 deaths (20 % of N) partly offset by 17 births in the same step. Between boundary steps, deaths run at 1–3 per step with no births, producing the linear decline that forms each tooth.

---

## 9. Causal Assessment Table

| # | Hypothesis | Evidence for | Evidence against | Classification | Confidence |
|---|---|---|---|---|---|
| 1 | Identical / concentrated initial ages | `state.py` L115 zeros; age hist `[247,0,…]`; founders die together at step 210 | CF1 (uniform random founder ages) leaves ACF unchanged (0.86/0.82); sawtooth persists at ACF 0.92 after founders extinct | **Initialization artifact, transient** | High |
| 2 | Deterministic common max lifespan | `mortality.py` L48–52; 13.1 % of deaths at max age vs 4.5 % the season before; 39 % of age deaths on boundary steps | Pulse is 1.4–3.4 % of N; CF2 (max life ×10) changes CV by 0.024→0.002, ACF unchanged | **Intended mechanism**, minor pulse | High |
| 3 | Insufficient stochastic mortality | Gompertz hazard is a per-season staircase (integer age) | Stochastic hazards account for 87 % of age deaths and 100 % of predation/starvation; per-step deaths flat within season | **Minor scheduling artifact** (staircase), not a pulse source | High |
| 4 | Synchronised maturation | `simulation.py` L203–205; whole cohorts flip in one step | Downstream of #5; does not itself change N | **Scheduling artifact (derived)** | High |
| 5 | **Batch reproduction** | L97/L216 season-end only; births 80.6 vs 0.00 per step; rises on 1 step/season; ACF 0.83–0.91 at exactly sps; **CF3 removes it (ACF→0.20–0.25, rising steps 3 %→21–36 %)** | None | **Scheduling artifact — PRIMARY** | **High** |
| 6 | Batch juvenile recruitment | Recruits enter in same step as breed | Inseparable from #5; survival itself is continuous B-H | Part of #5 | High |
| 7 | Hard density correction | — | B-H recruitment continuous (L153–158); hazard linear above onset; no culling code; `room` cap never reached | **Ruled out** | High |
| 8 | Cyclical / shared environment | All agents see same env | Env updated every step (27 distinct values / 30 steps); processes are AR(1)/random-walk, no cycle; corr(N, env) ≤ 0.29 | **Ruled out** | High |
| 9 | Shared behavioural / cognitive state | Common homeostatic thresholds | Within-season death rate flat (std 0.22); energy amplitude within season 6.4 on 0–100 scale; cognition off in baseline runs | **Ruled out** | High |
| 10 | Result-recording timing | Snapshot before breed (L209 vs L216) shifts birth edge to next row; default interval 10 vs sps 30 aliases to 3 pts/season | Sawtooth fully present at interval = 1 | **Measurement artifact — affects appearance only** | High |
| 11 | Small-population stochasticity | CV inflated during N ≈ 43 trough | ACF 0.81 when N > 400; per-step noise is diffuse | **Demographic stochasticity — present but not the periodic signal** | High |
| 12 | Legitimate endogenous cycles | Preset C crash–recovery is a real selection dynamic | It is a one-off transient, not periodic; unrelated to the sps-period sawtooth | **Intended mechanism (separate phenomenon)** | High |

---

## 10. Candidate Remedies and Scientific Consequences

Ranked least → most disruptive. **None implemented.**

### R1. Record snapshots after breeding, or align `record_interval` to a divisor of `steps_per_season`
- Addresses: #10 only. Changes: measurement.
- Effect: edge of each tooth drawn at the true season-end step; no change to dynamics. Reproducibility: unchanged (recording does not consume RNG). Schema: none. Tests: update snapshot-timing assertion in `test_regression`. Legacy: untouched.
- Verdict: cosmetic clarification; does **not** address the cause.

### R2. Continuous age hazard (use `age_steps / sps` as float instead of integer season)
- Addresses: #3 staircase. Changes: scientific model, marginally.
- Effect: smooths within-season senescence; negligible effect on N. Slight increase in mid-season age deaths. RNG consumption unchanged (same number of draws). Schema: none; results for old configs change by tiny amounts → **hash-preserving but not bit-identical**. Tests: mechanism test that hazard is monotone in steps. Legacy: untouched (AOM has no ages).

### R3. Staggered initial ages (uniform or from an approximate stable age distribution)
- Addresses: #1 only. Changes: initialisation.
- Effect: removes the founder-synchrony transient and the step-210 founder cull. **Does not remove the sawtooth** (CF1 evidence). Requires consistent initial maturity, energy and capital by age, otherwise old founders are unrealistically fresh. Extra RNG draws at init → shifts every downstream stream → **all existing seeds produce different trajectories**. Schema: new field e.g. `population.initial_age_distribution` (default `zero` to preserve old behaviour) + migration. Tests: age-histogram-at-t0, reproducibility. Legacy: untouched.
- Caution: a stable-age-distribution initialiser requires knowing the equilibrium survivorship, which is emergent — approximate only.

### R4. Individual lifespan variation / soft maximum age
- Addresses: #2. Changes: scientific model.
- Effect: replaces the hard cull with a steeper Gompertz tail or a per-agent max drawn at birth. Reduces the boundary death pulse (already small). Changes LRS for long-lived agents slightly. Extra RNG at birth if per-agent. Schema: `mortality.max_lifespan_mode: hard|soft|none` with default `hard`. Tests: age-at-death tail shape. Legacy: untouched.

### R5. **Distributed reproductive timing** (per-agent breeding phase within the season)
- Addresses: **#5 primary, and therefore #4 and #6**. Changes: event scheduling; scientific meaning debatable (see below).
- Effect (CF3 evidence): ACF 0.83–0.91 → 0.20–0.25; rising steps 3 % → 21–36 %; CV −8 to −23 %; mean N −10 to −27 % under the crude diagnostic pairing rule.
- **Scientific meaning.** Season-end breeding is a legitimate model of a synchronous breeder (strictly seasonal mating). Distributed breeding models an aseasonal or income breeder. This is a **modelling decision**, not a bug. Both are biologically real. The current design silently imposes strict breeding synchrony without exposing it as a choice.
- Design consequences that must be resolved first:
  - Mate availability: if only agents "on phase" are eligible, pairing collapses (my first CF3 attempt → 100 % extinction). Initiators on phase must draw mates from the whole ready pool; the mate's own `last_bred_season` then blocks re-pairing.
  - Memory (cognition A) updates per cohort at season end; with continuous births "cohort" needs redefinition (e.g. rolling window).
  - `breeding_every_seasons` semantics change subtly.
  - Ages become non-quantised → maturity and max-age crossings spread out automatically.
- Reproducibility: RNG consumption pattern changes completely → **existing seeds not comparable**. Schema: `reproduction.timing: season_end|distributed` default `season_end` + migration. Tests: births-per-step distribution, pairing efficiency, reproducibility, all mechanism tests re-run. Legacy: untouched (generational).

### R6. Continuous density dependence
- Already continuous (B-H, linear hazard). **Not needed.**

---

## 11. Recommended Next Decision

The designer must decide **one scientific question** before any coding:

> **Is the modelled organism a synchronous seasonal breeder, or should breeding timing be a configurable property of the scenario?**

- If seasonal synchrony is intended, the sawtooth is **correct model behaviour** and only R1 (recording alignment) and optionally R2/R3 (cosmetic transients) are warranted. The documentation should then state explicitly that population is expected to pulse once per season.
- If aseasonal or mixed breeding should be representable, R5 is the change that matters, and it should be built as a **selectable timing mode with `season_end` as the default** so every existing result, seed and hash remains valid.

Secondary decisions: whether the hard maximum age stays hard (R4), and whether founders should start with a distributed age structure (R3). Neither affects the primary pattern.

---

## 12. Uncertainties and Missing Evidence

- CF3 used a diagnostic pairing rule (initiators on-phase, mates from full pool) that is *not* a proposed design. Its −10 to −27 % effect on mean N reflects pairing inefficiency in the hack, not a property of distributed breeding.
- Counterfactuals CF1/CF3 change RNG consumption; results were compared at replication level (5 seeds), not as paired trajectories.
- Only two presets were used for counterfactuals (A, C). Preset B was included in baseline jaggedness only.
- The Gompertz staircase (#3) was not tested in isolation.
- No user-supplied screenshot was available; the user's own result bundle (seed 32345) was used and reproduces the pattern exactly.

---

## 13. Diagnostic Artifacts Created

All were created in a scratch directory *outside* the repository during the diagnostic session and are not shipped (the functionality was later formalised as `scripts/validate_reproduction_timing.py`):

| File | Purpose |
|---|---|
| `diag_harness.py` | In-process monkeypatch of `Recorder.record_snapshot` to capture full age arrays; jaggedness metrics |
| `diag_counterfactuals.py` | Runs CF0–CF4; edits `is_season_end` **only in a scratch copy of the repository**, restores after |
| `diag_jaggedness.csv` | Part 2 metrics, 3 presets × 5 seeds |
| `diag_counterfactuals.csv` | Part 5 metrics, 5 CFs × 2 presets × 5 seeds |
| `prod_md5.txt` | Pre-diagnostic checksums of `engine/*.py` |
| scratch repository copy | All diagnostic edits reverted; production verified unchanged by checksum |

**Verification:** `md5sum` of production `engine/*.py` matches the pre-diagnostic baseline; `diff -rq` between production and scratch `src/` shows no source differences; legacy reference file checksum `e0b1e126…` unchanged. No commits made.

---

**Final statement: The synchronized initial-age/lifespan hypothesis is partially supported but is not the primary cause. The primary cause is batch reproduction at season boundaries.**

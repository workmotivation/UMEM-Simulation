# ADR-001: Heritable propensities on a latent scale with softmax expression

- **Status**: Accepted (2026-09-07)
- **Schema**: introduced in schema version 2
- **Related**: ADR-002 (inheritance operates on this scale)

---

## Context and problem

Propensities are hierarchical: one per motivational domain, and one per task
within a domain. In v0.1.0 each was a strictly positive real number, inherited
multiplicatively and floored at `min_propensity`.

Two problems.

1. **Inheritance had no natural scale.** Applying a normal (additive) genetic
   model to a strictly positive, unbounded quantity requires either truncation
   (which biases the mean) or a multiplicative formulation (which is not the
   additive model of quantitative genetics). To use the infinitesimal model
   (ADR-002) we need an **unconstrained** scale on which averaging and Gaussian
   noise are meaningful.

2. **A redundant degree of freedom.** Task choice depends only on `log(domain
   propensity) + log(task propensity)` entering a softmax. Multiplying every
   propensity in a layer by a constant leaves behaviour completely unchanged.
   The overall scale is therefore unidentifiable: two genetically different
   populations can be behaviourally identical, which makes reported variance
   partly meaningless.

The naive alternative — inheriting the displayed proportions directly, clipping
to [0,1] and renormalising — is worse: clipping biases the mean, and
renormalising after independent perturbation induces spurious negative
correlations between components.

## Decision

Represent the heritable genetic component of each layer as a **centred latent
vector** `g` on the unconstrained real line, and express it as proportions via
softmax.

```
constraint     Σ_c g_c = 0                  within each layer
expression     p = softmax(g)
choice term    log p = g − logsumexp(g)
```

Applied **independently** to the domain layer and to each within-domain task
layer.

Founder initialisation derives `g` from the existing `init_mean` / `init_var`
fields by log-normal moment matching, so no new founder-distribution
configuration is introduced:

```
μ_c  = log(init_mean_c)
V₀_c = log(1 + init_var_c / init_mean_c²)
g_c ~ N(μ_c, V₀_c),  then g ← g − mean(g)
```

Conversion of legacy positive propensities to latent values, needed for
migration and for interoperating with `inheritance.model = legacy`:

```
g = log(max(prop, min_propensity)),  then g ← g − mean(g)
```

## Rationale

**Behaviourally equivalent, not a mechanism change.** Because the choice policy
is additive in log-odds and passed through a softmax, the constant subtracted by
centring cancels exactly. A run under the latent representation with matched
parameters produces the same behaviour as the positive representation. This is a
change of coordinates that removes an unidentifiable degree of freedom; it is
not a new scientific assumption.

**Centring makes the representation identifiable.** With `Σg = 0` there is
exactly one latent vector per behavioural phenotype, so reported genetic
variance measures something real rather than partly measuring an arbitrary
scale.

**Softmax is the standard link.** Mapping an unconstrained vector to positive
values summing to one is the compositional-data problem; softmax is the inverse
of the additive log-ratio transform and is the standard choice. Working on the
log-ratio scale and transforming at the end is the textbook way to avoid the
clipping and renormalisation pathologies described above.

**`min_propensity` gains a second, well-defined job**: it is the floor that
keeps the legacy→latent log transform finite. A legacy propensity of exactly
zero maps to `log(min_propensity)`, never to `−inf`.

## Consequences

### Positive
- The infinitesimal model (ADR-002) becomes directly applicable.
- No clipping bias, no renormalisation-induced correlation.
- Genetic variance is identifiable and comparable across runs.
- Domain and task layers normalise independently, matching the hierarchical
  design.

### Negative
- **Exported columns change meaning.** `domprop_*` and `taskprop_*` become
  proportions summing to 1; `domvar_*` becomes latent variance. Results produced
  under schema 1 are **not numerically comparable** to schema 2. Analysis,
  plotting labels, misallocation metrics, and the affected tests all change.
- The relative weight of genetic propensity against homeostatic urgency in the
  choice logit depends on the latent variance scale. Log-normal moment matching
  gives `V₀ = log(1.5) ≈ 0.405` for the task layer, against `Var(log X) = ψ'(2)
  ≈ 0.645` for the previous gamma(2, 0.5) initialisation. Genetic influence on
  choice is therefore slightly weaker at default settings than in v0.1.0; users
  can raise `init_var` to compensate. This is recorded here rather than silently
  absorbed, and preset recalibration accounts for it.
- Reading a latent value requires knowing it is centred; raw values are not
  interpretable in isolation, only as differences.

## Future extension points

- A temperature or scale parameter on the latent→softmax map would let users
  tune how decisively genotype determines behaviour, independently of the
  variance. Not added now to avoid a redundant parameter.
- Non-diagonal genetic covariance (see ADR-002) applies naturally on this scale.

## References

- Aitchison J (1986). *The Statistical Analysis of Compositional Data.* Chapman
  & Hall. (Additive log-ratio transform; softmax as its inverse.)
- See ADR-002 for the inheritance operator that uses this scale.

# 外部 AI 辅助工作流：实施进度

任务书：`docs/design/AI_ASSIST_TASK.md`。完成报告：`AI_ASSISTANCE_COMPLETION_REPORT.md`（仓库根目录）。
基线 v0.2.1 / 293 测试 → 交付 v0.3.0 / 340 测试。

| # | 增量 | 状态 |
|---|---|---|
| 1 | `ai_assist/registry.py` 输出字段注册表（6 表） | ✅ 漂移检测：真实运行未记录列 = 0 |
| 2 | `ai_assist/fingerprint.py` 字典/注册表指纹 | ✅ 稳定且随注册表变化 |
| 3 | `ai_assist/narrative.py` 确定性实验描述 | ✅ 10 预设未覆盖参数 = 0 |
| 4 | `ai_assist/scenario_import.py` 六阶段导入 | ✅ 10 个对抗用例正确 |
| 5 | `ai_assist/guides.py` 两份指南 + 内嵌示例 | ✅ 172/172 参数、全部输出字段覆盖 |
| 6 | `ai_assist/report.py` AI_REPORT.md | ✅ 单/复制/扫描/灭绝/取消/部分失败 |
| 7 | Streamlit 两页 + 桌面标签 | ✅ 两端端到端实测 |
| 8 | 测试 | ✅ 340 通过 |
| 9 | 文档、示例、完成报告、ZIP | ✅ |

已核实事实（写入叙述与指南，未沿用旧设计假设）：
`mutation_target=both` 时突变概率**按层独立判定**（domain、task 各一次 Bernoulli(p)），
故一个后代最多可产生 2 次突变事件；`mutation_events_per_offspring` 因此可超过配置概率。

引擎方程、默认值与随机数消耗未改动；未重新校准任何预设。

# ADR-005: Three mating modes on one engine

- **Status**: Accepted (2026-09-07) — schema 2
- **Related**: ADR-004 (the matching algorithm)

## Context and problem

The model needed to express qualitatively different mating systems — including
something recognisably "human-like" — without three parallel implementations,
and without overstating what an abstract model can say about human societies.

## Decision

Three modes, all running through the RKPM engine of ADR-004 and differing only
in **persistence** and **exclusivity**:

| Mode | Standard term | Persists | Exclusive | Default k |
|---|---|---|---|---|
| `random` | promiscuity | no | — | 1 |
| `pair_bonded` | social monogamy | yes | yes, 1:1 | 5 |
| `competitive` | polygyny-like skew | no | no | 25 |

`random` is `competitive` with `k = 1`; they share a code path. Asexual
reproduction bypasses matching entirely.

Field names stay neutral (`random`, `pair_bonded`, `competitive`) and the
reproductive types remain A and B, never male and female. The standard
behavioural-ecology terms appear in documentation and UI help so that the
correspondence is explicit.

Pair bonds: formed between unpaired **mature** agents of complementary type at a
configurable rate; dissolved on partner death, or stochastically at
`bond_dissolution_per_season` (default 0.0); one reproductive attempt **per
pair** per step. No households, parental care, shared resources, or marriage
institutions.

## Rationale

**The classification is standard.** quantiNemo offers exactly promiscuity,
monogamy and polygyny as a user choice for species with separate sexes
(Neuenschwander et al. 2008); Emlen & Oring (1977) is the classical framework.
Adopting it means the modes are recognisable and citable rather than invented.

**Reproductive skew is the underlying continuum**, so implementing three modes as
three mechanisms would have been redundant. Persistence and exclusivity are the
only genuine structural differences.

**Bond formation requires maturity only.** Energy, health and capital thresholds
govern whether a pair can *reproduce*, not whether it can *form*. Conflating the
two would make bonds dissolve and reform as condition fluctuated, which is not
what social monogamy means.

**Bonds are keyed by agent id, not slot.** The population arrays are compacted
after every death, so slot indices are invalidated constantly; storing slots
would silently corrupt bonds. Agent ids are stable for life.

**On the "human-like" preset.** Roughly 9% of mammal species are socially
monogamous (Lukas & Clutton-Brock 2013), and human sexual dimorphism sits
between monogamous and highly polygynous species, implying mixed strategies. The
`pair_bonded_humanlike` preset therefore combines social monogamy, a low
dissolution rate and moderate choosiness, and its description states plainly
that it is an abstract approximation and not a model of any real human society.

## Consequences

- One engine, three modes, verified by tests for exclusivity, persistence,
  release on partner death, and absence of double bonding.
- `pair_bonded` needs a higher configured rate (9.0 vs 1.7 in the shipped
  presets) because a bonded pair makes one attempt per step where random mating
  has two independent initiators, and because both partners must clear the
  condition thresholds simultaneously. This is a real demographic consequence of
  exclusivity, not a defect.

**Limitations.** No mating market, no partner search cost, no re-pairing
preference, no assortment by kinship, no inbreeding avoidance.

## References

- Neuenschwander S et al. (2008). quantiNemo. *Bioinformatics* 24(13):1552–1553.
- Emlen ST, Oring LW (1977). *Science* 197:215–223.
- Lukas D, Clutton-Brock TH (2013). *Science* 341:526–530.

# ADR-006: Founder age structure

- **Status**: Accepted (2026-09-07) — schema 2

## Context

v0.1.0 started every founder at age zero. The whole founding cohort therefore
matured together and reached the hard maximum age together.

**This was not the cause of persistent population sawtoothing.** The diagnostic
showed the autocorrelation at one season was 0.92 *after* every founder had
died, and randomising founder ages left it unchanged. Founder synchrony produces
a genuine but *transient* artifact: an initial cohort pulse and a matching
die-off one lifespan later.

## Decision

`population.founder_age_distribution`: `all_newborn_legacy`, `uniform` (new
default), or `stable`.

- **`uniform`**: ages drawn uniformly over `[0, max_lifespan_seasons ×
  steps_per_season)`.
- **`stable`**: an approximate stable age distribution. Per-season survivorship
  is built analytically from the configured baseline hazards — age hazard
  (Gompertz or logistic), base predation, background, and the juvenile
  supplement below maturity — accumulated into `l(a)`, normalised, then sampled
  with a uniform within-season offset.

Founders take `reached_maturity` from their age, and their refractory phase is
randomised so that a shared cooldown cannot resynchronise first reproduction.
Other state variables use their configured initial values and are **not**
adjusted for age.

`all_newborn_legacy` consumes no random numbers, so migrated scenarios reproduce
exactly.

## Rationale and limitations

The `stable` distribution is explicitly an **approximation**. True stable age
structure depends on realised survivorship, which is an outcome of the
simulation: starvation, crowding, and behavioural exposure cannot be known in
advance. Only the configuration-derived baseline hazards are used.

Leaving energy and health at their configured initial values means an old
founder is as fresh as a newborn. This keeps founder state consistent with the
rest of the model, at the cost of realism in the first season.

`born_season` is negative for founders born before the run started. Analysis and
tests must accommodate this; the previous assertion that it is non-negative was
updated accordingly.

## Consequences

Removes the initial birth pulse and the matching max-age cull. Changes random
number consumption, so seeds are not comparable to `all_newborn_legacy` runs.
Combined with distributed reproduction and the new inheritance model, it
contributed to preset recalibration.

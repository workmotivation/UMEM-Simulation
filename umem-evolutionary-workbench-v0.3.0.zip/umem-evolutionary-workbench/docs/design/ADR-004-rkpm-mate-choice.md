# ADR-004: Mate choice by Random-k Pair Matching

- **Status**: Accepted (2026-09-07) — schema 2
- **Related**: ADR-003, ADR-005

## Context and problem

Distributed reproduction requires matching partners at **every** step, so the
algorithm must be cheap. It also has to span a range of mating systems from
unbiased random mating to strong reproductive skew, without a different
mechanism for each.

v0.1.0 offered four unrelated mate-selection branches (random, weighted capital,
competitive, assortative) with no common parameter, so the strength of mate
choice could not be varied continuously or compared across modes.

## Options considered

| Option | Assessment |
|---|---|
| Random pairing only | Fast but cannot express skew. |
| Brute-force best match | Quadratic; too slow per step. |
| Gumbel top-k / softmax over quality | Workable but invented here, with no literature standing. |
| **Random-k Pair Matching (RKPM)** | **Chosen**: published, linear, one parameter. |

## Decision

Matching uses RKPM (Geffen & Scholz 2017): shuffle the pool, then for each
chooser inspect `k` randomly drawn candidates and take the best. Linear in the
number of choosers.

`k` is the single choosiness parameter: the expected rank of the chosen partner
among `n` candidates is `n / (k + 1)`. `k = 1` is unbiased random mating; `k =
25` selects roughly from the top 4%.

Two documented departures from the published algorithm:

1. The original ranks candidates by a **distance** function, suited to
   assortative matching. Skew needs a **directional** criterion, so the
   criterion is configurable: `partner_quality` (maximise) or `similarity`
   (minimise difference). The latter subsumes v0.1.0's `assortative` mode.
2. The original scans `k` array-adjacent agents after shuffling; we draw `k`
   candidates directly. Equivalent in distribution, and removes any residual
   dependence on array position.

Quality is a weighted sum over four permitted, normalised state variables
(`repro_capital`, `status`, `health`, `energy`). The key set is fixed: the
configuration stays declarative and validated, and no user expression is ever
evaluated.

## Rationale and evidence

**Reshuffling every step is mandatory, not cosmetic.** The paper warns that a
fixed processing order lets agents near the front of the array accumulate
systematically better partners as matching repeats. Since UMEM now matches every
step rather than once per season, this bias would compound quickly.

**Choosers draw from the whole eligible complementary pool, not only from other
simultaneous initiators.** An early diagnostic counterfactual that required both
partners to initiate in the same step drove the population extinct in every
replicate. Both reproductive types may initiate, each at half the per-step
hazard, so expected events per agent per season still equals `lambda`.

**Mate quality must be weighted on a non-depletable trait to produce skew.**
This was discovered by test, not by design. With the originally specified
weights (reproductive capital dominant) competitive mating produced *no* skew:
Crow's opportunity for selection was 3.709 at `k = 1` and 3.672 at `k = 25`.
The cause is that reproductive capital is reset to zero when an agent breeds, so
"quality" effectively measures *time since last reproduction* — a negative
feedback that equalises reproductive success instead of concentrating it.
Weighting `status`, which breeding does not deplete, gives 3.709 → 4.963 for the
same contrast. The default weights were therefore changed to lead with status,
and the `competitive_skew` preset uses status alone. This is recorded because it
is a non-obvious property of the model, not of the algorithm.

## Consequences

- One parameter spans promiscuity to strong skew; the three mating modes share
  one engine.
- Verified by test: `k = 1` is unbiased (mean partner rank ≈ n/2); larger `k`
  monotonically raises the mean quality of chosen partners; no agent is matched
  twice within one step.
- Skew is measurable with Crow's opportunity for selection, which the analysis
  layer already computed, so the acceptance criterion needed no new code.

**Limitations.** Quality is a fixed linear combination and does not itself
evolve. Choice is unilateral: the chosen partner does not refuse. There is no
mating market, no search cost, and no partner fidelity outside `pair_bonded`.

## Future extension points

Mutual acceptance; heritable preference; search costs; quality functions
including heritable propensities.

## References

Geffen N, Scholz S (2017). Efficient and effective pair-matching algorithms for
agent-based models. *JASSS* 20(4):8. Reimplemented from the published
description; no code was copied.

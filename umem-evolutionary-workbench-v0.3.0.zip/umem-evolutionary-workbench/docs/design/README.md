# Architecture Decision Records (ADR)

Each file records one significant design decision: what problem it solved, what
alternatives were weighed, what was chosen, why, and what it costs.

## Why these exist

Code comments explain *what* a line does. These records explain *why the design
is the way it is*, which is the information needed years later by someone —
possibly the original author — who wants to change it. They also credit the
published work the design is based on, so that anyone extending a mechanism can
go to the source rather than reverse-engineering our implementation.

## Reading order for newcomers

1. **ADR-001** — how heritable propensities are represented
2. **ADR-002** — how they are inherited
3. **ADR-003** — when reproduction happens
4. **ADR-004** — how mates are chosen
5. **ADR-005** — the three mating modes
6. **ADR-006** — founder age structure
7. **ADR-007** — when results are recorded

## Format

Each ADR has: Context and problem / Options considered / Decision / Rationale
and evidence / Consequences / Future extension points / References.

## Adding a new one

Number sequentially, keep it to one or two pages, and state the alternatives you
rejected — that is usually the most useful part later. Cite published sources in
`docs/references.md` rather than duplicating full bibliographic entries.

A decision does not need an ADR if it is local and easily reversed. It needs one
if it changes scientific meaning, is expensive to reverse, encodes a
non-obvious trade-off, or is derived from published work.

## Status values

`Proposed` → `Accepted` → (later) `Superseded by ADR-0xx`. Superseded records
are kept, not deleted; the history is the point.

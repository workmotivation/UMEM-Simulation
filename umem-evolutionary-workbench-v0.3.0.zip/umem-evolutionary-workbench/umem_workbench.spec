# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller specification for the Windows desktop build.

Build with::

    pyinstaller umem_workbench.spec --clean --noconfirm

Notes
-----
This spec has been written against the documented PyInstaller API but has not
been executed in this repository's development environment, which is Linux and
headless. Verify the produced executable on a real Windows machine before
distributing it. See docs/packaging.md.
"""

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None
ROOT = Path(SPECPATH)

# Preset JSON files ship alongside the executable so the application works
# offline and out of the box.
datas = [
    (str(ROOT / "presets"), "presets"),
    (str(ROOT / "docs"), "docs"),
    (str(ROOT / "LICENSE"), "."),
    (str(ROOT / "THIRD_PARTY_NOTICES.md"), "."),
]
datas += collect_data_files("umem_workbench")

# SciPy, pandas and matplotlib load parts of themselves lazily, so their
# submodules must be collected explicitly or the frozen build fails at runtime
# with an import error that does not occur when running from source.
hiddenimports = []
hiddenimports += collect_submodules("scipy.special")
hiddenimports += collect_submodules("scipy.stats")
hiddenimports += collect_submodules("pandas._libs")
hiddenimports += ["openpyxl.cell._writer", "matplotlib.backends.backend_agg"]

# Excluded to keep the bundle small: Streamlit is a separate way of running the
# application and is not needed by the desktop build, and the test stack is
# never used at runtime.
excludes = [
    "streamlit", "pytest", "tkinter", "IPython", "jupyter",
    "matplotlib.backends.backend_qt5agg", "PyQt5", "PyQt6",
]

a = Analysis(
    ["desktop_app.py"],
    pathex=[str(ROOT / "src")],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="UMEM-Workbench",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,          # windowed application, no console
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,              # set to an .ico path when branding is available
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="UMEM-Workbench",
)

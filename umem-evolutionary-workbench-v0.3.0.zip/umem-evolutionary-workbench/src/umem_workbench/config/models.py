"""Typed, validated configuration schema for the UMEM workbench.

All scientific parameters live here as Pydantic v2 models. Each field carries
human-readable metadata (label, help text, unit, safe range) via
``json_schema_extra`` so that the UI parameter glossary and validation are
generated from a *single* source and cannot drift apart.

Design notes
------------
* State variables (energy, health, reproductive capital, status) use a
  normalised 0--100 scale by default. This is documented, not empirical.
* Heritable propensities are strictly positive. They are *functional*
  propensities, not literal DNA loci.
* Nothing in this schema stores or evaluates user-supplied code.
"""

from __future__ import annotations

from typing import Any

from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

from ..version import SCHEMA_VERSION
from .enums import (  # noqa: F401
    AgeHazardShape,
    CognitionMode,
    EffectCondition,
    EffectTarget,
    EffectType,
    EnvProcess,
    ExperimentMode,
    FertilityDistribution,
    FounderAgeDistribution,
    InheritanceModel,
    InitDistribution,
    MateChoiceCriterion,
    MateSelection,
    MatingMode,
    MutationLevel,
    MutationTarget,
    ReproductionMode,
    ReproductionTiming,
    SexRestriction,
    SiblingVariation,
    SuccessDefinition,
    TaskRole,
)


def ui(label: str, help: str, unit: str = "", ui_min: float | None = None,
       ui_max: float | None = None, *, interpretation: str = "",
       category: str = "", reference: str = "",
       added_in_schema: int = 1, applicability: str = "all",
       deprecated: str = "") -> dict[str, Any]:
    """Pack UI and data-dictionary metadata into a ``json_schema_extra`` dict.

    This is the single source of truth for parameter documentation: both
    interfaces build their controls from it and ``docs/parameter_reference.md``
    is generated from it, so a field cannot acquire a stale or missing label.

    Parameters
    ----------
    label : short human-readable field label.
    help : one-sentence explanation shown as a tooltip / glossary entry.
    unit : unit or normalised-scale note.
    ui_min, ui_max : recommended safe range for sliders (may be wider than
        the hard validation bounds).
    interpretation : what the parameter means scientifically, beyond what it
        does mechanically. Shown in the data dictionary, not on the control.
    category : unit-time classification, one of ``rate``, ``probability``,
        ``interval``, ``count``, ``threshold``, ``mode``, ``weight``,
        ``scale``. Distinguishing these matters when converting between
        per-season and per-step parameterisations; see ADR-003.
    reference : design record and literature this field derives from, e.g.
        ``"ADR-002; Barton et al. 2017"``.
    added_in_schema : configuration schema version that introduced the field.
    applicability : which mechanism configuration the field is active under:
        ``all``, ``distributed_only``, ``legacy_timing_only``,
        ``sexual_only``, ``asexual_only``, ``pair_bond_only``,
        ``competitive_only``, ``polygenic_only``, ``legacy_inheritance_only``.
        Interfaces disable inactive fields and the data dictionary reports it,
        so an ignored legacy field cannot be mistaken for an active one.
    deprecated : non-empty when the field is retained only for compatibility;
        the text names the replacement.
    """

    return {
        "ui": {
            "label": label,
            "help": help,
            "unit": unit,
            "ui_min": ui_min,
            "ui_max": ui_max,
            "interpretation": interpretation,
            "category": category,
            "reference": reference,
            "added_in_schema": added_in_schema,
            "applicability": applicability,
            "deprecated": deprecated,
        }
    }


class _Base(BaseModel):
    """Shared base: forbid unknown keys so typos surface immediately."""

    model_config = ConfigDict(extra="forbid", validate_assignment=True)


# ---------------------------------------------------------------------------
# Tasks and effect rules
# ---------------------------------------------------------------------------
class TaskEffectRule(_Base):
    """One multidimensional effect of a task on a state variable.

    A task may carry several rules, letting a single action trade off multiple
    outcomes (e.g. risky foraging: +energy on success, x hazard always).
    """

    target: EffectTarget = Field(
        ..., json_schema_extra=ui("Target", "State variable this rule changes."))
    effect_type: EffectType = Field(
        EffectType.ADDITIVE,
        json_schema_extra=ui("Effect type", "How the value combines with state."))
    base_value: float = Field(
        0.0, json_schema_extra=ui("Base value", "Magnitude before env scaling.",
                                  "state units", -100, 100))
    condition: EffectCondition = Field(
        EffectCondition.ON_SUCCESS,
        json_schema_extra=ui("Condition", "Fires on success, failure, or always."))
    env_driver: str | None = Field(
        None, json_schema_extra=ui("Environment driver",
                                   "Env variable id that scales this effect."))
    env_sensitivity: float = Field(
        0.0, json_schema_extra=ui("Env sensitivity",
                                  "Coupling of the effect to the env driver.",
                                  "", -5, 5))
    noise_std: float = Field(
        0.0, ge=0.0, json_schema_extra=ui("Noise sd", "Gaussian noise on the effect.",
                                          "state units", 0, 10))
    min_age_steps: int = Field(
        0, ge=0, json_schema_extra=ui("Min age (steps)", "Rule inactive below this age."))
    require_mature: bool = Field(
        False, json_schema_extra=ui("Require mature", "Rule only for mature agents."))
    sex_restriction: SexRestriction = Field(
        SexRestriction.ANY,
        json_schema_extra=ui("Type restriction", "Reproductive type this rule needs."))

    @model_validator(mode="after")
    def _check_env(self) -> TaskEffectRule:
        if self.env_sensitivity != 0.0 and not self.env_driver:
            raise ValueError(
                "env_sensitivity is nonzero but no env_driver is set")
        return self


class TaskConfig(_Base):
    """A configurable behavioural task (never hard-coded in the engine)."""

    task_id: str = Field(
        ..., min_length=1,
        json_schema_extra=ui("Task id", "Immutable unique key."))
    name: str = Field(..., min_length=1,
                      json_schema_extra=ui("Name", "Display name."))
    description: str = Field("", json_schema_extra=ui("Description", "Free text."))
    domain: str = Field(..., min_length=1,
                        json_schema_extra=ui("Domain", "Behavioural domain id."))
    enabled: bool = Field(True, json_schema_extra=ui("Enabled", "Include in runs."))

    time_cost: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Time cost", "Time steps consumed.",
                                          "steps", 0, 5))
    energy_cost: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Energy cost", "Direct energy spent.",
                                          "energy", 0, 20))
    base_success: float = Field(
        0.2, ge=0.0, le=1.0,
        json_schema_extra=ui("Base success", "Baseline success probability.",
                             "prob", 0, 1))
    success_env_driver: str | None = Field(
        None, json_schema_extra=ui("Success driver",
                                   "Env variable modulating success."))
    success_env_sensitivity: float = Field(
        0.0, json_schema_extra=ui("Success sensitivity",
                                  "Logit shift per unit env driver.", "", -8, 8))
    outcome_noise: float = Field(
        0.3, ge=0.0, json_schema_extra=ui("Outcome noise", "Logit noise sd on success.",
                                          "", 0, 3))

    predation_multiplier: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Predation x", "Per-step hazard multiplier.",
                                          "", 0, 3))

    min_age_steps: int = Field(0, ge=0,
                               json_schema_extra=ui("Min age (steps)", "Age gate."))
    max_age_steps: int | None = Field(
        None, json_schema_extra=ui("Max age (steps)", "Upper age gate (optional)."))
    require_mature: bool = Field(
        False, json_schema_extra=ui("Require mature", "Maturity gate."))
    sex_restriction: SexRestriction = Field(
        SexRestriction.ANY,
        json_schema_extra=ui("Type restriction", "Reproductive-type gate."))

    observable_to_actor: bool = Field(
        True, json_schema_extra=ui("Observable", "Actor sees its own outcome."))
    public_signal: bool = Field(
        False, json_schema_extra=ui("Public signal",
                                    "Non-actors see a weak public signal."))

    role: TaskRole = Field(
        TaskRole.FUNCTIONAL,
        json_schema_extra=ui("Role", "functional / neutral / costly nonfunctional."))
    memory_eligible: bool = Field(
        True, json_schema_extra=ui("Memory eligible",
                                   "May enter intergenerational memory."))

    effects: list[TaskEffectRule] = Field(
        default_factory=list,
        json_schema_extra=ui("Effect rules", "Multidimensional effects."))

    @field_validator("effects")
    @classmethod
    def _driver_names(cls, v: list[TaskEffectRule]) -> list[TaskEffectRule]:
        return v

    def has_direct_benefit(self) -> bool:
        """True if any rule confers a positive benefit on a beneficial target.

        Used by the validation layer to detect mislabelled 'neutral' tasks.
        Hazard reduction (predation_multiplier < 1) also counts as a benefit.
        """

        beneficial = {
            EffectTarget.ENERGY, EffectTarget.HEALTH,
            EffectTarget.REPRO_CAPITAL, EffectTarget.STATUS,
            EffectTarget.OBSERVATION_QUALITY,
        }
        for r in self.effects:
            if r.target in beneficial and r.base_value > 0:
                return True
            if r.target == EffectTarget.HAZARD and r.base_value < 0:
                return True
        if self.predation_multiplier < 1.0:
            return True
        return False


# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------
class EnvVariableConfig(_Base):
    """A single bounded environmental variable with a stochastic process."""

    var_id: str = Field(..., min_length=1,
                        json_schema_extra=ui("Variable id", "Immutable unique key."))
    name: str = Field(..., min_length=1, json_schema_extra=ui("Name", "Display name."))
    description: str = Field("", json_schema_extra=ui("Description", "Free text."))
    process: EnvProcess = Field(
        EnvProcess.AR1, json_schema_extra=ui("Process", "Stochastic process type."))

    initial_value: float = Field(
        0.5, json_schema_extra=ui("Initial value", "Value at t=0.", "norm 0-1", 0, 1))
    mean: float = Field(
        0.5, json_schema_extra=ui("Long-run mean", "Reversion target.", "norm 0-1", 0, 1))
    min_value: float = Field(
        0.0, json_schema_extra=ui("Min", "Lower bound.", "norm", 0, 1))
    max_value: float = Field(
        1.0, json_schema_extra=ui("Max", "Upper bound.", "norm", 0, 1))
    persistence: float = Field(
        0.9, ge=0.0, le=1.0,
        json_schema_extra=ui("Persistence", "AR(1) autocorrelation.", "", 0, 1))
    volatility: float = Field(
        0.05, ge=0.0, json_schema_extra=ui("Volatility", "Innovation sd.", "", 0, 1))

    seasonal_amplitude: float = Field(
        0.0, ge=0.0, json_schema_extra=ui("Seasonal amp", "Seasonal amplitude.", "", 0, 1))
    seasonal_period_steps: int = Field(
        40, ge=1, json_schema_extra=ui("Seasonal period", "Steps per cycle.", "steps"))

    shock_probability: float = Field(
        0.0, ge=0.0, le=1.0,
        json_schema_extra=ui("Shock prob", "Per-step shock probability.", "prob", 0, 1))
    shock_magnitude: float = Field(
        0.0, json_schema_extra=ui("Shock size", "Additive shock magnitude.", "", -1, 1))
    shock_duration_steps: int = Field(
        1, ge=1, json_schema_extra=ui("Shock duration", "Steps a shock persists.", "steps"))

    regime_values: list[float] = Field(
        default_factory=list,
        json_schema_extra=ui("Regime values", "Values for regime switching."))
    regime_switch_prob: float = Field(
        0.02, ge=0.0, le=1.0,
        json_schema_extra=ui("Regime switch prob", "Per-step switch probability.", "prob"))

    imported_series: list[float] = Field(
        default_factory=list,
        json_schema_extra=ui("Imported series", "User time series (process=imported)."))

    observation_noise: float = Field(
        0.05, ge=0.0,
        json_schema_extra=ui("Obs noise", "Noise sd on agent observations.", "", 0, 1))
    globally_observable: bool = Field(
        True, json_schema_extra=ui("Globally observable", "Directly observed by agents."))

    @model_validator(mode="after")
    def _check_bounds(self) -> EnvVariableConfig:
        if self.min_value >= self.max_value:
            raise ValueError(
                f"env '{self.var_id}': min_value must be < max_value")
        if not (self.min_value <= self.initial_value <= self.max_value):
            raise ValueError(
                f"env '{self.var_id}': initial_value outside [min,max]")
        if self.process == EnvProcess.IMPORTED and not self.imported_series:
            raise ValueError(
                f"env '{self.var_id}': process=imported requires imported_series")
        if self.process == EnvProcess.REGIME_SWITCHING and len(self.regime_values) < 2:
            raise ValueError(
                f"env '{self.var_id}': regime switching needs >= 2 regime_values")
        return self


# ---------------------------------------------------------------------------
# Population, lifecycle, mortality
# ---------------------------------------------------------------------------
class DomainConfig(_Base):
    """A behavioural domain over which agents hold an inherited propensity."""

    domain_id: str = Field(..., min_length=1,
                          json_schema_extra=ui("Domain id", "Immutable key."))
    name: str = Field(..., min_length=1, json_schema_extra=ui("Name", "Display name."))
    init_mean: float = Field(
        1.0, gt=0.0, json_schema_extra=ui("Init mean", "Mean initial propensity.",
                                          "", 0.1, 5))
    init_var: float = Field(
        0.5, ge=0.0, json_schema_extra=ui("Init variance", "Initial variance.", "", 0, 5))


class PopulationConfig(_Base):
    founder_age_distribution: FounderAgeDistribution = Field(
        FounderAgeDistribution.UNIFORM,
        json_schema_extra=ui(
            "Founder ages", "Age structure of the initial population.",
            category="mode",
            interpretation="'all_newborn_legacy' starts every founder at age "
                           "zero (v0.1.0). 'uniform' spreads ages evenly over "
                           "the permitted lifespan. 'stable' approximates the "
                           "stable age distribution implied by the configured "
                           "baseline hazards. Founder synchrony is an early "
                           "transient, not the cause of persistent population "
                           "sawtoothing.",
            reference="ADR-006", added_in_schema=2))
    initial_population: int = Field(
        200, ge=2, json_schema_extra=ui("Initial population", "Starting agents.", "agents"))
    carrying_capacity: int = Field(
        500, ge=1, json_schema_extra=ui("Carrying capacity", "Soft population ceiling.",
                                        "agents"))
    max_population: int = Field(
        5000, ge=1, json_schema_extra=ui("Max population", "Hard cap for memory safety.",
                                         "agents"))
    init_distribution: InitDistribution = Field(
        InitDistribution.GAMMA,
        json_schema_extra=ui("Init distribution", "Propensity init distribution."))
    sex_ratio_type_a: float = Field(
        0.5, ge=0.0, le=1.0,
        json_schema_extra=ui("Type-A fraction", "Fraction born as reproductive type A.",
                             "frac", 0, 1))
    starting_population_file: str | None = Field(
        None, json_schema_extra=ui("Start pop file", "Path for from_file init."))

    @model_validator(mode="after")
    def _cap_order(self) -> PopulationConfig:
        if self.carrying_capacity > self.max_population:
            raise ValueError("carrying_capacity must be <= max_population")
        return self


class LifecycleConfig(_Base):
    steps_per_season: int = Field(
        40, ge=1, json_schema_extra=ui("Steps per season", "Time steps in a season.",
                                       "steps"))
    total_seasons: int = Field(
        30, ge=1, json_schema_extra=ui("Total seasons", "Seasons to simulate.", "seasons"))
    actions_per_step: int = Field(
        1, ge=1, json_schema_extra=ui("Actions per step", "Tasks drawn per step."))

    initial_energy: float = Field(
        70.0, ge=0.0, json_schema_extra=ui("Initial energy", "Newborn energy.",
                                           "0-100", 0, 100))
    energy_max: float = Field(
        100.0, gt=0.0, json_schema_extra=ui("Energy max", "Energy ceiling.", "0-100"))
    initial_health: float = Field(
        90.0, ge=0.0, json_schema_extra=ui("Initial health", "Newborn health.",
                                           "0-100", 0, 100))
    health_max: float = Field(
        100.0, gt=0.0, json_schema_extra=ui("Health max", "Health ceiling.", "0-100"))
    initial_repro_capital: float = Field(
        0.0, ge=0.0, json_schema_extra=ui("Initial repro capital",
                                          "Newborn reproductive capital.", "0-100"))
    repro_capital_max: float = Field(
        100.0, gt=0.0, json_schema_extra=ui("Repro capital max", "Ceiling.", "0-100"))
    initial_status: float = Field(
        50.0, ge=0.0, json_schema_extra=ui("Initial status", "Newborn status.", "0-100"))
    status_max: float = Field(
        100.0, gt=0.0, json_schema_extra=ui("Status max", "Ceiling.", "0-100"))

    basal_metabolism: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Basal metabolism", "Energy lost per step.",
                                          "energy/step", 0, 5))
    rest_energy_cost: float = Field(
        0.5, ge=0.0, json_schema_extra=ui("Rest cost", "Energy for fallback rest.",
                                          "energy", 0, 5))
    health_starvation_penalty: float = Field(
        10.0, ge=0.0, json_schema_extra=ui("Starvation penalty",
                                           "Health lost per step at zero energy.",
                                           "health/step", 0, 50))

    maturity_seasons: int = Field(
        2, ge=0, json_schema_extra=ui("Maturity (seasons)", "Age of reproductive maturity.",
                                      "seasons"))
    max_lifespan_seasons: int = Field(
        12, ge=1, json_schema_extra=ui("Max lifespan", "Hard lifespan ceiling.", "seasons"))
    newborns_act_next_step: bool = Field(
        True, json_schema_extra=ui("Newborns wait",
                                   "Newborns act from the next step, not immediately."))

    @model_validator(mode="after")
    def _life_order(self) -> LifecycleConfig:
        if self.maturity_seasons > self.max_lifespan_seasons:
            raise ValueError("maturity_seasons must be <= max_lifespan_seasons")
        return self


class MortalityConfig(_Base):
    base_predation_hazard: float = Field(
        0.02, ge=0.0, le=1.0,
        json_schema_extra=ui("Base predation", "Per-step baseline predation hazard.",
                             "prob", 0, 0.5))
    predation_env_driver: str | None = Field(
        "predator", json_schema_extra=ui("Predation driver",
                                         "Env variable scaling predation."))
    predation_env_sensitivity: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Predation sensitivity",
                                          "Scaling of hazard by driver.", "", 0, 5))

    age_hazard_shape: AgeHazardShape = Field(
        AgeHazardShape.GOMPERTZ,
        json_schema_extra=ui("Age hazard shape", "Gompertz or logistic senescence."))
    age_hazard_scale: float = Field(
        0.002, ge=0.0, json_schema_extra=ui("Age hazard scale", "Baseline age hazard.",
                                            "", 0, 0.1))
    age_hazard_rate: float = Field(
        0.15, ge=0.0, json_schema_extra=ui("Age hazard rate",
                                           "Growth of hazard with age (per season).",
                                           "", 0, 2))

    background_hazard: float = Field(
        0.0, ge=0.0, le=1.0,
        json_schema_extra=ui("Background hazard", "Constant per-step mortality.", "prob"))
    juvenile_extra_hazard: float = Field(
        0.0, ge=0.0, le=1.0,
        json_schema_extra=ui("Juvenile hazard", "Extra per-step hazard before maturity.",
                             "prob"))
    density_hazard_strength: float = Field(
        0.5, ge=0.0, json_schema_extra=ui("Density hazard",
                                          "Extra hazard as pop approaches K.", "", 0, 5))
    density_onset_fraction: float = Field(
        0.6, ge=0.0, json_schema_extra=ui(
            "Density onset", "Fraction of carrying capacity at which crowding "
            "mortality begins. Below this the density hazard is zero.",
            "", 0, 2))
    density_affects_juveniles_only: bool = Field(
        True, json_schema_extra=ui("Density juveniles only",
                                   "Apply density hazard only to juveniles."))


# ---------------------------------------------------------------------------
# Reproduction, inheritance
# ---------------------------------------------------------------------------
class ReproductionConfig(_Base):
    mode: ReproductionMode = Field(
        ReproductionMode.SEXUAL,
        json_schema_extra=ui("Mode", "Sexual or asexual reproduction.",
                             category="mode",
                             interpretation="Sexual requires one Type-A and one "
                                            "Type-B agent per event; asexual "
                                            "requires none."))

    # --- timing (schema 2; ADR-003) ---
    timing: ReproductionTiming = Field(
        ReproductionTiming.DISTRIBUTED,
        json_schema_extra=ui(
            "Reproduction timing",
            "Continuous (recommended) or legacy season-end batching.",
            category="mode",
            interpretation="Under 'distributed' every time step is an "
                           "opportunity to reproduce, as in a non-Wright-Fisher "
                           "model, and season boundaries carry no reproductive "
                           "meaning. 'season_end_legacy' reproduces the v0.1.0 "
                           "behaviour in which all eligible agents breed "
                           "together on the last step of a season; it is a "
                           "compatibility mode and produces a season-period "
                           "sawtooth in population size.",
            reference="ADR-003; Haller & Messer 2019 (SLiM 3)",
            added_in_schema=2))
    reproductive_event_rate: float = Field(
        1.0, ge=0.0,
        validation_alias=AliasChoices("reproductive_event_rate",
                                      "expected_births_per_season"),
        json_schema_extra=ui(
            "Reproductive event rate",
            "Reproductive *attempt events* per eligible agent per season.",
            "events/agent/season", 0, 12,
            category="rate",
            interpretation="An event rate, not a birth count. Births per event "
                           "= this rate x P(partner found) x fertility per event "
                           "x juvenile survival, so realised births are lower. "
                           "Converted to a per-step hazard by "
                           "1 - exp(-rate / steps_per_season), so expected "
                           "events per season do not change with time "
                           "resolution; geometric waiting times desynchronise "
                           "reproduction. The former name "
                           "'expected_births_per_season' is accepted on input "
                           "and was misleading.",
            reference="ADR-003", added_in_schema=2,
            applicability="distributed_only"))
    refractory_seasons: float = Field(
        0.0, ge=0.0,
        json_schema_extra=ui(
            "Refractory period", "Minimum time before breeding again after success.",
            "seasons", 0, 5,
            category="interval",
            interpretation="Starts only after a *successful* reproductive "
                           "event; failed attempts do not trigger it and cost "
                           "nothing. Stored internally in steps.",
            reference="ADR-003", added_in_schema=2))

    # --- mate choice (schema 2; ADR-004, ADR-005) ---
    mating_mode: MatingMode = Field(
        MatingMode.RANDOM,
        json_schema_extra=ui(
            "Mating mode", "Random mixing, pair bonding, or competitive.",
            category="mode",
            interpretation="Random = promiscuity (no bonds, no preference); "
                           "pair_bonded = social monogamy (exclusive, "
                           "persistent); competitive = polygyny-like skew "
                           "(choosy, non-exclusive). All three run through the "
                           "same matching engine and differ only in "
                           "persistence, exclusivity and choosiness.",
            reference="ADR-005; quantiNemo (Neuenschwander et al. 2008)",
            added_in_schema=2, applicability="sexual_only"))
    mate_choice_k: int = Field(
        1, ge=1,
        json_schema_extra=ui(
            "Choosiness (k)", "Number of candidates inspected per choice.",
            "candidates", 1, 100,
            category="count",
            interpretation="Random-k pair matching: the chooser inspects k "
                           "randomly drawn candidates and takes the best. k=1 "
                           "is unbiased random mating; the expected rank of the "
                           "chosen partner is n/(k+1), so larger k concentrates "
                           "reproductive success and raises the opportunity for "
                           "selection.",
            reference="ADR-004; Geffen & Scholz 2017", added_in_schema=2,
            applicability="sexual_only"))
    mate_choice_criterion: MateChoiceCriterion = Field(
        MateChoiceCriterion.PARTNER_QUALITY,
        json_schema_extra=ui(
            "Choice criterion", "Maximise partner quality, or match similarity.",
            category="mode",
            interpretation="Partner quality produces reproductive skew; "
                           "similarity produces assortative mating.",
            reference="ADR-004", added_in_schema=2,
            applicability="sexual_only"))
    mate_quality_weights: dict[str, float] = Field(
        default_factory=lambda: {"status": 1.0, "repro_capital": 0.3,
                                 "health": 0.25, "energy": 0.25},
        json_schema_extra=ui(
            "Quality weights", "Weights over agent state defining mate quality.",
            category="weight",
            interpretation="A declarative weighted sum over normalised state "
                           "variables. Only these four keys are permitted; no "
                           "user expression is ever evaluated. Weight "
                           "non-depletable traits such as status to obtain "
                           "reproductive skew: reproductive capital is reset "
                           "when an agent breeds, so choosing on it makes "
                           "'quality' amount to 'time since last breeding', "
                           "which equalises rather than concentrates "
                           "reproductive success.",
            reference="ADR-004", added_in_schema=2,
            applicability="sexual_only"))

    # --- pair bonds (pair_bonded mode only) ---
    bond_formation_per_season: float = Field(
        2.0, ge=0.0,
        json_schema_extra=ui(
            "Bond formation rate", "Rate at which unpaired mature agents form bonds.",
            "events/agent/season", 0, 10,
            category="rate",
            interpretation="Bond formation requires maturity only. Energy, "
                           "health and capital thresholds govern whether a bond "
                           "can reproduce, not whether it can form.",
            reference="ADR-005", added_in_schema=2,
            applicability="pair_bond_only"))
    bond_dissolution_per_season: float = Field(
        0.0, ge=0.0,
        json_schema_extra=ui(
            "Bond dissolution rate", "Rate at which existing bonds dissolve.",
            "events/pair/season", 0, 5,
            category="rate",
            interpretation="Zero by default, so bonds end only at the death of "
                           "a partner. A conservative non-zero value models "
                           "serial monogamy.",
            reference="ADR-005", added_in_schema=2,
            applicability="pair_bond_only"))
    breeding_every_seasons: int = Field(
        1, ge=1, json_schema_extra=ui(
            "Breeding interval (legacy timing only)",
            "Seasons between breeding events under season-end timing.",
            "seasons", category="interval",
            interpretation="Active only when timing is season_end_legacy. "
                           "Distributed timing uses refractory_seasons instead; "
                           "this field is then ignored.",
            applicability="legacy_timing_only",
            deprecated="Use reproduction.refractory_seasons with distributed "
                       "timing."))
    energy_threshold: float = Field(
        40.0, ge=0.0, json_schema_extra=ui("Energy threshold",
                                           "Min energy to breed.", "0-100", 0, 100))
    health_threshold: float = Field(
        30.0, ge=0.0, json_schema_extra=ui("Health threshold",
                                           "Min health to breed.", "0-100", 0, 100))
    repro_capital_threshold: float = Field(
        0.0, ge=0.0, json_schema_extra=ui("Capital threshold",
                                          "Min reproductive capital to breed.", "0-100"))

    mate_selection: MateSelection = Field(
        MateSelection.WEIGHTED_CAPITAL,
        json_schema_extra=ui("Mate selection", "How mates are chosen."))
    mate_availability_driver: str | None = Field(
        "mate", json_schema_extra=ui("Mate driver", "Env variable for mate availability."))
    max_offspring_per_event: int = Field(
        3, ge=1, json_schema_extra=ui("Max offspring/event", "Cap per breeding event."))

    fertility_distribution: FertilityDistribution = Field(
        FertilityDistribution.POISSON,
        json_schema_extra=ui("Fertility dist", "Distribution of surviving offspring."))
    fertility_mean: float = Field(
        1.5, ge=0.0, json_schema_extra=ui("Fertility mean",
                                          "Mean surviving offspring per event.",
                                          "offspring", 0, 8))
    fertility_binomial_p: float = Field(
        0.5, ge=0.0, le=1.0,
        json_schema_extra=ui("Binomial p", "Success prob for binomial fertility.", "prob"))
    fertility_discrete_pmf: list[float] = Field(
        default_factory=list,
        json_schema_extra=ui("Discrete pmf", "Probabilities for 0,1,2,... offspring."))

    repro_energy_cost: float = Field(
        20.0, ge=0.0, json_schema_extra=ui("Repro energy cost",
                                           "Energy spent per breeding.", "energy", 0, 100))
    repro_health_cost: float = Field(
        5.0, ge=0.0, json_schema_extra=ui("Repro health cost",
                                          "Health spent per breeding.", "health", 0, 100))
    gestation_delay_steps: int = Field(
        0, ge=0, json_schema_extra=ui(
            "Gestation delay (legacy timing only)",
            "Steps before offspring appear under season-end timing.",
            "steps", category="interval",
            interpretation="The continuous (distributed) model has no gestation "
                           "mechanism: a non-zero value is a blocking validation "
                           "error under distributed timing, never silently "
                           "ignored. Retained for reproducing season-end legacy "
                           "scenarios only.",
            applicability="legacy_timing_only",
            deprecated="No gestation model exists under distributed timing."))
    juvenile_survival: float = Field(
        0.85, ge=0.0, le=1.0,
        json_schema_extra=ui("Juvenile survival", "Prob a newborn survives to enter pop.",
                             "prob", 0, 1))
    density_dependent_recruitment: bool = Field(
        True, json_schema_extra=ui("Density recruitment",
                                   "Soft Beverton-Holt decline of juvenile survival "
                                   "as population approaches carrying capacity."))
    recruitment_strength: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Recruitment strength",
                                          "Steepness of density-dependent recruitment.",
                                          "", 0, 5))

    @model_validator(mode="after")
    def _fert_checks(self) -> ReproductionConfig:
        if self.fertility_distribution == FertilityDistribution.DISCRETE:
            pmf = self.fertility_discrete_pmf
            if not pmf or abs(sum(pmf) - 1.0) > 1e-6:
                raise ValueError("discrete fertility pmf must sum to 1.0")
        return self


class InheritanceConfig(_Base):
    """How offspring heritable propensities derive from their parents.

    Two models. ``polygenic_additive`` implements Fisher's infinitesimal model
    on the centred latent scale (ADR-001, ADR-002) and separates ordinary
    segregation from rare mutation. ``legacy`` preserves the v0.1.0 mechanism so
    that pre-schema-2 scenarios keep their original meaning.
    """

    model: InheritanceModel = Field(
        InheritanceModel.POLYGENIC_ADDITIVE,
        json_schema_extra=ui(
            "Inheritance model",
            "Polygenic additive (recommended) or the legacy v0.1.0 mechanism.",
            category="mode",
            interpretation="Polygenic additive treats propensities as latent "
                           "quantitative traits inherited by Fisher's "
                           "infinitesimal model, the standard approximation to "
                           "many small-effect Mendelian loci. Legacy is a "
                           "compatibility mode for scenarios written before "
                           "schema 2.",
            reference="ADR-002; Barton, Etheridge & Veber 2017",
            added_in_schema=2))

    # --- segregation (polygenic model only) ---
    sibling_variation: SiblingVariation = Field(
        SiblingVariation.STANDARD,
        json_schema_extra=ui(
            "Sibling variation",
            "How much full siblings differ through segregation.",
            category="mode",
            interpretation="Scales the Mendelian segregation variance. At "
                           "'standard' the configured founder variance is the "
                           "equilibrium, so genetic variation neither inflates "
                           "nor decays as an artifact.",
            reference="ADR-002",
            added_in_schema=2, applicability="polygenic_only"))
    segregation_multiplier: float = Field(
        1.0, ge=0.0,
        json_schema_extra=ui(
            "Segregation multiplier", "Used when sibling variation is custom.",
            "x V0/2", 0, 3,
            category="scale",
            interpretation="Segregation variance is multiplier x V0 / 2, where "
                           "V0 is the configured founder additive variance. "
                           "The 0.5 factor is the Mendelian sampling variance "
                           "of an outbred individual.",
            reference="ADR-002; Lynch & Walsh 1998 ch.7",
            added_in_schema=2, applicability="polygenic_only"))

    # --- mutation (polygenic model only) ---
    mutation_level: MutationLevel = Field(
        MutationLevel.CONSERVATIVE,
        json_schema_extra=ui(
            "Mutation level",
            "None, conservative, accelerated, or custom.",
            category="mode",
            interpretation="Rare introduction of novel variation, configured "
                           "and reported separately from segregation. These are "
                           "effective simulation parameters, not empirical "
                           "per-base mutation rates.",
            reference="ADR-002",
            added_in_schema=2, applicability="polygenic_only"))
    mutation_probability_per_offspring: float = Field(
        0.01, ge=0.0, le=1.0,
        json_schema_extra=ui(
            "Mutation probability", "Chance of an effective mutation per offspring.",
            "prob/offspring", 0, 0.2,
            category="probability",
            interpretation="Probability that an offspring experiences one "
                           "effective mutation event in a given propensity layer.",
            reference="ADR-002", added_in_schema=2,
            applicability="polygenic_only"))
    mutation_effect_sd_latent: float = Field(
        0.10, ge=0.0,
        json_schema_extra=ui(
            "Mutation effect size", "Zero-mean effect sd, absolute latent units.",
            "latent sd", 0, 1.0,
            category="scale",
            interpretation="Standard deviation of the mutation increment on the "
                           "latent log-ratio scale; 0.10 is roughly a 10% change "
                           "in relative odds. Absolute units are used so that a "
                           "scenario with zero founder variance still mutates.",
            reference="ADR-002", added_in_schema=2,
            applicability="polygenic_only"))
    mutation_target: MutationTarget = Field(
        MutationTarget.BOTH,
        json_schema_extra=ui(
            "Mutation target", "Which propensity layer mutation may strike.",
            category="mode",
            interpretation="Domain, task, or both. Layers are judged "
                           "independently when set to both.",
            reference="ADR-002", added_in_schema=2,
            applicability="polygenic_only"))

    # --- legacy model fields (ignored by the polygenic model) ---
    mutation_probability: float = Field(
        1.0, ge=0.0, le=1.0,
        json_schema_extra=ui("Mutation prob (legacy)", "Prob a trait mutates.",
                             "prob", 0, 1, category="probability",
                             interpretation="Legacy inheritance model only; "
                                            "ignored under polygenic_additive.",
                             reference="v0.1.0",
                             applicability="legacy_inheritance_only",
                             deprecated="Polygenic model uses mutation_level, "
                                        "mutation_probability_per_offspring, "
                                        "mutation_effect_sd_latent."))
    mutation_log_sd: float = Field(
        0.1, ge=0.0,
        json_schema_extra=ui("Mutation strength (legacy)",
                             "Log-normal mutation sd (multiplicative).",
                             "", 0, 1, category="scale",
                             interpretation="Legacy inheritance model only; "
                                            "ignored under polygenic_additive.",
                             reference="v0.1.0",
                             applicability="legacy_inheritance_only",
                             deprecated="Polygenic model uses mutation_level, "
                                        "mutation_probability_per_offspring, "
                                        "mutation_effect_sd_latent."))
    recombination_per_trait: bool = Field(
        True,
        json_schema_extra=ui("Per-trait recombination (legacy)",
                             "Pick each trait from one parent vs. blend.",
                             category="mode",
                             interpretation="Legacy inheritance model only; "
                                            "ignored under polygenic_additive.",
                             reference="v0.1.0",
                             applicability="legacy_inheritance_only",
                             deprecated="Polygenic model uses mutation_level, "
                                        "mutation_probability_per_offspring, "
                                        "mutation_effect_sd_latent."))
    blend_alpha: float = Field(
        0.5, ge=0.0, le=1.0,
        json_schema_extra=ui("Blend weight (legacy)", "Parent-A weight when blending.",
                             "", 0, 1, category="weight",
                             interpretation="Legacy inheritance model only; "
                                            "ignored under polygenic_additive.",
                             reference="v0.1.0",
                             applicability="legacy_inheritance_only",
                             deprecated="Polygenic model uses mutation_level, "
                                        "mutation_probability_per_offspring, "
                                        "mutation_effect_sd_latent."))

    # --- shared ---
    min_propensity: float = Field(
        0.01, gt=0.0,
        json_schema_extra=ui(
            "Min propensity", "Floor keeping traits positive.",
            category="threshold",
            interpretation="Legacy floor, and the floor that keeps the "
                           "legacy-to-latent log conversion finite.",
            reference="ADR-001"))

    @model_validator(mode="after")
    def _apply_presets(self):
        """Expand the named sibling-variation and mutation presets.

        Presets write through to the explicit numeric fields so that the
        effective values are always visible in Advanced mode, in exports, and in
        the configuration hash. Custom leaves the numbers untouched.
        """

        preset_seg = {SiblingVariation.LOW: 0.5,
                      SiblingVariation.STANDARD: 1.0,
                      SiblingVariation.HIGH: 1.5}
        if self.sibling_variation in preset_seg:
            object.__setattr__(self, "segregation_multiplier",
                               preset_seg[self.sibling_variation])

        preset_mut = {MutationLevel.NONE: (0.0, 0.0),
                      MutationLevel.CONSERVATIVE: (0.01, 0.10),
                      MutationLevel.ACCELERATED: (0.05, 0.20)}
        if self.mutation_level in preset_mut:
            prob, sd = preset_mut[self.mutation_level]
            object.__setattr__(self, "mutation_probability_per_offspring", prob)
            object.__setattr__(self, "mutation_effect_sd_latent", sd)
        return self


# ---------------------------------------------------------------------------
# Homeostasis and cognition
# ---------------------------------------------------------------------------
class HomeostasisConfig(_Base):
    enabled: bool = Field(True, json_schema_extra=ui("Enabled", "Master switch."))
    hunger_enabled: bool = Field(True, json_schema_extra=ui("Hunger", "Energy urgency on."))
    hunger_strength: float = Field(
        2.0, ge=0.0, json_schema_extra=ui("Hunger strength",
                                          "Logit boost to food tasks when hungry.",
                                          "", 0, 5))
    safety_enabled: bool = Field(True, json_schema_extra=ui("Safety", "Threat urgency on."))
    safety_strength: float = Field(
        2.0, ge=0.0, json_schema_extra=ui("Safety strength",
                                          "Logit boost to safety tasks under threat.",
                                          "", 0, 5))
    reproduction_enabled: bool = Field(
        True, json_schema_extra=ui("Reproduction", "Reproductive urgency on."))
    reproduction_strength: float = Field(
        2.0, ge=0.0, json_schema_extra=ui("Reproduction strength",
                                          "Logit boost to reproduction when ready.",
                                          "", 0, 5))


class CognitionConfig(_Base):
    # Internal cognition A: intergenerational experience
    experience_enabled: bool = Field(
        False, json_schema_extra=ui("Experience (A)", "Intergenerational memory on."))
    experience_success_definition: SuccessDefinition = Field(
        SuccessDefinition.SURVIVING_OFFSPRING,
        json_schema_extra=ui("Success definition", "Who counts as successful."))
    experience_top_quantile: float = Field(
        0.2, gt=0.0, le=1.0,
        json_schema_extra=ui("Top quantile", "Quantile for top-LRS definition.", "", 0, 1))
    experience_weight_recent: float = Field(
        0.7, ge=0.0, le=1.0,
        json_schema_extra=ui("Recent weight", "Weight on the most recent cohort.", "", 0, 1))
    experience_smoothing: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Smoothing", "Additive smoothing on counts."))
    experience_noise_sd: float = Field(
        0.3, ge=0.0, json_schema_extra=ui("Experience noise", "Noise on the memory signal.",
                                          "", 0, 3))
    experience_strength: float = Field(
        2.5, ge=0.0, json_schema_extra=ui("Experience strength",
                                          "Logit multiplier from memory.", "", 0, 8))

    # Internal cognition B: noisy environmental forecasting
    forecast_enabled: bool = Field(
        False, json_schema_extra=ui("Forecast (B)", "Noisy env forecasting on."))
    forecast_memory: float = Field(
        0.6, ge=0.0, le=1.0,
        json_schema_extra=ui("Forecast memory", "EWMA lambda on past forecast.", "", 0, 1))
    forecast_strength: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Forecast strength",
                                          "Logit shift from forecast surprise.", "", 0, 5))

    # Internal cognition C: optional individual reinforcement learning
    individual_learning_enabled: bool = Field(
        False, json_schema_extra=ui("Individual learning (C)",
                                    "Per-agent EWMA reinforcement (advanced)."))
    individual_learning_rate: float = Field(
        0.2, ge=0.0, le=1.0,
        json_schema_extra=ui("Learning rate", "EWMA rate on own outcomes.", "", 0, 1))
    individual_learning_strength: float = Field(
        1.0, ge=0.0, json_schema_extra=ui("Learning strength",
                                          "Logit shift from own experience.", "", 0, 5))

    def to_mode(self) -> CognitionMode:
        """Collapse the flags into the Simple-mode bundle (ignores learning)."""

        if self.experience_enabled and self.forecast_enabled:
            return CognitionMode.BOTH
        if self.experience_enabled:
            return CognitionMode.EXPERIENCE
        if self.forecast_enabled:
            return CognitionMode.FORECAST
        return CognitionMode.NONE


# ---------------------------------------------------------------------------
# Experiment, output, decision policy
# ---------------------------------------------------------------------------
class ChoiceConfig(_Base):
    softmax_temperature: float = Field(
        1.0, gt=0.0, json_schema_extra=ui("Softmax temperature",
                                          "Higher = more random choice.", "", 0.1, 5))
    decision_noise_sd: float = Field(
        0.1, ge=0.0, json_schema_extra=ui("Decision noise", "Gumbel-like logit noise sd.",
                                          "", 0, 2))


class ExperimentConfig(_Base):
    mode: ExperimentMode = Field(
        ExperimentMode.SINGLE, json_schema_extra=ui("Mode", "single/replications/sweep."))
    replications: int = Field(
        1, ge=1, json_schema_extra=ui("Replications", "Independent repeats.", "runs"))
    max_workers: int = Field(
        1, ge=1, json_schema_extra=ui("Max workers", "Parallel processes for replicates."))
    sweep_parameters: list[SweepParameter] = Field(
        default_factory=list,
        json_schema_extra=ui("Sweep params", "1-3 parameters to sweep."))
    max_sweep_combinations: int = Field(
        500, ge=1, json_schema_extra=ui("Max sweep combos", "Warn/refuse above this."))
    common_random_numbers: bool = Field(
        False, json_schema_extra=ui("Common random numbers",
                                    "Reuse seeds across sweep conditions."))


class SweepParameter(_Base):
    path: str = Field(..., min_length=1,
                     json_schema_extra=ui("Parameter path",
                                          "Dotted config path, e.g. mortality.base_predation_hazard."))
    values: list[float] = Field(
        default_factory=list, json_schema_extra=ui("Values", "Explicit values."))
    start: float | None = Field(None, json_schema_extra=ui("Start", "Range start."))
    stop: float | None = Field(None, json_schema_extra=ui("Stop", "Range stop."))
    step: float | None = Field(None, json_schema_extra=ui("Step", "Range step."))
    logarithmic: bool = Field(False, json_schema_extra=ui("Log scale", "Log-spaced range."))

    def resolved_values(self) -> list[float]:
        """Materialise the list of values from explicit list or start/stop/step."""

        import numpy as np

        if self.values:
            return list(self.values)
        if self.start is None or self.stop is None or self.step is None:
            raise ValueError(f"sweep '{self.path}': give values or start/stop/step")
        if self.logarithmic:
            if self.start <= 0 or self.stop <= 0:
                raise ValueError("log sweep needs positive start/stop")
            n = int(self.step)
            if n < 2:
                raise ValueError("log sweep 'step' is the count and must be >= 2")
            return list(np.logspace(np.log10(self.start), np.log10(self.stop), n))
        vals = list(np.arange(self.start, self.stop + 1e-9, self.step))
        return [float(v) for v in vals]


class OutputConfig(_Base):
    record_interval_steps: int = Field(
        10, ge=1, json_schema_extra=ui("Record interval", "Steps between snapshots.",
                                       "steps"))
    store_agent_sample: bool = Field(
        True, json_schema_extra=ui("Agent sample", "Store a reproducible agent sample."))
    agent_sample_size: int = Field(
        50, ge=1, json_schema_extra=ui("Sample size", "Agents per snapshot sample."))
    store_event_log: bool = Field(
        False, json_schema_extra=ui("Event log", "Store detailed events (large!)."))


# ---------------------------------------------------------------------------
# Top-level scenario
# ---------------------------------------------------------------------------
class ScenarioConfig(_Base):
    """Top-level scenario. See individual sections for field metadata."""

    """The complete, self-contained specification of one simulation scenario."""

    schema_version: int = Field(
        SCHEMA_VERSION, json_schema_extra=ui("Schema version", "Config schema version."))
    name: str = Field("Untitled", json_schema_extra=ui("Scenario name", "Display name."))
    description: str = Field("", json_schema_extra=ui("Description", "Free text."))
    preset_origin: str | None = Field(
        None, json_schema_extra=ui("Preset origin", "Preset this derives from, if any."))
    master_seed: int = Field(
        12345, ge=0, json_schema_extra=ui("Master seed", "Root seed for reproducibility."))

    domains: list[DomainConfig] = Field(default_factory=list)
    tasks: list[TaskConfig] = Field(default_factory=list)
    environment: list[EnvVariableConfig] = Field(default_factory=list)

    population: PopulationConfig = Field(default_factory=PopulationConfig)
    lifecycle: LifecycleConfig = Field(default_factory=LifecycleConfig)
    mortality: MortalityConfig = Field(default_factory=MortalityConfig)
    reproduction: ReproductionConfig = Field(default_factory=ReproductionConfig)
    inheritance: InheritanceConfig = Field(default_factory=InheritanceConfig)
    homeostasis: HomeostasisConfig = Field(default_factory=HomeostasisConfig)
    cognition: CognitionConfig = Field(default_factory=CognitionConfig)
    choice: ChoiceConfig = Field(default_factory=ChoiceConfig)
    experiment: ExperimentConfig = Field(default_factory=ExperimentConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)

    @model_validator(mode="after")
    def _cross_refs(self) -> ScenarioConfig:
        """Light structural cross-checks. Scientific checks live in validation.py."""

        domain_ids = {d.domain_id for d in self.domains}
        if len(domain_ids) != len(self.domains):
            raise ValueError("duplicate domain_id values")
        task_ids = {t.task_id for t in self.tasks}
        if len(task_ids) != len(self.tasks):
            raise ValueError("duplicate task_id values")
        env_ids = {e.var_id for e in self.environment}
        if len(env_ids) != len(self.environment):
            raise ValueError("duplicate env var_id values")
        for t in self.tasks:
            if t.domain not in domain_ids:
                raise ValueError(
                    f"task '{t.task_id}' references unknown domain '{t.domain}'")
        if len(self.experiment.sweep_parameters) > 3:
            raise ValueError("at most 3 sweep parameters are supported")
        return self

    def enabled_tasks(self) -> list[TaskConfig]:
        return [t for t in self.tasks if t.enabled]


# Resolve the forward reference used inside ExperimentConfig.
ExperimentConfig.model_rebuild()


__all__ = [
    "ui", "TaskEffectRule", "TaskConfig", "EnvVariableConfig", "DomainConfig",
    "PopulationConfig", "LifecycleConfig", "MortalityConfig", "ReproductionConfig",
    "InheritanceConfig", "HomeostasisConfig", "CognitionConfig", "ChoiceConfig",
    "ExperimentConfig", "SweepParameter", "OutputConfig", "ScenarioConfig",
]

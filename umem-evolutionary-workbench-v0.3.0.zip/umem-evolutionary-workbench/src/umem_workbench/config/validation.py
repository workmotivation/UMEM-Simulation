"""Pre-run scientific validation and workload estimation.

The report distinguishes three severities:

* ``ERROR``   -- the simulation cannot run.
* ``WARNING`` -- it can run but may be degenerate or biologically implausible.
* ``THEORY``  -- the configuration conflicts with the *interpretation* of a
  construct (e.g. a task labelled neutral that actually confers benefits).

Scientific parameters are never silently repaired; the report explains the issue
and lets the researcher decide.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from .enums import (
    EffectTarget,
    EnvProcess,
    InheritanceModel,
    InitDistribution,
    MatingMode,
    ReproductionMode,
    ReproductionTiming,
    TaskRole,
)
from .models import ScenarioConfig


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    THEORY = "theory"


@dataclass
class ValidationIssue:
    severity: Severity
    code: str
    message: str


@dataclass
class WorkloadEstimate:
    """Approximate, clearly-labelled resource estimate (not a guarantee)."""

    total_steps: int
    approx_agent_steps: int
    replications: int
    sweep_combinations: int
    approx_peak_agents: int
    approx_timeseries_rows: int

    def as_dict(self) -> dict[str, int]:
        return {
            "total_steps": self.total_steps,
            "approx_agent_steps": self.approx_agent_steps,
            "replications": self.replications,
            "sweep_combinations": self.sweep_combinations,
            "approx_peak_agents": self.approx_peak_agents,
            "approx_timeseries_rows": self.approx_timeseries_rows,
        }


@dataclass
class ValidationReport:
    issues: list[ValidationIssue] = field(default_factory=list)
    workload: WorkloadEstimate | None = None

    @property
    def errors(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]

    @property
    def theory_warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == Severity.THEORY]

    @property
    def can_run(self) -> bool:
        return len(self.errors) == 0

    def add(self, severity: Severity, code: str, message: str) -> None:
        self.issues.append(ValidationIssue(severity, code, message))


def _env_ids(scenario: ScenarioConfig) -> set[str]:
    return {e.var_id for e in scenario.environment}


def estimate_workload(scenario: ScenarioConfig) -> WorkloadEstimate:
    lc = scenario.lifecycle
    total_steps = lc.steps_per_season * lc.total_seasons
    peak = min(scenario.population.max_population,
               max(scenario.population.initial_population,
                   scenario.population.carrying_capacity))
    approx_agent_steps = total_steps * peak
    reps = scenario.experiment.replications
    combos = 1
    for sp in scenario.experiment.sweep_parameters:
        try:
            combos *= max(1, len(sp.resolved_values()))
        except Exception:
            combos *= 1
    ts_rows = (total_steps // max(1, scenario.output.record_interval_steps)) * reps * combos
    return WorkloadEstimate(
        total_steps=total_steps,
        approx_agent_steps=approx_agent_steps * reps * combos,
        replications=reps,
        sweep_combinations=combos,
        approx_peak_agents=peak,
        approx_timeseries_rows=ts_rows,
    )


def validate_scenario(scenario: ScenarioConfig) -> ValidationReport:
    """Run all scientific checks and return a structured report."""

    report = ValidationReport()
    add = report.add
    env_ids = _env_ids(scenario)

    enabled = scenario.enabled_tasks()
    if not enabled:
        add(Severity.ERROR, "no_tasks", "No tasks are enabled; nothing can happen.")

    # ------------------------------------------------------------------
    # Reproduction timing / mechanism compatibility (schema 2)
    # ------------------------------------------------------------------
    rc = scenario.reproduction
    if rc.timing == ReproductionTiming.DISTRIBUTED:
        if rc.gestation_delay_steps != 0:
            add(Severity.ERROR, "gestation_not_supported_distributed",
                f"gestation_delay_steps is {rc.gestation_delay_steps} but the "
                f"continuous (distributed) reproduction model has no gestation "
                f"mechanism. Set it to 0, or switch timing to season_end_legacy "
                f"if a delay must be reproduced. It is never silently ignored.")
        if rc.breeding_every_seasons != 1:
            add(Severity.WARNING, "legacy_field_ignored",
                f"breeding_every_seasons = {rc.breeding_every_seasons} has no "
                f"effect under distributed timing; use refractory_seasons.")
    if rc.mode == ReproductionMode.ASEXUAL and rc.mating_mode != MatingMode.RANDOM:
        add(Severity.WARNING, "mating_mode_irrelevant_asexual",
            f"mating_mode = {rc.mating_mode.value} is ignored: asexual "
            f"reproduction needs no partner.")
    if (rc.mating_mode == MatingMode.PAIR_BONDED
            and abs(scenario.population.sex_ratio_type_a - 0.5) > 0.2):
        add(Severity.WARNING, "pair_bond_type_imbalance",
            "Pair bonding with a strongly unbalanced Type-A fraction leaves "
            "many agents unable to find a bond partner.")
    if rc.mate_choice_k > scenario.population.initial_population:
        add(Severity.WARNING, "mate_choice_k_exceeds_population",
            "mate_choice_k exceeds the initial population; every choice will "
            "inspect the whole pool.")
    ic = scenario.inheritance
    if ic.model == InheritanceModel.POLYGENIC_ADDITIVE:
        if scenario.population.init_distribution == InitDistribution.EQUAL:
            add(Severity.THEORY, "zero_segregation_variance",
                "init_distribution = equal gives zero founder genetic variance, "
                "so segregation variance is zero and only mutation creates "
                "variation. This is correct under the infinitesimal model but "
                "may not be what you intend.")
        if ic.mutation_probability != 1.0 or ic.mutation_log_sd != 0.1:
            add(Severity.WARNING, "legacy_field_ignored",
                "mutation_probability / mutation_log_sd belong to the legacy "
                "inheritance model and are ignored under polygenic_additive.")

    # Role labels must agree with what the effect rules actually do (section
    # 12). A behaviour must not be treated as neutral if it confers a real
    # benefit, and a task declared functional that does nothing is almost
    # always a configuration mistake.
    for task in enabled:
        benefit = task.has_direct_benefit()
        if task.role in (TaskRole.COSTLY_NONFUNCTIONAL,
                         TaskRole.LOW_COST_NEUTRAL) and benefit:
            add(Severity.WARNING, "role_effect_conflict",
                f"Task '{task.task_id}' is labelled '{task.role.value}' but its "
                f"effect rules confer a direct benefit. Nonfunctional and "
                f"neutral behaviour must have no direct reproductive, health, "
                f"energy, observation, or hazard benefit, or the misallocation "
                f"metrics will be misleading.")
        elif task.role == TaskRole.FUNCTIONAL and not benefit:
            add(Severity.WARNING, "functional_without_effect",
                f"Task '{task.task_id}' is labelled 'functional' but has no "
                f"effect rule conferring a direct benefit. It will behave as a "
                f"costly nonfunctional behaviour.")

        if (task.role == TaskRole.LOW_COST_NEUTRAL
                and task.energy_cost > scenario.lifecycle.basal_metabolism):
            add(Severity.THEORY, "neutral_task_costly",
                f"Task '{task.task_id}' is labelled low-cost neutral but costs "
                f"{task.energy_cost:.2f} energy, above basal metabolism. "
                f"Consider labelling it costly nonfunctional instead.")

    # Domains with weight but no eligible task.
    task_domains = {t.domain for t in enabled}
    for d in scenario.domains:
        if d.init_mean > 0 and d.domain_id not in task_domains:
            add(Severity.WARNING, "empty_domain",
                f"Domain '{d.domain_id}' has positive propensity but no enabled task.")

    # Energy gain possibility.
    can_gain_energy = any(
        r.target == EffectTarget.ENERGY and r.base_value > 0
        for t in enabled for r in t.effects
    )
    if not can_gain_energy:
        add(Severity.ERROR, "no_energy_gain",
            "No enabled task can increase energy; the population will starve.")
    else:
        # Rough check: expected best-case intake vs. metabolism.
        best_gain = max(
            (r.base_value for t in enabled for r in t.effects
             if r.target == EffectTarget.ENERGY and r.base_value > 0),
            default=0.0,
        )
        if best_gain < scenario.lifecycle.basal_metabolism:
            add(Severity.WARNING, "intake_below_metabolism",
                f"Best-case energy gain ({best_gain:.2f}) is below basal metabolism "
                f"({scenario.lifecycle.basal_metabolism:.2f}); starvation is likely.")

    # Lifecycle sanity.
    if scenario.lifecycle.maturity_seasons > scenario.lifecycle.max_lifespan_seasons:
        add(Severity.ERROR, "maturity_gt_lifespan",
            "Maturity age exceeds maximum lifespan; no agent can ever reproduce.")

    # Reproduction feasibility.
    if scenario.reproduction.fertility_mean <= 0 and \
            scenario.reproduction.fertility_distribution.value != "discrete":
        add(Severity.ERROR, "zero_fertility",
            "Fertility mean is zero; the population cannot replace itself.")
    if scenario.reproduction.energy_threshold > scenario.lifecycle.energy_max:
        add(Severity.ERROR, "unreachable_energy_threshold",
            "Reproductive energy threshold exceeds the energy ceiling; unreachable.")
    if scenario.reproduction.health_threshold > scenario.lifecycle.health_max:
        add(Severity.ERROR, "unreachable_health_threshold",
            "Reproductive health threshold exceeds the health ceiling; unreachable.")
    if scenario.reproduction.repro_capital_threshold > scenario.lifecycle.repro_capital_max:
        add(Severity.ERROR, "unreachable_capital_threshold",
            "Reproductive capital threshold exceeds its ceiling; unreachable.")

    # Environment references used by mortality / reproduction / tasks.
    if scenario.mortality.predation_env_driver and \
            scenario.mortality.predation_env_driver not in env_ids:
        add(Severity.WARNING, "missing_predation_env",
            f"Predation driver '{scenario.mortality.predation_env_driver}' "
            "is not a defined environment variable; base hazard only will apply.")
    for t in enabled:
        if t.success_env_driver and t.success_env_driver not in env_ids:
            add(Severity.WARNING, "missing_success_env",
                f"Task '{t.task_id}' success driver "
                f"'{t.success_env_driver}' is undefined.")
        for r in t.effects:
            if r.env_driver and r.env_driver not in env_ids:
                add(Severity.WARNING, "missing_effect_env",
                    f"Task '{t.task_id}' effect driver '{r.env_driver}' is undefined.")

    # Initial states within bounds.
    lc = scenario.lifecycle
    if lc.initial_energy > lc.energy_max:
        add(Severity.ERROR, "energy_oob", "Initial energy exceeds the energy ceiling.")
    if lc.initial_health > lc.health_max:
        add(Severity.ERROR, "health_oob", "Initial health exceeds the health ceiling.")

    # Environment process validity (bounds already enforced by pydantic; add a
    # theoretical check for imported-series length).
    total_steps = lc.steps_per_season * lc.total_seasons
    for e in scenario.environment:
        if e.process == EnvProcess.IMPORTED and len(e.imported_series) < total_steps:
            add(Severity.WARNING, "short_imported_series",
                f"Imported series for '{e.var_id}' is shorter than the run "
                f"({len(e.imported_series)} < {total_steps}); it will be padded by "
                "holding the last value.")

    # Role vs. effect consistency (theoretical warnings).
    for t in enabled:
        if t.role == TaskRole.LOW_COST_NEUTRAL and t.has_direct_benefit():
            add(Severity.THEORY, "neutral_with_benefit",
                f"Task '{t.task_id}' is labelled low-cost neutral but confers a direct "
                "benefit; the neutral interpretation does not hold.")
        if t.role == TaskRole.COSTLY_NONFUNCTIONAL and t.has_direct_benefit():
            add(Severity.THEORY, "nonfunctional_with_benefit",
                f"Task '{t.task_id}' is labelled costly nonfunctional but confers a "
                "direct benefit; it is not truly nonfunctional.")
        if t.role == TaskRole.FUNCTIONAL and not t.effects and t.predation_multiplier == 1.0:
            add(Severity.WARNING, "functional_no_effect",
                f"Task '{t.task_id}' is labelled functional but has no configured effect.")

    # Recording interval present (pydantic enforces >=1; warn if very coarse).
    if scenario.output.record_interval_steps > total_steps:
        add(Severity.WARNING, "coarse_recording",
            "Recording interval is longer than the whole run; only one snapshot "
            "will be stored.")

    # Sweep size.
    workload = estimate_workload(scenario)
    if workload.sweep_combinations > scenario.experiment.max_sweep_combinations:
        add(Severity.ERROR, "sweep_too_large",
            f"Parameter sweep has {workload.sweep_combinations} combinations, above "
            f"the configured maximum of {scenario.experiment.max_sweep_combinations}.")

    # Memory guard.
    if workload.approx_peak_agents * total_steps > 5_000_000 and \
            scenario.output.store_event_log:
        add(Severity.WARNING, "large_event_log",
            "Detailed event logging with this population and duration may use a lot "
            "of memory; consider disabling the event log.")

    report.workload = workload
    return report


__all__ = [
    "Severity", "ValidationIssue", "ValidationReport", "WorkloadEstimate",
    "validate_scenario", "estimate_workload",
]

"""Enumerated, validated option sets used throughout the configuration schema.

Using explicit enums (rather than free-form strings or, worse, user-supplied
Python expressions) keeps the configuration safe to load from disk and makes the
UI able to present closed dropdowns. No part of the engine ever evaluates
user-entered code.
"""

from __future__ import annotations

from enum import Enum


class EnvProcess(str, Enum):
    """Stochastic process governing an environment variable over time."""

    CONSTANT = "constant"
    RANDOM_WALK = "random_walk"          # bounded Gaussian random walk
    AR1 = "ar1"                          # mean-reverting AR(1)
    SEASONAL = "seasonal"               # deterministic seasonal cycle
    AR1_SEASONAL = "ar1_seasonal"       # AR(1) plus seasonality
    REGIME_SWITCHING = "regime_switching"
    RARE_SHOCKS = "rare_shocks"          # AR(1) baseline with occasional shocks
    IMPORTED = "imported"               # user-supplied time series


class EffectTarget(str, Enum):
    """State variable that a task effect rule modifies."""

    ENERGY = "energy"
    HEALTH = "health"
    REPRO_CAPITAL = "repro_capital"
    STATUS = "status"
    HAZARD = "hazard"                    # multiplies/updates predation hazard
    OBSERVATION_QUALITY = "observation_quality"


class EffectType(str, Enum):
    """How an effect rule combines its value with the current state."""

    ADDITIVE = "additive"
    MULTIPLICATIVE = "multiplicative"
    PROBABILITY_MODIFIER = "probability_modifier"  # additive in logit space
    BOUNDED_REPLACEMENT = "bounded_replacement"


class EffectCondition(str, Enum):
    """When an effect rule fires relative to task success/failure."""

    ALWAYS = "always"
    ON_SUCCESS = "on_success"
    ON_FAILURE = "on_failure"


class TaskRole(str, Enum):
    """Scientific role label for a task (validated against its effect rules)."""

    FUNCTIONAL = "functional"
    LOW_COST_NEUTRAL = "low_cost_neutral"
    COSTLY_NONFUNCTIONAL = "costly_nonfunctional"


class SexRestriction(str, Enum):
    """Which reproductive type may perform a task."""

    ANY = "any"
    TYPE_A = "type_a"
    TYPE_B = "type_b"


class InitDistribution(str, Enum):
    """Distribution used to initialise heritable propensities."""

    EQUAL = "equal"
    GAMMA = "gamma"
    LOGNORMAL = "lognormal"
    FROM_FILE = "from_file"


class ReproductionMode(str, Enum):
    """Sexual (two compatible types) or asexual (clonal) reproduction."""

    SEXUAL = "sexual"
    ASEXUAL = "asexual"


class MateSelection(str, Enum):
    """How mates are chosen among eligible agents."""

    RANDOM = "random"
    WEIGHTED_CAPITAL = "weighted_capital"
    COMPETITIVE = "competitive"          # logistic relative-advantage ranking
    ASSORTATIVE = "assortative"          # advanced: similar propensity pairs


class FertilityDistribution(str, Enum):
    """Distribution of surviving offspring per successful breeding event."""

    FIXED = "fixed"
    POISSON = "poisson"
    BINOMIAL = "binomial"
    DISCRETE = "discrete"               # bounded user-defined pmf


class AgeHazardShape(str, Enum):
    """Functional form of age-related mortality hazard."""

    GOMPERTZ = "gompertz"
    LOGISTIC = "logistic"


class SuccessDefinition(str, Enum):
    """Definition of a 'successful' agent for intergenerational memory."""

    SURVIVED = "survived"
    REPRODUCED = "reproduced"
    SURVIVING_OFFSPRING = "surviving_offspring"
    TOP_QUANTILE_LRS = "top_quantile_lrs"  # top quantile of reproductive success


class CognitionMode(str, Enum):
    """Convenience bundle used by Simple mode to switch internal cognition."""

    NONE = "none"
    EXPERIENCE = "experience"
    FORECAST = "forecast"
    BOTH = "both"


class ExperimentMode(str, Enum):
    """Top-level experiment type."""

    SINGLE = "single"
    REPLICATIONS = "replications"
    SWEEP = "sweep"


# ---------------------------------------------------------------------------
# Inheritance (schema 2; see docs/design/ADR-001 and ADR-002)
# ---------------------------------------------------------------------------
class InheritanceModel(str, Enum):
    """How offspring heritable propensities derive from their parents."""

    #: Fisher's infinitesimal model on a centred latent scale. The default for
    #: new scenarios. See ADR-002.
    POLYGENIC_ADDITIVE = "polygenic_additive"
    #: The v0.1.0 mechanism: per-trait parental selection or blending on the
    #: positive scale, with multiplicative log-normal mutation. Retained so
    #: that pre-schema-2 scenarios keep their original scientific meaning.
    LEGACY = "legacy"


class SiblingVariation(str, Enum):
    """Preset multiplier on the segregation variance.

    Segregation variance is ``s * V0 / 2`` where ``V0`` is the configured
    founder additive variance; ``s`` is selected here. ``CUSTOM`` uses
    ``inheritance.segregation_multiplier`` directly.
    """

    LOW = "low"            # s = 0.5
    STANDARD = "standard"  # s = 1.0  -> founder variance is the equilibrium
    HIGH = "high"          # s = 1.5
    CUSTOM = "custom"


class MutationLevel(str, Enum):
    """Named mutation calibrations.

    These are effective simulation parameters chosen to produce usable dynamics
    over tens of seasons. They are **not** empirical per-base mutation rates.
    ``CUSTOM`` uses the explicit probability and effect-size fields.
    """

    NONE = "none"                  # disabled
    CONSERVATIVE = "conservative"  # p = 0.01 per offspring, sd = 0.10 latent
    ACCELERATED = "accelerated"    # p = 0.05 per offspring, sd = 0.20 latent
    CUSTOM = "custom"


class MutationTarget(str, Enum):
    """Which propensity layer an effective mutation may strike."""

    DOMAIN = "domain"
    TASK = "task"
    BOTH = "both"


# ---------------------------------------------------------------------------
# Reproduction scheduling and mate choice (schema 2; ADR-003/004/005)
# ---------------------------------------------------------------------------
class ReproductionTiming(str, Enum):
    """When reproductive opportunities occur."""

    #: Every time step is an opportunity to reproduce, as in a non-Wright-Fisher
    #: model. The default for new scenarios. See ADR-003.
    DISTRIBUTED = "distributed"
    #: All eligible agents breed together on the last step of each season, the
    #: v0.1.0 behaviour. A compatibility mode, not recommended for new work: it
    #: imposes strict breeding synchrony and produces a season-period sawtooth
    #: in population size.
    SEASON_END_LEGACY = "season_end_legacy"


class MatingMode(str, Enum):
    """How eligible agents are matched into reproductive events.

    Names follow behavioural ecology's standard classification; the reproductive
    types stay neutral (A/B), never male/female. See ADR-005.
    """

    #: Promiscuity: no bonds, partners drawn without preference.
    RANDOM = "random"
    #: Social monogamy: exclusive, persistent one-to-one bonds.
    PAIR_BONDED = "pair_bonded"
    #: Polygyny-like reproductive skew: non-exclusive, choosy, non-persistent.
    COMPETITIVE = "competitive"


class MateChoiceCriterion(str, Enum):
    """What a chooser optimises among its candidates."""

    #: Prefer the highest-quality candidate, producing reproductive skew.
    PARTNER_QUALITY = "partner_quality"
    #: Prefer the most similar candidate, producing assortative mating. This
    #: subsumes the v0.1.0 ``assortative`` mate-selection option.
    SIMILARITY = "similarity"


class FounderAgeDistribution(str, Enum):
    """Age structure of the initial population. See ADR-006."""

    #: Every founder starts at age zero (v0.1.0 behaviour).
    ALL_NEWBORN_LEGACY = "all_newborn_legacy"
    #: Ages drawn uniformly over the permitted lifespan.
    UNIFORM = "uniform"
    #: Ages drawn from an approximate stable age distribution derived from the
    #: configured baseline hazards.
    STABLE = "stable"


__all__ = [
    "EnvProcess", "EffectTarget", "EffectType", "EffectCondition", "TaskRole",
    "SexRestriction", "InitDistribution", "ReproductionMode", "MateSelection",
    "FertilityDistribution", "AgeHazardShape", "SuccessDefinition",
    "CognitionMode", "ExperimentMode",
    "InheritanceModel", "SiblingVariation", "MutationLevel", "MutationTarget",
    "ReproductionTiming", "MatingMode", "MateChoiceCriterion",
    "FounderAgeDistribution",
]

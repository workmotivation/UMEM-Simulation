"""Centralised configuration data dictionary.

The Pydantic configuration models and their ``ui()`` metadata are the single
source of truth for what every parameter is, does, and means. This module reads
that metadata and emits it as structured data, so that the parameter reference
documentation, the user interfaces, and any future machine-facing guide are all
generated from the same definitions and cannot drift from the code.

Emit with::

    umem-workbench data-dictionary --format json
    umem-workbench data-dictionary --format markdown > docs/parameter_reference.md
    umem-workbench data-dictionary --format csv
"""

from __future__ import annotations

import csv
import enum
import io
import json
import typing
from dataclasses import asdict, dataclass, field
from typing import Any

from pydantic import BaseModel
from pydantic.fields import FieldInfo

from ..version import SCHEMA_VERSION
from . import models as M  # noqa: N812

__all__ = [
    "DictionaryEntry",
    "build_dictionary",
    "to_json",
    "to_markdown",
    "to_csv",
    "SECTIONS",
    "LIST_SECTIONS",
]

#: Top-level scalar-model sections in the order they appear in documentation.
SECTIONS: tuple[tuple[str, type[BaseModel]], ...] = (
    ("population", M.PopulationConfig),
    ("lifecycle", M.LifecycleConfig),
    ("mortality", M.MortalityConfig),
    ("reproduction", M.ReproductionConfig),
    ("inheritance", M.InheritanceConfig),
    ("homeostasis", M.HomeostasisConfig),
    ("cognition", M.CognitionConfig),
    ("choice", M.ChoiceConfig),
    ("experiment", M.ExperimentConfig),
    ("output", M.OutputConfig),
)

#: List-valued sections; the path uses ``[]`` to denote an element.
LIST_SECTIONS: tuple[tuple[str, type[BaseModel]], ...] = (
    ("domains[]", M.DomainConfig),
    ("tasks[]", M.TaskConfig),
    ("tasks[].effects[]", M.TaskEffectRule),
    ("environment[]", M.EnvVariableConfig),
    ("experiment.sweep_parameters[]", M.SweepParameter),
)

_SECTION_NAMES = {name for name, _ in SECTIONS} | {"domains", "tasks", "environment"}


@dataclass
class DictionaryEntry:
    """One configuration parameter."""

    path: str
    name: str
    section: str
    type: str
    enum_values: list[str] = field(default_factory=list)
    default: Any = None
    minimum: float | None = None
    maximum: float | None = None
    ui_min: float | None = None
    ui_max: float | None = None
    unit: str = ""
    category: str = ""
    label: str = ""
    description: str = ""
    interpretation: str = ""
    applicability: str = "all"
    reference: str = ""
    added_in_schema: int = 1
    deprecated: str = ""
    required: bool = False


# ---------------------------------------------------------------------------
# Introspection helpers
# ---------------------------------------------------------------------------
def _type_name(annotation: Any) -> tuple[str, list[str]]:
    """Human-readable type plus enum values, if the field is an enum."""

    if annotation is None:
        return "any", []
    if isinstance(annotation, type) and issubclass(annotation, enum.Enum):
        return "enum", [e.value for e in annotation]
    origin = typing.get_origin(annotation)
    if origin is not None:
        args = [a for a in typing.get_args(annotation) if a is not type(None)]
        origin_name = getattr(origin, "__name__", str(origin))
        if origin_name in ("UnionType", "Union") and args:
            inner, vals = _type_name(args[0])
            return f"{inner} (optional)", vals
        if args:
            inner = ", ".join(_type_name(a)[0] for a in args)
            return f"{origin_name}[{inner}]", []
        return origin_name, []
    return getattr(annotation, "__name__", str(annotation)), []


def _bounds(info: FieldInfo) -> tuple[float | None, float | None]:
    lo = hi = None
    for meta in getattr(info, "metadata", ()):
        for attr, is_low in (("ge", True), ("gt", True), ("le", False), ("lt", False)):
            if hasattr(meta, attr):
                val = getattr(meta, attr)
                if is_low:
                    lo = val
                else:
                    hi = val
    return lo, hi


def _default(info: FieldInfo) -> tuple[Any, bool]:
    default = info.default
    if repr(default).startswith("PydanticUndefined"):
        if info.default_factory is not None:
            try:
                return info.default_factory(), False
            except TypeError:
                return None, False
        return None, True
    if isinstance(default, enum.Enum):
        return default.value, False
    return default, False


def _entries_for(model: type[BaseModel], prefix: str, section: str
                 ) -> list[DictionaryEntry]:
    entries = []
    for name, info in model.model_fields.items():
        raw = getattr(info, "json_schema_extra", None) or {}
        ui = raw.get("ui", {}) if isinstance(raw, dict) else {}
        type_name, enum_values = _type_name(info.annotation)
        lo, hi = _bounds(info)
        default, required = _default(info)
        entries.append(DictionaryEntry(
            path=f"{prefix}.{name}" if prefix else name,
            name=name,
            section=section,
            type=type_name,
            enum_values=enum_values,
            default=default,
            minimum=lo,
            maximum=hi,
            ui_min=ui.get("ui_min"),
            ui_max=ui.get("ui_max"),
            unit=ui.get("unit", "") or "",
            category=ui.get("category", "") or "",
            label=ui.get("label", "") or name.replace("_", " ").capitalize(),
            description=ui.get("help", "") or "",
            interpretation=ui.get("interpretation", "") or "",
            applicability=ui.get("applicability", "all") or "all",
            reference=ui.get("reference", "") or "",
            added_in_schema=int(ui.get("added_in_schema", 1) or 1),
            deprecated=ui.get("deprecated", "") or "",
            required=required,
        ))
    return entries


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def build_dictionary() -> list[DictionaryEntry]:
    """Every configuration parameter, in documentation order."""

    out: list[DictionaryEntry] = [
        e for e in _entries_for(M.ScenarioConfig, "", "scenario")
        if e.name not in _SECTION_NAMES]
    for section, model in SECTIONS:
        out.extend(_entries_for(model, section, section))
    for prefix, model in LIST_SECTIONS:
        out.extend(_entries_for(model, prefix, prefix.split("[")[0]))
    return out


def to_json(entries: list[DictionaryEntry] | None = None, indent: int = 2) -> str:
    entries = entries if entries is not None else build_dictionary()
    payload = {
        "schema_version": SCHEMA_VERSION,
        "n_parameters": len(entries),
        "parameters": [asdict(e) for e in entries],
    }
    return json.dumps(payload, indent=indent, default=str, ensure_ascii=False)


def to_csv(entries: list[DictionaryEntry] | None = None) -> str:
    entries = entries if entries is not None else build_dictionary()
    buf = io.StringIO()
    rows = [asdict(e) for e in entries]
    writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    for row in rows:
        row["enum_values"] = "|".join(row["enum_values"])
        row["default"] = json.dumps(row["default"], default=str)
        writer.writerow(row)
    return buf.getvalue()


def _fmt_default(value: Any, required: bool) -> str:
    if required:
        return "required"
    if isinstance(value, (dict, list)):
        return "`" + json.dumps(value, default=str) + "`" if value else "empty"
    if value is None:
        return "none"
    return f"`{value}`"


def _esc(text: str) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ")


def to_markdown(entries: list[DictionaryEntry] | None = None) -> str:
    """Render the reference document. Deterministic for a given schema."""

    entries = entries if entries is not None else build_dictionary()
    lines = [
        "# Parameter reference",
        "",
        f"Configuration schema version {SCHEMA_VERSION}. Generated from the model "
        "definitions by `umem-workbench data-dictionary --format markdown`; do "
        "not edit by hand.",
        "",
        "Scenario files are JSON or YAML. Paths use dotted notation; list "
        "elements may be addressed by identifier, e.g. "
        "`tasks.safe_forage.energy_cost`.",
        "",
        "**Column guide.** *Kind* classifies the unit-time meaning (rate, "
        "probability, interval, count, threshold, mode, weight, scale), which "
        "matters when converting between per-season and per-step "
        "parameterisations. *Applies to* states which mechanism configuration "
        "the field is active under; a field marked `legacy_timing_only` or "
        "`legacy_inheritance_only` is **ignored** under the new defaults and "
        "the validator warns if it is changed. *Since* is the schema version "
        "that introduced the field.",
        "",
        "> All defaults are illustrative demonstration values, not calibrated to "
        "any real species. See `known_limitations.md`.",
        "",
        "---",
        "",
    ]

    by_section: dict[str, list[DictionaryEntry]] = {}
    for e in entries:
        by_section.setdefault(e.section, []).append(e)

    header = ("| Parameter | Type | Default | Range | Unit | Kind | Applies to | "
              "Since | Description | Scientific interpretation | Source |")
    sep = "|---|---|---|---|---|---|---|---|---|---|---|"

    for section, rows in by_section.items():
        lines.append(f"## `{section}`")
        lines.append("")
        lines.append(header)
        lines.append(sep)
        for e in rows:
            type_txt = e.type
            if e.enum_values:
                type_txt = "enum: " + ", ".join(f"`{v}`" for v in e.enum_values)
            rng = ""
            if e.minimum is not None or e.maximum is not None:
                rng = f"{e.minimum if e.minimum is not None else '…'} to " \
                      f"{e.maximum if e.maximum is not None else '…'}"
            desc = _esc(e.description)
            if e.deprecated:
                desc += f" **Deprecated:** {_esc(e.deprecated)}"
            lines.append(
                f"| `{e.name}` | {type_txt} | {_fmt_default(e.default, e.required)} "
                f"| {rng} | {e.unit} | {e.category} | {e.applicability} | "
                f"{e.added_in_schema} | {desc} | {_esc(e.interpretation)} | "
                f"{_esc(e.reference)} |")
        lines.append("")
    return "\n".join(lines) + "\n"

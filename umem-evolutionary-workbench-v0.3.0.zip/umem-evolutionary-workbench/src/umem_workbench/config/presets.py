"""Built-in scenario presets (Master Prompt sections 22 and 27).

Three principal presets illustrate qualitatively different ecologies, plus a
legacy AOM reference scenario for continuity with the original model. Values are
theoretical demonstration settings, modestly calibrated for numerical viability,
**not** parameterisations of a real species.

Calibration note
----------------
The mortality, fecundity and metabolic constants below were chosen by sweeping
seeds until each preset produced a *usable* demographic trajectory over its
configured horizon: a population that neither goes extinct in the first few
seasons nor saturates immediately at the population ceiling. They are numerical
demonstration settings, not empirically derived life-history parameters, and no
biological interpretation should be attached to their particular values. The
qualitative contrasts between presets (abundant vs scarce vs volatile) are the
intended object of study; the absolute numbers are arbitrary.

Verified behaviour at the shipped values (12 seeds per preset, replication 0):

============================  ==========  ==================================
Preset                        Extinction  Final population range
============================  ==========  ==================================
stable_abundant (A)           0/12        ~230-390 (K=500)
scarce_low_fecundity (B)      0/12        ~230-380 (K=300), dips to ~20
volatile_high_fecundity (C)   0/12        ~520-680 (K=700), boom-bust
legacy_aom_reference          0/12        ~290-380 (K=400)
============================  ==========  ==================================

Preset B is intended to be the demanding ecology, and its trajectories show
deep bottlenecks (populations dipping to roughly twenty individuals) without
reliably going extinct. Pushing its mortality only slightly higher tips it into
frequent extinction, which is a property of the scenario rather than a defect;
users exploring that region should expect it.

These values were re-verified after the task exposure multiplier
(``predation_multiplier``) was connected to the mortality calculation, which
raised realised hazard across every scenario.
"""

from __future__ import annotations

from ..tasks.defaults import default_domains, default_tasks
from .enums import (  # noqa: F401
    AgeHazardShape,
    EnvProcess,
    FertilityDistribution,
    FounderAgeDistribution,
    InheritanceModel,
    MateSelection,
    MatingMode,
    MutationLevel,
    ReproductionMode,
    ReproductionTiming,
    SuccessDefinition,
)
from .models import (
    ChoiceConfig,
    CognitionConfig,
    EnvVariableConfig,
    ExperimentConfig,
    HomeostasisConfig,
    InheritanceConfig,
    LifecycleConfig,
    MortalityConfig,
    OutputConfig,
    PopulationConfig,
    ReproductionConfig,
    ScenarioConfig,
)

PRESET_IDS = [
    "stable_abundant",
    "scarce_low_fecundity",
    "volatile_high_fecundity",
    "legacy_aom_reference",
    "pair_bonded_humanlike",
    "competitive_skew",
    "asexual_clonal",
    "stable_abundant_legacy",
    "scarce_low_fecundity_legacy",
    "volatile_high_fecundity_legacy",
]

PRESET_DESCRIPTIONS = {
    "stable_abundant":
        "Stable, resource-abundant ecology. Low extinction risk, slower "
        "selection, some neutral behaviour persists. Theoretical demo only.",
    "scarce_low_fecundity":
        "Resource-scarce, low-fecundity ecology. Strong selection on food "
        "allocation, higher extinction risk, costly errors. Theoretical demo only.",
    "volatile_high_fecundity":
        "Volatile boom-bust, high-fecundity ecology. Rapid expansion and "
        "collapse, high variance, forecasting may lag. Theoretical demo only.",
    "legacy_aom_reference":
        "Legacy AOM 2.1 reference scenario for continuity: ~200 agents, three "
        "tasks (T3 survival-irrelevant), changing environment. Recorded values "
        "are mean inherited propensity, not realised energy allocation.",
    "pair_bonded_humanlike":
        "Social monogamy with moderate mate choice. A simplified abstract "
        "approximation, not a model of any real human society.",
    "competitive_skew":
        "Strong mate choice without persistent bonds, concentrating "
        "reproductive success. Compare opportunity for selection against "
        "random mating.",
    "asexual_clonal":
        "Asexual reproduction: no partner required, clonal inheritance apart "
        "from mutation. A control for the contribution of recombination.",
    "stable_abundant_legacy":
        "Stable and abundant with pre-schema-2 mechanics (season-end batch "
        "reproduction, newborn founders, legacy inheritance).",
    "scarce_low_fecundity_legacy":
        "Scarce and low-fecundity with pre-schema-2 mechanics.",
    "volatile_high_fecundity_legacy":
        "Volatile boom-bust with pre-schema-2 mechanics.",
}


def _std_environment(food_mean: float, food_persist: float, food_vol: float,
                     pred_mean: float, pred_persist: float, pred_vol: float,
                     pred_shock_p: float, mate_mean: float, mate_persist: float,
                     food_shock_p: float = 0.0,
                     food_process: EnvProcess = EnvProcess.AR1) -> list[EnvVariableConfig]:
    return [
        EnvVariableConfig(
            var_id="food", name="Food availability", process=food_process,
            initial_value=food_mean, mean=food_mean, persistence=food_persist,
            volatility=food_vol, shock_probability=food_shock_p,
            shock_magnitude=-0.3, shock_duration_steps=3, observation_noise=0.05),
        EnvVariableConfig(
            var_id="predator", name="Predator pressure", process=EnvProcess.AR1,
            initial_value=pred_mean, mean=pred_mean, persistence=pred_persist,
            volatility=pred_vol, shock_probability=pred_shock_p,
            shock_magnitude=0.3, shock_duration_steps=2, observation_noise=0.08),
        EnvVariableConfig(
            var_id="mate", name="Mate availability", process=EnvProcess.AR1,
            initial_value=mate_mean, mean=mate_mean, persistence=mate_persist,
            volatility=0.02, observation_noise=0.05),
    ]


def preset_stable_abundant() -> ScenarioConfig:
    return ScenarioConfig(
        name="Preset A: Stable and Resource-Abundant",
        description=PRESET_DESCRIPTIONS["stable_abundant"],
        preset_origin="stable_abundant", master_seed=12345,
        domains=default_domains(), tasks=default_tasks(True),
        environment=_std_environment(
            food_mean=0.80, food_persist=0.97, food_vol=0.03,
            pred_mean=0.20, pred_persist=0.70, pred_vol=0.05, pred_shock_p=0.01,
            mate_mean=0.70, mate_persist=0.99),
        population=PopulationConfig(initial_population=200, carrying_capacity=500,
                                    max_population=3000),
        lifecycle=LifecycleConfig(steps_per_season=40, total_seasons=30,
                                  initial_energy=70, initial_health=90,
                                  basal_metabolism=1.0, maturity_seasons=2,
                                  max_lifespan_seasons=12),
        mortality=MortalityConfig(base_predation_hazard=0.0015,
                                  age_hazard_shape=AgeHazardShape.GOMPERTZ,
                                  age_hazard_scale=0.0008, age_hazard_rate=0.12,
                                  juvenile_extra_hazard=0.003,
                                  density_hazard_strength=0.4),
        reproduction=ReproductionConfig(
            fertility_distribution=FertilityDistribution.POISSON,
            fertility_mean=1.5, max_offspring_per_event=3,
            reproductive_event_rate=1.7,
            energy_threshold=40, health_threshold=30,
            mate_selection=MateSelection.WEIGHTED_CAPITAL,
            repro_energy_cost=20, repro_health_cost=5, juvenile_survival=0.85,
            density_dependent_recruitment=True, recruitment_strength=1.0),
        inheritance=InheritanceConfig(mutation_probability=1.0, mutation_log_sd=0.10),
        homeostasis=HomeostasisConfig(enabled=True),
        cognition=CognitionConfig(),  # off in scientific baseline
        choice=ChoiceConfig(), experiment=ExperimentConfig(), output=OutputConfig(),
    )


def preset_scarce_low_fecundity() -> ScenarioConfig:
    return ScenarioConfig(
        name="Preset B: Resource-Scarce and Low-Fecundity",
        description=PRESET_DESCRIPTIONS["scarce_low_fecundity"],
        preset_origin="scarce_low_fecundity", master_seed=22345,
        domains=default_domains(), tasks=default_tasks(True),
        environment=_std_environment(
            food_mean=0.45, food_persist=0.96, food_vol=0.05,
            pred_mean=0.48, pred_persist=0.65, pred_vol=0.08, pred_shock_p=0.02,
            mate_mean=0.65, mate_persist=0.98),
        population=PopulationConfig(initial_population=180, carrying_capacity=300,
                                    max_population=2000),
        lifecycle=LifecycleConfig(steps_per_season=40, total_seasons=40,
                                  initial_energy=60, initial_health=90,
                                  basal_metabolism=0.8, maturity_seasons=2,
                                  max_lifespan_seasons=10),
        mortality=MortalityConfig(base_predation_hazard=0.0009,
                                  age_hazard_scale=0.001, age_hazard_rate=0.15,
                                  juvenile_extra_hazard=0.002,
                                  density_hazard_strength=0.9),
        reproduction=ReproductionConfig(
            fertility_distribution=FertilityDistribution.POISSON,
            fertility_mean=2.0, max_offspring_per_event=3,
            reproductive_event_rate=1.9,
            energy_threshold=40, health_threshold=35,
            mate_selection=MateSelection.COMPETITIVE,
            repro_energy_cost=25, repro_health_cost=8, juvenile_survival=0.80,
            density_dependent_recruitment=True, recruitment_strength=0.6),
        inheritance=InheritanceConfig(mutation_probability=1.0, mutation_log_sd=0.10),
        homeostasis=HomeostasisConfig(enabled=True, hunger_strength=3.0),
        cognition=CognitionConfig(),
        choice=ChoiceConfig(), experiment=ExperimentConfig(), output=OutputConfig(),
    )


def preset_volatile_high_fecundity() -> ScenarioConfig:
    return ScenarioConfig(
        name="Preset C: Volatile Boom-Bust and High-Fecundity",
        description=PRESET_DESCRIPTIONS["volatile_high_fecundity"],
        preset_origin="volatile_high_fecundity", master_seed=32345,
        domains=default_domains(), tasks=default_tasks(True),
        environment=_std_environment(
            food_mean=0.55, food_persist=0.50, food_vol=0.18, food_shock_p=0.05,
            food_process=EnvProcess.RARE_SHOCKS,
            pred_mean=0.52, pred_persist=0.40, pred_vol=0.20, pred_shock_p=0.08,
            mate_mean=0.65, mate_persist=0.97),
        population=PopulationConfig(initial_population=250, carrying_capacity=700,
                                    max_population=4000),
        lifecycle=LifecycleConfig(steps_per_season=30, total_seasons=35,
                                  initial_energy=65, initial_health=90,
                                  basal_metabolism=1.1, maturity_seasons=1,
                                  max_lifespan_seasons=7),
        mortality=MortalityConfig(base_predation_hazard=0.002,
                                  age_hazard_scale=0.0012, age_hazard_rate=0.22,
                                  juvenile_extra_hazard=0.008,
                                  density_hazard_strength=1.5),
        reproduction=ReproductionConfig(
            fertility_distribution=FertilityDistribution.POISSON,
            fertility_mean=3.2, max_offspring_per_event=6,
            reproductive_event_rate=2.2,
            energy_threshold=40, health_threshold=30,
            mate_selection=MateSelection.WEIGHTED_CAPITAL,
            repro_energy_cost=18, repro_health_cost=6, juvenile_survival=0.6,
            density_dependent_recruitment=True, recruitment_strength=2.0),
        inheritance=InheritanceConfig(mutation_probability=1.0, mutation_log_sd=0.12),
        homeostasis=HomeostasisConfig(enabled=True),
        cognition=CognitionConfig(),
        choice=ChoiceConfig(), experiment=ExperimentConfig(), output=OutputConfig(),
    )


def preset_legacy_aom_reference() -> ScenarioConfig:
    """A life-history scenario echoing the AOM 2.1 reference characteristics.

    This is a *continuity* scenario in the new engine, not a byte-for-byte
    reproduction of the original generational model. For the original one-action
    per-generation dynamics use ``legacy.aom_adapter`` instead.
    """

    from ..tasks.defaults import DOMAIN_FOOD, DOMAIN_NEUTRAL
    from .enums import EffectCondition, EffectTarget, EffectType, TaskRole
    from .models import DomainConfig, TaskConfig, TaskEffectRule

    domains = [
        DomainConfig(domain_id=DOMAIN_FOOD, name="Food"),
        DomainConfig(domain_id=DOMAIN_NEUTRAL, name="Neutral"),
    ]
    tasks = [
        TaskConfig(task_id="task1", name="Task 1 (survival-relevant)",
                   domain=DOMAIN_FOOD, energy_cost=1.0, base_success=0.3,
                   success_env_driver="food", success_env_sensitivity=3.0,
                   role=TaskRole.FUNCTIONAL,
                   effects=[TaskEffectRule(target=EffectTarget.ENERGY,
                                           effect_type=EffectType.ADDITIVE,
                                           base_value=10.0,
                                           condition=EffectCondition.ON_SUCCESS)]),
        TaskConfig(task_id="task2", name="Task 2 (survival-relevant)",
                   domain=DOMAIN_FOOD, energy_cost=1.0, base_success=0.3,
                   success_env_driver="food2", success_env_sensitivity=3.0,
                   role=TaskRole.FUNCTIONAL,
                   effects=[TaskEffectRule(target=EffectTarget.ENERGY,
                                           effect_type=EffectType.ADDITIVE,
                                           base_value=10.0,
                                           condition=EffectCondition.ON_SUCCESS)]),
        TaskConfig(task_id="task3", name="Task 3 (survival-irrelevant)",
                   domain=DOMAIN_NEUTRAL, energy_cost=1.0, base_success=1.0,
                   role=TaskRole.COSTLY_NONFUNCTIONAL, memory_eligible=True,
                   effects=[]),
    ]
    env = [
        EnvVariableConfig(var_id="food", name="Food driver 1",
                          process=EnvProcess.RANDOM_WALK, initial_value=0.7,
                          mean=0.7, persistence=0.9, volatility=0.05),
        EnvVariableConfig(var_id="food2", name="Food driver 2",
                          process=EnvProcess.RANDOM_WALK, initial_value=0.3,
                          mean=0.3, persistence=0.9, volatility=0.05),
    ]
    return ScenarioConfig(
        name="Legacy AOM 2.1 reference",
        description=PRESET_DESCRIPTIONS["legacy_aom_reference"],
        preset_origin="legacy_aom_reference", master_seed=42,
        domains=domains, tasks=tasks, environment=env,
        population=PopulationConfig(initial_population=200, carrying_capacity=400,
                                    max_population=1500),
        lifecycle=LifecycleConfig(steps_per_season=40, total_seasons=30,
                                  maturity_seasons=1, max_lifespan_seasons=8),
        mortality=MortalityConfig(predation_env_driver=None,
                                  base_predation_hazard=0.004),
        reproduction=ReproductionConfig(mate_availability_driver=None,
                                        fertility_mean=1.5),
        cognition=CognitionConfig(experience_enabled=False,
                                  experience_strength=2.5,
                                  experience_success_definition=SuccessDefinition.SURVIVED),
    )



# ---------------------------------------------------------------------------
# Mating-system and inheritance demonstration presets (schema 2)
# ---------------------------------------------------------------------------
def _derive(base_id: str, *, name: str, description: str, **overrides):
    """Build a variant of an existing preset by overriding a few fields."""

    scenario = _PRESET_FACTORIES[base_id]()
    scenario.name = name
    scenario.description = description
    scenario.preset_origin = None
    for path, value in overrides.items():
        section, _, field = path.partition(".")
        setattr(getattr(scenario, section), field, value)
    return scenario


def preset_pair_bonded_humanlike() -> ScenarioConfig:
    """Social monogamy with modest mate choice.

    A simplified, abstract approximation only. Roughly 9% of mammal species are
    socially monogamous, and human sexual dimorphism sits between monogamous and
    highly polygynous species, implying mixed strategies (Lukas & Clutton-Brock
    2013). This preset therefore pairs social monogamy with a low dissolution
    rate and moderate choosiness. It is **not** a model of any real human
    society, and contains no household, parental-care, or marriage structure.
    """

    return _derive(
        "stable_abundant",
        name="Pair-Bonded (Human-Like Approximation)",
        description=(
            "Social monogamy: exclusive persistent bonds, moderate mate choice, "
            "occasional dissolution. An abstract approximation for teaching and "
            "comparison, not a model of any real human society."),
        **{"reproduction.mating_mode": MatingMode.PAIR_BONDED,
           "reproduction.mate_choice_k": 5,
           # Higher than the random-mating presets because a bonded pair makes
           # one reproductive attempt per step rather than two initiators each
           # making their own, and because both partners must clear the
           # condition thresholds simultaneously.
           "reproduction.reproductive_event_rate": 9.0,
           "reproduction.bond_formation_per_season": 4.0,
           "reproduction.bond_dissolution_per_season": 0.05,
           "population.founder_age_distribution": FounderAgeDistribution.STABLE})


def preset_competitive_skew() -> ScenarioConfig:
    """Strong reproductive skew through mate choice."""

    return _derive(
        "stable_abundant",
        name="Competitive / Open Mating",
        description=(
            "Polygyny-like reproductive skew: no persistent bonds and strong "
            "mate choice, so reproductive success concentrates among "
            "higher-quality agents. Compare the opportunity for selection "
            "against the random-mating preset."),
        **{"reproduction.mating_mode": MatingMode.COMPETITIVE,
           "reproduction.mate_choice_k": 25,
           # Status is not depleted by breeding, so choosing on it produces
           # persistent skew. Weighting reproductive capital instead would
           # equalise reproductive success, because capital is reset whenever
           # an agent breeds. See ADR-004.
           "reproduction.mate_quality_weights": {
               "status": 1.0, "repro_capital": 0.0,
               "health": 0.0, "energy": 0.0}})


def preset_asexual_clonal() -> ScenarioConfig:
    """Asexual reproduction: no partner required, clonal inheritance."""

    return _derive(
        "stable_abundant",
        name="Asexual (Clonal)",
        description=(
            "Asexual reproduction. No Type-A/Type-B matching, no segregation: "
            "offspring inherit the parental latent propensities exactly apart "
            "from rare mutation. A control for the contribution of sexual "
            "recombination."),
        **{"reproduction.mode": ReproductionMode.ASEXUAL,
           "inheritance.mutation_level": MutationLevel.ACCELERATED})


def _legacy_variant(base_id: str, label: str) -> ScenarioConfig:
    """Pre-schema-2 mechanics, for comparison against the new defaults."""

    return _derive(
        base_id,
        name=f"{label} (Legacy Mechanics)",
        description=(
            "Season-end batch reproduction, all founders newborn, and the "
            "v0.1.0 inheritance model. Provided so that results produced before "
            "schema 2 can be reproduced and compared. Not recommended for new "
            "work: season-end batching produces a season-period sawtooth in "
            "population size."),
        **{"reproduction.timing": ReproductionTiming.SEASON_END_LEGACY,
           "population.founder_age_distribution":
               FounderAgeDistribution.ALL_NEWBORN_LEGACY,
           "inheritance.model": InheritanceModel.LEGACY})


def preset_stable_abundant_legacy() -> ScenarioConfig:
    return _legacy_variant("stable_abundant", "Stable and Abundant")


def preset_scarce_low_fecundity_legacy() -> ScenarioConfig:
    return _legacy_variant("scarce_low_fecundity", "Scarce and Low-Fecundity")


def preset_volatile_high_fecundity_legacy() -> ScenarioConfig:
    return _legacy_variant("volatile_high_fecundity", "Volatile Boom-Bust")


_PRESET_FACTORIES = {
    "stable_abundant": preset_stable_abundant,
    "scarce_low_fecundity": preset_scarce_low_fecundity,
    "volatile_high_fecundity": preset_volatile_high_fecundity,
    "legacy_aom_reference": preset_legacy_aom_reference,
    "pair_bonded_humanlike": preset_pair_bonded_humanlike,
    "competitive_skew": preset_competitive_skew,
    "asexual_clonal": preset_asexual_clonal,
    "stable_abundant_legacy": preset_stable_abundant_legacy,
    "scarce_low_fecundity_legacy": preset_scarce_low_fecundity_legacy,
    "volatile_high_fecundity_legacy": preset_volatile_high_fecundity_legacy,
}


def load_preset(preset_id: str) -> ScenarioConfig:
    """Return a fresh :class:`ScenarioConfig` for ``preset_id``."""

    if preset_id not in _PRESET_FACTORIES:
        raise KeyError(
            f"Unknown preset '{preset_id}'. Available: {list(_PRESET_FACTORIES)}")
    return _PRESET_FACTORIES[preset_id]()


def all_presets() -> dict[str, ScenarioConfig]:
    return {pid: factory() for pid, factory in _PRESET_FACTORIES.items()}


__all__ = [
    "PRESET_IDS", "PRESET_DESCRIPTIONS", "load_preset", "all_presets",
    "preset_stable_abundant", "preset_scarce_low_fecundity",
    "preset_volatile_high_fecundity", "preset_legacy_aom_reference",
]

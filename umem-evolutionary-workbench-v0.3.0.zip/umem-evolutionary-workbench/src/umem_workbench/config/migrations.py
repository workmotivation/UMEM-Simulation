"""Forward migration of older scenario dictionaries to the current schema.

Each migration is a function ``dict -> dict`` that upgrades a scenario by exactly
one schema version. :func:`migrate_scenario_dict` chains them. This keeps old
saved scenarios loadable as the schema evolves.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from ..version import SCHEMA_VERSION


def _migrate_0_to_1(data: dict[str, Any]) -> dict[str, Any]:
    """Example migration: a pre-versioned scenario becomes schema v1.

    A version-0 scenario is any dict lacking ``schema_version``. We simply stamp
    it as v1; this exists so that at least one migration path is exercised by
    the test-suite and so the mechanism is in place for future changes.
    """

    data = dict(data)
    data["schema_version"] = 1
    return data


def _migrate_1_to_2(data: dict[str, Any]) -> dict[str, Any]:
    """Schema 1 -> 2: reproduction timing, mate choice, and inheritance model.

    Schema 2 changes three defaults that alter scientific meaning: reproduction
    becomes continuous, founders start with a dispersed age structure, and
    inheritance uses the polygenic additive model. A scenario written before
    schema 2 was authored under the old assumptions, so it is migrated to the
    **legacy** value of each, never silently opted into the new mechanism.

    Fields that do not change meaning are left to their model defaults.
    """

    data = dict(data)

    repro = dict(data.get("reproduction") or {})
    repro.setdefault("timing", "season_end_legacy")
    if "expected_births_per_season" in repro:
        repro.setdefault("reproductive_event_rate",
                         repro.pop("expected_births_per_season"))
    data["reproduction"] = repro

    population = dict(data.get("population") or {})
    population.setdefault("founder_age_distribution", "all_newborn_legacy")
    data["population"] = population

    inheritance = dict(data.get("inheritance") or {})
    inheritance.setdefault("model", "legacy")
    data["inheritance"] = inheritance

    data["schema_version"] = 2
    return data


# Registry keyed by the *source* version each migration upgrades from.
_MIGRATIONS: dict[int, Callable[[dict[str, Any]], dict[str, Any]]] = {
    0: _migrate_0_to_1,
    1: _migrate_1_to_2,
}


def migrate_scenario_dict(data: dict[str, Any]) -> dict[str, Any]:
    """Upgrade ``data`` in place to :data:`SCHEMA_VERSION`."""

    version = int(data.get("schema_version", 0))
    while version < SCHEMA_VERSION:
        migrate = _MIGRATIONS.get(version)
        if migrate is None:
            raise ValueError(
                f"No migration registered from schema version {version}")
        data = migrate(data)
        version = int(data.get("schema_version", version + 1))
    if version > SCHEMA_VERSION:
        raise ValueError(
            f"Scenario schema version {version} is newer than supported "
            f"{SCHEMA_VERSION}; please upgrade the application.")
    return data


__all__ = ["migrate_scenario_dict"]

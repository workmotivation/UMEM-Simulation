"""(De)serialization of scenarios and stable configuration hashing.

JSON support is mandatory; YAML is supported when PyYAML is available. The
configuration hash is used to label runs and to detect whether two scenarios are
scientifically identical. Purely cosmetic fields (``name``, ``description``,
``preset_origin``) are excluded from the hash so that renaming a scenario does
not change its identity.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .migrations import migrate_scenario_dict
from .models import ScenarioConfig

# Cosmetic fields that do not affect the scientific meaning of a run.
_HASH_EXCLUDE = {"name", "description", "preset_origin"}


def scenario_to_dict(scenario: ScenarioConfig) -> dict[str, Any]:
    """Return a plain-dict, JSON-serializable representation."""

    return scenario.model_dump(mode="json")


def scenario_from_dict(data: dict[str, Any]) -> ScenarioConfig:
    """Validate a scenario dict, migrating older schema versions first."""

    data = migrate_scenario_dict(dict(data))
    return ScenarioConfig.model_validate(data)


def scenario_to_json(scenario: ScenarioConfig, *, indent: int = 2) -> str:
    return json.dumps(scenario_to_dict(scenario), indent=indent, sort_keys=True)


def scenario_from_json(text: str) -> ScenarioConfig:
    return scenario_from_dict(json.loads(text))


def save_scenario_json(scenario: ScenarioConfig, path: str | Path) -> None:
    Path(path).write_text(scenario_to_json(scenario), encoding="utf-8")


def load_scenario_json(path: str | Path) -> ScenarioConfig:
    return scenario_from_json(Path(path).read_text(encoding="utf-8"))


def save_scenario_yaml(scenario: ScenarioConfig, path: str | Path) -> None:
    import yaml  # optional dependency

    Path(path).write_text(
        yaml.safe_dump(scenario_to_dict(scenario), sort_keys=True),
        encoding="utf-8",
    )


def load_scenario_yaml(path: str | Path) -> ScenarioConfig:
    import yaml  # optional dependency

    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return scenario_from_dict(data)


def _canonical_for_hash(data: dict[str, Any]) -> dict[str, Any]:
    """Strip cosmetic fields for stable hashing."""

    return {k: v for k, v in data.items() if k not in _HASH_EXCLUDE}


def config_hash(scenario: ScenarioConfig) -> str:
    """Deterministic SHA-256 hash of the scientific configuration.

    Independent of field ordering and of cosmetic metadata. Two scenarios that
    differ only by name/description share a hash.
    """

    canonical = _canonical_for_hash(scenario_to_dict(scenario))
    blob = json.dumps(canonical, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


__all__ = [
    "scenario_to_dict", "scenario_from_dict", "scenario_to_json",
    "scenario_from_json", "save_scenario_json", "load_scenario_json",
    "save_scenario_yaml", "load_scenario_yaml", "config_hash",
]

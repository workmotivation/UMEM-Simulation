"""Deterministic fingerprints for the guide/report contract.

A fingerprint changes when — and only when — the authoritative registries it
covers change. Guides and reports embed these so an external AI (or a test) can
tell whether a guide was generated from the same definitions as the report it
is being asked to interpret.
"""

from __future__ import annotations

import hashlib
import json

from ..config.data_dictionary import build_dictionary
from ..version import SCHEMA_VERSION, __version__
from .registry import REGISTRY_FORMAT_VERSION, registry_as_dicts

__all__ = ["dictionary_fingerprint", "output_registry_fingerprint",
           "contract_header", "GUIDE_FORMAT_VERSION", "REPORT_FORMAT_VERSION"]

#: Bumped when the *structure* of the generated guides or reports changes in a
#: way an external AI must be told about (new sections, renamed table IDs).
GUIDE_FORMAT_VERSION = "1.0"
REPORT_FORMAT_VERSION = "1.0"


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def dictionary_fingerprint() -> str:
    """Fingerprint of the configuration data dictionary (inputs)."""

    # Exclude free-text prose so a wording fix does not look like a schema change.
    entries = build_dictionary()
    core = [{k: v for k, v in e.__dict__.items()
             if k not in ("description", "interpretation", "label", "reference")}
            for e in entries]
    return _sha(json.dumps(core, sort_keys=True, default=str))


def output_registry_fingerprint() -> str:
    """Fingerprint of the output-field registry (outputs)."""

    core = []
    for table in registry_as_dicts():
        core.append({"id": table["id"], "granularity": table["granularity"],
                     "fields": [{"id": f["id"], "kind": f["kind"], "unit": f["unit"],
                                 "applies_to": f["applies_to"]} for f in table["fields"]]})
    return _sha(json.dumps(core, sort_keys=True))


def contract_header(kind: str) -> dict[str, str]:
    """Identity block placed at the top of every guide and report."""

    return {
        "application": "UMEM Evolutionary Simulation Workbench",
        "application_version": __version__,
        "config_schema_version": str(SCHEMA_VERSION),
        "document_kind": kind,
        "guide_format_version": GUIDE_FORMAT_VERSION,
        "report_format_version": REPORT_FORMAT_VERSION,
        "output_registry_format_version": REGISTRY_FORMAT_VERSION,
        "parameter_dictionary_fingerprint": dictionary_fingerprint(),
        "output_registry_fingerprint": output_registry_fingerprint(),
    }

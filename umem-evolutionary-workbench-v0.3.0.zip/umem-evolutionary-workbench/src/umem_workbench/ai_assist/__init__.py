"""External-AI assistance: guides, staged import, deterministic narrative, reports.

UMEM makes no AI API calls. Everything here runs locally and offline; the user
downloads generated text files and uploads them to an AI service of their choice.
"""

from .fingerprint import (
                     contract_header,
                     dictionary_fingerprint,
                     output_registry_fingerprint,
)
from .guides import (
                     report_interpretation_guide,
                     scenario_design_guide,
                     starter_message_design,
                     starter_message_interpret,
)
from .narrative import ExperimentDescription, describe_scenario
from .registry import OUTPUT_REGISTRY, expand_for_scenario
from .report import ReportBundle, build_ai_report
from .scenario_import import (
                     ImportIssue,
                     ImportResult,
                     diff_scenarios,
                     import_scenario_text,
                     validation_feedback_for_ai,
)

__all__ = ["scenario_design_guide", "report_interpretation_guide", "starter_message_design",
           "starter_message_interpret", "describe_scenario", "ExperimentDescription",
           "import_scenario_text", "ImportResult", "ImportIssue", "validation_feedback_for_ai",
           "diff_scenarios", "build_ai_report", "ReportBundle", "OUTPUT_REGISTRY",
           "expand_for_scenario", "contract_header", "dictionary_fingerprint",
           "output_registry_fingerprint"]

"""Deterministic natural-language description of a scenario.

This renderer is **local and rule-based**. It uses no language model and no
network. Given the same scenario it always produces the same text, so it can be
shown in the manual setup panel, in the AI-import preview (as the *proposed*
description) and inside every report, and tests can assert on it.

Design rules
------------
* Describe **actual configured semantics**, verified against the engine, not
  design intent. Example: under the polygenic model with
  ``mutation_target = both``, each offspring is tested independently in the
  domain layer and the task layer, so one offspring can carry two events.
* Describe interactions the reader is likely to misread: the reproductive event
  rate is not a birth rate; inherited propensity is not realised allocation.
* Never force every technical field into the prose. The prose covers what a
  researcher needs; the complete specification is a separate structured block.
* Every parameter must be **accounted for**: either it is mentioned in prose,
  listed in the complete specification, or reported as lacking a narrative rule.
  Silent omission is a bug.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..config.data_dictionary import build_dictionary
from ..config.enums import (
    InheritanceModel,
    MatingMode,
    ReproductionMode,
    ReproductionTiming,
    TaskRole,
)
from ..config.models import ScenarioConfig
from ..config.serialization import scenario_to_dict
from ..ui_common.labels import inactive_applicabilities

__all__ = ["ExperimentDescription", "describe_scenario", "NARRATIVE_FORMAT_VERSION"]

NARRATIVE_FORMAT_VERSION = "1.0"


@dataclass
class ExperimentDescription:
    """The rendered description plus everything needed to audit it."""

    prose_sections: dict[str, str]           # ordered section title -> paragraph
    specification: list[dict[str, Any]]      # every active field with value
    inactive_fields: list[dict[str, Any]]    # fields ignored under current mechanisms
    unusual_settings: list[str]              # human notes on non-default/odd values
    uncovered_paths: list[str]               # parameters with no narrative rule
    format_version: str = NARRATIVE_FORMAT_VERSION

    def prose(self) -> str:
        return "\n\n".join(f"**{k}.** {v}" for k, v in self.prose_sections.items())

    def markdown(self, include_specification: bool = True) -> str:
        out = ["## Experiment conditions", "", self.prose(), ""]
        if self.unusual_settings:
            out += ["### Notes on unusual or custom settings", ""]
            out += [f"- {n}" for n in self.unusual_settings] + [""]
        if include_specification:
            out += ["### Complete specification (active settings)", "",
                    "| Path | Value | Meaning |", "|---|---|---|"]
            out += [f"| `{r['path']}` | `{r['value']}` | {r['label']} |" for r in self.specification]
            out += [""]
            if self.inactive_fields:
                out += ["### Inactive settings (ignored under the current mechanisms)", "",
                        "| Path | Value | Why inactive |", "|---|---|---|"]
                out += [f"| `{r['path']}` | `{r['value']}` | {r['reason']} |" for r in self.inactive_fields]
                out += [""]
            if self.uncovered_paths:
                out += ["### Parameters without a narrative rule", "",
                        "These are listed so nothing is silently omitted:", ""]
                out += [f"- `{p}`" for p in self.uncovered_paths] + [""]
        return "\n".join(out)


# ---------------------------------------------------------------------------
def _fmt(v: Any) -> str:
    if isinstance(v, float):
        return f"{v:g}"
    if hasattr(v, "value"):
        return str(v.value)
    return str(v)


def describe_scenario(scenario: ScenarioConfig) -> ExperimentDescription:
    """Render the description. Pure function of the scenario."""

    sc = scenario
    lc, pop, mort, rc, inh, hom, cog, ch, ex, out = (
        sc.lifecycle, sc.population, sc.mortality, sc.reproduction, sc.inheritance,
        sc.homeostasis, sc.cognition, sc.choice, sc.experiment, sc.output)
    covered: set[str] = set()
    notes: list[str] = []

    def use(*paths: str) -> None:
        covered.update(paths)

    S = lc.steps_per_season
    sections: dict[str, str] = {}

    # ---- Population and time scale ----
    founder = pop.founder_age_distribution.value
    founder_txt = {
        "all_newborn_legacy": "all founders start at age zero (the legacy convention)",
        "uniform": "founder ages are spread uniformly over the permitted lifespan",
        "stable": "founder ages approximate a stable age distribution derived from the configured hazards",
    }[founder]
    sections["Population and time"] = (
        f"The simulation starts with {pop.initial_population} agents and runs for "
        f"{lc.total_seasons} seasons of {S} time steps each ({lc.total_seasons * S} steps). "
        f"Carrying capacity is {pop.carrying_capacity} agents and a hard ceiling of "
        f"{pop.max_population} prevents runaway growth. Agents mature after "
        f"{lc.maturity_seasons} season(s) and cannot live beyond {lc.max_lifespan_seasons} "
        f"seasons; {founder_txt}. Each newborn is assigned reproductive Type A with "
        f"probability {pop.sex_ratio_type_a:g} (Type A/B are neutral labels, not sexes, "
        f"and are not inherited).")
    use("population.initial_population", "lifecycle.total_seasons", "lifecycle.steps_per_season",
        "population.carrying_capacity", "population.max_population", "lifecycle.maturity_seasons",
        "lifecycle.max_lifespan_seasons", "population.founder_age_distribution",
        "population.sex_ratio_type_a", "population.init_distribution",
        "population.starting_population_file")
    if getattr(pop, "starting_population_file", None):
        notes.append(f"Founders are loaded from `{pop.starting_population_file}` rather than generated.")
    if lc.max_lifespan_seasons <= 12 and mort.age_hazard_rate < 0.25:
        notes.append("The senescence hazard rises slowly, so a noticeable share of agents "
                     "reach the hard maximum lifespan and die there together; expect a point "
                     "mass at the maximum age in lifespan histograms.")

    # ---- Environment ----
    env_parts = []
    for v in sc.environment:
        env_parts.append(f"`{v.var_id}` follows a {v.process.value} process around a mean "
                         f"of {v.mean:g} (volatility {v.volatility:g}, persistence {v.persistence:g}"
                         + (f", shock probability {v.shock_probability:g}" if v.shock_probability else "")
                         + f"), observed with noise {v.observation_noise:g}")
    sections["Environment"] = (
        "The environment is exogenous and pre-generated: it does not respond to the "
        "population, so there is no resource depletion or predator–prey feedback. "
        + ("; ".join(env_parts) + "." if env_parts else "No environmental variables are defined."))
    use("environment[].var_id", "environment[].name", "environment[].description", "environment[].process",
        "environment[].mean", "environment[].volatility", "environment[].persistence",
        "environment[].shock_probability", "environment[].observation_noise",
        "environment[].initial_value", "environment[].shock_magnitude", "environment[].min_value",
        "environment[].max_value", "environment[].seasonal_amplitude", "environment[].seasonal_period_steps",
        "environment[].shock_duration_steps", "environment[].regime_values", "environment[].regime_switch_prob",
        "environment[].imported_series", "environment[].globally_observable")

    # ---- Behaviours ----
    enabled = [t for t in sc.tasks if t.enabled]
    by_role = {r: [t for t in enabled if t.role == r] for r in TaskRole}
    domains = ", ".join(d.domain_id for d in sc.domains)
    task_txt = (f"Agents choose among {len(enabled)} enabled tasks grouped into "
                f"{len(sc.domains)} motivational domains ({domains}). "
                f"{len(by_role[TaskRole.FUNCTIONAL])} tasks confer a direct benefit; "
                f"{len(by_role[TaskRole.LOW_COST_NEUTRAL])} are low-cost neutral behaviours with no "
                f"modelled benefit, and {len(by_role[TaskRole.COSTLY_NONFUNCTIONAL])} are costly "
                f"nonfunctional behaviours that spend time or energy for no benefit. Choice is a "
                f"softmax (temperature {ch.softmax_temperature:g}) over inherited propensity, "
                f"homeostatic urgency and any enabled cognition, with decision noise "
                f"{ch.decision_noise_sd:g} and {lc.actions_per_step} action(s) per step.")
    sections["Available behaviours"] = task_txt
    use("domains[].domain_id", "domains[].name", "domains[].init_mean", "domains[].init_var",
        "tasks[].task_id", "tasks[].name", "tasks[].description", "tasks[].domain", "tasks[].role",
        "tasks[].enabled", "tasks[].energy_cost", "tasks[].time_cost", "tasks[].base_success",
        "tasks[].success_env_driver", "tasks[].success_env_sensitivity", "tasks[].outcome_noise",
        "tasks[].predation_multiplier", "tasks[].min_age_steps", "tasks[].max_age_steps", "tasks[].require_mature",
        "tasks[].sex_restriction", "tasks[].observable_to_actor", "tasks[].public_signal",
        "tasks[].memory_eligible", "tasks[].effects",
        "tasks[].effects[].target", "tasks[].effects[].effect_type", "tasks[].effects[].base_value",
        "tasks[].effects[].condition", "tasks[].effects[].env_driver", "tasks[].effects[].env_sensitivity",
        "tasks[].effects[].noise_std", "tasks[].effects[].min_age_steps", "tasks[].effects[].require_mature",
        "tasks[].effects[].sex_restriction",
        "choice.softmax_temperature", "choice.decision_noise_sd", "lifecycle.actions_per_step")

    # ---- Survival ----
    sections["Survival constraints"] = (
        f"Every step each agent pays basal metabolism {lc.basal_metabolism:g} energy (plus "
        f"{lc.rest_energy_cost:g} when it cannot act); at zero energy it loses "
        f"{lc.health_starvation_penalty:g} health per step and dies when health reaches zero. "
        f"Stochastic hazards act every step and combine as competing risks: a base predation "
        f"hazard of {mort.base_predation_hazard:g} per step scaled by the predator variable and "
        f"by the chosen task's exposure multiplier; a {mort.age_hazard_shape.value} senescence "
        f"hazard (scale {mort.age_hazard_scale:g}, rate {mort.age_hazard_rate:g}); a background "
        f"hazard of {mort.background_hazard:g}; an extra {mort.juvenile_extra_hazard:g} for "
        f"juveniles; and a crowding hazard that switches on above "
        f"{mort.density_onset_fraction:g} of carrying capacity (strength "
        f"{mort.density_hazard_strength:g}). Homeostasis is {'enabled' if hom.enabled else 'disabled'}"
        + (": " + ", ".join(p for p in (
               f"hunger (strength {hom.hunger_strength:g})" if hom.hunger_enabled else "",
               f"threat/safety (strength {hom.safety_strength:g})" if hom.safety_enabled else "",
               f"reproductive readiness (strength {hom.reproduction_strength:g})" if hom.reproduction_enabled else "") if p)
           + " shift task choice. This is physiological regulation, not cognition." if hom.enabled else "."))
    use("lifecycle.basal_metabolism", "lifecycle.rest_energy_cost", "lifecycle.health_starvation_penalty",
        "lifecycle.initial_energy", "lifecycle.initial_health", "lifecycle.initial_repro_capital",
        "lifecycle.initial_status", "lifecycle.energy_max", "lifecycle.health_max",
        "lifecycle.repro_capital_max", "lifecycle.status_max", "lifecycle.newborns_act_next_step",
        "mortality.base_predation_hazard", "mortality.predation_env_driver", "mortality.predation_env_sensitivity",
        "mortality.age_hazard_shape", "mortality.age_hazard_scale", "mortality.age_hazard_rate",
        "mortality.background_hazard", "mortality.juvenile_extra_hazard", "mortality.density_hazard_strength",
        "mortality.density_onset_fraction", "mortality.density_affects_juveniles_only",
        "homeostasis.enabled", "homeostasis.hunger_enabled", "homeostasis.hunger_strength",
        "homeostasis.safety_enabled", "homeostasis.safety_strength",
        "homeostasis.reproduction_enabled", "homeostasis.reproduction_strength")

    # ---- Reproduction ----
    distributed = rc.timing == ReproductionTiming.DISTRIBUTED
    asexual = rc.mode == ReproductionMode.ASEXUAL
    elig = (f"An agent is eligible to reproduce when mature, with energy ≥ {rc.energy_threshold:g}, "
            f"health ≥ {rc.health_threshold:g} and reproductive capital ≥ {rc.repro_capital_threshold:g}")
    if distributed:
        timing_txt = (f"Reproduction is continuous: every time step is an opportunity. Eligible agents "
                      f"initiate reproductive attempts at a rate of {rc.reproductive_event_rate:g} per "
                      f"season (a per-step hazard of {1 - 2.718281828 ** (-rc.reproductive_event_rate / S):.4f}). "
                      f"This is an attempt-event rate, not a birth rate: realised births also depend on "
                      f"finding a partner, the fertility draw and juvenile recruitment. "
                      + (f"After a successful event an agent waits {rc.refractory_seasons:g} season(s) "
                         f"before trying again; failed attempts cost nothing." if rc.refractory_seasons
                         else "There is no refractory period; failed attempts cost nothing."))
    else:
        timing_txt = (f"Reproduction uses the legacy season-end schedule: all eligible agents breed together "
                      f"on the last step of every {rc.breeding_every_seasons} season(s)"
                      + (f", with offspring appearing {rc.gestation_delay_steps} steps later" if rc.gestation_delay_steps else "")
                      + ". This is a compatibility mode and produces a season-period sawtooth in population size.")
    if asexual:
        mating_txt = ("Reproduction is asexual: no partner is required and each eligible agent reproduces "
                      "alone. Mating settings are inactive.")
    else:
        mode = rc.mating_mode
        if mode == MatingMode.RANDOM:
            mating_txt = ("Mating is random mixing (promiscuity): an initiating agent takes any available "
                          "eligible partner of the complementary type without preference.")
        elif mode == MatingMode.PAIR_BONDED:
            mating_txt = (f"Mating is pair-bonded (social monogamy): mature agents form exclusive one-to-one "
                          f"bonds at a rate of {rc.bond_formation_per_season:g} per season, choosing among "
                          f"{rc.mate_choice_k} candidate(s) by {rc.mate_choice_criterion.value.replace('_', ' ')}. "
                          f"Bonds persist until a partner dies"
                          + (f" or dissolve at {rc.bond_dissolution_per_season:g} per season" if rc.bond_dissolution_per_season else "")
                          + ". Bond formation requires maturity only; a bonded pair reproduces only when both "
                          "partners meet the eligibility thresholds in the same step, so its realised rate is "
                          "well below the configured event rate.")
        else:
            mating_txt = (f"Mating is competitive: initiators inspect {rc.mate_choice_k} candidates and take "
                          f"the best by {rc.mate_choice_criterion.value.replace('_', ' ')} (weights "
                          + ", ".join(f"{k} {v:g}" for k, v in rc.mate_quality_weights.items() if v)
                          + "), with no persistent bonds, so reproductive success concentrates on higher-quality agents.")
        mating_txt += (f" Each event requires one Type A and one Type B parent. Parental costs are symmetric "
                       f"({rc.repro_energy_cost:g} energy, {rc.repro_health_cost:g} health each) and both "
                       f"contribute equally to offspring.")
    fert = (f"Each successful event yields a {rc.fertility_distribution.value} fertility draw with mean "
            f"{rc.fertility_mean:g} (at most {rc.max_offspring_per_event}); each offspring survives recruitment "
            f"with probability {rc.juvenile_survival:g}"
            + (f", reduced by Beverton–Holt density dependence (strength {rc.recruitment_strength:g}) as the "
               f"population approaches carrying capacity." if rc.density_dependent_recruitment else "."))
    sections["Reproduction"] = f"{elig}. {timing_txt} {mating_txt} {fert}"
    use("reproduction.mode", "reproduction.timing", "reproduction.reproductive_event_rate", "reproduction.refractory_seasons",
        "reproduction.mating_mode", "reproduction.mate_choice_k", "reproduction.mate_choice_criterion",
        "reproduction.mate_quality_weights", "reproduction.bond_formation_per_season", "reproduction.bond_dissolution_per_season",
        "reproduction.breeding_every_seasons", "reproduction.gestation_delay_steps", "reproduction.energy_threshold",
        "reproduction.health_threshold", "reproduction.repro_capital_threshold", "reproduction.mate_selection",
        "reproduction.fertility_distribution", "reproduction.fertility_mean", "reproduction.fertility_p",
        "reproduction.fertility_discrete_pmf", "reproduction.max_offspring_per_event", "reproduction.repro_energy_cost",
        "reproduction.repro_health_cost", "reproduction.juvenile_survival", "reproduction.density_dependent_recruitment",
        "reproduction.recruitment_strength", "reproduction.fertility_binomial_p",
        "reproduction.mate_availability_driver")
    if getattr(rc, "mate_availability_driver", None):
        notes.append(f"Mate availability is scaled by the environmental variable `{rc.mate_availability_driver}`.")
    if not asexual and rc.mating_mode == MatingMode.COMPETITIVE and rc.mate_quality_weights.get("repro_capital", 0) > rc.mate_quality_weights.get("status", 0):
        notes.append("Mate quality is weighted mainly on reproductive capital, which is reset when an agent "
                     "breeds; this tends to equalise rather than concentrate reproductive success.")

    # ---- Inheritance ----
    if inh.model == InheritanceModel.POLYGENIC_ADDITIVE:
        seg = ("Asexual offspring are clonal copies of the parent's latent values (no segregation)."
               if asexual else
               f"Each offspring's latent value is the mid-parent value plus an independent Mendelian "
               f"segregation term whose variance is {inh.segregation_multiplier:g} × V₀/2, where V₀ is the "
               f"configured founder variance (sibling variation: {inh.sibling_variation.value}); at 1.0 the "
               f"founder variance is the neutral equilibrium.")
        if inh.mutation_probability_per_offspring > 0 and inh.mutation_effect_sd_latent > 0:
            layers = {"domain": "the domain layer only", "task": "the task layer only",
                      "both": "the domain layer and the task layer, tested independently, so one offspring can carry up to two events"}[inh.mutation_target.value]
            mut = (f"Mutation ({inh.mutation_level.value}) is a separate rare event: with probability "
                   f"{inh.mutation_probability_per_offspring:g} per offspring in {layers}, one randomly chosen "
                   f"component receives a zero-mean shift of standard deviation {inh.mutation_effect_sd_latent:g} "
                   f"in latent (log-ratio) units. These are effective simulation parameters, not human mutation rates.")
        else:
            mut = "Mutation is disabled, so no new genetic variation arises during the run."
        sections["Inheritance and mutation"] = (
            "Motivational propensities are heritable polygenic quantitative traits on a latent scale, "
            "expressed as proportions that sum to one within the domain layer and within each domain's "
            f"tasks; they are not identified genes. {seg} {mut}")
    else:
        sections["Inheritance and mutation"] = (
            "Inheritance uses the legacy v0.1.0 mechanism: each trait is "
            + ("taken from one parent chosen at random" if inh.recombination_per_trait else f"blended with weight {inh.blend_alpha:g} on parent A")
            + f", then multiplied by a log-normal mutation factor (sd {inh.mutation_log_sd:g}) with probability "
            f"{inh.mutation_probability:g}, floored at {inh.min_propensity:g}. Segregation and mutation are not "
            "separated in this model.")
    use("inheritance.model", "inheritance.sibling_variation", "inheritance.segregation_multiplier", "inheritance.mutation_level",
        "inheritance.mutation_probability_per_offspring", "inheritance.mutation_effect_sd_latent", "inheritance.mutation_target",
        "inheritance.mutation_probability", "inheritance.mutation_log_sd", "inheritance.recombination_per_trait",
        "inheritance.blend_alpha", "inheritance.min_propensity")

    # ---- Cognition ----
    cparts = []
    if cog.experience_enabled:
        cparts.append(f"intergenerational experience (A): a population-shared memory of which tasks successful "
                      f"agents ({cog.experience_success_definition.value}) performed, refreshed each season with "
                      f"strength {cog.experience_strength:g} and noise {cog.experience_noise_sd:g}; the association "
                      f"is correlational and is the main route to misallocation")
    if cog.forecast_enabled:
        cparts.append(f"environmental forecasting (B): a shared exponentially weighted forecast (memory {cog.forecast_memory:g}) "
                      f"built only from past noisy observations, strength {cog.forecast_strength:g}")
    if cog.individual_learning_enabled:
        cparts.append(f"individual learning (C): per-agent reinforcement from own outcomes, rate "
                      f"{cog.individual_learning_rate:g}, strength {cog.individual_learning_strength:g}")
    sections["Cognition"] = (
        ("Cognitive mechanisms enabled: " + "; ".join(cparts) + ". None of these implies consciousness or intention.")
        if cparts else
        "All cognitive mechanisms are disabled: behaviour is driven only by inherited propensity, homeostasis and noise (a pure evolutionary baseline).")
    use("cognition.experience_enabled", "cognition.experience_strength", "cognition.experience_noise_sd",
        "cognition.experience_weight_recent", "cognition.experience_smoothing",
        "cognition.experience_success_definition", "cognition.experience_top_quantile",
        "cognition.forecast_enabled", "cognition.forecast_memory", "cognition.forecast_strength",
        "cognition.individual_learning_enabled", "cognition.individual_learning_rate",
        "cognition.individual_learning_strength")

    # ---- Experiment design ----
    mode = ex.mode.value
    if mode == "single":
        design = "A single run. One trajectory is descriptive only and cannot support conclusions; use replications for inference."
    elif mode == "replications":
        design = (f"{ex.replications} independent replications sharing the master seed but using different random "
                  f"substreams; run in parallel with up to {ex.max_workers} worker(s). Results are reproducible and "
                  f"worker count does not affect them.")
    else:
        params = "; ".join(f"`{p.path}` over {p.resolved_values()}" for p in ex.sweep_parameters)
        design = (f"A parameter sweep over {params}, with {ex.replications} replication(s) per cell"
                  + (", using common random numbers across cells (paired design)" if ex.common_random_numbers else "")
                  + ".")
    sections["Experiment design"] = (
        f"{design} Master seed {sc.master_seed}. Fitness is realised lifetime reproductive success, an outcome, "
        f"not a score imposed on agents.")
    use("master_seed", "experiment.mode", "experiment.replications", "experiment.max_workers", "experiment.common_random_numbers",
        "experiment.sweep_parameters", "experiment.sweep_parameters[].path", "experiment.sweep_parameters[].values",
        "experiment.sweep_parameters[].start", "experiment.sweep_parameters[].stop", "experiment.sweep_parameters[].step",
        "experiment.sweep_parameters[].logarithmic", "experiment.max_sweep_combinations",
        "name", "description", "preset_origin", "schema_version")

    # ---- Recording ----
    sections["Recording"] = (
        f"Population-level snapshots are recorded every {out.record_interval_steps} step(s), plus a closing "
        f"snapshot after the final reproduction. "
        + (f"A reproducible sample of {out.agent_sample_size} agents is stored per snapshot." if out.store_agent_sample
           else "No individual-agent sample is stored.")
        + (" A detailed event log is kept." if out.store_event_log else ""))
    use("output.record_interval_steps", "output.store_agent_sample", "output.agent_sample_size", "output.store_event_log")

    # ---- Specification, inactive fields, coverage ----
    inactive_tags = inactive_applicabilities(sc)
    data = scenario_to_dict(sc)
    spec_rows, inactive_rows = [], []
    dictionary = build_dictionary()
    for e in dictionary:
        if "[]" in e.path:
            continue    # list sections are covered as a whole in prose
        section, _, fld = e.path.partition(".")
        if not fld:
            val = data.get(section)
        else:
            val = (data.get(section) or {}).get(fld)
        if isinstance(val, (dict, list)):
            val = str(val)
        row = {"path": e.path, "value": _fmt(val), "label": e.label,
               "applicability": e.applicability}
        if e.applicability in inactive_tags:
            row["reason"] = e.applicability.replace("_", " ")
            inactive_rows.append(row)
        else:
            spec_rows.append(row)

    def _default_of(e):
        return e.default
    for e in dictionary:
        if "[]" in e.path or e.applicability in inactive_tags:
            continue
        section, _, fld = e.path.partition(".")
        val = (data.get(section) or {}).get(fld) if fld else data.get(section)
        if e.category in ("mode",) and fld and val != e.default and e.default is not None:
            notes.append(f"`{e.path}` is set to `{val}` (default `{e.default}`).")

    uncovered = sorted(e.path for e in dictionary if e.path not in covered)
    return ExperimentDescription(sections, spec_rows, inactive_rows, notes, uncovered)

"""Experiment-specific report for external-AI interpretation (AI_REPORT.md).

The report is plain UTF-8 Markdown with **stable section and table IDs**
(``[S1]``, ``[T3]`` …) so an external AI can cite exactly where a number came
from. It reuses the tested analysis functions for every statistic — nothing is
recomputed here, and no new inference is introduced. Undefined values are
written as ``null``, never as zero. Failed, extinct, cancelled and partial runs
are reported, not hidden.

Size is bounded. Time series are summarised (per-season means) in the main
report
complete tables live in the export bundle and are listed in the
manifest. Optional appendices provide full time series split into numbered
parts, each labelled with what it covers and what was omitted.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..analysis.aggregation import aggregate_summaries, extinction_rate, summary_table
from ..analysis.metrics import summarise_run
from ..config.serialization import scenario_from_dict
from ..engine.results import RunResult
from ..export.bundles import mechanism_summary
from ..version import SCHEMA_VERSION, __version__
from .fingerprint import GUIDE_FORMAT_VERSION, REPORT_FORMAT_VERSION, contract_header
from .narrative import describe_scenario
from .registry import OUTPUT_REGISTRY, expand_for_scenario

__all__ = [
    "build_ai_report",
    "ReportBundle",
    "estimate_size_bytes",
    "time_series_appendix_parts",
]

#: Metrics shown in the headline summary tables, grouped by theme.
THEMES: dict[str, list[str]] = {
    "Population": [
        "final_population",
        "peak_population",
        "min_population",
        "mean_population",
        "population_cv",
        "extinct",
        "extinction_season",
        "seasons_completed",
    ],
    "Survival (completed lives only)": [
        "n_deaths",
        "mean_lifespan_seasons",
        "median_lifespan_seasons",
        "max_lifespan_observed_seasons",
        "mean_lifespan_given_maturity",
        "frac_reaching_maturity",
    ],
    "Reproduction": [
        "reproduction_timing",
        "total_reproductive_attempts",
        "total_failed_no_partner",
        "failed_match_rate",
        "total_successful_events",
        "total_offspring_pre_survival",
        "total_offspring_survived",
        "realised_juvenile_survival",
        "mean_offspring_per_event_pre_survival",
        "mean_pairs_per_step",
        "mean_total_pairs_per_season",
        "mean_births_per_season",
        "mean_eligible_agents_per_step",
        "share_steps_with_births",
        "birth_phase_entropy",
    ],
    "Mating": [
        "mean_active_bonds_per_step",
        "peak_active_bonds",
        "total_bonds_formed",
        "total_bonds_dissolved",
        "total_bonds_dissolved_by_death",
        "total_bonds_dissolved_stochastic",
    ],
    "Realised fitness (completed lives)": [
        "mean_lrs_completed_lives",
        "var_lrs_completed_lives",
        "frac_zero_lrs",
        "opportunity_for_selection_I",
        "lrs_gini",
        "lrs_top20pct_share",
        "mean_lrs_given_maturity",
    ],
    "Inheritance and diversity": [
        "total_mutation_events",
        "mutation_events_per_offspring",
        "final_n_lineages",
        "peak_n_lineages",
        "initial_mean_domain_variance",
        "final_mean_domain_variance",
        "variance_retained_fraction",
    ],
    "Behaviour and misallocation": [
        "final_nonfunctional_action_rate",
        "final_nonfunctional_time_share",
        "final_nonfunctional_energy_share",
        "final_neutral_action_rate",
        "nonfunctional_rate_initial",
        "nonfunctional_rate_final",
        "nonfunctional_rate_change",
        "nonfunctional_persistence_ratio",
    ],
    "Cognition diagnostics": [
        "experience_memory_active",
        "experience_mismatch_total_abs",
        "experience_mismatch_nonbeneficial",
        "forecast_mae_mean",
        "one_step_regret_proxy",
    ],
}


def _v(x: Any) -> str:
    """Render a value; undefined -> null."""

    if x is None:
        return "null"
    if isinstance(x, (bool, np.bool_)):
        return "true" if x else "false"
    if isinstance(x, (float, np.floating)):
        return "null" if not math.isfinite(float(x)) else f"{float(x):.6g}"
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    return str(x)


def _registry_lookup(scenario) -> dict[str, dict[str, str]]:
    out = {}
    for t in OUTPUT_REGISTRY:
        for f in t.fields:
            for fid in expand_for_scenario(f, scenario):
                out[fid] = {
                    "table": t.id,
                    "kind": f.kind,
                    "unit": f.unit,
                    "applies_to": f.applies_to,
                    "definition": f.definition,
                    "null_meaning": f.null_meaning,
                }
    return out


@dataclass
class ReportBundle:
    """The report plus its optional appendices and size estimate."""

    report_markdown: str
    appendices: dict[str, str] = field(default_factory=dict)
    size_estimate: dict[str, int] = field(default_factory=dict)


def estimate_size_bytes(text: str) -> int:
    return len(text.encode("utf-8"))


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------
def _identity(
    runs: list[RunResult],
    mode: str,
    cancelled: bool,
    requested: int,
    cell_count: int | None,
) -> str:
    h = contract_header("ai_report")
    completed = len(runs)
    failed = max(0, requested - completed) if requested else 0
    first = runs[0] if runs else None
    rows = [
        ("application_version", __version__),
        ("config_schema_version", str(SCHEMA_VERSION)),
        ("report_format_version", REPORT_FORMAT_VERSION),
        ("expects_interpretation_guide_version", GUIDE_FORMAT_VERSION),
        ("parameter_dictionary_fingerprint", h["parameter_dictionary_fingerprint"]),
        ("output_registry_fingerprint", h["output_registry_fingerprint"]),
        ("experiment_mode", mode),
        ("runs_requested", str(requested) if requested else "null"),
        ("runs_completed", str(completed)),
        ("runs_failed_or_not_started", str(failed)),
        ("experiment_cancelled", "true" if cancelled else "false"),
        (
            "any_run_partial_cancelled",
            "true" if any(r.cancelled for r in runs) else "false",
        ),
        ("any_run_extinct", "true" if any(r.extinct for r in runs) else "false"),
        ("scenario_name", first.scenario_dict.get("name") if first else "null"),
        (
            "preset_origin",
            (first.scenario_dict.get("preset_origin") or "custom") if first else "null",
        ),
        ("config_hash", first.config_hash if first else "null"),
        ("master_seed", str(first.master_seed) if first else "null"),
        (
            "replication_indices",
            ", ".join(str(r.replication_index) for r in runs) if runs else "null",
        ),
        ("run_ids", ", ".join(r.run_id[:8] for r in runs) if runs else "null"),
        ("start_time", first.start_time if first else "null"),
        ("end_time", runs[-1].end_time if runs else "null"),
    ]
    if cell_count is not None:
        rows.append(("sweep_cells", str(cell_count)))
    warnings = sorted({w for r in runs for w in (r.warnings or [])})
    txt = ["## [S1] Identity and provenance", "", "| Field | Value |", "|---|---|"]
    txt += [f"| {k} | `{v}` |" for k, v in rows]
    txt += ["", "**Warnings** (" + str(len(warnings)) + "):"]
    txt += [f"- {w}" for w in warnings] if warnings else ["- none recorded"]
    if cancelled or any(r.cancelled for r in runs):
        txt += [
            "",
            "> **Partial results.** The experiment or at least one run was cancelled before "
            "completion. Every table below describes what was actually simulated; treat "
            "aggregates as partial.",
        ]
    return "\n".join(txt) + "\n"


def _conditions(scenario) -> str:
    d = describe_scenario(scenario)
    return (
        "## [S2] Experiment conditions (deterministic description)\n\n"
        + d.markdown(include_specification=True)
        .replace("## Experiment conditions\n", "")
        .replace(
            "### Complete specification (active settings)",
            "### [T1] Complete effective configuration (active settings)",
        )
        .replace(
            "### Inactive settings (ignored under the current mechanisms)",
            "### [T2] Inactive settings",
        )
        + "\n"
    )


def _mechanisms(scenario_dict: dict) -> str:
    m = mechanism_summary(scenario_dict)
    return (
        "### [T3] Active mechanisms\n\n| Mechanism | Value |\n|---|---|\n"
        + "\n".join(
            f"| {k} | `{_v(v) if not isinstance(v, dict) else json.dumps(v)}` |"
            for k, v in m.items()
        )
        + "\n\n"
    )


def _dictionary_for(
    summary_keys: list[str], scenario, missing_reasons: dict[str, str]
) -> str:
    look = _registry_lookup(scenario)
    rows = [
        "## [S3] Output data dictionary (fields used in this report)",
        "",
        "| Key | Table | Kind | Unit | Applies to | Definition | Null means |",
        "|---|---|---|---|---|---|---|",
    ]
    for k in summary_keys:
        f = look.get(k)
        if f is None:
            # pattern fields with role/cause placeholders resolve by prefix
            f = next(
                (
                    v
                    for kid, v in look.items()
                    if kid.split("<")[0]
                    and k.startswith(kid.split("<")[0])
                    and "<" in kid
                ),
                None,
            )
        if f is None:
            rows.append(
                f"| `{k}` | summary_metrics | — | — | — | (no registry entry; reported for transparency) | — |"
            )
        else:
            rows.append(
                f"| `{k}` | {f['table']} | {f['kind']} | {f['unit']} | {f['applies_to']} | "
                f"{f['definition'].replace('|', '/')} | {f['null_meaning'].replace('|', '/') or 'not applicable / undefined'} |"
            )
    if missing_reasons:
        rows += ["", "**Unavailable in this experiment:**"] + [
            f"- `{k}`: {why}" for k, why in missing_reasons.items()
        ]
    return "\n".join(rows) + "\n\n"


def _single_summary_tables(summary: dict[str, Any], tid_start: int) -> tuple[str, int]:
    out, tid = [], tid_start
    for theme, keys in THEMES.items():
        present = [k for k in keys if k in summary]
        if not present:
            continue
        out += [f"### [T{tid}] {theme}", "", "| Source key | Value |", "|---|---|"]
        out += [f"| `summary_metrics.{k}` | {_v(summary[k])} |" for k in present]
        out.append("")
        tid += 1
    # death causes
    causes = {k: v for k, v in summary.items() if k.startswith("death_share_")}
    if causes:
        out += [
            f"### [T{tid}] Death causes (share of completed lives)",
            "",
            "| Source key | Share | Count |",
            "|---|---|---|",
        ]
        for k, v in causes.items():
            c = k.replace("death_share_", "death_count_")
            out.append(f"| `summary_metrics.{k}` | {_v(v)} | {_v(summary.get(c))} |")
        out.append("")
        tid += 1
    # final propensities vs allocation
    props = [(k, v) for k, v in summary.items() if k.startswith("final_domain_prop_")]
    if props:
        out += [
            f"### [T{tid}] Final inherited domain propensity (mean expressed proportion)",
            "",
            "| Domain | Value | Change over run | log ratio |",
            "|---|---|---|---|",
        ]
        for k, v in props:
            d = k.replace("final_domain_prop_", "")
            out.append(
                f"| {d} | {_v(v)} | {_v(summary.get('domain_prop_change_' + d))} | {_v(summary.get('domain_prop_log_ratio_' + d))} |"
            )
        out += [
            "",
            "Inherited propensity is a tendency; realised allocation is in the next table. They diverge whenever homeostasis or cognition reweights choice.",
            "",
        ]
        tid += 1
    alloc = [(k, v) for k, v in summary.items() if k.startswith("final_time_alloc_")]
    if alloc:
        out += [
            f"### [T{tid}] Final realised time and energy allocation by task",
            "",
            "| Task | Time share | Energy share | Inherited task propensity |",
            "|---|---|---|---|",
        ]
        for k, v in alloc:
            t = k.replace("final_time_alloc_", "")
            out.append(
                f"| {t} | {_v(v)} | {_v(summary.get('final_energy_alloc_' + t))} | {_v(summary.get('final_task_prop_' + t))} |"
            )
        out.append("")
        tid += 1
    return "\n".join(out), tid


def _season_summary_table(run: RunResult, tid: int) -> str:
    ts = run.time_series
    if ts is None or not len(ts):
        return (
            f"### [T{tid}] Population by season\n\nnull (no time series recorded)\n\n"
        )
    cols = [
        c
        for c in (
            "population",
            "births_interval",
            "deaths_interval",
            "mean_energy",
            "mean_health",
            "frac_mature",
            "n_lineages",
        )
        if c in ts.columns
    ]
    agg = {
        "population": "last",
        "births_interval": "sum",
        "deaths_interval": "sum",
        "mean_energy": "mean",
        "mean_health": "mean",
        "frac_mature": "mean",
        "n_lineages": "last",
    }
    g = ts.groupby("season").agg({c: agg[c] for c in cols})
    lines = [
        f"### [T{tid}] Population by season (aggregated from `time_series`)",
        "",
        "Method: `population`, `n_lineages` = value at the season's last recorded row; births/deaths = "
        "sum over the season's recording intervals; state means = mean over rows. Resolution: one row "
        "per season; the full per-interval series is in `data/time_series.csv` (see manifest).",
        "",
        "| season | " + " | ".join(cols) + " |",
        "|" + "---|" * (len(cols) + 1),
    ]
    for season, row in g.iterrows():
        lines.append(
            f"| {int(season)} | " + " | ".join(_v(row[c]) for c in cols) + " |"
        )
    return "\n".join(lines) + "\n\n"


def _replication_tables(runs: list[RunResult], tid: int) -> str:
    table = summary_table(runs)
    agg = aggregate_summaries(table)
    ext = extinction_rate(runs)
    head = [
        "final_population",
        "mean_population",
        "mean_lifespan_seconds" if False else "mean_lifespan_seasons",
        "total_offspring_survived",
        "mean_lrs_completed_lives",
        "opportunity_for_selection_I",
        "lrs_gini",
        "final_nonfunctional_action_rate",
        "variance_retained_fraction",
        "extinct",
        "cancelled",
    ]
    head = [h for h in head if h in table.columns]
    out = [
        f"### [T{tid}] Per-run summary (one row per replication)",
        "",
        "| replication_index | run_id | " + " | ".join(head) + " |",
        "|" + "---|" * (len(head) + 2),
    ]
    for _, r in table.iterrows():
        out.append(
            f"| {int(r['replication_index'])} | {str(r['run_id'])[:8]} | "
            + " | ".join(_v(r[h]) for h in head)
            + " |"
        )
    tid += 1
    out += [
        "",
        f"### [T{tid}] Across-replication summary (mean and 95% t-interval; n = replications with a finite value)",
        "",
        "Uncertainty method: Student-t interval on the replicate mean (`analysis/aggregation.py`). "
        "Replications share the master seed and differ only in random substream; they are the unit of replication. "
        "Time steps and agents are not.",
        "",
        "| metric | mean | ci_lower | ci_upper | sd | median | n |",
        "|---|---|---|---|---|---|---|",
    ]
    keep = [k for t in THEMES.values() for k in t]
    for _, r in agg[agg["metric"].isin(keep)].iterrows():
        out.append(
            f"| `{r['metric']}` | {_v(r['mean'])} | {_v(r['ci_lower'])} | {_v(r['ci_upper'])} | {_v(r['sd'])} | {_v(r['median'])} | {int(r['n_replications'])} |"
        )
    tid += 1
    out += [
        "",
        f"### [T{tid}] Extinction",
        "",
        "| n_runs | n_extinct | extinction_rate | wilson_ci_lower | wilson_ci_upper |",
        "|---|---|---|---|---|",
        f"| {ext['n_runs']} | {ext['n_extinct']} | {_v(ext['extinction_rate'])} | {_v(ext.get('extinction_ci_lower'))} | {_v(ext.get('extinction_ci_upper'))} |",
        "",
        "Method: Wilson score interval (used because extinction counts are often 0 or n).",
        "",
    ]
    return "\n".join(out) + "\n"


def _sweep_tables(sweep, tid: int) -> str:
    out = [
        f"### [T{tid}] Sweep cells: parameter overrides and configuration hashes",
        "",
        "Each cell is a distinct configuration. Reconstruct a cell by applying its overrides to the base "
        "configuration in [T1]. Cells must never be pooled as if they were replicates of one condition.",
        "",
        "| cell | "
        + " | ".join(f"`{p}`" for p in sweep.parameter_paths)
        + " | config_hash | master_seed | runs_completed | n_extinct | n_cancelled |",
        "|" + "---|" * (len(sweep.parameter_paths) + 6),
    ]
    for cell in sweep.cells:
        runs = cell.replications.runs if cell.replications else []
        h = runs[0].config_hash[:16] if runs else "null"
        seed = runs[0].master_seed if runs else "null"
        out.append(
            f"| {cell.index} | "
            + " | ".join(_v(cell.values[p]) for p in sweep.parameter_paths)
            + f" | `{h}` | {seed} | {len(runs)} | {sum(r.extinct for r in runs)} | {sum(r.cancelled for r in runs)} |"
        )
    tid += 1
    out += [
        "",
        f"Seed policy: `{sweep.seed_policy}`"
        + (
            " (common random numbers: cells are paired)"
            if sweep.seed_policy == "common_random_numbers"
            else ""
        ),
        "",
    ]
    agg = sweep.aggregated_table()
    keep = [
        "final_population",
        "mean_population",
        "total_offspring_survived",
        "mean_lrs_completed_lives",
        "opportunity_for_selection_I",
        "lrs_gini",
        "final_nonfunctional_action_rate",
        "extinct",
    ]
    out += [
        f"### [T{tid}] Per-cell metrics (mean, 95% t-interval, n per cell)",
        "",
        "| "
        + " | ".join(f"`{p}`" for p in sweep.parameter_paths)
        + " | metric | mean | ci_lower | ci_upper | sd | n |",
        "|" + "---|" * (len(sweep.parameter_paths) + 6),
    ]
    if len(agg):
        sub = agg[agg["metric"].isin(keep)]
        for _, r in sub.iterrows():
            out.append(
                "| "
                + " | ".join(_v(r[p]) for p in sweep.parameter_paths)
                + f" | `{r['metric']}` | {_v(r['mean'])} | {_v(r['ci_lower'])} | {_v(r['ci_upper'])} | {_v(r['sd'])} | {int(r['n_replications'])} |"
            )
    else:
        out.append("| null | (no completed cells) | | | | | |")
    return "\n".join(out) + "\n\n"


def _manifest(runs: list[RunResult], include_appendices: dict[str, str]) -> str:
    first = runs[0]
    n_ts = sum(len(r.time_series) for r in runs if r.time_series is not None)
    n_bs = sum(len(r.breeding_series) for r in runs if r.breeding_series is not None)
    n_dl = sum(len(r.dead_log_df) for r in runs if r.dead_log_df is not None)
    n_ag = sum(len(r.agent_samples) for r in runs if r.agent_samples is not None)
    rows = [
        (
            "scenario.json",
            "complete effective configuration",
            "JSON",
            "1",
            "all",
            "yes ([T1], [S2])",
        ),
        (
            "metadata.json",
            "identity, seeds, versions, mechanisms",
            "JSON",
            "1",
            "all",
            "yes ([S1], [T3])",
        ),
        (
            "results.xlsx",
            "formatted workbook of all tables below",
            "Excel",
            "—",
            "all",
            "partially (summaries)",
        ),
        (
            "data/summary_metrics.csv",
            "all scalar metrics",
            "CSV",
            str(len(runs)) + " run(s)",
            "all",
            "yes (summary tables)",
        ),
        (
            "data/time_series.csv",
            "per-recording-interval snapshot",
            "CSV",
            f"{n_ts:,}",
            "all",
            "summarised per season only",
        ),
        (
            "data/breeding_series.csv",
            "reproduction bookkeeping per step/season",
            "CSV",
            f"{n_bs:,}",
            "all",
            "summarised only",
        ),
        (
            "data/dead_log.csv",
            "one row per completed life",
            "CSV",
            f"{n_dl:,}",
            "completed lives",
            "summarised only (LRS, lifespan, causes)",
        ),
        (
            "data/agent_sample.csv",
            "sampled individual agents",
            "CSV",
            f"{n_ag:,}" if n_ag else "0 (disabled)",
            "sampled agents",
            "no",
        ),
        (
            "data/environment_trajectories.csv",
            "true environment per step",
            "CSV",
            str(
                len(next(iter(first.env_trajectories.values())))
                if first.env_trajectories
                else 0
            ),
            "all steps",
            "no",
        ),
        ("figures/*.png", "standard figure set", "PNG", "10", "—", "no"),
        (
            "AI_REPORT_INTERPRETATION_GUIDE.md",
            "generic interpretation manual",
            "Markdown",
            "—",
            "—",
            "companion",
        ),
    ]
    for name in include_appendices:
        rows.append(
            (
                name,
                "full per-interval time series (appendix part)",
                "Markdown",
                "—",
                "see part header",
                "appendix",
            )
        )
    out = [
        "## [S6] Manifest of full export files",
        "",
        "Everything below is in the reproducibility bundle. The last column states whether its data appear "
        "in this report. Ask the user for a file by name when a question needs data not included here.",
        "",
        "| File | Purpose | Format | Rows | Coverage | In this report? |",
        "|---|---|---|---|---|---|",
    ]
    out += [f"| `{a}` | {b} | {c} | {d} | {e} | {f} |" for a, b, c, d, e, f in rows]
    return "\n".join(out) + "\n"


def time_series_appendix_parts(
    runs: list[RunResult], rows_per_part: int = 400
) -> dict[str, str]:
    """Full time series as numbered Markdown parts (optional, size-labelled)."""

    parts: dict[str, str] = {}
    for run in runs:
        ts = run.time_series
        if ts is None or not len(ts):
            continue
        cols = [
            "step",
            "season",
            "population",
            "births_interval",
            "deaths_interval",
            "mean_energy",
            "mean_health",
            "n_lineages",
        ]
        cols = [c for c in cols if c in ts.columns]
        n_parts = math.ceil(len(ts) / rows_per_part)
        for i in range(n_parts):
            chunk = ts.iloc[i * rows_per_part : (i + 1) * rows_per_part]
            name = f"AI_REPORT_APPENDIX_ts_rep{run.replication_index}_part{i + 1}of{n_parts}.md"
            head = [
                f"# Appendix: time series, replication {run.replication_index}, part {i + 1} of {n_parts}",
                "",
                f"Run `{run.run_id}`, config `{run.config_hash[:16]}`. Rows {int(chunk['step'].iloc[0])}–{int(chunk['step'].iloc[-1])} "
                f"of {int(ts['step'].iloc[-1])} steps. Columns included: {', '.join(cols)}. Omitted: "
                f"{len(ts.columns) - len(cols)} other columns (per-task allocation, environment, cognition); see data/time_series.csv.",
                "",
                "| " + " | ".join(cols) + " |",
                "|" + "---|" * len(cols),
            ]
            body = [
                "| " + " | ".join(_v(r[c]) for c in cols) + " |"
                for _, r in chunk.iterrows()
            ]
            parts[name] = "\n".join(head + body) + "\n"
    return parts


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def build_ai_report(
    outcome, *, include_time_series_appendix: bool = False
) -> ReportBundle:
    """Build the report for an :class:`ExperimentOutcome` (single/replications/sweep)."""

    runs: list[RunResult] = outcome.runs
    mode = outcome.mode
    payload = outcome.payload
    requested = 1
    cell_count = None
    if hasattr(payload, "cells"):
        cell_count = len(payload.cells)
        requested = sum(
            c.replications.n_requested for c in payload.cells if c.replications
        )
    elif hasattr(payload, "n_requested"):
        requested = payload.n_requested

    if not runs:
        text = "# AI_REPORT.md\n\nNo completed runs. " + _identity(
            [], mode, outcome.cancelled, requested, cell_count
        )
        return ReportBundle(text, {}, {"AI_REPORT.md": estimate_size_bytes(text)})

    first = runs[0]
    scenario = scenario_from_dict(first.scenario_dict)
    parts = [
        "# AI_REPORT.md",
        "",
        "Experiment-specific report for external-AI interpretation, generated locally by the UMEM Evolutionary "
        "Simulation Workbench. Read `AI_REPORT_INTERPRETATION_GUIDE.md` first. All numbers here come from the "
        "application's tested analysis functions; `null` means undefined or not applicable, never zero. "
        "Section IDs [S*] and table IDs [T*] are stable citation anchors.",
        "",
        _identity(runs, mode, outcome.cancelled, requested, cell_count),
        _conditions(scenario),
        _mechanisms(first.scenario_dict),
    ]

    summary = summarise_run(first)
    keys = [k for t in THEMES.values() for k in t if k in summary]
    missing: dict[str, str] = {}
    mech = mechanism_summary(first.scenario_dict)
    if mech["reproduction_timing"] != "distributed":
        missing[
            "mean_pairs_per_step / mean_attempts_per_step / total_reproductive_attempts"
        ] = "legacy season-end timing records one row per season; per-step quantities and attempt counts are not tracked."
    if mech["mating_mode"] != "pair_bonded":
        missing["bond_* metrics"] = "mating mode is not pair_bonded; no bonds exist."
    if mech["inheritance_model"] != "polygenic_additive":
        missing["total_mutation_events, mutation_events_per_offspring"] = (
            "legacy inheritance does not count discrete mutation events."
        )
    cog = first.scenario_dict.get("cognition", {})
    if not cog.get("experience_enabled"):
        missing["experience_* metrics"] = (
            "cognition A (intergenerational experience) is disabled."
        )
    if not cog.get("forecast_enabled"):
        missing["forecast_* metrics"] = "cognition B (forecasting) is disabled."
    parts.append(_dictionary_for(keys, scenario, missing))

    tid = 4
    if mode == "single":
        parts += [
            "## [S4] Results — single run (DESCRIPTIVE ONLY)",
            "",
            "> One trajectory. No uncertainty can be estimated from it and it cannot support conclusions; "
            "it can motivate a replicated experiment.",
            "",
        ]
        body, tid = _single_summary_tables(summary, tid)
        parts += [body, _season_summary_table(first, tid)]
        tid += 1
    elif mode == "replications":
        parts += [
            "## [S4] Results — replicated experiment",
            "",
            f"{len(runs)} completed replication(s) of one configuration. The first run's detailed tables are "
            "shown for orientation; inference should use the across-replication table.",
            "",
        ]
        parts.append(_replication_tables(runs, tid))
        tid += 3
        parts += [
            f"#### Orientation: detailed tables for replication {first.replication_index} only",
            "",
        ]
        body, tid = _single_summary_tables(summary, tid)
        parts += [body, _season_summary_table(first, tid)]
        tid += 1
    else:
        parts += [
            "## [S4] Results — parameter sweep",
            "",
            "Base configuration is in [T1]; each cell overrides the listed paths. Cells are different "
            "configurations and are reported separately.",
            "",
        ]
        parts.append(_sweep_tables(payload, tid))
        tid += 2

    parts += [
        "## [S5] Definitions of denominators and observation windows",
        "",
        "- **Completed lives** (`dead_log`): agents that died during the run. Survivors at the end are censored and excluded from lifespan and LRS summaries. Early in a run these summaries are dominated by short lives.",
        "- **Founders vs birth cohorts**: founders may start at dispersed ages (negative `born_season`) and are not a fully observed cohort; agents born during the run and dead by its end are.",
        "- **Realised births vs attempts**: `total_reproductive_attempts` counts initiations; `total_successful_events` counts events that produced a fertility draw; `total_offspring_survived` counts recruits. The event rate is a configured attempt rate, not a birth rate.",
        "- **Behavioural allocation vs inherited propensity**: `timealloc_*`/`freq_*` are realised; `domprop_*`/`taskprop_*` are inherited tendencies expressed as proportions.",
        "- **Aggregate vs individual**: every table here is population-level; individual evidence exists only in `data/agent_sample.csv` when enabled.",
        "- **Per-step vs per-season**: metric names state their denominator; per-step means are `null` under legacy timing.",
        "- **Time resolution**: `time_series` rows are recording intervals (`output.record_interval_steps` steps), not steps; interval counts sum over the interval.",
        "",
    ]

    appendices = (
        time_series_appendix_parts(runs) if include_time_series_appendix else {}
    )
    parts.append(_manifest(runs, appendices))
    parts += [
        "## [S7] What this report omits",
        "",
        "- Full per-interval time series (summarised per season in the report; complete in `data/time_series.csv`"
        + (
            " and in the appendix parts listed above)."
            if appendices
            else "; appendix parts not generated)."
        ),
        "- Per-task allocation, environment and cognition columns over time (in `data/time_series.csv`).",
        "- Individual agent records (in `data/agent_sample.csv` when enabled).",
        "- Individual completed-life records (in `data/dead_log.csv`).",
        "- Figures (in `figures/`).",
        "",
        "This report does **not** contain every raw observation. Numerical claims should be limited to the tables above; request a manifest file for anything else.",
        "",
    ]

    text = "\n".join(parts)
    sizes = {"AI_REPORT.md": estimate_size_bytes(text)}
    sizes.update({k: estimate_size_bytes(v) for k, v in appendices.items()})
    return ReportBundle(text, appendices, sizes)

"""Registry of every exported table and field.

This is the authoritative description of UMEM's *outputs*, complementing the
configuration data dictionary (``config/data_dictionary.py``) which describes
*inputs*. Both the interpretation guide and every experiment report are
generated from it, so a field cannot appear in an export without a definition,
and a definition cannot outlive the field it describes: the coverage test in
``tests/unit/test_ai_assist.py`` fails when the two drift apart.

Many exported columns are generated per domain, task, environment variable or
death cause. Those are described once as a **pattern** (``domprop_<domain>``)
and expanded against a concrete scenario when a report is rendered.

Measurement kinds (``kind``)
----------------------------
``count``        events in one recording interval or one step
``stock``        a level observed at a point in time (population, active bonds)
``rate``         events per unit time or per unit exposure
``share``        a proportion in [0, 1]
``mean``         an average over agents alive at the observation point
``cumulative``   a running total since the start of the run
``id``           an identifier, not a measurement
``label``        categorical text
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

__all__ = ["FieldSpec", "TableSpec", "OUTPUT_REGISTRY", "expand_for_scenario",
           "registry_as_dicts", "REGISTRY_FORMAT_VERSION"]

REGISTRY_FORMAT_VERSION = "1.0"


@dataclass(frozen=True)
class FieldSpec:
    id: str                       # stable id; may contain <placeholder>
    definition: str
    kind: str
    unit: str = ""
    calculation: str = ""
    applies_to: str = "all"       # all | distributed_only | legacy_timing_only | pair_bond_only | polygenic_only | cognition_a | cognition_b
    null_meaning: str = ""
    limitations: str = ""
    pattern: bool = False         # True when <placeholder> expands per scenario


@dataclass(frozen=True)
class TableSpec:
    id: str
    granularity: str              # per_step | per_recording_interval | per_completed_life | per_sampled_agent | per_season(legacy) | per_run | per_cell
    description: str
    export_files: tuple[str, ...]
    fields: tuple[FieldSpec, ...] = field(default_factory=tuple)


def _f(id, definition, kind, unit="", calculation="", applies_to="all",
       null_meaning="", limitations="", pattern=False) -> FieldSpec:
    return FieldSpec(id, definition, kind, unit, calculation, applies_to,
                     null_meaning, limitations, pattern)


TIME_SERIES = TableSpec(
    "time_series", "per_recording_interval",
    "Population-level snapshot every `output.record_interval_steps` steps, plus "
    "a closing snapshot after the final reproduction so the last row equals the "
    "final population. Interval counts cover the steps since the previous row.",
    ("data/time_series.csv", "results.xlsx#Time_Series"),
    (
        _f("step", "Simulation time step (0-based) at which the row was recorded.", "id", "steps"),
        _f("season", "Season index of the step; season = step // steps_per_season.", "id", "seasons"),
        _f("population", "Living agents after this step's mortality, ageing and reproduction.", "stock", "agents",
           limitations="Founders are included; see dead_log for completed lives only."),
        _f("births_interval", "Offspring that entered the population during the interval ending at this step.", "count", "agents",
           calculation="Sum of surviving offspring appended since the previous row."),
        _f("deaths_interval", "Deaths during the interval, all causes.", "count", "agents"),
        _f("deaths_<cause>", "Deaths during the interval attributed to <cause>: starvation, health/injury, predation, age/senescence, background, density, juvenile.", "count", "agents",
           calculation="Deterministic causes first (starvation, health, max age); probabilistic cause sampled proportional to component hazards.", pattern=True),
        _f("mean_energy", "Mean energy of living agents.", "mean", "0-100 scale"),
        _f("median_energy", "Median energy of living agents.", "mean", "0-100 scale"),
        _f("mean_health", "Mean health of living agents.", "mean", "0-100 scale"),
        _f("median_health", "Median health of living agents.", "mean", "0-100 scale"),
        _f("mean_repro_capital", "Mean reproductive capital of living agents.", "mean", "0-100 scale",
           limitations="Reset to zero when an agent breeds; low values do not imply poor condition."),
        _f("mean_status", "Mean status of living agents.", "mean", "0-100 scale"),
        _f("mean_age_steps", "Mean age of living agents in steps.", "mean", "steps"),
        _f("frac_mature", "Share of living agents that have reached maturity.", "share"),
        _f("n_lineages", "Distinct founder lineages still represented among living agents.", "stock", "lineages",
           limitations="Founders each start their own lineage; lineage count equals initial population at step 0."),
        _f("domprop_<domain>", "Mean expressed propensity for motivational domain <domain>. Under the polygenic model this is a proportion (all domains sum to 1); under legacy inheritance it is a positive real number.", "mean", "proportion (polygenic) / a.u. (legacy)",
           calculation="Polygenic: softmax of the centred latent vector, averaged over living agents.",
           limitations="An inherited tendency, not realised behaviour; compare with timealloc_<task>.", pattern=True),
        _f("domvar_<domain>", "Within-population variance of the domain propensity. Under the polygenic model this is variance of the latent (log-ratio) value.", "mean", "latent variance (polygenic) / a.u.² (legacy)",
           limitations="Latent variance and legacy variance are on different scales and are not comparable.", pattern=True),
        _f("taskprop_<task>", "Mean expressed within-domain propensity for task <task>. Polygenic: proportions sum to 1 within each domain.", "mean", "proportion / a.u.",
           limitations="Disabled tasks still carry (unexpressed) propensity; their freq/timealloc are exactly zero.", pattern=True),
        _f("effpref_<task>", "Mean effective choice probability for <task> after homeostasis and cognition are applied.", "mean", "probability", pattern=True),
        _f("freq_<task>", "Share of all actions in the interval that were <task>.", "share", pattern=True),
        _f("timealloc_<task>", "Share of agent time in the interval spent on <task>.", "share", pattern=True,
           limitations="Realised allocation; diverges from taskprop_ whenever homeostasis or cognition reweights choice."),
        _f("energyalloc_<task>", "Share of energy spent in the interval on <task>.", "share", pattern=True),
        _f("nonfunc_action_rate", "Share of actions on tasks labelled costly_nonfunctional.", "share"),
        _f("nonfunc_time_share", "Share of time on costly_nonfunctional tasks.", "share"),
        _f("nonfunc_energy_share", "Share of energy on costly_nonfunctional tasks.", "share"),
        _f("neutral_action_rate", "Share of actions on tasks labelled low_cost_neutral.", "share"),
        _f("env_<var>", "True value of environmental variable <var> at this step.", "stock", "variable units", pattern=True),
        _f("obs_<var>", "Population-mean noisy observation of <var>.", "mean", "variable units", pattern=True),
        _f("forecast_<var>", "Population-shared EWMA forecast of <var>.", "stock", "variable units", applies_to="cognition_b",
           null_meaning="Unchanged from initial value when cognition B is disabled.", pattern=True),
        _f("forecast_err_<var>", "forecast_<var> minus env_<var>.", "stock", "variable units", applies_to="cognition_b", pattern=True),
        _f("exp_<task>", "Intergenerational memory weight for <task>: its share of successful-cohort activity.", "share", applies_to="cognition_a",
           null_meaning="Zero when cognition A is disabled.",
           limitations="Correlational: a task can be well represented because successful agents had time to do it.", pattern=True),
    ),
)

BREEDING_SERIES = TableSpec(
    "breeding_series", "per_step (distributed) / per_season (legacy timing)",
    "Reproduction bookkeeping. Under distributed timing one row per step; under "
    "season_end_legacy one row per season. Per-step column names ending in "
    "_step are events in that row only; cumulative_ columns are running totals.",
    ("data/breeding_series.csv",),
    (
        _f("step", "Time step of the row (distributed timing only).", "id", "steps", applies_to="distributed_only", null_meaning="Absent under legacy timing."),
        _f("season", "Season of the row.", "id", "seasons"),
        _f("n_eligible", "Agents meeting all reproductive eligibility conditions at this observation.", "stock", "agents",
           limitations="A stock, not unique agents: summing over steps gives agent-steps of exposure."),
        _f("n_attempts", "Reproductive attempts initiated (distributed: initiators this step; pair-bonded: pairs attempting).", "count", "events", applies_to="distributed_only"),
        _f("n_pairs", "Successful reproductive events (a parent or parent pair produced a fertility draw).", "count", "events"),
        _f("n_failed_no_partner", "Attempts that found no available complementary-type partner.", "count", "events", applies_to="distributed_only"),
        _f("n_events_with_offspring", "Events whose fertility draw was at least one.", "count", "events"),
        _f("n_offspring_pre_survival", "Offspring drawn before juvenile survival was applied.", "count", "agents"),
        _f("n_offspring_survived", "Offspring that survived recruitment and entered the population.", "count", "agents"),
        _f("n_active_bonds", "Pair bonds in force after this step's bond updates.", "stock", "bonds", applies_to="pair_bond_only", null_meaning="Zero outside pair_bonded mode."),
        _f("n_bonds_formed_step", "Bonds formed during this step.", "count", "bonds", applies_to="pair_bond_only"),
        _f("n_bonds_dissolved_step", "Bonds dissolved during this step (all causes).", "count", "bonds", applies_to="pair_bond_only",
           calculation="= n_bonds_dissolved_by_death_step + n_bonds_dissolved_stochastic_step"),
        _f("n_bonds_dissolved_by_death_step", "Bonds ended by a partner's death this step.", "count", "bonds", applies_to="pair_bond_only"),
        _f("n_bonds_dissolved_stochastic_step", "Bonds ended by the configured dissolution hazard this step.", "count", "bonds", applies_to="pair_bond_only"),
        _f("cumulative_bonds_formed", "Running total of bonds formed since the start.", "cumulative", "bonds", applies_to="pair_bond_only",
           limitations="Do not sum this column; use n_bonds_formed_step."),
        _f("cumulative_bonds_dissolved", "Running total of bonds dissolved since the start.", "cumulative", "bonds", applies_to="pair_bond_only"),
        _f("n_mutation_events", "Effective mutation events among offspring produced in this row.", "count", "events", applies_to="polygenic_only",
           calculation="Each offspring is tested independently per layer (domain, task) when mutation_target=both, so one offspring can contribute up to two events."),
    ),
)

DEAD_LOG = TableSpec(
    "dead_log", "per_completed_life",
    "One row per agent that died during the run. Agents alive at the end are NOT "
    "included, so every lifetime here is complete and every summary from this "
    "table is over completed lives only.",
    ("data/dead_log.csv",),
    (
        _f("age_steps", "Age at death in steps; divide by steps_per_season for seasons.", "count", "steps",
           limitations="A hard maximum lifespan produces a point mass at max_lifespan_seasons; it is not a histogram artifact."),
        _f("born_season", "Season of birth. Negative for founders born before the run when founder ages are dispersed.", "id", "seasons"),
        _f("death_season", "Season of death.", "id", "seasons"),
        _f("cause", "Attributed cause of death (label).", "label"),
        _f("lifetime_offspring", "Surviving offspring credited to this agent over its life: realised lifetime reproductive success (LRS), the model's fitness measure.", "count", "agents",
           limitations="Completed lives only; living agents' partial LRS is not included."),
        _f("sex", "Reproductive type: 0 = Type A, 1 = Type B. Neutral labels, not male/female.", "label"),
        _f("lineage_id", "Founder lineage.", "id"),
        _f("reached_maturity", "Whether the agent reached maturity before dying.", "label"),
    ),
)

AGENT_SAMPLE = TableSpec(
    "agent_sample", "per_sampled_agent",
    "A reproducible random sample of living agents at each recording interval, "
    "for individual-level inspection. Optional (`output.store_agent_sample`).",
    ("data/agent_sample.csv", "results.xlsx#Agent_Sample"),
    (
        _f("step", "Recording step.", "id", "steps"), _f("season", "Season.", "id", "seasons"),
        _f("agent_id", "Stable agent identifier.", "id"), _f("lineage_id", "Founder lineage.", "id"),
        _f("sex", "Reproductive type A(0)/B(1).", "label"), _f("age_steps", "Age in steps.", "count", "steps"),
        _f("energy", "Energy.", "stock", "0-100"), _f("health", "Health.", "stock", "0-100"),
        _f("repro_capital", "Reproductive capital.", "stock", "0-100"),
        _f("lifetime_offspring", "Surviving offspring so far (partial; agent still alive).", "cumulative", "agents"),
        _f("domprop_<domain>", "Expressed domain propensity of this agent.", "stock", "proportion / a.u.", pattern=True),
    ),
)

SUMMARY = TableSpec(
    "summary_metrics", "per_run",
    "Scalar descriptive metrics for one run (analysis/metrics.py, "
    "analysis/reproduction_metrics.py, analysis/misallocation.py). None is a "
    "fitness function.",
    ("data/summary_metrics.csv", "results.xlsx#Summary_Metrics"),
    (
        _f("final_population", "Living agents at the end.", "stock", "agents"),
        _f("peak_population", "Maximum recorded population.", "stock", "agents"),
        _f("min_population", "Minimum recorded population.", "stock", "agents"),
        _f("mean_population", "Mean over recording rows.", "mean", "agents"),
        _f("population_cv", "Std/mean of population over rows.", "share"),
        _f("extinct", "Population reached zero.", "label"),
        _f("extinction_season", "Season of extinction.", "id", "seasons", null_meaning="null when not extinct"),
        _f("seasons_completed", "Seasons simulated.", "count", "seasons"),
        _f("n_deaths", "Completed lives (dead_log rows).", "count", "agents"),
        _f("mean_lifespan_seasons", "Mean age at death, completed lives.", "mean", "seasons", limitations="Excludes agents alive at the end (right-censored)."),
        _f("median_lifespan_seasons", "Median age at death.", "mean", "seasons"),
        _f("max_lifespan_observed_seasons", "Longest completed life.", "mean", "seasons"),
        _f("mean_lifespan_given_maturity", "Mean age at death among agents that reached maturity.", "mean", "seasons"),
        _f("frac_reaching_maturity", "Share of completed lives that reached maturity.", "share"),
        _f("death_share_<cause>", "Share of completed lives attributed to <cause>.", "share", pattern=True),
        _f("death_count_<cause>", "Completed lives attributed to <cause>.", "count", "agents", pattern=True),
        _f("reproduction_timing", "Timing mode of the run.", "label"),
        _f("total_reproductive_attempts", "Attempts initiated over the run.", "cumulative", "events", applies_to="distributed_only", null_meaning="0 under legacy timing (attempts are not tracked)."),
        _f("total_failed_no_partner", "Attempts without an available partner.", "cumulative", "events", applies_to="distributed_only"),
        _f("failed_match_rate", "total_failed_no_partner / total_reproductive_attempts.", "share", null_meaning="null when there were no attempts"),
        _f("total_successful_events", "Reproductive events that produced a fertility draw.", "cumulative", "events"),
        _f("total_offspring_pre_survival", "Offspring drawn before juvenile survival.", "cumulative", "agents"),
        _f("total_offspring_survived", "Offspring that entered the population.", "cumulative", "agents"),
        _f("realised_juvenile_survival", "survived / pre_survival.", "share", null_meaning="null when no offspring were drawn"),
        _f("mean_offspring_per_event_pre_survival", "Mean fertility draw per event.", "mean", "agents/event"),
        _f("total_mutation_events", "Effective mutation events over the run.", "cumulative", "events", applies_to="polygenic_only"),
        _f("mutation_events_per_offspring", "total_mutation_events / total_offspring_survived.", "rate", "events/offspring", applies_to="polygenic_only",
           limitations="Can exceed the configured per-layer probability because domain and task layers are tested independently."),
        _f("mean_pairs_per_step", "Mean successful events per step.", "mean", "events/step", applies_to="distributed_only", null_meaning="null under legacy timing (rows are seasons)."),
        _f("mean_attempts_per_step", "Mean attempts per step.", "mean", "events/step", applies_to="distributed_only"),
        _f("mean_eligible_agents_per_step", "Mean eligible stock per step.", "mean", "agents", applies_to="distributed_only"),
        _f("mean_births_per_step", "Mean surviving offspring per step.", "mean", "agents/step", applies_to="distributed_only"),
        _f("share_steps_with_births", "Share of steps with at least one birth.", "share"),
        _f("birth_phase_entropy", "Normalised entropy of births over step-within-season; 1 = uniform, 0 = all on one step.", "share", null_meaning="null when there were no births"),
        _f("mean_total_pairs_per_season", "Events summed within season, averaged across seasons.", "mean", "events/season"),
        _f("mean_total_attempts_per_season", "Attempts summed within season, averaged across seasons.", "mean", "events/season", applies_to="distributed_only"),
        _f("mean_births_per_season", "Surviving offspring per season.", "mean", "agents/season"),
        _f("mean_eligible_agent_steps_per_season", "Eligibility exposure (agent-steps) per season; not unique agents.", "mean", "agent-steps/season", applies_to="distributed_only"),
        _f("mean_eligible_agents_at_season_end", "Eligible agents at each season-end evaluation.", "mean", "agents", applies_to="legacy_timing_only"),
        _f("mean_active_bonds_per_step", "Mean bonds in force.", "mean", "bonds", applies_to="pair_bond_only"),
        _f("peak_active_bonds", "Maximum bonds in force.", "stock", "bonds", applies_to="pair_bond_only"),
        _f("total_bonds_formed", "Bonds formed over the run.", "cumulative", "bonds", applies_to="pair_bond_only"),
        _f("total_bonds_dissolved", "Bonds dissolved over the run.", "cumulative", "bonds", applies_to="pair_bond_only"),
        _f("total_bonds_dissolved_by_death", "Dissolutions by partner death.", "cumulative", "bonds", applies_to="pair_bond_only"),
        _f("total_bonds_dissolved_stochastic", "Dissolutions by configured hazard.", "cumulative", "bonds", applies_to="pair_bond_only"),
        _f("bond_counter_consistent", "Internal check: sum of per-step formations equals the cumulative total.", "label", applies_to="pair_bond_only"),
        _f("mean_lrs_completed_lives", "Mean lifetime reproductive success, completed lives.", "mean", "agents", limitations="Founders and censored survivors bias this early in a run."),
        _f("var_lrs_completed_lives", "Variance of LRS.", "mean", "agents²"),
        _f("frac_zero_lrs", "Share of completed lives with no surviving offspring.", "share"),
        _f("opportunity_for_selection_I", "Crow's I = Var(LRS)/mean(LRS)²; an upper bound on selection strength, not selection on any trait.", "rate", null_meaning="null when mean LRS is zero"),
        _f("lrs_gini", "Gini coefficient of LRS over completed lives.", "share"),
        _f("lrs_top20pct_share", "Share of all offspring from the top 20% of completed lives by LRS.", "share"),
        _f("mean_lrs_given_maturity", "Mean LRS among agents that reached maturity.", "mean", "agents"),
        _f("lrs_gini_given_maturity", "Gini of LRS among matured agents.", "share"),
        _f("final_n_lineages", "Lineages alive at the end.", "stock", "lineages"),
        _f("peak_n_lineages", "Maximum lineages.", "stock", "lineages"),
        _f("final_mean_domain_variance", "Mean domvar_ at the end.", "mean"),
        _f("initial_mean_domain_variance", "Mean domvar_ at the start.", "mean"),
        _f("variance_retained_fraction", "final / initial domain variance.", "rate", limitations="Under the polygenic model the founder variance is the neutral equilibrium (ADR-002), so values near 1 indicate neither selection nor drift dominated."),
        _f("final_domain_prop_<domain>", "domprop_<domain> at the end.", "mean", pattern=True),
        _f("final_task_prop_<task>", "taskprop_<task> at the end.", "mean", pattern=True),
        _f("final_time_alloc_<task>", "timealloc_<task> at the end.", "share", pattern=True),
        _f("final_energy_alloc_<task>", "energyalloc_<task> at the end.", "share", pattern=True),
        _f("domain_prop_change_<domain>", "Final minus initial domprop.", "mean", pattern=True),
        _f("domain_prop_log_ratio_<domain>", "log(final/initial) domprop.", "mean", pattern=True),
        _f("final_nonfunctional_action_rate", "Nonfunctional action share, last rows.", "share"),
        _f("mean_nonfunctional_action_rate", "Nonfunctional action share, run mean.", "share"),
        _f("final_nonfunctional_time_share", "Nonfunctional time share, last rows.", "share"),
        _f("mean_nonfunctional_time_share", "Run mean.", "share"),
        _f("final_nonfunctional_energy_share", "Nonfunctional energy share, last rows.", "share"),
        _f("mean_nonfunctional_energy_share", "Run mean.", "share"),
        _f("final_neutral_action_rate", "Neutral action share, last rows.", "share"),
        _f("mean_neutral_action_rate", "Run mean.", "share"),
        _f("final_time_share_<role>", "Time share by role (functional, costly_nonfunctional, low_cost_neutral).", "share", pattern=True),
        _f("final_energy_share_<role>", "Energy share by role.", "share", pattern=True),
        _f("final_action_share_<role>", "Action share by role.", "share", pattern=True),
        _f("final_inherited_prop_<role>", "Inherited propensity by role.", "mean", pattern=True),
        _f("final_effective_pref_<role>", "Effective preference by role.", "mean", pattern=True),
        _f("nonfunctional_rate_initial", "Nonfunctional action rate, first rows.", "share"),
        _f("nonfunctional_rate_final", "Nonfunctional action rate, last rows.", "share"),
        _f("nonfunctional_rate_change", "final minus initial.", "share"),
        _f("nonfunctional_persistence_ratio", "final / initial.", "rate", null_meaning="null when initial is zero"),
        _f("forecast_mae_<var>", "Mean absolute forecast error for <var>.", "mean", applies_to="cognition_b", pattern=True),
        _f("forecast_rmse_<var>", "RMSE of forecast.", "mean", applies_to="cognition_b", pattern=True),
        _f("forecast_bias_<var>", "Mean signed forecast error.", "mean", applies_to="cognition_b", pattern=True),
        _f("forecast_mae_mean", "Mean of forecast_mae_ over variables.", "mean", applies_to="cognition_b"),
        _f("observation_mae_<var>", "Mean absolute observation error.", "mean", pattern=True),
        _f("observation_bias_<var>", "Mean signed observation error.", "mean", pattern=True),
        _f("experience_memory_active", "Whether intergenerational memory carried any signal.", "label", applies_to="cognition_a"),
        _f("memory_share_<task>", "Share of memory weight on <task>.", "share", applies_to="cognition_a", pattern=True),
        _f("contribution_share_<task>", "Configured objective contribution share (1 if task has a direct benefit).", "share", applies_to="cognition_a", pattern=True),
        _f("experience_mismatch_<task>", "memory_share minus contribution_share.", "share", applies_to="cognition_a", pattern=True),
        _f("experience_mismatch_total_abs", "Sum of |mismatch|.", "share", applies_to="cognition_a", null_meaning="null when memory inactive"),
        _f("experience_mismatch_nonbeneficial", "Mismatch summed over tasks with no direct benefit.", "share", applies_to="cognition_a", null_meaning="null when memory inactive"),
        _f("one_step_regret_proxy", "Local single-step diagnostic; NOT a fitness measure.", "share"),
        _f("one_step_regret_is_local_diagnostic", "Always true; a reminder.", "label"),
        _f("run_id", "Run identifier.", "id"), _f("config_hash", "Scientific configuration hash.", "id"),
        _f("replication_index", "Replication index.", "id"), _f("cancelled", "Run cancelled; results partial.", "label"),
    ),
)

ENVIRONMENT_TRAJ = TableSpec(
    "environment_trajectories", "per_step",
    "True value of every environmental variable at every step (pre-generated, exogenous).",
    ("data/environment_trajectories.csv",),
    (_f("step", "Time step.", "id", "steps"),
     _f("<var>", "True value of environmental variable <var>.", "stock", "variable units", pattern=True)),
)

OUTPUT_REGISTRY: tuple[TableSpec, ...] = (
    TIME_SERIES, BREEDING_SERIES, DEAD_LOG, AGENT_SAMPLE, SUMMARY, ENVIRONMENT_TRAJ)


def registry_as_dicts() -> list[dict[str, Any]]:
    return [{**asdict(t), "fields": [asdict(f) for f in t.fields]} for t in OUTPUT_REGISTRY]


def expand_for_scenario(spec: FieldSpec, scenario) -> list[str]:
    """Expand a pattern field id against a concrete scenario's ids."""

    if not spec.pattern:
        return [spec.id]
    fid = spec.id
    if "<domain>" in fid:
        return [fid.replace("<domain>", d.domain_id) for d in scenario.domains]
    if "<task>" in fid:
        return [fid.replace("<task>", t.task_id) for t in scenario.tasks]
    if "<var>" in fid:
        return [fid.replace("<var>", v.var_id) for v in scenario.environment]
    if "<cause>" in fid:
        from ..engine.events import DEATH_CAUSE_LABELS, DeathCause
        return [fid.replace("<cause>", DEATH_CAUSE_LABELS[c].replace("/", "_") if fid.startswith("death_") else DEATH_CAUSE_LABELS[c])
                for c in DeathCause if c != DeathCause.ALIVE]
    if "<role>" in fid:
        return [fid.replace("<role>", r) for r in ("functional", "costly_nonfunctional", "low_cost_neutral")]
    return [fid]

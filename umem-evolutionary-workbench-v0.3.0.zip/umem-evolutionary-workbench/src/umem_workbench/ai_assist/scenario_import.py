"""Staged import of externally produced scenario JSON.

Pipeline (each stage stops on blocking errors):

1. **Extract** — raw JSON, or exactly one fenced ```json block. Two or more
   candidates are rejected rather than guessed.
2. **Syntax** — `json.loads` only. Nothing is ever evaluated. NaN/Infinity are
   rejected.
3. **Version / migration** — schema newer than supported is an actionable error;
   supported older schemas are migrated with every change listed for review.
4. **Schema** — Pydantic validation with `extra="forbid"`, so unknown keys are
   errors, not silently dropped.
5. **References and scientific combinations** — `validate_scenario`.
6. **Workload** — `estimate_workload`.

A successful import is a **proposal**. It never touches the active scenario or
existing results; the caller applies it explicitly. Both the submitted and the
effective (migrated, default-filled) configuration are retained so the review
can show exactly what changed.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from pydantic import ValidationError

from ..config.migrations import migrate_scenario_dict
from ..config.models import ScenarioConfig
from ..config.serialization import config_hash, scenario_to_dict
from ..config.validation import Severity, estimate_workload, validate_scenario
from ..version import SCHEMA_VERSION, __version__
from .narrative import describe_scenario

__all__ = ["ImportIssue", "ImportResult", "import_scenario_text",
           "diff_scenarios", "validation_feedback_for_ai", "MAX_IMPORT_BYTES"]

#: Generous but bounded; a scenario is a few tens of kilobytes.
MAX_IMPORT_BYTES = 2_000_000
MAX_DEPTH = 12
_FENCE = re.compile(r"```(?:json|JSON)?\s*\n(.*?)\n```", re.DOTALL)


@dataclass
class ImportIssue:
    stage: str            # extract | syntax | version | schema | validation | workload
    severity: str         # error | warning | theory | info
    path: str
    message: str
    allowed: str = ""     # allowed values / range when known


@dataclass
class ImportResult:
    ok: bool
    issues: list[ImportIssue] = field(default_factory=list)
    submitted: dict[str, Any] | None = None       # as parsed, before migration
    effective: dict[str, Any] | None = None       # migrated + default-filled
    scenario: ScenarioConfig | None = None
    migration_changes: list[dict[str, Any]] = field(default_factory=list)
    config_hash: str | None = None
    description_markdown: str | None = None
    workload: dict[str, Any] | None = None
    submitted_text_bytes: int = 0

    @property
    def errors(self) -> list[ImportIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[ImportIssue]:
        return [i for i in self.issues if i.severity in ("warning", "theory")]


# ---------------------------------------------------------------------------
# Stage 1-2: extract and parse
# ---------------------------------------------------------------------------
def _extract_json_text(text: str) -> tuple[str | None, list[ImportIssue]]:
    stripped = text.strip()
    if not stripped:
        return None, [ImportIssue("extract", "error", "", "No content supplied.")]
    fenced = _FENCE.findall(text)
    if len(fenced) > 1:
        return None, [ImportIssue(
            "extract", "error", "",
            f"Found {len(fenced)} fenced code blocks. Supply exactly one JSON object "
            f"(raw or in a single ```json block); UMEM will not guess which one is meant.")]
    if len(fenced) == 1:
        return fenced[0].strip(), []
    if stripped.startswith("{"):
        return stripped, []
    return None, [ImportIssue(
        "extract", "error", "",
        "Content is neither a raw JSON object nor a single fenced ```json block.")]


def _parse(text: str) -> tuple[dict | None, list[ImportIssue]]:
    def _reject_constant(name):
        raise ValueError(f"non-finite constant {name!r} is not allowed")
    try:
        data = json.loads(text, parse_constant=_reject_constant)
    except ValueError as exc:
        return None, [ImportIssue("syntax", "error", "", f"Invalid JSON: {exc}")]
    if not isinstance(data, dict):
        return None, [ImportIssue("syntax", "error", "", "Top level must be a JSON object.")]
    if _depth(data) > MAX_DEPTH:
        return None, [ImportIssue("syntax", "error", "", f"JSON nesting exceeds {MAX_DEPTH} levels.")]
    return data, []


def _depth(obj, level=0) -> int:
    if isinstance(obj, dict):
        return max([level] + [_depth(v, level + 1) for v in obj.values()])
    if isinstance(obj, list):
        return max([level] + [_depth(v, level + 1) for v in obj])
    return level


# ---------------------------------------------------------------------------
# Stage 3: version / migration
# ---------------------------------------------------------------------------
def _flatten(d: Any, prefix: str = "") -> dict[str, Any]:
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            out.update(_flatten(v, f"{prefix}.{k}" if prefix else str(k)))
    elif isinstance(d, list):
        for i, v in enumerate(d):
            ident = v.get("task_id") or v.get("domain_id") or v.get("var_id") or i if isinstance(v, dict) else i
            out.update(_flatten(v, f"{prefix}.{ident}"))
    else:
        out[prefix] = d
    return out


def diff_scenarios(before: dict[str, Any], after: dict[str, Any]) -> list[dict[str, Any]]:
    """Changed dotted paths between two scenario dicts (added / removed / changed)."""

    a, b = _flatten(before), _flatten(after)
    rows = []
    for path in sorted(set(a) | set(b)):
        if path in ("name", "description", "preset_origin"):
            continue
        if path not in a:
            rows.append({"path": path, "before": None, "after": b[path], "kind": "added"})
        elif path not in b:
            rows.append({"path": path, "before": a[path], "after": None, "kind": "removed"})
        elif a[path] != b[path]:
            rows.append({"path": path, "before": a[path], "after": b[path], "kind": "changed"})
    return rows


def _version_stage(data: dict) -> tuple[dict | None, list[ImportIssue], list[dict]]:
    version = data.get("schema_version", 1)
    try:
        version = int(version)
    except (TypeError, ValueError):
        return None, [ImportIssue("version", "error", "schema_version",
                                  f"schema_version must be an integer, got {version!r}.",
                                  f"supported: 1..{SCHEMA_VERSION}")], []
    if version > SCHEMA_VERSION:
        return None, [ImportIssue(
            "version", "error", "schema_version",
            f"This scenario declares schema {version}, but this application (v{__version__}) "
            f"supports up to schema {SCHEMA_VERSION}. Update UMEM, or ask the AI to produce "
            f"schema {SCHEMA_VERSION} using the current guide.",
            f"supported: 1..{SCHEMA_VERSION}")], []
    if version < SCHEMA_VERSION:
        migrated = migrate_scenario_dict(dict(data))
        changes = diff_scenarios(data, migrated)
        issues = [ImportIssue("version", "info", "schema_version",
                              f"Migrated from schema {version} to {SCHEMA_VERSION}; "
                              f"{len(changes)} field(s) were added or changed to preserve the "
                              f"original scientific meaning (see migration changes).")]
        return migrated, issues, changes
    return dict(data), [], []


# ---------------------------------------------------------------------------
# Stage 4: schema
# ---------------------------------------------------------------------------
def _schema_stage(data: dict) -> tuple[ScenarioConfig | None, list[ImportIssue]]:
    try:
        return ScenarioConfig(**{k: v for k, v in data.items()}), []
    except ValidationError as exc:
        issues = []
        for err in exc.errors():
            loc = ".".join(str(x) for x in err["loc"])
            typ = err["type"]
            msg = err["msg"]
            allowed = ""
            if typ == "extra_forbidden":
                msg = "Unknown field. UMEM rejects unrecognised keys rather than ignoring them."
            elif typ == "enum":
                allowed = str(err.get("ctx", {}).get("expected", ""))
            elif typ in ("greater_than_equal", "less_than_equal", "greater_than", "less_than"):
                allowed = str(err.get("ctx", {}))
            issues.append(ImportIssue("schema", "error", loc, msg, allowed))
        return None, issues


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def import_scenario_text(text: str) -> ImportResult:
    """Run the full staged pipeline on pasted or uploaded text."""

    res = ImportResult(ok=False, submitted_text_bytes=len(text.encode("utf-8")))
    if res.submitted_text_bytes > MAX_IMPORT_BYTES:
        res.issues.append(ImportIssue("extract", "error", "",
                                      f"Input is {res.submitted_text_bytes:,} bytes; the limit is "
                                      f"{MAX_IMPORT_BYTES:,}. A scenario is normally under 50 kB."))
        return res

    json_text, issues = _extract_json_text(text)
    res.issues += issues
    if json_text is None:
        return res

    data, issues = _parse(json_text)
    res.issues += issues
    if data is None:
        return res
    res.submitted = data

    migrated, issues, changes = _version_stage(data)
    res.issues += issues
    res.migration_changes = changes
    if migrated is None:
        return res

    scenario, issues = _schema_stage(migrated)
    res.issues += issues
    if scenario is None:
        return res

    report = validate_scenario(scenario)
    sev = {Severity.ERROR: "error", Severity.WARNING: "warning", Severity.THEORY: "theory"}
    for i in report.issues:
        res.issues.append(ImportIssue("validation", sev.get(i.severity, "warning"), i.code, i.message))
    res.scenario = scenario
    res.effective = scenario_to_dict(scenario)
    res.config_hash = config_hash(scenario)
    res.description_markdown = describe_scenario(scenario).markdown()

    try:
        wl = estimate_workload(scenario)
        res.workload = {k: v for k, v in vars(wl).items()}
    except Exception as exc:  # pragma: no cover
        res.issues.append(ImportIssue("workload", "warning", "", f"Could not estimate workload: {exc}"))

    res.ok = report.can_run
    return res


# ---------------------------------------------------------------------------
# Repair feedback for the external AI
# ---------------------------------------------------------------------------
def validation_feedback_for_ai(result: ImportResult, *, include_submitted: bool = False,
                               original_text: str = "") -> str:
    """Plain-text message the user can paste back into their AI conversation."""

    lines = [
        "UMEM import validation feedback",
        "==============================",
        f"Application version: {__version__}   Supported schema: {SCHEMA_VERSION}",
        f"Result: {'ACCEPTED (with notes)' if result.ok else 'REJECTED'}",
        "",
        "Please repair the scenario JSON so it passes UMEM's validation. Change ONLY what",
        "the issues below require; preserve every other setting exactly as submitted, keep",
        "all IDs and enum values as given, and return one complete JSON object with no",
        "comments, NaN, Infinity or placeholders.",
        "",
    ]
    if result.errors:
        lines.append("Blocking errors:")
        for i in result.errors:
            lines.append(f"  - [{i.stage}] {i.path or '(document)'}: {i.message}"
                         + (f"  Allowed: {i.allowed}" if i.allowed else ""))
        lines.append("")
    if result.warnings:
        lines.append("Warnings (import allowed; consider addressing):")
        for i in result.warnings:
            lines.append(f"  - [{i.stage}] {i.path or '(document)'}: {i.message}")
        lines.append("")
    if result.migration_changes:
        lines.append("Migration applied (older schema; these values were filled to preserve meaning):")
        for c in result.migration_changes[:40]:
            lines.append(f"  - {c['path']}: {c['before']!r} -> {c['after']!r}")
        lines.append("")
    if include_submitted and original_text:
        lines += ["Submitted JSON (as received):", "```json", original_text.strip(), "```", ""]
    return "\n".join(lines)

"""Aggregation across replications and sweep cells (Master Prompt section 17).

Replications differ only in their replication index (and therefore their RNG
substreams), so summarising across them estimates the *stochastic* spread of a
single configuration. Sweep cells differ in configuration and must never be
pooled together as if they were replicates of one condition.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from typing import Any

import numpy as np
import pandas as pd

from ..engine.results import RunResult

__all__ = [
    "summary_table",
    "aggregate_summaries",
    "aggregate_time_series",
    "extinction_rate",
    "mean_ci",
]


def mean_ci(values: Sequence[float], confidence: float = 0.95
            ) -> tuple[float, float, float, int]:
    """Return ``(mean, lower, upper, n)`` using a normal-approximation CI.

    Falls back to a Student-t critical value when SciPy is available, which
    matters for the small replicate counts (5-20) typical of interactive use.
    Non-finite values are dropped before the calculation.
    """

    arr = np.asarray([v for v in values], dtype=float)
    arr = arr[np.isfinite(arr)]
    n = int(arr.size)
    if n == 0:
        return float("nan"), float("nan"), float("nan"), 0
    mean = float(np.mean(arr))
    if n == 1:
        return mean, mean, mean, 1

    sem = float(np.std(arr, ddof=1) / np.sqrt(n))
    try:
        from scipy import stats
        crit = float(stats.t.ppf(0.5 + confidence / 2.0, df=n - 1))
    except Exception:  # pragma: no cover - SciPy is a hard dependency in practice
        crit = 1.959963985 if confidence >= 0.95 else 1.644853627
    return mean, mean - crit * sem, mean + crit * sem, n


def summary_table(results: Iterable[RunResult]) -> pd.DataFrame:
    """One row of summary metrics per run."""

    from .metrics import summarise_run
    rows = [summarise_run(r) for r in results]
    return pd.DataFrame(rows)


def aggregate_summaries(summaries: pd.DataFrame, confidence: float = 0.95,
                        group_by: Sequence[str] | None = None) -> pd.DataFrame:
    """Aggregate a per-run summary table into mean / CI / spread per metric.

    Parameters
    ----------
    summaries
        Output of :func:`summary_table`, one row per replication.
    group_by
        Optional columns identifying sweep cells. When given, aggregation is
        performed *within* each cell, never across cells.
    """

    if summaries is None or not len(summaries):
        return pd.DataFrame()

    id_like = {"run_id", "config_hash", "replication_index"}
    group_by = list(group_by or [])
    numeric = [
        c for c in summaries.columns
        if c not in id_like and c not in group_by
        and pd.api.types.is_numeric_dtype(summaries[c])
    ]

    def _agg(block: pd.DataFrame) -> pd.DataFrame:
        rows = []
        for col in numeric:
            mean, lo, hi, n = mean_ci(block[col].to_numpy(), confidence)
            vals = block[col].to_numpy(dtype=float)
            vals = vals[np.isfinite(vals)]
            rows.append({
                "metric": col,
                "mean": mean,
                "ci_lower": lo,
                "ci_upper": hi,
                "sd": float(np.std(vals, ddof=1)) if vals.size > 1 else 0.0,
                "median": float(np.median(vals)) if vals.size else float("nan"),
                "min": float(np.min(vals)) if vals.size else float("nan"),
                "max": float(np.max(vals)) if vals.size else float("nan"),
                "n_replications": n,
                "confidence": confidence,
            })
        return pd.DataFrame(rows)

    if not group_by:
        return _agg(summaries)

    out = []
    for keys, block in summaries.groupby(group_by, dropna=False):
        agg = _agg(block)
        if not isinstance(keys, tuple):
            keys = (keys,)
        for name, value in zip(group_by, keys):
            agg[name] = value
        out.append(agg)
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame()


def aggregate_time_series(results: Sequence[RunResult],
                          columns: Sequence[str] | None = None,
                          confidence: float = 0.95) -> pd.DataFrame:
    """Align replicate time series on ``step`` and summarise across replicates.

    Runs that ended early (extinction) contribute no rows beyond their final
    step, so the replicate count per step is reported explicitly as ``n``.
    Interpreting the tail of an aggregate curve without checking ``n`` is a
    common way to misread these plots.
    """

    frames = []
    for idx, r in enumerate(results):
        ts = r.time_series
        if ts is None or not len(ts):
            continue
        frame = ts.copy()
        frame["__rep"] = idx
        frames.append(frame)
    if not frames:
        return pd.DataFrame()

    stacked = pd.concat(frames, ignore_index=True)
    if columns is None:
        columns = [
            c for c in stacked.columns
            if c not in ("__rep", "step", "season")
            and pd.api.types.is_numeric_dtype(stacked[c])
        ]

    out_rows = []
    for step, block in stacked.groupby("step"):
        row: dict[str, Any] = {
            "step": step,
            "season": float(block["season"].iloc[0]) if "season" in block else np.nan,
            "n_replications": int(block["__rep"].nunique()),
        }
        for col in columns:
            if col not in block:
                continue
            mean, lo, hi, _ = mean_ci(block[col].to_numpy(), confidence)
            row[f"{col}_mean"] = mean
            row[f"{col}_ci_lower"] = lo
            row[f"{col}_ci_upper"] = hi
        out_rows.append(row)
    return pd.DataFrame(out_rows).sort_values("step").reset_index(drop=True)


def extinction_rate(results: Sequence[RunResult]) -> dict[str, Any]:
    """Extinction frequency with a Wilson score interval.

    A Wilson interval is used rather than the normal approximation because
    extinction counts are frequently 0 or n, where the normal interval
    degenerates to zero width and would imply false certainty.
    """

    n = len(results)
    if n == 0:
        return {"n_runs": 0, "n_extinct": 0, "extinction_rate": float("nan")}
    k = sum(1 for r in results if r.extinct)
    p = k / n
    z = 1.959963985
    denom = 1.0 + z ** 2 / n
    centre = (p + z ** 2 / (2 * n)) / denom
    half = (z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2))) / denom
    return {
        "n_runs": n,
        "n_extinct": k,
        "extinction_rate": p,
        "extinction_ci_lower": float(max(0.0, centre - half)),
        "extinction_ci_upper": float(min(1.0, centre + half)),
    }

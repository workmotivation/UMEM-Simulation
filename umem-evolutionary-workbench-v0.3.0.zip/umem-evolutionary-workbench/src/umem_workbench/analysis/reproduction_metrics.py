"""Reproduction, mating and inheritance summary metrics.

All quantities here are **descriptive**. None is a fitness function: fitness in
this model is realised lifetime reproductive success, an outcome the simulation
produces rather than an objective imposed on agents.

Naming convention
-----------------
The breeding series has one row per **time step** under distributed timing and
one row per **season** under legacy timing. Every metric name therefore states
its denominator explicitly (``_per_step``, ``_per_season``) or is a plain total.
A quantity such as "mean pairs" without a stated denominator is ambiguous across
timing modes and is deliberately not provided.

* ``*_per_step``: mean over breeding-series rows of the *instantaneous* value.
  Under legacy timing there is one row per season, so the same function reports
  ``nan`` for per-step means rather than silently mislabelling a per-season
  value.
* ``*_per_season``: rows are first summed within each season, then averaged
  across seasons. Defined for both timing modes.
* ``eligible_agent_steps``: eligibility is a *stock* observed each step, so its
  per-season sum is an exposure (agent-steps), not a count of unique agents.

Definitions of the concentration measures
-----------------------------------------
* **LRS Gini**: Gini coefficient of lifetime reproductive success over completed
  lives; 0 = perfectly even, 1 = one agent produced everything.
* **Top-20% share**: fraction of all surviving offspring attributable to the
  20% of completed lives with the highest LRS.
* **Birth-phase entropy**: normalised Shannon entropy of births by step-within-
  season; 1 = births uniform across the season, 0 = all births on one step.
* **Failed-match rate**: attempts that found no partner, over all attempts.

Edge cases: zero births, zero LRS, extinction, very short runs, and legacy
columns that do not exist all return ``nan`` or ``0`` as appropriate; nothing
here raises, and no infinities are produced.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from ..config.enums import ReproductionTiming
from ..engine.results import RunResult

__all__ = [
    "reproduction_summary",
    "gini",
    "top_share",
    "birth_phase_entropy",
    "per_season_totals",
]


# ---------------------------------------------------------------------------
# Pure helpers (tested on synthetic data)
# ---------------------------------------------------------------------------
def gini(values) -> float:
    """Gini coefficient. ``nan`` for empty input; 0 for all-zero input."""

    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan")
    if np.all(x == 0):
        return 0.0
    x = np.sort(np.maximum(x, 0.0))
    n = x.size
    cum = np.cumsum(x)
    return float((n + 1 - 2 * np.sum(cum) / cum[-1]) / n)


def top_share(values, fraction: float = 0.2) -> float:
    """Share of the total held by the top ``fraction`` of contributors."""

    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0 or x.sum() <= 0:
        return float("nan")
    k = max(1, int(np.ceil(fraction * x.size)))
    return float(np.sort(x)[::-1][:k].sum() / x.sum())


def birth_phase_entropy(births, step_in_season, steps_per_season: int) -> float:
    """Normalised entropy of births over step-within-season. ``nan`` if none."""

    births = np.asarray(births, dtype=float)
    phase = np.asarray(step_in_season, dtype=int)
    sps = max(1, int(steps_per_season))
    if births.size == 0 or births.sum() <= 0 or sps == 1:
        return float("nan")
    by_phase = np.bincount(phase % sps, weights=births, minlength=sps)
    p = by_phase[by_phase > 0] / by_phase.sum()
    return float(-(p * np.log(p)).sum() / np.log(sps))


def per_season_totals(bs: pd.DataFrame, column: str) -> pd.Series:
    """Sum a breeding-series column within each season."""

    if column not in bs.columns or "season" not in bs.columns:
        return pd.Series(dtype=float)
    return bs.groupby("season")[column].sum()


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def _col(bs: pd.DataFrame, name: str) -> np.ndarray | None:
    return bs[name].to_numpy(dtype=float) if name in bs.columns else None


def reproduction_summary(result: RunResult) -> dict[str, Any]:
    """All reproduction, mating, and inheritance summary metrics for one run."""

    out: dict[str, Any] = {}
    scen = result.scenario_dict
    timing = (scen.get("reproduction", {}) or {}).get("timing",
                                                      "season_end_legacy")
    distributed = timing == ReproductionTiming.DISTRIBUTED.value
    sps = int((scen.get("lifecycle", {}) or {}).get("steps_per_season", 1))
    out["reproduction_timing"] = timing

    bs = result.breeding_series
    if bs is None or not len(bs):
        bs = pd.DataFrame()

    # ---------------- totals (both timing modes) ----------------
    def total(name: str) -> int:
        v = _col(bs, name)
        return int(np.nansum(v)) if v is not None else 0

    out["total_reproductive_attempts"] = total("n_attempts")
    out["total_failed_no_partner"] = total("n_failed_no_partner")
    out["total_successful_events"] = total("n_pairs")
    out["total_offspring_pre_survival"] = total("n_offspring_pre_survival")
    out["total_offspring_survived"] = total("n_offspring_survived")
    out["total_mutation_events"] = total("n_mutation_events")

    att = out["total_reproductive_attempts"]
    out["failed_match_rate"] = (out["total_failed_no_partner"] / att
                                if att > 0 else float("nan"))
    pre = out["total_offspring_pre_survival"]
    out["realised_juvenile_survival"] = (out["total_offspring_survived"] / pre
                                        if pre > 0 else float("nan"))
    ev = out["total_successful_events"]
    out["mean_offspring_per_event_pre_survival"] = (pre / ev if ev > 0
                                                    else float("nan"))
    out["mutation_events_per_offspring"] = (
        out["total_mutation_events"] / out["total_offspring_survived"]
        if out["total_offspring_survived"] > 0 else float("nan"))

    # ---------------- per-step means (distributed only) ----------------
    if distributed and len(bs):
        for src, dst in (("n_pairs", "mean_pairs_per_step"),
                         ("n_attempts", "mean_attempts_per_step"),
                         ("n_eligible", "mean_eligible_agents_per_step"),
                         ("n_offspring_survived", "mean_births_per_step")):
            v = _col(bs, src)
            out[dst] = float(np.nanmean(v)) if v is not None else float("nan")
        births = _col(bs, "n_offspring_survived")
        if births is not None and "step" in bs.columns:
            out["share_steps_with_births"] = float((births > 0).mean())
            out["birth_phase_entropy"] = birth_phase_entropy(
                births, bs["step"].to_numpy(), sps)
    else:
        for dst in ("mean_pairs_per_step", "mean_attempts_per_step",
                    "mean_eligible_agents_per_step", "mean_births_per_step",
                    "share_steps_with_births", "birth_phase_entropy"):
            out[dst] = float("nan")
        # Legacy: one event per season by construction.
        if len(bs):
            out["share_steps_with_births"] = float(
                (bs["n_offspring_survived"].to_numpy() > 0).sum()
                / max(1, sps * bs["season"].nunique()))
            out["birth_phase_entropy"] = 0.0 if total("n_offspring_survived") else float("nan")

    # ---------------- per-season totals (both modes) ----------------
    for src, dst in (("n_pairs", "mean_total_pairs_per_season"),
                     ("n_attempts", "mean_total_attempts_per_season"),
                     ("n_offspring_survived", "mean_births_per_season"),
                     ("n_eligible", "mean_eligible_agent_steps_per_season")):
        ps = per_season_totals(bs, src)
        out[dst] = float(ps.mean()) if len(ps) else float("nan")
    # Under legacy timing eligibility is observed once per season, so the
    # "agent-steps" exposure is just the count; state that explicitly.
    if not distributed:
        out["mean_eligible_agents_at_season_end"] = out.pop(
            "mean_eligible_agent_steps_per_season")

    # ---------------- pair bonds ----------------
    if "n_active_bonds" in bs.columns and len(bs):
        out["mean_active_bonds_per_step"] = (
            float(bs["n_active_bonds"].mean()) if distributed else float("nan"))
        out["peak_active_bonds"] = int(bs["n_active_bonds"].max())
        out["total_bonds_formed"] = total("n_bonds_formed_step")
        out["total_bonds_dissolved"] = total("n_bonds_dissolved_step")
        out["total_bonds_dissolved_by_death"] = total(
            "n_bonds_dissolved_by_death_step")
        out["total_bonds_dissolved_stochastic"] = total(
            "n_bonds_dissolved_stochastic_step")
        if "cumulative_bonds_formed" in bs.columns:
            # Consistency check exposed as a metric so a regression is visible.
            out["bond_counter_consistent"] = bool(
                out["total_bonds_formed"]
                == int(bs["cumulative_bonds_formed"].iloc[-1]))

    # ---------------- LRS and concentration ----------------
    dl = result.dead_log_df
    if dl is not None and len(dl):
        lrs = dl["lifetime_offspring"].to_numpy(dtype=float)
        mean_lrs = float(np.mean(lrs))
        out["mean_lrs_completed_lives"] = mean_lrs
        out["var_lrs_completed_lives"] = float(np.var(lrs))
        out["frac_zero_lrs"] = float(np.mean(lrs <= 0))
        out["opportunity_for_selection_I"] = (
            float(np.var(lrs) / mean_lrs ** 2) if mean_lrs > 0 else float("nan"))
        out["lrs_gini"] = gini(lrs)
        out["lrs_top20pct_share"] = top_share(lrs, 0.2)
        mature = dl["reached_maturity"].to_numpy().astype(bool)
        if mature.any():
            out["mean_lrs_given_maturity"] = float(np.mean(lrs[mature]))
            out["lrs_gini_given_maturity"] = gini(lrs[mature])
    else:
        for k in ("mean_lrs_completed_lives", "var_lrs_completed_lives",
                  "frac_zero_lrs", "opportunity_for_selection_I", "lrs_gini",
                  "lrs_top20pct_share"):
            out[k] = float("nan")

    return out

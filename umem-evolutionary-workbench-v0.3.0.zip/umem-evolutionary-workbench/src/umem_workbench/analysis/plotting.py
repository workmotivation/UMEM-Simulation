"""Figure generation (Master Prompt sections 18 and 19.2).

All figures use a colourblind-safe qualitative palette, are drawn on a
non-interactive Agg backend so they work headless, and default to 300 DPI for
publication export. Every function returns a :class:`matplotlib.figure.Figure`
and never calls ``show``; saving is the caller's decision.
"""

from __future__ import annotations

from typing import Any

import matplotlib

matplotlib.use("Agg")  # noqa: E402  - must precede pyplot import

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..engine.results import RunResult

__all__ = [
    "OKABE_ITO",
    "apply_house_style",
    "plot_population",
    "plot_death_causes",
    "plot_domain_propensities",
    "plot_task_allocation",
    "plot_environment",
    "plot_forecast_error",
    "plot_nonfunctional_behaviour",
    "plot_lifespan_distribution",
    "plot_lrs_distribution",
    "plot_replicate_band",
    "standard_figure_set",
    "save_figures",
]

#: Okabe-Ito qualitative palette: distinguishable under the common forms of
#: colour vision deficiency and in greyscale print.
OKABE_ITO = [
    "#0072B2",  # blue
    "#D55E00",  # vermillion
    "#009E73",  # bluish green
    "#CC79A7",  # reddish purple
    "#E69F00",  # orange
    "#56B4E9",  # sky blue
    "#F0E442",  # yellow
    "#000000",  # black
]

DEFAULT_DPI = 300


def apply_house_style() -> None:
    """Apply the shared rcParams. Idempotent."""

    plt.rcParams.update({
        "figure.dpi": 110,
        "savefig.dpi": DEFAULT_DPI,
        "savefig.bbox": "tight",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linewidth": 0.6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "legend.frameon": False,
        "legend.fontsize": 9,
        "axes.prop_cycle": plt.cycler(color=OKABE_ITO),
    })


apply_house_style()


def _x_axis(ts: pd.DataFrame) -> tuple[np.ndarray, str]:
    if "step" in ts.columns:
        return ts["step"].to_numpy(), "Time step"
    return np.arange(len(ts)), "Snapshot"


def _finish(ax, title: str, xlabel: str, ylabel: str) -> None:
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)


def _no_data(title: str):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.text(0.5, 0.5, "No data available", ha="center", va="center",
            transform=ax.transAxes, color="0.4")
    ax.set_axis_off()
    ax.set_title(title)
    return fig


# ---------------------------------------------------------------------------
# 18.1 Population
# ---------------------------------------------------------------------------
def plot_population(result: RunResult, show_capacity: bool = True):
    ts = result.time_series
    if ts is None or not len(ts):
        return _no_data("Population")
    x, xlabel = _x_axis(ts)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(x, ts["population"], color=OKABE_ITO[0], lw=1.6, label="Population")

    if show_capacity:
        k = result.scenario_dict.get("population", {}).get("carrying_capacity")
        if k:
            ax.axhline(k, color="0.5", ls="--", lw=1.0,
                       label=f"Carrying capacity ({k})")
    if result.extinct:
        ax.axhline(0, color=OKABE_ITO[1], lw=1.0)
        ax.annotate("Extinct", xy=(x[-1], 0), xytext=(-40, 14),
                    textcoords="offset points", color=OKABE_ITO[1])
    _finish(ax, "Population over time", xlabel, "Individuals")
    ax.legend()
    return fig


def plot_death_causes(result: RunResult):
    """Stacked deaths per recording interval, by attributed cause."""

    ts = result.time_series
    if ts is None or not len(ts):
        return _no_data("Mortality by cause")
    cols = [c for c in ts.columns
            if c.startswith("deaths_") and c != "deaths_interval"]
    if not cols:
        return _no_data("Mortality by cause")

    x, xlabel = _x_axis(ts)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.stackplot(x, *[ts[c].to_numpy(dtype=float) for c in cols],
                 labels=[c[len("deaths_"):] for c in cols],
                 colors=OKABE_ITO[:len(cols)], alpha=0.9)
    _finish(ax, "Deaths per recording interval, by cause", xlabel, "Deaths")
    ax.legend(ncol=2, loc="upper right")
    return fig


# ---------------------------------------------------------------------------
# 18.4 Motivation and behaviour
# ---------------------------------------------------------------------------
def plot_domain_propensities(result: RunResult):
    """Mean inherited domain propensity over time.

    These are *inherited propensities*, not realised energy allocation; the two
    diverge whenever homeostasis or cognition reweights choice.
    """

    ts = result.time_series
    if ts is None or not len(ts):
        return _no_data("Domain propensities")
    cols = [c for c in ts.columns if c.startswith("domprop_")]
    if not cols:
        return _no_data("Domain propensities")

    x, xlabel = _x_axis(ts)
    fig, ax = plt.subplots(figsize=(7, 4))
    for i, c in enumerate(cols):
        ax.plot(x, ts[c], lw=1.5, color=OKABE_ITO[i % len(OKABE_ITO)],
                label=c[len("domprop_"):])
    _finish(ax, "Mean inherited domain propensity", xlabel, "Propensity (a.u.)")
    ax.legend(ncol=2)
    return fig


def plot_task_allocation(result: RunResult, kind: str = "timealloc"):
    """Stacked share of time or energy across tasks."""

    ts = result.time_series
    if ts is None or not len(ts):
        return _no_data("Task allocation")
    cols = [c for c in ts.columns if c.startswith(f"{kind}_")]
    if not cols:
        return _no_data("Task allocation")

    x, xlabel = _x_axis(ts)
    data = [ts[c].to_numpy(dtype=float) for c in cols]
    data = [np.nan_to_num(d, nan=0.0) for d in data]
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    ax.stackplot(x, *data, labels=[c[len(kind) + 1:] for c in cols],
                 colors=[OKABE_ITO[i % len(OKABE_ITO)] for i in range(len(cols))],
                 alpha=0.9)
    label = "Time share" if kind == "timealloc" else "Energy share"
    _finish(ax, f"{label} by task", xlabel, label)
    ax.legend(ncol=3, fontsize=8, loc="upper center",
              bbox_to_anchor=(0.5, -0.18))
    return fig


# ---------------------------------------------------------------------------
# 18.5 Environment and cognition
# ---------------------------------------------------------------------------
def plot_environment(result: RunResult, include_observation: bool = True):
    ts = result.time_series
    if ts is None or not len(ts):
        return _no_data("Environment")
    env_cols = [c for c in ts.columns if c.startswith("env_")]
    if not env_cols:
        return _no_data("Environment")

    x, xlabel = _x_axis(ts)
    fig, ax = plt.subplots(figsize=(7, 4))
    for i, c in enumerate(env_cols):
        var = c[len("env_"):]
        colour = OKABE_ITO[i % len(OKABE_ITO)]
        ax.plot(x, ts[c], lw=1.6, color=colour, label=f"{var} (true)")
        obs = f"obs_{var}"
        if include_observation and obs in ts.columns:
            ax.plot(x, ts[obs], lw=0.9, ls=":", color=colour, alpha=0.8,
                    label=f"{var} (perceived)")
    _finish(ax, "Environmental variables: true vs perceived", xlabel, "Value")
    ax.legend(ncol=2, fontsize=8)
    return fig


def plot_forecast_error(result: RunResult):
    ts = result.time_series
    if ts is None or not len(ts):
        return _no_data("Forecast error")
    cols = [c for c in ts.columns if c.startswith("forecast_err_")]
    if not cols:
        return _no_data("Forecast error (cognition B disabled)")

    x, xlabel = _x_axis(ts)
    fig, ax = plt.subplots(figsize=(7, 4))
    for i, c in enumerate(cols):
        ax.plot(x, ts[c], lw=1.2, color=OKABE_ITO[i % len(OKABE_ITO)],
                label=c[len("forecast_err_"):])
    ax.axhline(0, color="0.5", lw=0.8)
    _finish(ax, "Forecast error (forecast - true)", xlabel, "Error")
    ax.legend(ncol=2)
    return fig


# ---------------------------------------------------------------------------
# 18.6 Nonfunctional behaviour and misallocation
# ---------------------------------------------------------------------------
def plot_nonfunctional_behaviour(result: RunResult):
    ts = result.time_series
    if ts is None or not len(ts):
        return _no_data("Nonfunctional behaviour")
    wanted = [("nonfunc_action_rate", "Costly nonfunctional: action rate"),
              ("nonfunc_time_share", "Costly nonfunctional: time share"),
              ("nonfunc_energy_share", "Costly nonfunctional: energy share"),
              ("neutral_action_rate", "Low-cost neutral: action rate")]
    present = [(c, lab) for c, lab in wanted if c in ts.columns]
    if not present:
        return _no_data("Nonfunctional behaviour")

    x, xlabel = _x_axis(ts)
    fig, ax = plt.subplots(figsize=(7, 4))
    for i, (c, lab) in enumerate(present):
        ax.plot(x, ts[c], lw=1.5, color=OKABE_ITO[i % len(OKABE_ITO)], label=lab)
    _finish(ax, "Nonfunctional and neutral behaviour", xlabel, "Share of actions / cost")
    ax.legend(fontsize=8)
    return fig


# ---------------------------------------------------------------------------
# 18.2 / 18.3 distributions
# ---------------------------------------------------------------------------
def plot_lifespan_distribution(result: RunResult):
    dl = result.dead_log_df
    if dl is None or not len(dl):
        return _no_data("Lifespan distribution")
    sps = max(1, result.scenario_dict.get("lifecycle", {}).get("steps_per_season", 1))
    age = dl["age_steps"].to_numpy(dtype=float) / sps

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.hist(age, bins=min(40, max(8, int(np.sqrt(age.size)))),
            color=OKABE_ITO[0], alpha=0.85, edgecolor="white", linewidth=0.4)
    ax.axvline(float(np.mean(age)), color=OKABE_ITO[1], ls="--", lw=1.2,
               label=f"mean = {np.mean(age):.2f}")
    _finish(ax, "Lifespan at death (completed lives)", "Lifespan (seasons)", "Count")
    ax.legend()
    return fig


def plot_lrs_distribution(result: RunResult):
    """Realised lifetime reproductive success: the model's fitness measure."""

    dl = result.dead_log_df
    if dl is None or not len(dl):
        return _no_data("Lifetime reproductive success")
    lrs = dl["lifetime_offspring"].to_numpy(dtype=float)

    fig, ax = plt.subplots(figsize=(7, 4))
    bins = np.arange(-0.5, max(1.0, lrs.max()) + 1.5, 1.0)
    ax.hist(lrs, bins=bins, color=OKABE_ITO[2], alpha=0.85,
            edgecolor="white", linewidth=0.4)
    ax.axvline(float(np.mean(lrs)), color=OKABE_ITO[1], ls="--", lw=1.2,
               label=f"mean = {np.mean(lrs):.2f}")
    _finish(ax, "Realised lifetime reproductive success", "Surviving offspring", "Individuals")
    ax.legend()
    return fig


# ---------------------------------------------------------------------------
# Replicate band
# ---------------------------------------------------------------------------
def plot_replicate_band(agg: pd.DataFrame, column: str = "population",
                        title: str | None = None):
    """Mean with confidence band from :func:`analysis.aggregate_time_series`."""

    mean_c, lo_c, hi_c = f"{column}_mean", f"{column}_ci_lower", f"{column}_ci_upper"
    if agg is None or not len(agg) or mean_c not in agg.columns:
        return _no_data(title or column)

    x = agg["step"].to_numpy()
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(x, agg[mean_c], color=OKABE_ITO[0], lw=1.7, label="Mean")
    if lo_c in agg.columns and hi_c in agg.columns:
        ax.fill_between(x, agg[lo_c], agg[hi_c], color=OKABE_ITO[0], alpha=0.20,
                        linewidth=0, label="95% CI")

    # Replicate count falls once runs go extinct; flag it so the tail of the
    # band is not over-interpreted.
    if "n_replications" in agg.columns:
        n = agg["n_replications"].to_numpy()
        if n.size and n.min() < n.max():
            drop = int(x[np.argmax(n < n.max())])
            ax.axvline(drop, color="0.55", ls=":", lw=1.0)
            ax.annotate("replicates begin to drop out", xy=(drop, ax.get_ylim()[1]),
                        xytext=(4, -12), textcoords="offset points",
                        fontsize=8, color="0.4")
    _finish(ax, title or f"{column} across replications", "Time step", column)
    ax.legend()
    return fig


# ---------------------------------------------------------------------------
# Bundles
# ---------------------------------------------------------------------------
def standard_figure_set(result: RunResult) -> dict[str, Any]:
    """The default figure bundle used by the dashboard and the ZIP export."""

    return {
        "population": plot_population(result),
        "death_causes": plot_death_causes(result),
        "domain_propensities": plot_domain_propensities(result),
        "time_allocation": plot_task_allocation(result, "timealloc"),
        "energy_allocation": plot_task_allocation(result, "energyalloc"),
        "environment": plot_environment(result),
        "forecast_error": plot_forecast_error(result),
        "nonfunctional_behaviour": plot_nonfunctional_behaviour(result),
        "lifespan_distribution": plot_lifespan_distribution(result),
        "lrs_distribution": plot_lrs_distribution(result),
    }


def save_figures(figures: dict[str, Any], directory, fmt: str = "png",
                 dpi: int = DEFAULT_DPI, close: bool = True) -> list[str]:
    """Write ``figures`` to ``directory`` and return the written paths."""

    from pathlib import Path
    out_dir = Path(directory)
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    for name, fig in figures.items():
        path = out_dir / f"{name}.{fmt}"
        fig.savefig(path, dpi=dpi, format=fmt)
        written.append(str(path))
        if close:
            plt.close(fig)
    return written

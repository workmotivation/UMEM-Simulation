"""Analysis layer: descriptive metrics, misallocation diagnostics, aggregation."""

from .aggregation import (
                          aggregate_summaries,
                          aggregate_time_series,
                          extinction_rate,
                          mean_ci,
                          summary_table,
)
from .metrics import (
                          diversity_metrics,
                          population_metrics,
                          propensity_metrics,
                          reproduction_metrics,
                          summarise_run,
                          survival_metrics,
)
from .misallocation import (
                          allocation_metrics,
                          cognitive_amplification_ratio,
                          experience_causality_mismatch,
                          forecast_error_metrics,
                          misallocation_metrics,
                          one_step_regret,
                          role_consistency_report,
)
from .reproduction_metrics import (
                          birth_phase_entropy,
                          gini,
                          reproduction_summary,
                          top_share,
)

__all__ = [
    "summarise_run", "population_metrics", "survival_metrics",
    "reproduction_metrics", "diversity_metrics", "propensity_metrics",
    "misallocation_metrics", "allocation_metrics",
    "cognitive_amplification_ratio", "forecast_error_metrics",
    "experience_causality_mismatch", "one_step_regret",
    "role_consistency_report",
    "summary_table", "aggregate_summaries", "aggregate_time_series",
    "extinction_rate", "mean_ci",
    "reproduction_summary", "gini", "top_share", "birth_phase_entropy",
]

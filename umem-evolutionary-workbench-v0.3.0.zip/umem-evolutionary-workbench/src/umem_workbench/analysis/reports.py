"""Human-readable run reports (Master Prompt sections 18 and 20).

These reports are deliberately descriptive. They state what the simulation did
and attach the interpretive caveats the specification requires, but they do not
tell the user what the result "means" biologically, because this is an abstract
theoretical model whose parameters are not empirically derived.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import numpy as np
import pandas as pd

from ..engine.results import RunResult
from ..version import __version__

__all__ = [
    "STANDARD_CAVEATS",
    "run_report_text",
    "replication_report_text",
    "metrics_to_frame",
    "format_metric",
]

#: Caveats that must accompany any exported result set. Mirrors the language
#: used in the About screen and the documentation.
STANDARD_CAVEATS = [
    "This is an abstract theoretical model. Parameter values are illustrative "
    "demonstration settings and are not empirically calibrated to any species.",
    "The heritable 'motivational propensity' is a functional modelling "
    "construct. It does not correspond to any identified genetic locus.",
    "The model makes no claim about subjective experience, consciousness, or "
    "felt motivation in any organism.",
    "Fitness in this model is realised lifetime reproductive success, an "
    "outcome of the simulation. No global survival or utility score is imposed "
    "on agents.",
    "Recorded propensities are inherited tendencies. They are not identical to "
    "realised time or energy allocation, which also reflects homeostasis, "
    "eligibility, and cognition.",
    "Results are stochastic. Conclusions should be drawn from replicated runs "
    "with uncertainty intervals, not from a single trajectory.",
]


def format_metric(value: Any, digits: int = 4) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (int, np.integer)):
        return f"{int(value):,}"
    if isinstance(value, (float, np.floating)):
        if not np.isfinite(value):
            return "undefined"
        if abs(value) >= 1000:
            return f"{value:,.1f}"
        return f"{value:.{digits}g}"
    return str(value)


def metrics_to_frame(summary: dict[str, Any]) -> pd.DataFrame:
    """Flatten a summary dict into a two-column frame for display or export."""

    rows = [{"metric": k, "value": format_metric(v), "raw_value": v}
            for k, v in summary.items()]
    return pd.DataFrame(rows)


def _section(title: str) -> str:
    return f"\n{title}\n{'-' * len(title)}\n"


def _kv(summary: dict[str, Any], keys: Sequence[tuple[str, str]]) -> str:
    lines = []
    for key, label in keys:
        if key in summary:
            lines.append(f"  {label:.<44} {format_metric(summary[key])}")
    return "\n".join(lines) + "\n" if lines else "  (not available)\n"


def run_report_text(result: RunResult, summary: dict[str, Any] | None = None
                    ) -> str:
    """A plain-text report for a single run."""

    if summary is None:
        from .metrics import summarise_run
        summary = summarise_run(result)

    scen = result.scenario_dict
    out = []
    out.append("=" * 68)
    out.append("UMEM Evolutionary Simulation Workbench - Run Report")
    out.append("=" * 68)
    out.append(f"Scenario         : {scen.get('name', 'unnamed')}")
    out.append(f"Preset origin    : {scen.get('preset_origin') or 'custom'}")
    out.append(f"Run id           : {result.run_id}")
    out.append(f"Config hash      : {result.config_hash}")
    out.append(f"Master seed      : {scen.get('master_seed')}")
    out.append(f"Replication index: {result.replication_index}")
    out.append(f"Software version : {__version__}")
    out.append(f"Started / ended  : {result.start_time} / {result.end_time}")
    if result.cancelled:
        out.append("STATUS           : CANCELLED BY USER (results are partial)")

    out.append(_section("Population"))
    out.append(_kv(summary, [
        ("final_population", "Final population"),
        ("peak_population", "Peak population"),
        ("min_population", "Minimum population"),
        ("mean_population", "Mean population"),
        ("population_cv", "Population coefficient of variation"),
        ("extinct", "Extinct"),
        ("extinction_season", "Extinction season"),
        ("seasons_completed", "Seasons completed"),
    ]))

    out.append(_section("Survival"))
    out.append(_kv(summary, [
        ("n_deaths", "Completed lives recorded"),
        ("mean_lifespan_seasons", "Mean lifespan (seasons)"),
        ("median_lifespan_seasons", "Median lifespan (seasons)"),
        ("mean_lifespan_given_maturity", "Mean lifespan given maturity"),
        ("frac_reaching_maturity", "Fraction reaching maturity"),
    ]))
    cause_keys = [(k, k.replace("death_share_", "  share: "))
                  for k in summary if k.startswith("death_share_")]
    if cause_keys:
        out.append("  Death causes (share of completed lives):\n")
        out.append(_kv(summary, cause_keys))

    out.append(_section("Reproduction and realised fitness"))
    out.append(_kv(summary, [
        ("reproduction_timing", "Reproduction timing"),
        ("total_reproductive_attempts", "Total reproductive attempts"),
        ("total_failed_no_partner", "  ... failed: no partner available"),
        ("failed_match_rate", "Failed-match rate"),
        ("total_successful_events", "Total successful reproductive events"),
        ("total_offspring_pre_survival", "Total offspring before juvenile survival"),
        ("total_offspring_survived", "Total surviving offspring"),
        ("realised_juvenile_survival", "Realised juvenile survival"),
        ("mean_pairs_per_step", "Mean events per step (distributed)"),
        ("mean_total_pairs_per_season", "Mean total events per season"),
        ("mean_eligible_agents_per_step", "Mean eligible agents per step"),
        ("share_steps_with_births", "Share of steps with births"),
        ("birth_phase_entropy", "Birth-phase entropy (1 = uniform)"),
        ("total_bonds_formed", "Pair bonds formed"),
        ("total_bonds_dissolved", "Pair bonds dissolved"),
        ("peak_active_bonds", "Peak active pair bonds"),
        ("total_mutation_events", "Mutation events"),
        ("mean_lrs_completed_lives", "Mean lifetime reproductive success"),
        ("var_lrs_completed_lives", "Variance in LRS"),
        ("frac_zero_lrs", "Fraction leaving no offspring"),
        ("opportunity_for_selection_I", "Opportunity for selection (Crow's I)"),
        ("lrs_gini", "LRS Gini coefficient"),
        ("lrs_top20pct_share", "Offspring share of top 20% of parents"),
    ]))

    out.append(_section("Behaviour and misallocation"))
    out.append(_kv(summary, [
        ("final_nonfunctional_action_rate", "Nonfunctional action rate (final)"),
        ("final_nonfunctional_time_share", "Nonfunctional time share (final)"),
        ("final_nonfunctional_energy_share", "Nonfunctional energy share (final)"),
        ("final_neutral_action_rate", "Neutral action rate (final)"),
        ("nonfunctional_rate_change", "Change in nonfunctional rate"),
        ("experience_memory_active", "Intergenerational memory active"),
        ("experience_mismatch_total_abs", "Experience-causality mismatch (total)"),
        ("experience_mismatch_nonbeneficial", "  ... on non-beneficial tasks"),
        ("forecast_mae_mean", "Mean forecast absolute error"),
    ]))

    out.append(_section("Diversity"))
    out.append(_kv(summary, [
        ("final_n_lineages", "Surviving lineages"),
        ("peak_n_lineages", "Peak lineages"),
        ("variance_retained_fraction", "Heritable variance retained"),
    ]))

    out.append(_section("Interpretation caveats"))
    for i, caveat in enumerate(STANDARD_CAVEATS, 1):
        out.append(f"  {i}. {caveat}")
    out.append("")
    return "\n".join(out)


def replication_report_text(results: Sequence[RunResult],
                            aggregated: pd.DataFrame | None = None) -> str:
    """A plain-text report for a replicated experiment (section 17.2)."""

    from .aggregation import aggregate_summaries, extinction_rate, summary_table

    if not results:
        return "No runs to report."

    table = summary_table(results)
    if aggregated is None:
        aggregated = aggregate_summaries(table)
    ext = extinction_rate(results)

    scen = results[0].scenario_dict
    out = []
    out.append("=" * 68)
    out.append("UMEM Evolutionary Simulation Workbench - Replication Report")
    out.append("=" * 68)
    out.append(f"Scenario     : {scen.get('name', 'unnamed')}")
    out.append(f"Config hash  : {results[0].config_hash}")
    out.append(f"Master seed  : {scen.get('master_seed')}")
    out.append(f"Replications : {len(results)}")
    out.append(f"Version      : {__version__}")

    out.append(_section("Extinction"))
    out.append(f"  Extinct runs ......... {ext['n_extinct']} / {ext['n_runs']}")
    out.append(f"  Extinction rate ...... {format_metric(ext['extinction_rate'])}")
    if "extinction_ci_lower" in ext:
        out.append(f"  95% Wilson interval .. [{format_metric(ext['extinction_ci_lower'])}, "
                   f"{format_metric(ext['extinction_ci_upper'])}]")

    headline = [
        "final_population", "peak_population", "mean_lifespan_seasons",
        "mean_lrs_completed_lives", "opportunity_for_selection_I",
        "final_nonfunctional_action_rate", "final_nonfunctional_energy_share",
        "variance_retained_fraction",
    ]
    out.append(_section("Headline metrics (mean [95% CI], sd)"))
    idx = aggregated.set_index("metric") if len(aggregated) else pd.DataFrame()
    for metric in headline:
        if len(idx) and metric in idx.index:
            row = idx.loc[metric]
            out.append(
                f"  {metric:.<44} {format_metric(row['mean'])} "
                f"[{format_metric(row['ci_lower'])}, {format_metric(row['ci_upper'])}] "
                f"sd={format_metric(row['sd'])}")

    # Distribution of LRS pooled across replicates (section 17.2).
    lrs = [r.dead_log_df["lifetime_offspring"].to_numpy(dtype=float)
           for r in results
           if r.dead_log_df is not None and len(r.dead_log_df)]
    if lrs:
        pooled = np.concatenate(lrs)
        out.append(_section("Pooled lifetime reproductive success"))
        out.append(f"  n completed lives .... {pooled.size:,}")
        out.append(f"  mean ................. {format_metric(float(pooled.mean()))}")
        out.append(f"  sd ................... {format_metric(float(pooled.std(ddof=1)))}")
        for q in (0.25, 0.5, 0.75, 0.9, 0.99):
            out.append(f"  quantile {q:<11.2f} {format_metric(float(np.quantile(pooled, q)))}")

    out.append(_section("Interpretation caveats"))
    for i, caveat in enumerate(STANDARD_CAVEATS, 1):
        out.append(f"  {i}. {caveat}")
    out.append("")
    return "\n".join(out)

"""Summary metrics derived from a completed run (Master Prompt sections 13, 18).

All metrics here are *descriptive summaries of what the simulation did*. None of
them is a fitness function: realised fitness in this model is lifetime
reproductive success (section 11.4), which is an outcome of the run rather than
an objective imposed on agents.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from ..engine.events import DEATH_CAUSE_LABELS, DeathCause
from ..engine.results import RunResult

__all__ = [
    "population_metrics",
    "survival_metrics",
    "reproduction_metrics",
    "diversity_metrics",
    "propensity_metrics",
    "summarise_run",
]


def _safe_last(series: pd.Series) -> float:
    return float(series.iloc[-1]) if len(series) else float("nan")


def _safe_mean(values: np.ndarray) -> float:
    return float(np.mean(values)) if values.size else float("nan")


# ---------------------------------------------------------------------------
# Population
# ---------------------------------------------------------------------------
def population_metrics(result: RunResult) -> dict[str, Any]:
    ts = result.time_series
    if ts is None or not len(ts):
        return {"extinct": True, "final_population": 0}

    pop = ts["population"].to_numpy(dtype=float)
    out: dict[str, Any] = {
        "final_population": int(result.final_population),
        "peak_population": int(np.nanmax(pop)),
        "min_population": int(np.nanmin(pop)),
        "mean_population": float(np.nanmean(pop)),
        "extinct": bool(result.extinct),
        "seasons_completed": int(ts["season"].max()) + 1 if "season" in ts else 0,
    }
    # Season of extinction, if any.
    if result.extinct:
        zero = ts.loc[ts["population"] <= 0, "season"]
        out["extinction_season"] = int(zero.iloc[0]) if len(zero) else None
    else:
        out["extinction_season"] = None

    # Coefficient of variation as a simple volatility descriptor.
    mean_pop = out["mean_population"]
    out["population_cv"] = (
        float(np.nanstd(pop) / mean_pop) if mean_pop > 0 else float("nan"))
    return out


# ---------------------------------------------------------------------------
# Survival / mortality
# ---------------------------------------------------------------------------
def survival_metrics(result: RunResult) -> dict[str, Any]:
    dl = result.dead_log_df
    out: dict[str, Any] = {}
    if dl is None or not len(dl):
        return {"n_deaths": 0}

    steps_per_season = max(1, result.scenario_dict.get(
        "lifecycle", {}).get("steps_per_season", 1))
    age_seasons = dl["age_steps"].to_numpy(dtype=float) / steps_per_season

    out["n_deaths"] = int(len(dl))
    out["mean_lifespan_seasons"] = float(np.mean(age_seasons))
    out["median_lifespan_seasons"] = float(np.median(age_seasons))
    out["max_lifespan_observed_seasons"] = float(np.max(age_seasons))
    out["frac_reaching_maturity"] = float(np.mean(dl["reached_maturity"].to_numpy()))

    # Death-cause composition. The dead log stores human-readable labels, but
    # accept raw enum codes too so the metric survives a schema change.
    causes = dl["cause"].to_numpy()
    total = max(1, len(causes))
    numeric_causes = np.issubdtype(causes.dtype, np.number)
    for cause in DeathCause:
        if cause == DeathCause.ALIVE:
            continue
        label = DEATH_CAUSE_LABELS[cause]
        key = int(cause) if numeric_causes else label
        share = float(np.count_nonzero(causes == key) / total)
        out[f"death_share_{label.replace('/', '_')}"] = share
        out[f"death_count_{label.replace('/', '_')}"] = int(
            np.count_nonzero(causes == key))

    # Lifespan conditional on reaching maturity (juvenile mortality otherwise
    # dominates the mean and makes the number hard to interpret).
    mature = dl["reached_maturity"].to_numpy().astype(bool)
    if mature.any():
        out["mean_lifespan_given_maturity"] = float(np.mean(age_seasons[mature]))
    return out


# ---------------------------------------------------------------------------
# Reproduction / realised fitness
# ---------------------------------------------------------------------------
def reproduction_metrics(result: RunResult) -> dict[str, Any]:
    """Reproduction, mating and inheritance summary. See
    :mod:`umem_workbench.analysis.reproduction_metrics` for definitions.

    The former keys ``mean_pairs_per_season`` and ``mean_eligible_per_season``
    were removed: under distributed timing they were per-*step* means
    mislabelled as per-season. Use ``mean_pairs_per_step`` /
    ``mean_total_pairs_per_season`` and ``mean_eligible_agents_per_step`` /
    ``mean_eligible_agent_steps_per_season`` instead.
    """

    from .reproduction_metrics import reproduction_summary
    return reproduction_summary(result)


# ---------------------------------------------------------------------------
# Diversity
# ---------------------------------------------------------------------------
def diversity_metrics(result: RunResult) -> dict[str, Any]:
    ts = result.time_series
    out: dict[str, Any] = {}
    if ts is None or not len(ts):
        return out
    if "n_lineages" in ts:
        out["final_n_lineages"] = _safe_last(ts["n_lineages"])
        out["peak_n_lineages"] = float(ts["n_lineages"].max())
    # Mean within-population variance of domain propensities at the end of the
    # run: a coarse index of remaining heritable variation.
    var_cols = [c for c in ts.columns if c.startswith("domvar_")]
    if var_cols:
        out["final_mean_domain_variance"] = float(ts[var_cols].iloc[-1].mean())
        out["initial_mean_domain_variance"] = float(ts[var_cols].iloc[0].mean())
        init = out["initial_mean_domain_variance"]
        out["variance_retained_fraction"] = (
            out["final_mean_domain_variance"] / init if init > 0 else float("nan"))
    return out


# ---------------------------------------------------------------------------
# Propensity / behaviour
# ---------------------------------------------------------------------------
def propensity_metrics(result: RunResult) -> dict[str, Any]:
    ts = result.time_series
    out: dict[str, Any] = {}
    if ts is None or not len(ts):
        return out

    for prefix, label in (("domprop_", "final_domain_prop"),
                          ("taskprop_", "final_task_prop"),
                          ("timealloc_", "final_time_alloc"),
                          ("energyalloc_", "final_energy_alloc")):
        for col in [c for c in ts.columns if c.startswith(prefix)]:
            key = col[len(prefix):]
            out[f"{label}_{key}"] = _safe_last(ts[col])

    # Direction of change in domain propensity across the run (drift/selection).
    for col in [c for c in ts.columns if c.startswith("domprop_")]:
        key = col[len("domprop_"):]
        first, last = float(ts[col].iloc[0]), float(ts[col].iloc[-1])
        out[f"domain_prop_change_{key}"] = last - first
        out[f"domain_prop_log_ratio_{key}"] = (
            float(np.log(last / first)) if first > 0 and last > 0 else float("nan"))
    return out


# ---------------------------------------------------------------------------
# Aggregate entry point
# ---------------------------------------------------------------------------
def summarise_run(result: RunResult, include_misallocation: bool = True
                  ) -> dict[str, Any]:
    """Compute the full descriptive summary for ``result``.

    The returned dict is flat (scalar values only) so it can be written
    directly into a one-row DataFrame, an Excel summary sheet, or a sweep table.
    """

    summary: dict[str, Any] = {
        "run_id": result.run_id,
        "config_hash": result.config_hash,
        "replication_index": getattr(result, "replication_index", 0),
        "cancelled": bool(result.cancelled),
    }
    summary.update(population_metrics(result))
    summary.update(survival_metrics(result))
    summary.update(reproduction_metrics(result))
    summary.update(diversity_metrics(result))
    summary.update(propensity_metrics(result))
    if include_misallocation:
        from .misallocation import misallocation_metrics
        summary.update(misallocation_metrics(result))
    return summary

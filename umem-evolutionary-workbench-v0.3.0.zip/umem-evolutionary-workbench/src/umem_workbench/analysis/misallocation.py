"""Cognitive misallocation metrics (Master Prompt section 13).

Design rule from the specification: provide *several transparent metrics rather
than one opaque index*. Nothing here is combined into a single weighted utility
score. Where a ratio is unavoidable (cognitive amplification) the denominator
handling is explicit and the metric is reported alongside its raw components.

Definitions used
----------------
functional
    A task whose configured effect rules confer a direct benefit
    (energy, health, reproductive capital, observation quality, or hazard
    reduction). Determined from the effect rules, not from the role label.
costly nonfunctional
    Role ``COSTLY_NONFUNCTIONAL``: no direct modelled benefit, but a
    non-trivial time, energy, or hazard cost.
low-cost neutral
    Role ``LOW_COST_NEUTRAL``: no direct modelled benefit and minimal cost,
    able to persist by drift.

The role label is what the user asserted; the effect rules are what the model
actually does. :func:`role_consistency_report` surfaces disagreements between
the two, which the validation layer also warns about.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from ..config.enums import TaskRole
from ..config.models import ScenarioConfig
from ..engine.results import RunResult

__all__ = [
    "misallocation_metrics",
    "cognitive_amplification_ratio",
    "forecast_error_metrics",
    "experience_causality_mismatch",
    "role_consistency_report",
    "one_step_regret",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _scenario_of(result: RunResult) -> ScenarioConfig:
    from ..config.serialization import scenario_from_dict
    return scenario_from_dict(result.scenario_dict)


def _tasks_by_role(scenario: ScenarioConfig) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {
        "functional": [], "costly_nonfunctional": [], "low_cost_neutral": []}
    for task in scenario.enabled_tasks():
        if task.role == TaskRole.COSTLY_NONFUNCTIONAL:
            out["costly_nonfunctional"].append(task.task_id)
        elif task.role == TaskRole.LOW_COST_NEUTRAL:
            out["low_cost_neutral"].append(task.task_id)
        else:
            out["functional"].append(task.task_id)
    return out


def _final_mean(ts: pd.DataFrame, cols: list[str], tail: int = 1) -> float:
    """Mean over the last ``tail`` recorded snapshots of the summed columns."""

    present = [c for c in cols if c in ts.columns]
    if not present or not len(ts):
        return float("nan")
    block = ts[present].tail(max(1, tail))
    return float(block.sum(axis=1).mean())


# ---------------------------------------------------------------------------
# 13.1-13.3 action rate, time allocation, energy allocation
# ---------------------------------------------------------------------------
def allocation_metrics(result: RunResult, tail: int = 5) -> dict[str, Any]:
    """Nonfunctional and neutral action rate, time share, and energy share."""

    ts = result.time_series
    if ts is None or not len(ts):
        return {}

    scenario = _scenario_of(result)
    roles = _tasks_by_role(scenario)
    out: dict[str, Any] = {}

    # The recorder already tracks the aggregate shares; prefer those so the
    # definition stays identical to what the engine counted.
    for col, key in (("nonfunc_action_rate", "nonfunctional_action_rate"),
                     ("neutral_action_rate", "neutral_action_rate"),
                     ("nonfunc_time_share", "nonfunctional_time_share"),
                     ("nonfunc_energy_share", "nonfunctional_energy_share")):
        if col in ts.columns:
            out[f"final_{key}"] = float(ts[col].tail(max(1, tail)).mean())
            out[f"mean_{key}"] = float(ts[col].mean())

    # Per-role breakdowns straight from the per-task columns.
    for role_name, task_ids in roles.items():
        if not task_ids:
            continue
        out[f"final_time_share_{role_name}"] = _final_mean(
            ts, [f"timealloc_{t}" for t in task_ids], tail)
        out[f"final_energy_share_{role_name}"] = _final_mean(
            ts, [f"energyalloc_{t}" for t in task_ids], tail)
        out[f"final_action_share_{role_name}"] = _final_mean(
            ts, [f"freq_{t}" for t in task_ids], tail)
        out[f"final_inherited_prop_{role_name}"] = _final_mean(
            ts, [f"taskprop_{t}" for t in task_ids], tail)
        out[f"final_effective_pref_{role_name}"] = _final_mean(
            ts, [f"effpref_{t}" for t in task_ids], tail)

    # Persistence of nonfunctional behaviour: has it decayed or held up?
    if "nonfunc_action_rate" in ts.columns and len(ts) > 1:
        first = float(ts["nonfunc_action_rate"].head(max(1, tail)).mean())
        last = float(ts["nonfunc_action_rate"].tail(max(1, tail)).mean())
        out["nonfunctional_rate_initial"] = first
        out["nonfunctional_rate_final"] = last
        out["nonfunctional_rate_change"] = last - first
        out["nonfunctional_persistence_ratio"] = (
            last / first if first > 0 else float("nan"))
    return out


# ---------------------------------------------------------------------------
# 13.4 cognitive amplification ratio
# ---------------------------------------------------------------------------
def cognitive_amplification_ratio(
        cognitive: RunResult | float,
        baseline: RunResult | float,
        metric: str = "final_nonfunctional_action_rate",
        epsilon: float = 1e-9) -> dict[str, Any]:
    """Nonfunctional behaviour under cognition relative to a no-cognition run.

    Parameters
    ----------
    cognitive, baseline
        Either :class:`RunResult` objects or already-computed scalar values of
        ``metric``. The baseline must be the *same scenario with cognition
        disabled*; the caller is responsible for that pairing.
    metric
        Which allocation metric to compare.
    epsilon
        Floor applied to the denominator.

    Returns
    -------
    dict with the two raw components, the ratio, the difference, and a flag
    recording whether the denominator was degenerate. The difference is
    reported because when the baseline is near zero the ratio is unstable and
    the additive contrast is the more honest summary.
    """

    def _value(obj: RunResult | float) -> float:
        if isinstance(obj, (int, float)):
            return float(obj)
        return float(allocation_metrics(obj).get(metric, float("nan")))

    num = _value(cognitive)
    den = _value(baseline)
    degenerate = not np.isfinite(den) or abs(den) < epsilon

    return {
        "amplification_metric": metric,
        "amplification_numerator": num,
        "amplification_denominator": den,
        "cognitive_amplification_ratio": (
            float("nan") if degenerate else num / den),
        "cognitive_amplification_difference": num - den,
        "amplification_denominator_degenerate": bool(degenerate),
    }


# ---------------------------------------------------------------------------
# 13.5 forecast error
# ---------------------------------------------------------------------------
def forecast_error_metrics(result: RunResult) -> dict[str, Any]:
    """Difference between forecast/perceived and true environment."""

    ts = result.time_series
    out: dict[str, Any] = {}
    if ts is None or not len(ts):
        return out

    err_cols = [c for c in ts.columns if c.startswith("forecast_err_")]
    for col in err_cols:
        var = col[len("forecast_err_"):]
        err = ts[col].to_numpy(dtype=float)
        err = err[np.isfinite(err)]
        if not err.size:
            continue
        out[f"forecast_mae_{var}"] = float(np.mean(np.abs(err)))
        out[f"forecast_rmse_{var}"] = float(np.sqrt(np.mean(err ** 2)))
        out[f"forecast_bias_{var}"] = float(np.mean(err))

    # Observation error (perception) is distinct from forecast error
    # (anticipation); both matter for interpreting misallocation.
    for col in [c for c in ts.columns if c.startswith("obs_")]:
        var = col[len("obs_"):]
        true_col = f"env_{var}"
        if true_col not in ts.columns:
            continue
        diff = (ts[col].to_numpy(dtype=float)
                - ts[true_col].to_numpy(dtype=float))
        diff = diff[np.isfinite(diff)]
        if diff.size:
            out[f"observation_mae_{var}"] = float(np.mean(np.abs(diff)))
            out[f"observation_bias_{var}"] = float(np.mean(diff))

    if out:
        mae = [v for k, v in out.items() if k.startswith("forecast_mae_")]
        if mae:
            out["forecast_mae_mean"] = float(np.mean(mae))
    return out


# ---------------------------------------------------------------------------
# 13.6 experience-causality mismatch
# ---------------------------------------------------------------------------
def experience_causality_mismatch(result: RunResult, tail: int = 5
                                  ) -> dict[str, Any]:
    """Gap between a task's weight in success memory and its real contribution.

    The intergenerational memory records how strongly each memory-eligible task
    is *associated* with successful agents. That association is correlational:
    a task can be well represented in the memory of successful agents purely
    because successful agents had time to do it. This metric contrasts that
    representation with the task's configured objective contribution.

    The objective contribution is a deliberately coarse indicator derived from
    the configuration: 1.0 if the task's effect rules confer any direct benefit,
    0.0 otherwise. A large positive mismatch on a zero-contribution task is the
    signature of cognitive misallocation.
    """

    ts = result.time_series
    out: dict[str, Any] = {}
    if ts is None or not len(ts):
        return out

    exp_cols = [c for c in ts.columns if c.startswith("exp_")]
    if not exp_cols:
        return out

    scenario = _scenario_of(result)
    by_id = {t.task_id: t for t in scenario.enabled_tasks()}

    # Normalise memory representation across tasks so the comparison is on a
    # common scale (shares summing to 1 over memory-eligible tasks).
    block = ts[exp_cols].tail(max(1, tail)).mean(axis=0)
    values = block.to_numpy(dtype=float)
    values = np.where(np.isfinite(values), values, 0.0)
    total = float(np.sum(np.abs(values)))

    if total <= 0:
        # Intergenerational memory carries no signal (typically because
        # cognition A is disabled). Reporting a mismatch here would be
        # meaningless -- and reporting zero memory share against non-zero
        # contribution shares would spuriously imply a maximal mismatch -- so
        # the metric is explicitly undefined instead.
        return {"experience_mismatch_total_abs": float("nan"),
                "experience_mismatch_nonbeneficial": float("nan"),
                "experience_memory_active": False}

    shares = values / total

    contributions: list[float] = []
    for col in exp_cols:
        task = by_id.get(col[len("exp_"):])
        contributions.append(
            1.0 if (task is not None and task.has_direct_benefit()) else 0.0)
    contributions = np.asarray(contributions, dtype=float)
    csum = float(contributions.sum())
    contribution_shares = (contributions / csum if csum > 0
                           else np.zeros_like(contributions))

    mismatches = shares - contribution_shares
    for col, mism, share, contrib in zip(
            exp_cols, mismatches, shares, contribution_shares):
        tid = col[len("exp_"):]
        out[f"memory_share_{tid}"] = float(share)
        out[f"contribution_share_{tid}"] = float(contrib)
        out[f"experience_mismatch_{tid}"] = float(mism)

    out["experience_memory_active"] = True
    out["experience_mismatch_total_abs"] = float(np.sum(np.abs(mismatches)))
    # Mismatch restricted to tasks with no modelled benefit: the clearest
    # single indicator of memory crediting a causally inert behaviour.
    inert = contributions <= 0
    out["experience_mismatch_nonbeneficial"] = (
        float(np.sum(mismatches[inert])) if inert.any() else 0.0)
    return out


# ---------------------------------------------------------------------------
# Role/effect consistency (section 12 safeguard)
# ---------------------------------------------------------------------------
def role_consistency_report(scenario: ScenarioConfig) -> list[dict[str, Any]]:
    """Flag tasks whose declared role disagrees with their effect rules."""

    rows: list[dict[str, Any]] = []
    for task in scenario.enabled_tasks():
        benefit = task.has_direct_benefit()
        role = task.role
        inconsistent = (
            (role in (TaskRole.COSTLY_NONFUNCTIONAL, TaskRole.LOW_COST_NEUTRAL)
             and benefit)
            or (role == TaskRole.FUNCTIONAL and not benefit))
        rows.append({
            "task_id": task.task_id,
            "role": role.value,
            "has_direct_benefit": benefit,
            "energy_cost": task.energy_cost,
            "inconsistent": inconsistent,
        })
    return rows


# ---------------------------------------------------------------------------
# Optional local diagnostic
# ---------------------------------------------------------------------------
def one_step_regret(result: RunResult, tail: int = 5) -> dict[str, Any]:
    """Local one-step diagnostic: share of actions spent on inert behaviour.

    .. warning::
       This is a **local, single-step diagnostic only**. It is not a measure of
       evolutionary fitness and must never be presented as one. An action that
       looks wasteful in a single step may be neutral or even favourable over a
       lifetime, and this model deliberately does not impose a global utility
       function over energy, health, and reproduction.
    """

    ts = result.time_series
    if ts is None or not len(ts) or "nonfunc_action_rate" not in ts.columns:
        return {}
    val = float(ts["nonfunc_action_rate"].tail(max(1, tail)).mean())
    return {
        "one_step_regret_proxy": val,
        "one_step_regret_is_local_diagnostic": True,
    }


# ---------------------------------------------------------------------------
# Aggregate entry point
# ---------------------------------------------------------------------------
def misallocation_metrics(result: RunResult, tail: int = 5) -> dict[str, Any]:
    """All section-13 metrics that can be computed from a single run.

    The cognitive amplification ratio is *not* included here because it is
    inherently a two-run comparison; call
    :func:`cognitive_amplification_ratio` with a matched no-cognition baseline.
    """

    out: dict[str, Any] = {}
    out.update(allocation_metrics(result, tail=tail))
    out.update(forecast_error_metrics(result))
    out.update(experience_causality_mismatch(result, tail=tail))
    out.update(one_step_regret(result, tail=tail))
    return out

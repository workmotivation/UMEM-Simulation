"""PySide6 desktop interface package."""

from .app import PYSIDE_AVAILABLE, main

__all__ = ["main", "PYSIDE_AVAILABLE"]

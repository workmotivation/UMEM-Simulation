"""PySide6 desktop interface (Master Prompt sections 16 and 26).

The desktop application shares :class:`WorkbenchState` with the Streamlit
interface, so both drive exactly the same engine, validation, and export code.

Threading model
---------------
Simulation work never runs on the Qt GUI thread. A :class:`SimulationWorker`
lives on a :class:`QThread` and communicates only through signals, so the
window stays responsive and Cancel takes effect promptly. The worker holds a
:class:`CancellationToken`
the engine checks it at step boundaries and returns
whatever it has already collected, which is then clearly labelled partial.

This module is import-safe without PySide6 installed: the import error is
raised only when :func:`main` is actually called.
"""

from __future__ import annotations

import sys
import traceback
from pathlib import Path
from typing import Any

try:  # pragma: no cover - exercised only in a desktop environment
    from PySide6.QtCore import QObject, Qt, QThread, Signal, Slot
    from PySide6.QtGui import QAction, QFont
    from PySide6.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QDoubleSpinBox,
        QFileDialog,
        QFormLayout,
        QGroupBox,
        QHBoxLayout,
        QLabel,
        QMainWindow,
        QMessageBox,
        QPlainTextEdit,
        QProgressBar,
        QPushButton,
        QScrollArea,
        QSpinBox,
        QSplitter,
        QStatusBar,
        QTableWidget,
        QTableWidgetItem,
        QTabWidget,
        QTextEdit,
        QVBoxLayout,
        QWidget,
    )

    PYSIDE_AVAILABLE = True
except ImportError:  # pragma: no cover
    PYSIDE_AVAILABLE = False

    # Minimal stand-ins so that the class bodies below can still be evaluated
    # at import time. They are never functional: any attempt to actually build
    # the interface raises a helpful ImportError from _require_pyside().
    class QObject:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            pass

    class QMainWindow:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:
            pass

    class _SignalStub:
        def __init__(self, *args, **kwargs) -> None:
            pass

        def connect(self, *args, **kwargs) -> None:
            pass

        def emit(self, *args, **kwargs) -> None:
            pass

    def Signal(*args, **kwargs):  # type: ignore[no-redef]
        return _SignalStub()

    def Slot(*args, **kwargs):  # type: ignore[no-redef]
        def decorator(func):
            return func

        return decorator

    QThread = QApplication = QFont = None  # type: ignore[assignment]

from ..config.enums import ExperimentMode
from ..config.presets import PRESET_DESCRIPTIONS, PRESET_IDS
from ..config.serialization import scenario_from_dict, scenario_to_dict
from ..ui_common.help_text import (
    ABOUT_TEXT,
    DISCLAIMER_SHORT,
    DISCLAIMERS,
)
from ..ui_common.presets import (
    SimpleSettings,
    apply_simple_settings,
    read_simple_settings,
)
from ..ui_common.view_models import WorkbenchState
from ..version import __version__

__all__ = ["main", "MainWindow", "SimulationWorker", "PYSIDE_AVAILABLE"]

APP_TITLE = "UMEM Evolutionary Simulation Workbench"


def _require_pyside() -> None:
    if not PYSIDE_AVAILABLE:
        raise ImportError(
            "PySide6 is required for the desktop interface. Install it with "
            "'pip install PySide6', or use the Streamlit interface instead: "
            "streamlit run streamlit_app.py"
        )


# ---------------------------------------------------------------------------
# Background worker
# ---------------------------------------------------------------------------
class SimulationWorker(QObject):
    """Runs an experiment off the GUI thread."""

    progressed = Signal(float, str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, state: WorkbenchState) -> None:
        super().__init__()
        self._state = state

    @Slot()
    def run(self) -> None:
        try:
            outcome = self._state.run(
                on_progress=lambda fraction, message: self.progressed.emit(
                    float(fraction), str(message)
                )
            )
            self.finished.emit(outcome)
        except Exception as exc:  # pragma: no cover - surfaced in the GUI
            self.failed.emit(f"{exc}\n\n{traceback.format_exc()}")


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class MainWindow(QMainWindow):
    """The application window."""

    def __init__(self) -> None:
        _require_pyside()
        super().__init__()
        self.state = WorkbenchState()
        self._thread: QThread | None = None
        self._worker: SimulationWorker | None = None

        self.setWindowTitle(APP_TITLE)
        self.resize(1180, 820)
        self._build_menu()
        self._build_ui()
        self._refresh_status()

    # ------------------------------------------------------------------
    def _build_menu(self) -> None:
        menu = self.menuBar()

        file_menu = menu.addMenu("&File")
        for label, slot, shortcut in (
            ("&Open scenario...", self.on_open_scenario, "Ctrl+O"),
            ("&Save scenario...", self.on_save_scenario, "Ctrl+S"),
            ("&Export results...", self.on_export, "Ctrl+E"),
        ):
            action = QAction(label, self)
            action.setShortcut(shortcut)
            action.triggered.connect(slot)
            file_menu.addAction(action)
        file_menu.addSeparator()
        quit_action = QAction("&Quit", self)
        quit_action.setShortcut("Ctrl+Q")
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)

        run_menu = menu.addMenu("&Run")
        self.run_action = QAction("&Run experiment", self)
        self.run_action.setShortcut("F5")
        self.run_action.triggered.connect(self.on_run)
        run_menu.addAction(self.run_action)
        self.cancel_action = QAction("&Cancel", self)
        self.cancel_action.setShortcut("Esc")
        self.cancel_action.setEnabled(False)
        self.cancel_action.triggered.connect(self.on_cancel)
        run_menu.addAction(self.cancel_action)

        help_menu = menu.addMenu("&Help")
        about_action = QAction("&About", self)
        about_action.triggered.connect(self.on_about)
        help_menu.addAction(about_action)

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        central = QWidget()
        layout = QVBoxLayout(central)

        banner = QLabel(DISCLAIMER_SHORT)
        banner.setWordWrap(True)
        banner.setStyleSheet(
            "background:#fff4e5; border:1px solid #e0b070; padding:6px;"
        )
        layout.addWidget(banner)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_simple_tab(), "Simple")
        self.tabs.addTab(self._build_advanced_tab(), "Advanced")
        self.tabs.addTab(self._build_run_tab(), "Run")
        self.tabs.addTab(self._build_results_tab(), "Results")
        self.tabs.addTab(self._build_ai_tab(), "AI assistance")
        self.tabs.addTab(self._build_about_tab(), "About")
        layout.addWidget(self.tabs)

        self.setCentralWidget(central)
        self.setStatusBar(QStatusBar())

    # ------------------------------------------------------------------
    def _build_simple_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)

        preset_box = QGroupBox("Preset scenario")
        preset_layout = QHBoxLayout(preset_box)
        self.preset_combo = QComboBox()
        for preset_id in PRESET_IDS:
            self.preset_combo.addItem(preset_id.replace("_", " ").title(), preset_id)
        self.preset_combo.currentIndexChanged.connect(self._on_preset_described)
        preset_layout.addWidget(self.preset_combo, 3)
        load_button = QPushButton("Load preset")
        load_button.clicked.connect(self.on_load_preset)
        preset_layout.addWidget(load_button, 1)
        outer.addWidget(preset_box)

        self.preset_description = QLabel(PRESET_DESCRIPTIONS.get(PRESET_IDS[0], ""))
        self.preset_description.setWordWrap(True)
        outer.addWidget(self.preset_description)

        controls = QGroupBox("Simple controls")
        form = QFormLayout(controls)
        current = read_simple_settings(self.state.scenario)

        def _double(minimum, maximum, value, step) -> QDoubleSpinBox:
            box = QDoubleSpinBox()
            box.setRange(minimum, maximum)
            box.setSingleStep(step)
            box.setValue(float(value))
            return box

        def _int(minimum, maximum, value) -> QSpinBox:
            box = QSpinBox()
            box.setRange(minimum, maximum)
            box.setValue(int(value))
            return box

        self.resource_box = _double(0.05, 1.0, current.resource_abundance or 0.5, 0.05)
        self.volatility_box = _double(
            0.0, 0.5, current.environmental_volatility or 0.05, 0.01
        )
        self.predation_box = _double(0.0, 1.0, current.predation_pressure or 0.3, 0.05)
        self.initial_pop_box = _int(10, 5000, current.initial_population or 200)
        self.capacity_box = _int(10, 10000, current.carrying_capacity or 500)
        self.lifespan_box = _int(2, 30, current.average_lifespan or 12)
        self.maturity_box = _int(0, 15, current.maturity_age or 2)
        self.fertility_box = _double(0.0, 8.0, current.fertility or 1.5, 0.1)
        self.mutation_box = _double(0.0, 0.5, current.mutation_strength or 0.1, 0.01)
        self.seasons_box = _int(1, 500, current.total_seasons or 30)
        self.replications_box = _int(1, 200, current.replications or 1)
        self.seed_box = _int(0, 2**31 - 2, current.master_seed or 12345)

        # --- schema 2: reproduction and inheritance (shared SimpleSettings) ---
        def _combo(options, value, labels=None):
            box = QComboBox()
            for opt in options:
                box.addItem((labels or {}).get(opt, opt), opt)
            idx = options.index(value) if value in options else 0
            box.setCurrentIndex(idx)
            return box

        self.repro_mode_combo = _combo(
            ["sexual", "asexual"],
            current.reproduction_mode or "sexual",
            {"sexual": "Sexual (Type A + Type B)", "asexual": "Asexual (no partner)"},
        )
        self.timing_combo = _combo(
            ["distributed", "season_end_legacy"],
            current.reproduction_timing or "distributed",
            {
                "distributed": "Continuous (recommended)",
                "season_end_legacy": "Season-end (compatibility mode)",
            },
        )
        self.rate_box = _double(0.0, 12.0, current.reproductive_rate or 1.7, 0.1)
        self.mating_combo = _combo(
            ["random", "pair_bonded", "competitive"],
            current.mating_mode or "random",
            {
                "random": "Random mixing (promiscuity)",
                "pair_bonded": "Pair bonding (social monogamy)",
                "competitive": "Competitive (reproductive skew)",
            },
        )
        self.choosiness_box = _int(1, 100, current.mate_choice_k or 1)
        self.founder_combo = _combo(
            ["uniform", "stable", "all_newborn_legacy"],
            current.founder_age_distribution or "uniform",
            {
                "uniform": "Spread evenly over lifespan",
                "stable": "Approximate stable age structure",
                "all_newborn_legacy": "All start at age zero (legacy)",
            },
        )
        self.inheritance_combo = _combo(
            ["polygenic_additive", "legacy"],
            current.inheritance_model or "polygenic_additive",
            {
                "polygenic_additive": "Polygenic additive (recommended)",
                "legacy": "Legacy (compatibility mode)",
            },
        )
        self.sibling_combo = _combo(
            ["low", "standard", "high"], current.sibling_variation or "standard"
        )
        self.mutation_level_combo = _combo(
            ["none", "conservative", "accelerated"],
            current.mutation_level or "conservative",
        )
        self.gestation_note = QLabel(
            "Gestation delay is not part of the continuous model; a non-zero "
            "value is rejected under continuous timing. Set it in Advanced "
            "mode only for season-end legacy scenarios."
        )
        self.gestation_note.setWordWrap(True)
        self.gestation_note.setStyleSheet("color:#7a5200;")

        self.repro_mode_combo.currentIndexChanged.connect(
            self._refresh_simple_enablement
        )
        self.timing_combo.currentIndexChanged.connect(self._refresh_simple_enablement)
        self.mating_combo.currentIndexChanged.connect(self._refresh_simple_enablement)
        self.inheritance_combo.currentIndexChanged.connect(
            self._refresh_simple_enablement
        )

        self.cognition_combo = QComboBox()
        self.cognition_combo.addItems(["none", "experience", "forecast", "both"])
        self.cognition_combo.setCurrentText(current.cognition_mode or "none")

        self.homeostasis_check = QCheckBox("Homeostasis enabled")
        self.homeostasis_check.setChecked(bool(current.homeostasis_enabled))
        self.nonfunctional_check = QCheckBox("Costly nonfunctional behaviour")
        self.nonfunctional_check.setChecked(bool(current.nonfunctional_enabled))

        form.addRow("Resource abundance", self.resource_box)
        form.addRow("Environmental volatility", self.volatility_box)
        form.addRow("Predation pressure", self.predation_box)
        form.addRow("Initial population (agents)", self.initial_pop_box)
        form.addRow("Carrying capacity (agents)", self.capacity_box)
        form.addRow("Average lifespan (seasons)", self.lifespan_box)
        form.addRow("Maturity age (seasons)", self.maturity_box)
        form.addRow("Fertility (offspring/event)", self.fertility_box)
        form.addRow("Mutation strength", self.mutation_box)
        form.addRow("Cognition mode", self.cognition_combo)
        form.addRow("", self.homeostasis_check)
        form.addRow("", self.nonfunctional_check)
        form.addRow("Number of seasons", self.seasons_box)
        form.addRow("Replications", self.replications_box)
        form.addRow("Master seed", self.seed_box)

        repro_group = QGroupBox(
            "Reproduction (Type A / Type B are neutral reproductive types)"
        )
        repro_form = QFormLayout(repro_group)
        repro_form.addRow("Reproduction mode", self.repro_mode_combo)
        repro_form.addRow("Reproduction timing", self.timing_combo)
        repro_form.addRow(
            "Reproductive event rate (events/agent/season)", self.rate_box
        )
        repro_form.addRow("Mating mode", self.mating_combo)
        repro_form.addRow("Choosiness k (candidates inspected)", self.choosiness_box)
        repro_form.addRow("", self.gestation_note)
        bond_note = QLabel(
            "Pair bonds form between mature agents; reproduction "
            "additionally requires the energy, health and capital "
            "thresholds."
        )
        bond_note.setWordWrap(True)
        repro_form.addRow("", bond_note)
        outer.addWidget(repro_group)

        inh_group = QGroupBox(
            "Inheritance (polygenic quantitative traits, not single genes)"
        )
        inh_form = QFormLayout(inh_group)
        inh_form.addRow("Founder ages", self.founder_combo)
        inh_form.addRow("Inheritance model", self.inheritance_combo)
        inh_form.addRow("Sibling genetic variation", self.sibling_combo)
        inh_form.addRow("Mutation level", self.mutation_level_combo)
        outer.addWidget(inh_group)
        self._refresh_simple_enablement()
        outer.addWidget(controls)

        apply_button = QPushButton("Apply settings")
        apply_button.clicked.connect(self.on_apply_simple)
        outer.addWidget(apply_button)
        outer.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(page)
        return scroll

    # ------------------------------------------------------------------
    def _build_advanced_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        note = QLabel(
            "Advanced view of the current configuration. Values are shown as "
            "dotted paths; edit a scenario file directly or use the Simple "
            "controls, then reload here. Editing marks the scenario Custom."
        )
        note.setWordWrap(True)
        layout.addWidget(note)

        self.config_table = QTableWidget(0, 2)
        self.config_table.setHorizontalHeaderLabels(["Parameter", "Value"])
        self.config_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.config_table)

        self.validation_text = QTextEdit()
        self.validation_text.setReadOnly(True)
        self.validation_text.setMaximumHeight(180)
        layout.addWidget(QLabel("Validation report"))
        layout.addWidget(self.validation_text)
        return page

    # ------------------------------------------------------------------
    def _build_run_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        mode_box = QGroupBox("Experiment")
        mode_form = QFormLayout(mode_box)
        self.mode_combo = QComboBox()
        self.mode_combo.addItems([m.value for m in ExperimentMode])
        self.workers_box = QSpinBox()
        self.workers_box.setRange(1, 32)
        self.workers_box.setValue(1)
        mode_form.addRow("Mode", self.mode_combo)
        mode_form.addRow("Parallel workers", self.workers_box)
        layout.addWidget(mode_box)

        self.workload_label = QLabel("")
        self.workload_label.setWordWrap(True)
        layout.addWidget(self.workload_label)

        buttons = QHBoxLayout()
        self.run_button = QPushButton("Run experiment")
        self.run_button.clicked.connect(self.on_run)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self.on_cancel)
        buttons.addWidget(self.run_button)
        buttons.addWidget(self.cancel_button)
        layout.addLayout(buttons)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        layout.addWidget(self.progress)

        self.run_log = QTextEdit()
        self.run_log.setReadOnly(True)
        layout.addWidget(self.run_log)
        return page

    # ------------------------------------------------------------------
    def _build_results_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.results_table = QTableWidget(0, 2)
        self.results_table.setHorizontalHeaderLabels(["Metric", "Value"])
        self.results_table.horizontalHeader().setStretchLastSection(True)

        self.report_text = QTextEdit()
        self.report_text.setReadOnly(True)
        self.report_text.setFont(QFont("Courier New", 9))

        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.results_table)
        splitter.addWidget(self.report_text)
        splitter.setSizes([320, 420])
        layout.addWidget(splitter)

        export_button = QPushButton("Export results bundle...")
        export_button.clicked.connect(self.on_export)
        layout.addWidget(export_button)
        return page

    # ------------------------------------------------------------------
    def _build_ai_tab(self) -> QWidget:
        """External-AI assistance: guides, import/preview/apply, report."""

        page = QWidget()
        layout = QVBoxLayout(page)
        note = QLabel(
            "UMEM makes no AI calls and sends nothing anywhere. Download the guide, "
            "use it with an AI tool of your choice, then bring the JSON back here. "
            "Nothing changes until you press Apply."
        )
        note.setWordWrap(True)
        layout.addWidget(note)

        row = QHBoxLayout()
        b1 = QPushButton("Save AI_SCENARIO_DESIGN_GUIDE.md…")
        b1.clicked.connect(self.on_save_design_guide)
        b2 = QPushButton("Save AI_REPORT_INTERPRETATION_GUIDE.md…")
        b2.clicked.connect(self.on_save_interp_guide)
        self.ai_report_button = QPushButton("Save AI_REPORT.md for this experiment…")
        self.ai_report_button.clicked.connect(self.on_save_ai_report)
        self.ai_report_button.setEnabled(False)
        row.addWidget(b1)
        row.addWidget(b2)
        row.addWidget(self.ai_report_button)
        layout.addLayout(row)

        self.conditions_view = QTextEdit()
        self.conditions_view.setReadOnly(True)
        layout.addWidget(QLabel("Experiment conditions (currently applied)"))
        layout.addWidget(self.conditions_view)

        layout.addWidget(
            QLabel("Paste scenario JSON from your AI (raw or one ```json block):")
        )
        self.ai_paste = QPlainTextEdit()
        self.ai_paste.setPlaceholderText("{ ... }")
        layout.addWidget(self.ai_paste)
        row2 = QHBoxLayout()
        b3 = QPushButton("Load JSON file…")
        b3.clicked.connect(self.on_ai_load_file)
        b4 = QPushButton("Validate and preview")
        b4.clicked.connect(self.on_ai_preview)
        self.ai_apply_button = QPushButton("Apply proposed scenario")
        self.ai_apply_button.setEnabled(False)
        self.ai_apply_button.clicked.connect(self.on_ai_apply)
        b5 = QPushButton("Save validation feedback for AI…")
        b5.clicked.connect(self.on_ai_save_feedback)
        for b in (b3, b4, self.ai_apply_button, b5):
            row2.addWidget(b)
        layout.addLayout(row2)
        self.ai_review = QTextEdit()
        self.ai_review.setReadOnly(True)
        layout.addWidget(QLabel("Review (proposed description, changes, errors)"))
        layout.addWidget(self.ai_review)
        self._ai_import_result = None
        return page

    def _refresh_conditions_view(self) -> None:
        if hasattr(self, "conditions_view"):
            self.conditions_view.setPlainText(
                self.state.experiment_description().markdown(
                    include_specification=False
                )
            )

    def _save_text(self, title: str, default: str, text: str) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, title, default, "Markdown (*.md);;Text (*.txt)"
        )
        if path:
            Path(path).write_text(text, encoding="utf-8")
            self.statusBar().showMessage(f"Saved {path}", 5000)

    def on_save_design_guide(self) -> None:
        from ..ai_assist import scenario_design_guide

        self._save_text(
            "Save design guide", "AI_SCENARIO_DESIGN_GUIDE.md", scenario_design_guide()
        )

    def on_save_interp_guide(self) -> None:
        from ..ai_assist import report_interpretation_guide

        self._save_text(
            "Save interpretation guide",
            "AI_REPORT_INTERPRETATION_GUIDE.md",
            report_interpretation_guide(),
        )

    def on_save_ai_report(self) -> None:
        if self.state.outcome is None:
            QMessageBox.information(self, "No results", "Run an experiment first.")
            return
        self._save_text(
            "Save AI report", "AI_REPORT.md", self.state.ai_report().report_markdown
        )

    def on_ai_load_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Load scenario JSON", "", "JSON/text (*.json *.txt *.md)"
        )
        if path:
            self.ai_paste.setPlainText(
                Path(path).read_text(encoding="utf-8", errors="replace")
            )

    def on_ai_preview(self) -> None:
        from ..ai_assist import diff_scenarios
        from ..config.serialization import scenario_to_dict

        text = self.ai_paste.toPlainText()
        res = self.state.preview_import(text)
        self._ai_import_result = res
        lines = [
            f"Result: {'VALID (not yet applied)' if res.ok else 'REJECTED — current scenario unchanged'}",
            "",
        ]
        for i in res.errors:
            lines.append(
                f"ERROR [{i.stage}] {i.path}: {i.message}"
                + (f"  allowed: {i.allowed}" if i.allowed else "")
            )
        for i in res.warnings:
            lines.append(f"warning [{i.stage}] {i.path}: {i.message}")
        if res.migration_changes:
            lines += ["", f"Migration applied ({len(res.migration_changes)} changes):"]
            lines += [
                f"  {c['path']}: {c['before']!r} -> {c['after']!r}"
                for c in res.migration_changes
            ]
        if res.ok and res.scenario is not None:
            changes = diff_scenarios(
                scenario_to_dict(self.state.scenario), res.effective
            )
            lines += [
                "",
                f"Changes versus currently applied scenario ({len(changes)}):",
            ]
            lines += [
                f"  {c['path']}: {c['before']!r} -> {c['after']!r}"
                for c in changes[:200]
            ]
            lines += ["", "PROPOSED EXPERIMENT:", res.description_markdown]
        self.ai_review.setPlainText("\n".join(lines))
        self.ai_apply_button.setEnabled(bool(res.ok))

    def on_ai_apply(self) -> None:
        if self._ai_import_result is None or not self._ai_import_result.ok:
            return
        self.state.apply_import(self._ai_import_result)
        self._ai_import_result = None
        self.ai_apply_button.setEnabled(False)
        self._sync_simple_controls()
        self._refresh_status()
        self.ai_review.append(
            "\nApplied. Existing results were cleared; use Run to simulate."
        )

    def on_ai_save_feedback(self) -> None:
        from ..ai_assist import validation_feedback_for_ai

        if self._ai_import_result is None:
            QMessageBox.information(
                self, "Nothing to report", "Validate a scenario first."
            )
            return
        self._save_text(
            "Save feedback",
            "UMEM_validation_feedback.txt",
            validation_feedback_for_ai(self._ai_import_result),
        )

    # ------------------------------------------------------------------
    def _build_about_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        text = QTextEdit()
        text.setReadOnly(True)
        caveats = "\n\n".join(f"{title}\n{body}" for title, body in DISCLAIMERS)
        text.setPlainText(
            f"{ABOUT_TEXT}\n\nScientific caveats\n==================\n\n"
            f"{caveats}\n\nVersion {__version__}. MIT licence."
        )
        layout.addWidget(text)
        return page

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------
    def _on_preset_described(self) -> None:
        preset_id = self.preset_combo.currentData()
        self.preset_description.setText(PRESET_DESCRIPTIONS.get(preset_id, ""))

    def on_load_preset(self) -> None:
        self.state.load_preset(self.preset_combo.currentData())
        self._sync_simple_controls()
        self._refresh_status()
        self.statusBar().showMessage("Preset loaded.", 4000)

    def _refresh_simple_enablement(self) -> None:
        """Enable only the controls that apply to the selected mechanisms."""

        asexual = self.repro_mode_combo.currentData() == "asexual"
        legacy_timing = self.timing_combo.currentData() == "season_end_legacy"
        legacy_inh = self.inheritance_combo.currentData() == "legacy"
        random_mating = self.mating_combo.currentData() == "random"

        self.mating_combo.setEnabled(not asexual)
        self.choosiness_box.setEnabled(not asexual and not random_mating)
        self.rate_box.setEnabled(not legacy_timing)
        self.gestation_note.setVisible(not legacy_timing)
        # Segregation is meaningless for clonal reproduction.
        self.sibling_combo.setEnabled(not asexual and not legacy_inh)
        self.mutation_level_combo.setEnabled(not legacy_inh)
        # Legacy-only slider.
        self.mutation_box.setEnabled(legacy_inh)

    def _sync_simple_controls(self) -> None:
        current = read_simple_settings(self.state.scenario)
        self.resource_box.setValue(float(current.resource_abundance or 0.5))
        self.volatility_box.setValue(float(current.environmental_volatility or 0.05))
        self.predation_box.setValue(float(current.predation_pressure or 0.3))
        self.initial_pop_box.setValue(int(current.initial_population or 200))
        self.capacity_box.setValue(int(current.carrying_capacity or 500))
        self.lifespan_box.setValue(int(current.average_lifespan or 12))
        self.maturity_box.setValue(int(current.maturity_age or 2))
        self.fertility_box.setValue(float(current.fertility or 1.5))
        self.mutation_box.setValue(float(current.mutation_strength or 0.1))
        self.seasons_box.setValue(int(current.total_seasons or 30))
        self.replications_box.setValue(int(current.replications or 1))
        self.seed_box.setValue(int(current.master_seed or 12345))
        for combo, value in (
            (self.repro_mode_combo, current.reproduction_mode),
            (self.timing_combo, current.reproduction_timing),
            (self.mating_combo, current.mating_mode),
            (self.founder_combo, current.founder_age_distribution),
            (self.inheritance_combo, current.inheritance_model),
            (self.sibling_combo, current.sibling_variation),
            (self.mutation_level_combo, current.mutation_level),
        ):
            idx = combo.findData(value)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        self.rate_box.setValue(float(current.reproductive_rate or 1.7))
        self.choosiness_box.setValue(int(current.mate_choice_k or 1))
        self._refresh_simple_enablement()
        self.cognition_combo.setCurrentText(current.cognition_mode or "none")
        self.homeostasis_check.setChecked(bool(current.homeostasis_enabled))
        self.nonfunctional_check.setChecked(bool(current.nonfunctional_enabled))

    def on_apply_simple(self) -> None:
        settings = SimpleSettings(
            resource_abundance=self.resource_box.value(),
            environmental_volatility=self.volatility_box.value(),
            predation_pressure=self.predation_box.value(),
            initial_population=self.initial_pop_box.value(),
            carrying_capacity=self.capacity_box.value(),
            average_lifespan=self.lifespan_box.value(),
            maturity_age=self.maturity_box.value(),
            fertility=self.fertility_box.value(),
            mutation_strength=self.mutation_box.value(),
            cognition_mode=self.cognition_combo.currentText(),
            homeostasis_enabled=self.homeostasis_check.isChecked(),
            nonfunctional_enabled=self.nonfunctional_check.isChecked(),
            total_seasons=self.seasons_box.value(),
            replications=self.replications_box.value(),
            master_seed=self.seed_box.value(),
            reproduction_mode=self.repro_mode_combo.currentData(),
            reproduction_timing=self.timing_combo.currentData(),
            reproductive_rate=self.rate_box.value(),
            mating_mode=self.mating_combo.currentData(),
            mate_choice_k=self.choosiness_box.value(),
            founder_age_distribution=self.founder_combo.currentData(),
            inheritance_model=self.inheritance_combo.currentData(),
            sibling_variation=self.sibling_combo.currentData(),
            mutation_level=self.mutation_level_combo.currentData(),
        )
        try:
            self.state.update_scenario(
                apply_simple_settings(self.state.scenario, settings)
            )
        except Exception as exc:
            QMessageBox.critical(self, "Invalid configuration", str(exc))
            return
        self._refresh_status()
        self.statusBar().showMessage("Settings applied.", 4000)

    # ------------------------------------------------------------------
    def _refresh_status(self) -> None:
        self.setWindowTitle(f"{APP_TITLE} - {self.state.display_name}")
        self._refresh_conditions_view()
        if hasattr(self, "ai_report_button"):
            self.ai_report_button.setEnabled(self.state.outcome is not None)

        data = scenario_to_dict(self.state.scenario)
        rows: list[tuple[str, str]] = []

        def _walk(node: Any, prefix: str = "") -> None:
            if isinstance(node, dict):
                for key, value in node.items():
                    _walk(value, f"{prefix}.{key}" if prefix else str(key))
            elif isinstance(node, list):
                for index, item in enumerate(node):
                    ident = index
                    if isinstance(item, dict):
                        ident = (
                            item.get("task_id")
                            or item.get("domain_id")
                            or item.get("var_id")
                            or index
                        )
                    _walk(item, f"{prefix}.{ident}")
            else:
                rows.append((prefix, str(node)))

        _walk(data)
        self.config_table.setRowCount(len(rows))
        for row, (path, value) in enumerate(rows):
            self.config_table.setItem(row, 0, QTableWidgetItem(path))
            self.config_table.setItem(row, 1, QTableWidgetItem(value))

        report = self.state.validate()
        if not report.issues:
            self.validation_text.setPlainText("No validation issues.")
        else:
            lines = [
                f"[{i.severity.name}] {i.code}: {i.message}" for i in report.issues
            ]
            self.validation_text.setPlainText("\n".join(lines))

        pre = self.state.preflight()
        self.workload_label.setText(
            f"Mode: {pre['mode']} | sweep cells: {pre['n_sweep_cells']} | "
            f"runs per cell: {pre['n_replications_per_cell']} | "
            f"total runs: {pre['total_runs']}. "
            f"Estimated {getattr(pre['workload'], 'total_steps', 0):,} agent "
            f"time steps per run (approximate)."
        )
        self.run_button.setEnabled(pre["can_run"])
        self.run_action.setEnabled(pre["can_run"])

    # ------------------------------------------------------------------
    def on_run(self) -> None:
        if self._thread is not None:
            return

        data = scenario_to_dict(self.state.scenario)
        data["experiment"]["mode"] = self.mode_combo.currentText()
        data["experiment"]["replications"] = self.replications_box.value()
        data["experiment"]["max_workers"] = self.workers_box.value()
        try:
            self.state.update_scenario(scenario_from_dict(data))
        except Exception as exc:
            QMessageBox.critical(self, "Invalid configuration", str(exc))
            return

        self.run_log.clear()
        self.progress.setValue(0)
        self._set_running(True)

        self._thread = QThread(self)
        self._worker = SimulationWorker(self.state)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progressed.connect(self.on_progress)
        self._worker.finished.connect(self.on_finished)
        self._worker.failed.connect(self.on_failed)
        self._thread.start()

    def _set_running(self, running: bool) -> None:
        self.run_button.setEnabled(not running)
        self.run_action.setEnabled(not running)
        self.cancel_button.setEnabled(running)
        self.cancel_action.setEnabled(running)

    @Slot(float, str)
    def on_progress(self, fraction: float, message: str) -> None:
        self.progress.setValue(int(round(fraction * 100)))
        self.statusBar().showMessage(message)

    @Slot(object)
    def on_finished(self, outcome: Any) -> None:
        self._teardown_thread()
        self._set_running(False)
        self.progress.setValue(100)

        if outcome.cancelled:
            self.run_log.append("Run cancelled. The results below are partial.")
        else:
            self.run_log.append(f"Completed {len(outcome.runs)} run(s).")

        self._populate_results()
        if hasattr(self, "ai_report_button"):
            self.ai_report_button.setEnabled(True)
        self.tabs.setCurrentIndex(3)

    @Slot(str)
    def on_failed(self, message: str) -> None:
        self._teardown_thread()
        self._set_running(False)
        self.run_log.append(f"Run failed:\n{message}")
        QMessageBox.critical(self, "Run failed", message.split("\n")[0])

    def _teardown_thread(self) -> None:
        if self._thread is not None:
            self._thread.quit()
            self._thread.wait(5000)
            self._thread = None
            self._worker = None

    def on_cancel(self) -> None:
        self.state.cancel("cancelled from the desktop interface")
        self.statusBar().showMessage(
            "Cancellation requested; finishing the current step...", 5000
        )

    # ------------------------------------------------------------------
    def _populate_results(self) -> None:
        run = self.state.primary_run
        if run is None:
            return
        from ..analysis.metrics import summarise_run
        from ..analysis.reports import format_metric

        summary = run.summary or summarise_run(run)
        items = list(summary.items())
        self.results_table.setRowCount(len(items))
        for row, (metric, value) in enumerate(items):
            self.results_table.setItem(row, 0, QTableWidgetItem(str(metric)))
            self.results_table.setItem(row, 1, QTableWidgetItem(format_metric(value)))
        self.report_text.setPlainText(self.state.report_text())

    # ------------------------------------------------------------------
    def on_open_scenario(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open scenario", "", "Scenario JSON (*.json)"
        )
        if not path:
            return
        try:
            self.state.load_from_file(path)
        except Exception as exc:
            QMessageBox.critical(self, "Could not open scenario", str(exc))
            return
        self._sync_simple_controls()
        self._refresh_status()

    def on_save_scenario(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save scenario", "scenario.json", "Scenario JSON (*.json)"
        )
        if not path:
            return
        try:
            self.state.save_to_file(path)
        except Exception as exc:
            QMessageBox.critical(self, "Could not save scenario", str(exc))
            return
        self.statusBar().showMessage(f"Saved to {path}", 5000)

    def on_export(self) -> None:
        if self.state.primary_run is None:
            QMessageBox.information(
                self, "Nothing to export", "Run an experiment first."
            )
            return
        directory = QFileDialog.getExistingDirectory(self, "Choose an output folder")
        if not directory:
            return
        try:
            path = self.state.export_bundle(directory)
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))
            return
        QMessageBox.information(self, "Export complete", f"Bundle written to:\n{path}")

    def on_about(self) -> None:
        QMessageBox.about(
            self,
            f"About {APP_TITLE}",
            f"{APP_TITLE}\nVersion {__version__}\n\n{DISCLAIMER_SHORT}",
        )

    # ------------------------------------------------------------------
    def closeEvent(self, event) -> None:  # noqa: N802 - Qt naming
        if self._thread is not None:
            self.state.cancel("window closed")
            self._teardown_thread()
        event.accept()


def main() -> int:
    """Entry point for the desktop application."""

    _require_pyside()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_TITLE)
    app.setApplicationVersion(__version__)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

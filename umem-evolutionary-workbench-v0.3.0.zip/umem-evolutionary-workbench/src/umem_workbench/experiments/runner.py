"""Unified experiment entry point (Master Prompt section 17).

``run_experiment`` dispatches on ``scenario.experiment.mode`` so the UI layers
can hand over a scenario and a progress callback without branching themselves.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from ..config.enums import ExperimentMode
from ..config.models import ScenarioConfig
from ..config.validation import estimate_workload, validate_scenario
from ..engine.results import RunResult
from .cancellation import CancellationToken
from .parameter_sweep import (
    SeedPolicy,
    SweepResult,
    expand_grid,
    run_sweep,
)
from .replications import ReplicationResult, run_replications
from .single_run import ScenarioNotRunnable, run_single

__all__ = ["ExperimentOutcome", "run_experiment", "preflight"]

ExperimentPayload = RunResult | ReplicationResult | SweepResult


@dataclass
class ExperimentOutcome:
    """What an experiment produced, plus how it was run."""

    mode: str
    payload: ExperimentPayload
    cancelled: bool = False

    @property
    def runs(self) -> list[RunResult]:
        """Every individual run, whatever the mode."""

        if isinstance(self.payload, RunResult):
            return [self.payload]
        if isinstance(self.payload, ReplicationResult):
            return list(self.payload.runs)
        out: list[RunResult] = []
        for cell in self.payload.cells:
            if cell.replications is not None:
                out.extend(cell.replications.runs)
        return out

    def report_text(self) -> str:
        from ..analysis.reports import replication_report_text, run_report_text
        if isinstance(self.payload, RunResult):
            return run_report_text(self.payload)
        runs = self.runs
        return replication_report_text(runs) if runs else "No runs completed."


def preflight(scenario: ScenarioConfig) -> dict[str, Any]:
    """Validation report plus workload estimate, before anything is run.

    The UI shows this so the user can see the combination count and estimated
    cost of a sweep *before* committing to it (section 17.3).
    """

    report = validate_scenario(scenario)
    workload = estimate_workload(scenario)
    mode = scenario.experiment.mode

    n_cells = 1
    if mode == ExperimentMode.SWEEP and scenario.experiment.sweep_parameters:
        try:
            n_cells = len(expand_grid(scenario.experiment.sweep_parameters))
        except Exception:
            n_cells = 0

    n_reps = (scenario.experiment.replications
              if mode != ExperimentMode.SINGLE else 1)
    limit = scenario.experiment.max_sweep_combinations
    return {
        "validation": report,
        "can_run": report.can_run,
        "workload": workload,
        "mode": mode.value,
        "n_sweep_cells": n_cells,
        "n_replications_per_cell": n_reps,
        "total_runs": n_cells * n_reps,
        "exceeds_max_combinations": n_cells > limit,
        "max_combinations": limit,
    }


def run_experiment(scenario: ScenarioConfig,
                   *,
                   cancel: CancellationToken | None = None,
                   progress: Callable[[float, str], None] | None = None,
                   parallel: bool | None = None,
                   max_workers: int | None = None,
                   validate: bool = True,
                   allow_exceeding_max: bool = False) -> ExperimentOutcome:
    """Run whichever experiment ``scenario.experiment.mode`` specifies."""

    if validate:
        report = validate_scenario(scenario)
        if not report.can_run:
            raise ScenarioNotRunnable(report)

    exp = scenario.experiment
    mode = exp.mode
    if max_workers is None:
        max_workers = exp.max_workers
    if parallel is None:
        parallel = max_workers > 1

    if mode == ExperimentMode.SINGLE:
        result = run_single(scenario, 0, cancel=cancel, progress=progress,
                            validate=False)
        return ExperimentOutcome("single", result, cancelled=result.cancelled)

    if mode == ExperimentMode.REPLICATIONS:
        rep = run_replications(scenario, exp.replications, parallel=parallel,
                               max_workers=max_workers, cancel=cancel,
                               progress=progress, validate=False)
        return ExperimentOutcome("replications", rep, cancelled=rep.cancelled)

    if mode == ExperimentMode.SWEEP:
        policy = (SeedPolicy.COMMON_RANDOM_NUMBERS if exp.common_random_numbers
                  else SeedPolicy.INDEPENDENT)
        sweep = run_sweep(
            scenario, exp.sweep_parameters,
            replications_per_cell=exp.replications,
            seed_policy=policy, parallel=parallel, max_workers=max_workers,
            cancel=cancel, progress=progress,
            max_combinations=exp.max_sweep_combinations,
            allow_exceeding_max=allow_exceeding_max, validate=False)
        return ExperimentOutcome("sweep", sweep, cancelled=sweep.cancelled)

    raise ValueError(f"unsupported experiment mode: {mode}")

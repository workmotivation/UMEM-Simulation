"""Cooperative cancellation for long-running experiments.

The engine checks a cancel callable at step boundaries. A token is used rather
than a hard thread kill so that a cancelled run still returns the partial
results collected so far, correctly flagged, instead of losing them.
"""

from __future__ import annotations

import threading

__all__ = ["CancellationToken", "CancelledError", "never_cancel"]


class CancelledError(RuntimeError):
    """Raised when an operation is abandoned because of cancellation."""


class CancellationToken:
    """A thread-safe, one-way cancellation flag.

    The token is callable so it can be passed straight to the engine wherever a
    ``cancel: Callable[[], bool]`` is expected.
    """

    __slots__ = ("_event", "_reason")

    def __init__(self) -> None:
        self._event = threading.Event()
        self._reason: str | None = None

    def cancel(self, reason: str = "cancelled by user") -> None:
        self._reason = reason
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    @property
    def reason(self) -> str | None:
        return self._reason

    def __call__(self) -> bool:
        return self._event.is_set()

    def raise_if_cancelled(self) -> None:
        if self._event.is_set():
            raise CancelledError(self._reason or "cancelled")

    def wait(self, timeout: float | None = None) -> bool:
        return self._event.wait(timeout)

    def reset(self) -> None:
        """Clear the flag so the token can be reused for another experiment."""

        self._event.clear()
        self._reason = None


def never_cancel() -> bool:
    """A no-op cancel callable."""

    return False

"""Parameter sweeps (Master Prompt section 17.3).

A sweep varies one to three scalar parameters, addressed by a stable dotted
configuration path, and runs a replicated experiment in every cell of the
resulting grid.

Seed policy
-----------
Two options, both reproducible:

``independent`` (default)
    Every cell derives its own seed from the base seed and the cell index, so
    cells are statistically independent.
``common_random_numbers``
    Every cell reuses the same seed sequence, so replication *i* in every cell
    sees the same environmental draws. This removes environmental variance from
    between-cell comparisons and sharply increases power for detecting a
    parameter effect, at the cost of correlating the cells. It is offered as a
    documented advanced option because the resulting estimates are paired and
    must be analysed as such.
"""

from __future__ import annotations

import itertools
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from ..config.models import ScenarioConfig, SweepParameter
from ..config.serialization import scenario_from_dict, scenario_to_dict
from ..config.validation import validate_scenario
from .cancellation import CancellationToken
from .replications import ReplicationResult, run_replications
from .single_run import ScenarioNotRunnable

__all__ = [
    "SeedPolicy",
    "SweepCell",
    "SweepResult",
    "expand_grid",
    "apply_path",
    "get_path",
    "run_sweep",
    "MAX_COMBINATIONS_DEFAULT",
]

#: Default warning threshold for the number of grid cells (section 17.3).
MAX_COMBINATIONS_DEFAULT = 200


class SeedPolicy:
    INDEPENDENT = "independent"
    COMMON_RANDOM_NUMBERS = "common_random_numbers"


# ---------------------------------------------------------------------------
# Dotted-path access
# ---------------------------------------------------------------------------
def get_path(scenario: ScenarioConfig | dict[str, Any], path: str) -> Any:
    """Read a value by dotted path, e.g. ``mortality.base_predation_hazard``.

    List elements are addressed by index (``environment.0.mean``) or, more
    stably, by identifier (``tasks.safe_forage.energy_cost``), since inserting
    a task should not silently change what a saved sweep refers to.
    """

    node: Any = (scenario_to_dict(scenario)
                 if isinstance(scenario, ScenarioConfig) else scenario)
    for part in path.split("."):
        node = _descend(node, part, path)
    return node


def apply_path(scenario_dict: dict[str, Any], path: str, value: Any
               ) -> dict[str, Any]:
    """Return a copy of ``scenario_dict`` with ``path`` set to ``value``."""

    import copy
    out = copy.deepcopy(scenario_dict)
    parts = path.split(".")
    node: Any = out
    for part in parts[:-1]:
        node = _descend(node, part, path)
    last = parts[-1]
    if isinstance(node, list):
        node[_list_index(node, last, path)] = value
    elif isinstance(node, dict):
        if last not in node:
            raise KeyError(f"sweep path '{path}': no key '{last}'")
        node[last] = value
    else:
        raise KeyError(f"sweep path '{path}': cannot assign into {type(node)}")
    return out


def _descend(node: Any, part: str, path: str) -> Any:
    if isinstance(node, list):
        return node[_list_index(node, part, path)]
    if isinstance(node, dict):
        if part not in node:
            raise KeyError(f"sweep path '{path}': no key '{part}'")
        return node[part]
    raise KeyError(f"sweep path '{path}': cannot descend into {type(node)}")


def _list_index(node: list, part: str, path: str) -> int:
    if part.isdigit():
        idx = int(part)
        if idx >= len(node):
            raise IndexError(f"sweep path '{path}': index {idx} out of range")
        return idx
    for i, item in enumerate(node):
        if isinstance(item, dict):
            for key in ("task_id", "domain_id", "var_id", "id"):
                if item.get(key) == part:
                    return i
    raise KeyError(f"sweep path '{path}': no element identified by '{part}'")


# ---------------------------------------------------------------------------
# Grid
# ---------------------------------------------------------------------------
@dataclass
class SweepCell:
    """One combination of swept parameter values."""

    index: int
    values: dict[str, float]
    scenario_dict: dict[str, Any]
    replications: ReplicationResult | None = None

    def label(self) -> str:
        return ", ".join(f"{k}={v:g}" for k, v in self.values.items())


def expand_grid(parameters: Sequence[SweepParameter]) -> list[dict[str, float]]:
    """Materialise the cartesian product of the swept parameter values."""

    if not parameters:
        return []
    if len(parameters) > 3:
        raise ValueError("sweeps support at most three parameters (section 17.3)")

    axes = []
    for param in parameters:
        values = param.resolved_values()
        if not values:
            raise ValueError(f"sweep parameter '{param.path}' resolved to no values")
        axes.append([(param.path, float(v)) for v in values])
    return [dict(combo) for combo in itertools.product(*axes)]


@dataclass
class SweepResult:
    base_scenario_dict: dict[str, Any]
    parameter_paths: list[str]
    cells: list[SweepCell] = field(default_factory=list)
    cancelled: bool = False
    seed_policy: str = SeedPolicy.INDEPENDENT

    def summary_table(self) -> pd.DataFrame:
        """Long-format table: one row per replication, with cell coordinates."""

        frames = []
        for cell in self.cells:
            if cell.replications is None or not cell.replications.runs:
                continue
            block = cell.replications.summaries.copy()
            block["sweep_cell"] = cell.index
            for path, value in cell.values.items():
                block[path] = value
            frames.append(block)
        return (pd.concat(frames, ignore_index=True) if frames
                else pd.DataFrame())

    def aggregated_table(self, confidence: float = 0.95) -> pd.DataFrame:
        """Mean and CI per metric within each sweep cell."""

        from ..analysis.aggregation import aggregate_summaries
        table = self.summary_table()
        if not len(table):
            return pd.DataFrame()
        return aggregate_summaries(table, confidence=confidence,
                                   group_by=self.parameter_paths)

    def response_curve(self, metric: str = "final_population") -> pd.DataFrame:
        """Metric vs swept values, ready to plot as a curve or heatmap."""

        agg = self.aggregated_table()
        if not len(agg):
            return pd.DataFrame()
        sel = agg[agg["metric"] == metric]
        cols = self.parameter_paths + [
            "mean", "ci_lower", "ci_upper", "sd", "n_replications"]
        return sel[[c for c in cols if c in sel.columns]].reset_index(drop=True)


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
def run_sweep(scenario: ScenarioConfig,
              parameters: Sequence[SweepParameter] | None = None,
              *,
              replications_per_cell: int = 3,
              seed_policy: str = SeedPolicy.INDEPENDENT,
              parallel: bool = False,
              max_workers: int | None = None,
              cancel: CancellationToken | None = None,
              progress: Callable[[float, str], None] | None = None,
              max_combinations: int = MAX_COMBINATIONS_DEFAULT,
              allow_exceeding_max: bool = False,
              validate: bool = True) -> SweepResult:
    """Run a replicated experiment in every cell of the parameter grid."""

    if parameters is None:
        parameters = scenario.experiment.sweep_parameters
    if not parameters:
        raise ValueError("no sweep parameters supplied")

    grid = expand_grid(parameters)
    if len(grid) > max_combinations and not allow_exceeding_max:
        raise ValueError(
            f"sweep would run {len(grid)} combinations, above the configured "
            f"maximum of {max_combinations}. Reduce the grid or pass "
            f"allow_exceeding_max=True.")

    if validate:
        report = validate_scenario(scenario)
        if not report.can_run:
            raise ScenarioNotRunnable(report)

    base_dict = scenario_to_dict(scenario)
    base_seed = int(scenario.master_seed)
    paths = [p.path for p in parameters]
    out = SweepResult(base_scenario_dict=base_dict, parameter_paths=paths,
                      seed_policy=seed_policy)

    for index, values in enumerate(grid):
        if cancel is not None and cancel.cancelled:
            out.cancelled = True
            break

        cell_dict = base_dict
        for path, value in values.items():
            cell_dict = apply_path(cell_dict, path, value)

        # Seed policy. Under CRN every cell keeps the base seed, so replication
        # i faces an identical environmental sequence in every cell.
        if seed_policy == SeedPolicy.COMMON_RANDOM_NUMBERS:
            cell_dict["master_seed"] = base_seed
        else:
            cell_dict["master_seed"] = (base_seed + 1_000_003 * (index + 1)) % (2 ** 31 - 1)

        cell_scenario = scenario_from_dict(cell_dict)
        cell = SweepCell(index=index, values=values,
                         scenario_dict=scenario_to_dict(cell_scenario))

        def _cell_progress(frac: float, msg: str, _i=index) -> None:
            if progress is not None:
                overall = (_i + frac) / max(1, len(grid))
                progress(overall, f"cell {_i + 1}/{len(grid)}: {msg}")

        cell.replications = run_replications(
            cell_scenario,
            replications_per_cell,
            parallel=parallel,
            max_workers=max_workers,
            cancel=cancel,
            progress=_cell_progress,
            validate=False,
        )
        out.cells.append(cell)
        if cell.replications.cancelled:
            out.cancelled = True
            break

    return out

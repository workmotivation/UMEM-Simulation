"""Replicated experiments (Master Prompt section 17.2).

Replications share a master seed and differ only in their replication index,
which selects an independent RNG substream via ``SeedSequence``. That keeps the
whole set reproducible from a single seed while guaranteeing the substreams are
statistically independent rather than merely offset.
"""

from __future__ import annotations

import os
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from ..config.models import ScenarioConfig
from ..config.serialization import config_hash, scenario_from_dict, scenario_to_dict
from ..config.validation import validate_scenario
from ..engine.results import RunResult
from .cancellation import CancellationToken
from .single_run import ScenarioNotRunnable, run_single

__all__ = ["ReplicationResult", "run_replications"]


@dataclass
class ReplicationResult:
    """The outcome of a replicated experiment."""

    scenario_dict: dict[str, Any]
    config_hash: str
    runs: list[RunResult] = field(default_factory=list)
    cancelled: bool = False
    n_requested: int = 0

    # Lazily computed analysis products.
    _summaries: pd.DataFrame | None = field(default=None, repr=False)
    _aggregated: pd.DataFrame | None = field(default=None, repr=False)

    @property
    def n_completed(self) -> int:
        return len(self.runs)

    @property
    def summaries(self) -> pd.DataFrame:
        """One row of summary metrics per completed replication."""

        if self._summaries is None:
            from ..analysis.aggregation import summary_table
            self._summaries = summary_table(self.runs)
        return self._summaries

    @property
    def aggregated(self) -> pd.DataFrame:
        """Mean / CI / spread per metric across replications."""

        if self._aggregated is None:
            from ..analysis.aggregation import aggregate_summaries
            self._aggregated = aggregate_summaries(self.summaries)
        return self._aggregated

    def extinction(self) -> dict[str, Any]:
        from ..analysis.aggregation import extinction_rate
        return extinction_rate(self.runs)

    def time_series_band(self, columns: Sequence[str] | None = None
                         ) -> pd.DataFrame:
        from ..analysis.aggregation import aggregate_time_series
        return aggregate_time_series(self.runs, columns=columns)

    def report_text(self) -> str:
        from ..analysis.reports import replication_report_text
        return replication_report_text(self.runs, self.aggregated)


# ---------------------------------------------------------------------------
# Worker for process-based parallelism
# ---------------------------------------------------------------------------
def _worker(payload: tuple[dict[str, Any], int]) -> RunResult:
    """Top-level so it is picklable by ProcessPoolExecutor.

    The scenario crosses the process boundary as a plain dict; rebuilding it
    inside the worker re-runs validation and avoids depending on pydantic model
    pickling behaviour.
    """

    scenario_dict, rep_index = payload
    scenario = scenario_from_dict(scenario_dict)
    # Validation already happened in the parent; skip it here so a large sweep
    # does not pay for it once per replication.
    return run_single(scenario, rep_index, validate=False)


def run_replications(scenario: ScenarioConfig,
                     n_replications: int = 10,
                     *,
                     parallel: bool = False,
                     max_workers: int | None = None,
                     cancel: CancellationToken | None = None,
                     progress: Callable[[float, str], None] | None = None,
                     validate: bool = True,
                     start_index: int = 0) -> ReplicationResult:
    """Run ``n_replications`` independent trajectories of one scenario.

    Parameters
    ----------
    parallel
        Use a process pool. Worthwhile for many long replications; for short
        runs the process start-up cost dominates and serial is faster.
    cancel
        Cooperative cancellation token. In serial mode cancellation is checked
        inside the engine, so a partially completed run is still returned. In
        parallel mode already-dispatched replications run to completion but no
        further ones are submitted.
    start_index
        First replication index. Useful for extending an existing experiment
        with more replications without repeating the ones already done.
    """

    if n_replications < 1:
        raise ValueError("n_replications must be >= 1")

    if validate:
        report = validate_scenario(scenario)
        if not report.can_run:
            raise ScenarioNotRunnable(report)

    scen_dict = scenario_to_dict(scenario)
    out = ReplicationResult(
        scenario_dict=scen_dict,
        config_hash=config_hash(scenario),
        n_requested=n_replications,
    )
    indices = list(range(start_index, start_index + n_replications))

    def _emit(done: int, message: str) -> None:
        if progress is not None:
            progress(done / max(1, n_replications), message)

    # ---------------- serial ----------------
    if not parallel:
        for done, rep in enumerate(indices, start=1):
            if cancel is not None and cancel.cancelled:
                out.cancelled = True
                break
            result = run_single(scenario, rep, cancel=cancel, validate=False)
            out.runs.append(result)
            if result.cancelled:
                out.cancelled = True
                break
            _emit(done, f"replication {done}/{n_replications}")
        return out

    # ---------------- parallel ----------------
    from concurrent.futures import ProcessPoolExecutor, as_completed

    if max_workers is None:
        max_workers = max(1, min(len(indices), (os.cpu_count() or 2)))

    payloads = [(scen_dict, rep) for rep in indices]
    collected: list[tuple[int, RunResult]] = []

    with ProcessPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_worker, p): p[1] for p in payloads}
        done = 0
        for future in as_completed(futures):
            rep = futures[future]
            if cancel is not None and cancel.cancelled:
                out.cancelled = True
                for pending in futures:
                    pending.cancel()
                break
            try:
                collected.append((rep, future.result()))
            except Exception as exc:  # pragma: no cover - surfaced to the caller
                raise RuntimeError(
                    f"replication {rep} failed in worker process: {exc}") from exc
            done += 1
            _emit(done, f"replication {done}/{n_replications}")

    # Restore deterministic ordering: as_completed yields out of order, and a
    # reproducible experiment must not depend on which worker finished first.
    collected.sort(key=lambda pair: pair[0])
    out.runs = [r for _, r in collected]
    return out

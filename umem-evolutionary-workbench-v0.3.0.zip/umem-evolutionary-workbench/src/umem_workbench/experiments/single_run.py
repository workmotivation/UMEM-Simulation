"""Single-run execution (Master Prompt section 17.1)."""

from __future__ import annotations

from collections.abc import Callable

from ..config.models import ScenarioConfig
from ..config.validation import validate_scenario
from ..engine.randomness import RandomStreams
from ..engine.results import RunResult
from ..engine.simulation import run_simulation

__all__ = ["run_single", "ScenarioNotRunnable"]


class ScenarioNotRunnable(ValueError):
    """Raised when a scenario has blocking validation errors."""

    def __init__(self, report) -> None:
        self.report = report
        errors = "; ".join(i.message for i in report.issues
                           if i.severity.name == "ERROR")
        super().__init__(f"Scenario cannot be run: {errors}")


def run_single(scenario: ScenarioConfig,
               replication_index: int = 0,
               *,
               cancel: Callable[[], bool] | None = None,
               progress: Callable[[float, str], None] | None = None,
               validate: bool = True,
               warnings_out: list[str] | None = None) -> RunResult:
    """Run one trajectory and return its :class:`RunResult`.

    Parameters
    ----------
    replication_index
        Selects the RNG substream. The same ``(master_seed, replication_index)``
        pair always reproduces the same trajectory.
    validate
        When true (default) the scenario is validated first and blocking errors
        raise :class:`ScenarioNotRunnable` rather than producing a run whose
        results would be meaningless.
    """

    if validate:
        report = validate_scenario(scenario)
        if not report.can_run:
            raise ScenarioNotRunnable(report)

    streams = RandomStreams.create(scenario.master_seed, replication_index)

    # The engine reports progress as a dict of raw counters; the experiment and
    # UI layers work in (fraction, message). Adapt at this boundary so neither
    # side has to know about the other's convention.
    engine_progress = None
    if progress is not None:
        def engine_progress(payload: dict) -> None:  # noqa: F811
            total = max(1, int(payload.get("total_steps", 1)))
            step = int(payload.get("step", 0))
            message = (f"season {payload.get('season', 0)}, "
                       f"step {step}/{total}, "
                       f"population {payload.get('population', 0)}")
            progress(min(1.0, step / total), message)

    return run_simulation(
        scenario,
        replication_index,
        streams,
        cancel=cancel,
        progress=engine_progress,
        warnings=warnings_out,
    )

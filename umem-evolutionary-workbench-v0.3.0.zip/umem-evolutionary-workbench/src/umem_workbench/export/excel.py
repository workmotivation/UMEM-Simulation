"""Excel workbook export (Master Prompt section 19.1).

The workbook is a *data and provenance* deliverable, not a calculation model:
every cell is a recorded value, so there are no spreadsheet formulas to
recalculate. Sheets that would exceed Excel's row limit are written out as
companion CSV files and referenced from the workbook instead of being silently
truncated.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from ..engine.results import RunResult

__all__ = ["export_workbook", "EXCEL_MAX_ROWS"]

#: Excel's hard row limit; one row is reserved for the header.
EXCEL_MAX_ROWS = 1_048_576
_SAFE_ROWS = EXCEL_MAX_ROWS - 2

_FONT = "Arial"
_HEADER_FILL = PatternFill("solid", fgColor="1F3864")
_HEADER_FONT = Font(name=_FONT, bold=True, color="FFFFFF", size=10)
_BODY_FONT = Font(name=_FONT, size=10)
_TITLE_FONT = Font(name=_FONT, bold=True, size=13, color="1F3864")
_NOTE_FONT = Font(name=_FONT, italic=True, size=9, color="595959")


# ---------------------------------------------------------------------------
# Sheet helpers
# ---------------------------------------------------------------------------
def _write_frame(ws: Worksheet, frame: pd.DataFrame, *, freeze: str = "A2",
                 autofilter: bool = True, number_format: str = "0.0000",
                 start_row: int = 1) -> None:
    """Write a DataFrame with header styling, freeze panes, and filters."""

    if frame is None or not len(frame.columns):
        ws.cell(row=start_row, column=1, value="(no data)").font = _NOTE_FONT
        return

    for col_idx, name in enumerate(frame.columns, start=1):
        cell = ws.cell(row=start_row, column=col_idx, value=str(name))
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center",
                                   wrap_text=True)

    for r, (_, row) in enumerate(frame.iterrows(), start=start_row + 1):
        for c, value in enumerate(row, start=1):
            if isinstance(value, (list, dict, tuple)):
                value = str(value)
            elif pd.isna(value):
                value = None
            elif hasattr(value, "item"):
                value = value.item()
            cell = ws.cell(row=r, column=c, value=value)
            cell.font = _BODY_FONT
            if isinstance(value, float):
                cell.number_format = number_format

    # Column widths sized to content, with a sane ceiling.
    for col_idx, name in enumerate(frame.columns, start=1):
        longest = 0
        if len(frame):
            lengths = frame[name].astype(str).str.len()
            longest_val = lengths.max()
            if pd.notna(longest_val):
                longest = int(longest_val)
        width = min(46, max(11, len(str(name)) + 2, longest + 2))
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    if freeze:
        ws.freeze_panes = freeze
    if autofilter and len(frame):
        ws.auto_filter.ref = (
            f"A{start_row}:{get_column_letter(len(frame.columns))}"
            f"{start_row + len(frame)}")


def _kv_frame(mapping: dict[str, Any]) -> pd.DataFrame:
    rows = []
    for key, value in mapping.items():
        if isinstance(value, (dict, list, tuple)):
            value = str(value)
        rows.append({"field": key, "value": value})
    return pd.DataFrame(rows)


def _flatten_config(data: dict[str, Any], prefix: str = "") -> list[dict[str, Any]]:
    """Flatten nested config into dotted path / value rows."""

    rows: list[dict[str, Any]] = []
    for key, value in data.items():
        path = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, dict):
            rows.extend(_flatten_config(value, path))
        elif isinstance(value, list):
            if value and isinstance(value[0], dict):
                for i, item in enumerate(value):
                    ident = (item.get("task_id") or item.get("domain_id")
                             or item.get("var_id") or str(i))
                    rows.extend(_flatten_config(item, f"{path}.{ident}"))
            else:
                rows.append({"path": path, "value": str(value)})
        else:
            rows.append({"path": path, "value": value})
    return rows


def _spill_to_csv(frame: pd.DataFrame, out_dir: Path, name: str) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{name}.csv"
    frame.to_csv(path, index=False)
    return path


# ---------------------------------------------------------------------------
# Individual sheets
# ---------------------------------------------------------------------------
def _sheet_overview(ws: Worksheet, result: RunResult, summary: dict[str, Any],
                    spilled: list[str], extra_notes: Sequence[str]) -> None:
    from ..analysis.reports import STANDARD_CAVEATS

    scen = result.scenario_dict
    ws["A1"] = "UMEM Evolutionary Simulation Workbench - Results Export"
    ws["A1"].font = _TITLE_FONT
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 96

    rows = [
        ("Scenario name", scen.get("name", "unnamed")),
        ("Description", scen.get("description", "")),
        ("Preset origin", scen.get("preset_origin") or "custom"),
        ("Run id", result.run_id),
        ("Configuration hash", result.config_hash),
        ("Master seed", scen.get("master_seed")),
        ("Replication index", result.replication_index),
        ("Started", result.start_time),
        ("Ended", result.end_time),
        ("Cancelled", "yes (partial results)" if result.cancelled else "no"),
        ("Application version", result.app_version),
        ("Config schema version", result.schema_version),
    ]
    r = 3
    for label, value in rows:
        ws.cell(row=r, column=1, value=label).font = Font(name=_FONT, bold=True, size=10)
        ws.cell(row=r, column=2, value=value).font = _BODY_FONT
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Sheets in this workbook").font = _TITLE_FONT
    r += 1
    sheet_notes = [
        ("Run_Metadata", "Identifiers, seeds, timings, RNG stream provenance."),
        ("Scenario_Config", "Every configuration value as a dotted path."),
        ("Tasks / Task_Effects", "Task definitions and their effect rules."),
        ("Environment_Config", "Environmental process parameters."),
        ("Cognition_Config", "Cognition A/B/C settings."),
        ("Lifecycle_Config / Reproduction_Config", "Life-history parameters."),
        ("Inheritance_Config", "Inheritance model, segregation, mutation."),
        ("Summary_Metrics", "All descriptive metrics for this run."),
        ("Time_Series", "Recorded snapshots over time."),
        ("Death_Causes", "Attributed causes of death."),
        ("Task_Allocation", "Per-task time, energy, frequency, propensity."),
        ("Trait_Summary", "Inherited propensity trajectories."),
        ("Replicate_Summary", "One row per replication (replicated runs only)."),
        ("Parameter_Sweep", "Per-cell sweep results (sweeps only)."),
        ("Agent_Sample", "Reproducible individual-level sample, when enabled."),
        ("Warnings", "Validation and runtime warnings."),
    ]
    for name, note in sheet_notes:
        ws.cell(row=r, column=1, value=name).font = _BODY_FONT
        ws.cell(row=r, column=2, value=note).font = _NOTE_FONT
        r += 1

    if spilled:
        r += 1
        ws.cell(row=r, column=1, value="Companion CSV files").font = _TITLE_FONT
        r += 1
        ws.cell(row=r, column=2,
                value="These tables exceeded the Excel row limit and were "
                      "written alongside the workbook rather than truncated:"
                ).font = _NOTE_FONT
        r += 1
        for path in spilled:
            ws.cell(row=r, column=2, value=path).font = _BODY_FONT
            r += 1

    r += 1
    ws.cell(row=r, column=1, value="How to interpret these results").font = _TITLE_FONT
    r += 1
    for i, caveat in enumerate(STANDARD_CAVEATS, 1):
        ws.cell(row=r, column=1, value=f"{i}.").font = _BODY_FONT
        cell = ws.cell(row=r, column=2, value=caveat)
        cell.font = _NOTE_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[r].height = 26
        r += 1

    for note in extra_notes:
        ws.cell(row=r, column=2, value=note).font = _NOTE_FONT
        r += 1


def _tasks_frames(scen: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame]:
    tasks = scen.get("tasks", []) or []
    task_rows, effect_rows = [], []
    for task in tasks:
        row = {k: v for k, v in task.items() if k != "effects"}
        task_rows.append(row)
        for i, eff in enumerate(task.get("effects", []) or []):
            effect_rows.append({"task_id": task.get("task_id"),
                                "effect_index": i, **eff})
    return pd.DataFrame(task_rows), pd.DataFrame(effect_rows)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def export_workbook(path: str | Path,
                    result: RunResult,
                    *,
                    summary: dict[str, Any] | None = None,
                    replicate_summary: pd.DataFrame | None = None,
                    sweep_summary: pd.DataFrame | None = None,
                    warnings: Sequence[str] | None = None,
                    csv_dir: str | Path | None = None) -> dict[str, Any]:
    """Write the full results workbook and return a manifest.

    Parameters
    ----------
    result
        The run whose detail sheets are exported. For replicated or swept
        experiments pass a representative run plus the aggregate tables.
    csv_dir
        Where oversized tables spill to. Defaults to a folder beside the
        workbook.
    """

    from openpyxl import Workbook

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    csv_dir = Path(csv_dir) if csv_dir else path.parent / f"{path.stem}_large_tables"

    if summary is None:
        from ..analysis.metrics import summarise_run
        summary = summarise_run(result)

    scen = result.scenario_dict
    wb = Workbook()
    spilled: list[str] = []

    def add(name: str, frame: pd.DataFrame | None, *,
            number_format: str = "0.0000") -> None:
        ws = wb.create_sheet(name[:31])
        if frame is None:
            _write_frame(ws, pd.DataFrame())
            return
        if len(frame) > _SAFE_ROWS:
            csv_path = _spill_to_csv(frame, csv_dir, name)
            spilled.append(str(csv_path))
            note = pd.DataFrame([{
                "note": f"{len(frame):,} rows exceeded the Excel limit; "
                        f"written to {csv_path.name} instead.",
                "csv_file": str(csv_path),
                "rows": len(frame),
            }])
            _write_frame(ws, note, autofilter=False)
            return
        _write_frame(ws, frame, number_format=number_format)

    # --- Overview (first sheet) ---
    overview = wb.active
    overview.title = "Run_Overview"

    # --- Metadata ---
    meta = {
        "run_id": result.run_id,
        "config_hash": result.config_hash,
        "scenario_name": scen.get("name"),
        "preset_origin": scen.get("preset_origin"),
        "master_seed": scen.get("master_seed"),
        "replication_index": result.replication_index,
        "start_time": result.start_time,
        "end_time": result.end_time,
        "cancelled": result.cancelled,
        "extinct": result.extinct,
        "final_population": result.final_population,
        "app_version": result.app_version,
        "schema_version": result.schema_version,
    }
    for name, seeds in (result.seed_metadata or {}).items():
        meta[f"seed_{name}"] = str(seeds)
    # Active scientific mechanisms, so they are visible without reading the
    # full configuration (mechanism_summary is the single definition).
    from .bundles import mechanism_summary
    for key, value in mechanism_summary(scen).items():
        meta[f"mechanism_{key}"] = value
    add("Run_Metadata", _kv_frame(meta), number_format="General")

    # --- Configuration ---
    add("Scenario_Config", pd.DataFrame(_flatten_config(scen)),
        number_format="General")
    tasks_df, effects_df = _tasks_frames(scen)
    add("Tasks", tasks_df, number_format="General")
    add("Task_Effects", effects_df, number_format="General")
    add("Environment_Config", pd.DataFrame(scen.get("environment", []) or []),
        number_format="General")
    add("Cognition_Config", _kv_frame(scen.get("cognition", {}) or {}),
        number_format="General")
    add("Lifecycle_Config", _kv_frame(scen.get("lifecycle", {}) or {}),
        number_format="General")
    add("Reproduction_Config", _kv_frame(scen.get("reproduction", {}) or {}),
        number_format="General")
    add("Inheritance_Config", _kv_frame(scen.get("inheritance", {}) or {}),
        number_format="General")

    # --- Results ---
    from ..analysis.reports import metrics_to_frame
    metrics_df = metrics_to_frame(summary)[["metric", "value"]]
    add("Summary_Metrics", metrics_df, number_format="General")

    ts = result.time_series
    add("Time_Series", ts)

    if ts is not None and len(ts):
        death_cols = ["step", "season"] + [
            c for c in ts.columns if c.startswith("deaths_")]
        add("Death_Causes", ts[[c for c in death_cols if c in ts.columns]],
            number_format="0.00")

        alloc_prefixes = ("freq_", "timealloc_", "energyalloc_",
                          "taskprop_", "effpref_")
        alloc_cols = ["step", "season"] + [
            c for c in ts.columns if c.startswith(alloc_prefixes)]
        add("Task_Allocation", ts[[c for c in alloc_cols if c in ts.columns]])

        trait_cols = ["step", "season"] + [
            c for c in ts.columns
            if c.startswith("domprop_") or c.startswith("domvar_")]
        add("Trait_Summary", ts[[c for c in trait_cols if c in ts.columns]])
    else:
        add("Death_Causes", None)
        add("Task_Allocation", None)
        add("Trait_Summary", None)

    if replicate_summary is not None and len(replicate_summary):
        add("Replicate_Summary", replicate_summary)
    if sweep_summary is not None and len(sweep_summary):
        add("Parameter_Sweep", sweep_summary)
    if result.agent_samples is not None and len(result.agent_samples):
        add("Agent_Sample", result.agent_samples)

    all_warnings = list(result.warnings or []) + list(warnings or [])
    warn_df = (pd.DataFrame({"warning": all_warnings}) if all_warnings
               else pd.DataFrame({"warning": ["No warnings recorded."]}))
    add("Warnings", warn_df, number_format="General")

    # Overview last: it needs the spill list.
    _sheet_overview(overview, result, summary, spilled, extra_notes=[])

    wb.save(path)
    return {
        "workbook": str(path),
        "spilled_csv": spilled,
        "sheets": [ws.title for ws in wb.worksheets],
    }

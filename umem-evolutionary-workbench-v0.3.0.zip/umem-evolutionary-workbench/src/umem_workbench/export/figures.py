"""Figure export (Master Prompt section 19.2).

Figures are always regenerated from the recorded data, never captured from the
GUI, so an exported figure is reproducible from the scenario and seed alone.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt

from ..analysis.plotting import DEFAULT_DPI, standard_figure_set
from ..engine.results import RunResult

__all__ = ["SUPPORTED_FORMATS", "export_figures", "export_figure"]

#: Raster and vector formats offered by the UI.
SUPPORTED_FORMATS = ("png", "svg", "pdf")


def _check_formats(formats: Sequence[str]) -> list[str]:
    bad = [f for f in formats if f.lower() not in SUPPORTED_FORMATS]
    if bad:
        raise ValueError(
            f"unsupported figure format(s): {bad}. "
            f"Supported: {', '.join(SUPPORTED_FORMATS)}")
    return [f.lower() for f in formats]


def export_figure(fig, path: str | Path, dpi: int = DEFAULT_DPI) -> str:
    """Save one figure, inferring the format from the file suffix."""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fmt = path.suffix.lstrip(".").lower()
    _check_formats([fmt])
    fig.savefig(path, format=fmt, dpi=dpi, bbox_inches="tight")
    return str(path)


def export_figures(result: RunResult,
                   directory: str | Path,
                   *,
                   formats: Sequence[str] = ("png",),
                   dpi: int = DEFAULT_DPI,
                   figures: dict[str, Any] | None = None,
                   close: bool = True) -> dict[str, list[str]]:
    """Render and save the standard figure set in the requested formats.

    Returns ``{figure_name: [paths]}``. Vector formats ignore ``dpi`` except
    for any rasterised elements.
    """

    formats = _check_formats(formats)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)

    if figures is None:
        figures = standard_figure_set(result)

    written: dict[str, list[str]] = {}
    try:
        for name, fig in figures.items():
            paths = []
            for fmt in formats:
                paths.append(export_figure(fig, directory / f"{name}.{fmt}", dpi))
            written[name] = paths
    finally:
        if close:
            for fig in figures.values():
                plt.close(fig)
    return written

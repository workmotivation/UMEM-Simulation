"""The 'Export All' reproducibility bundle (Master Prompt section 19.3).

The bundle is built in a temporary staging directory and zipped, so a failure
part-way through never leaves a half-written archive next to the user's data.
Output paths are validated to keep writes out of protected installation
folders.
"""

from __future__ import annotations

import datetime as _dt
import json
import platform
import shutil
import sys
import tempfile
import zipfile
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from ..engine.results import RunResult

__all__ = ["export_bundle", "build_metadata", "mechanism_summary",
           "reproducibility_instructions",
           "UnsafeOutputDirectory"]


class UnsafeOutputDirectory(ValueError):
    """Raised when an export target looks like a protected install location."""


def _assert_safe_directory(directory: Path) -> None:
    """Refuse to write into installation or system directories."""

    resolved = directory.resolve()
    forbidden_roots = []
    for candidate in (sys.prefix, sys.base_prefix, str(Path(__file__).resolve().parents[3])):
        try:
            forbidden_roots.append(Path(candidate).resolve())
        except OSError:  # pragma: no cover
            continue
    if platform.system() == "Windows":
        for env_key in ("ProgramFiles", "ProgramFiles(x86)", "WINDIR"):
            import os
            value = os.environ.get(env_key)
            if value:
                forbidden_roots.append(Path(value).resolve())
    else:
        forbidden_roots += [Path("/usr"), Path("/bin"), Path("/sbin"),
                            Path("/etc"), Path("/System")]

    for root in forbidden_roots:
        try:
            if resolved == root or root in resolved.parents:
                raise UnsafeOutputDirectory(
                    f"Refusing to export into '{resolved}', which lies inside "
                    f"the protected location '{root}'. Choose a documents or "
                    f"project folder instead.")
        except OSError:  # pragma: no cover
            continue


def mechanism_summary(scenario_dict: dict[str, Any]) -> dict[str, Any]:
    """The scientifically important mechanism modes, flattened for metadata.

    The complete scenario remains authoritative; this exists so a researcher
    can identify the active reproduction and inheritance mechanisms from
    ``Run_Metadata`` / ``metadata.json`` without searching the full
    configuration.
    """

    rep = scenario_dict.get("reproduction", {}) or {}
    inh = scenario_dict.get("inheritance", {}) or {}
    pop = scenario_dict.get("population", {}) or {}
    return {
        "reproduction_mode": rep.get("mode"),
        "reproduction_timing": rep.get("timing"),
        "mating_mode": rep.get("mating_mode"),
        "mate_choice_criterion": rep.get("mate_choice_criterion"),
        "mate_choice_k": rep.get("mate_choice_k"),
        "mate_quality_weights": rep.get("mate_quality_weights"),
        "reproductive_event_rate_per_season": rep.get("reproductive_event_rate"),
        "refractory_seasons": rep.get("refractory_seasons"),
        "bond_formation_per_season": rep.get("bond_formation_per_season"),
        "bond_dissolution_per_season": rep.get("bond_dissolution_per_season"),
        "founder_age_distribution": pop.get("founder_age_distribution"),
        "sex_ratio_type_a": pop.get("sex_ratio_type_a"),
        "inheritance_model": inh.get("model"),
        "inheritance_model_version": (
            "polygenic_additive.v1" if inh.get("model") == "polygenic_additive"
            else "legacy.v1"),
        "sibling_variation": inh.get("sibling_variation"),
        "segregation_multiplier_effective": inh.get("segregation_multiplier"),
        "mutation_level": inh.get("mutation_level"),
        "mutation_probability_per_offspring": inh.get(
            "mutation_probability_per_offspring"),
        "mutation_effect_sd_latent": inh.get("mutation_effect_sd_latent"),
        "mutation_target": inh.get("mutation_target"),
    }


def build_metadata(result: RunResult,
                   extra: dict[str, Any] | None = None) -> dict[str, Any]:
    """Everything needed to reproduce the run, in one JSON-serialisable dict."""

    try:
        import numpy
        import pandas
        deps = {"numpy": numpy.__version__, "pandas": pandas.__version__}
    except Exception:  # pragma: no cover
        deps = {}
    try:
        import matplotlib
        deps["matplotlib"] = matplotlib.__version__
    except Exception:  # pragma: no cover
        pass
    try:
        import scipy
        deps["scipy"] = scipy.__version__
    except Exception:  # pragma: no cover
        pass

    meta: dict[str, Any] = {
        "application": "UMEM Evolutionary Simulation Workbench",
        "app_version": result.app_version,
        "config_schema_version": result.schema_version,
        "exported_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "run_id": result.run_id,
        "config_hash": result.config_hash,
        "master_seed": result.master_seed,
        "replication_index": result.replication_index,
        "seed_metadata": {k: list(v) for k, v in (result.seed_metadata or {}).items()},
        "start_time": result.start_time,
        "end_time": result.end_time,
        "cancelled": result.cancelled,
        "extinct": result.extinct,
        "final_population": result.final_population,
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "dependencies": deps,
        "warnings": list(result.warnings or []),
        "mechanisms": mechanism_summary(result.scenario_dict),
    }
    if extra:
        meta.update(extra)
    return meta


def reproducibility_instructions(result: RunResult) -> str:
    """Short instructions shipped inside every bundle."""

    scen = result.scenario_dict
    return f"""\
Reproducing this result
=======================

Software
--------
UMEM Evolutionary Simulation Workbench, version {result.app_version}
Configuration schema version {result.schema_version}

What identifies this run
------------------------
scenario file   : scenario.json
config hash     : {result.config_hash}
master seed     : {result.master_seed}
replication idx : {result.replication_index}

The configuration hash covers every scientifically relevant setting. It
deliberately excludes the scenario name and description, so renaming a scenario
does not change its hash. If your hash matches the one above, you are running
the same model.

Steps
-----
1. Install the application (see README.md), or:
       pip install -e .

2. Reproduce from Python:

       from umem_workbench.config.serialization import load_scenario_json
       from umem_workbench.experiments import run_single

       scenario = load_scenario_json("scenario.json")
       result = run_single(scenario, replication_index={result.replication_index})

3. Confirm the identity of the configuration:

       from umem_workbench.config.serialization import config_hash
       assert config_hash(scenario) == "{result.config_hash}"

The same (master seed, replication index) pair always reproduces the same
trajectory, because every random stream is derived from a NumPy SeedSequence
spawned from those two numbers. Results are reproducible across machines for a
given NumPy version.

Interpretation
--------------
This is an abstract theoretical model. Parameter values are illustrative
demonstration settings, not empirically calibrated to any species. The
heritable "motivational propensity" is a functional modelling construct and
does not correspond to any identified genetic locus. The model makes no claim
about subjective experience or consciousness. Fitness is realised lifetime
reproductive success, an outcome of the simulation rather than a score imposed
on agents.

Scenario: {scen.get('name', 'unnamed')}
Preset origin: {scen.get('preset_origin') or 'custom'}
"""


def export_bundle(directory: str | Path,
                  result: RunResult,
                  *,
                  bundle_name: str | None = None,
                  replication_result=None,
                  sweep_result=None,
                  figure_formats: Sequence[str] = ("png",),
                  figure_dpi: int = 300,
                  include_figures: bool = True,
                  include_excel: bool = True,
                  include_raw_csv: bool = True,
                  warnings: Sequence[str] | None = None,
                  allow_unsafe_directory: bool = False,
                  outcome=None) -> str:
    """Build the ZIP bundle in ``directory`` and return its path.

    When ``outcome`` (an :class:`ExperimentOutcome`) is given, the bundle also
    contains ``AI_REPORT.md`` for the whole experiment and the generic
    ``AI_REPORT_INTERPRETATION_GUIDE.md``. Both are generated locally.
    """

    from .csv_export import export_replicate_csvs, export_run_csvs, export_sweep_csvs
    from .excel import export_workbook
    from .figures import export_figures

    directory = Path(directory)
    if not allow_unsafe_directory:
        _assert_safe_directory(directory)
    directory.mkdir(parents=True, exist_ok=True)

    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    scen_name = str(result.scenario_dict.get("name", "scenario"))
    safe_name = "".join(ch if ch.isalnum() or ch in "-_" else "_"
                        for ch in scen_name)[:40]
    bundle_name = bundle_name or f"umem_{safe_name}_{stamp}"
    zip_path = directory / f"{bundle_name}.zip"

    staging = Path(tempfile.mkdtemp(prefix="umem_bundle_"))
    try:
        # 1. Scenario and metadata.
        (staging / "scenario.json").write_text(
            json.dumps(result.scenario_dict, indent=2, ensure_ascii=False),
            encoding="utf-8")

        extra: dict[str, Any] = {}
        if replication_result is not None:
            extra["n_replications"] = replication_result.n_completed
        if sweep_result is not None:
            extra["sweep_parameter_paths"] = list(sweep_result.parameter_paths)
            extra["n_sweep_cells"] = len(sweep_result.cells)
            extra["seed_policy"] = sweep_result.seed_policy
        (staging / "metadata.json").write_text(
            json.dumps(build_metadata(result, extra), indent=2, ensure_ascii=False),
            encoding="utf-8")

        # 2. Instructions and report.
        (staging / "REPRODUCIBILITY.txt").write_text(
            reproducibility_instructions(result), encoding="utf-8")

        from ..analysis.metrics import summarise_run
        from ..analysis.reports import run_report_text
        summary = result.summary or summarise_run(result)
        (staging / "run_report.txt").write_text(
            run_report_text(result, summary), encoding="utf-8")

        # 3. Warning log.
        all_warnings = list(result.warnings or []) + list(warnings or [])
        (staging / "warnings.log").write_text(
            "\n".join(all_warnings) if all_warnings
            else "No warnings recorded.\n", encoding="utf-8")

        # 4. CSV tables.
        rep_summary = sweep_summary = None
        if include_raw_csv:
            export_run_csvs(result, staging / "data")
        if replication_result is not None:
            export_replicate_csvs(replication_result, staging / "data")
            rep_summary = replication_result.summaries
        if sweep_result is not None:
            export_sweep_csvs(sweep_result, staging / "data")
            sweep_summary = sweep_result.aggregated_table()

        # 5. Excel workbook.
        if include_excel:
            export_workbook(staging / "results.xlsx", result, summary=summary,
                            replicate_summary=rep_summary,
                            sweep_summary=sweep_summary,
                            warnings=all_warnings,
                            csv_dir=staging / "data")

        # 6. Figures.
        if include_figures:
            export_figures(result, staging / "figures",
                           formats=figure_formats, dpi=figure_dpi)

        # 6b. External-AI interpretation files (generated locally, no network).
        try:
            from ..ai_assist import build_ai_report, report_interpretation_guide
            (staging / "AI_REPORT_INTERPRETATION_GUIDE.md").write_text(
                report_interpretation_guide(), encoding="utf-8")
            if outcome is not None:
                bundle = build_ai_report(outcome)
                (staging / "AI_REPORT.md").write_text(bundle.report_markdown, encoding="utf-8")
        except Exception as exc:  # pragma: no cover - never let this break an export
            (staging / "warnings.log").open("a", encoding="utf-8").write(
                f"\nAI report generation failed: {exc}\n")

        # 7. Zip it.
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(staging.rglob("*")):
                if path.is_file():
                    zf.write(path, path.relative_to(staging))
    finally:
        shutil.rmtree(staging, ignore_errors=True)

    return str(zip_path)

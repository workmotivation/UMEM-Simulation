"""CSV export (Master Prompt sections 19.1 and 19.3).

CSV is the fallback for tables too large for a worksheet and the preferred
format for downstream analysis in R, Python, or Julia. Files are written UTF-8
with a BOM by default so that Excel on Windows opens them without mangling
non-ASCII scenario names.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..engine.results import RunResult

__all__ = ["export_run_csvs", "export_replicate_csvs", "export_sweep_csvs",
           "write_csv"]

DEFAULT_ENCODING = "utf-8-sig"


def write_csv(frame: pd.DataFrame, path: str | Path,
              encoding: str = DEFAULT_ENCODING) -> str | None:
    """Write ``frame`` to ``path``; returns the path, or None if empty."""

    if frame is None or not len(frame):
        return None
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding=encoding)
    return str(path)


def export_run_csvs(result: RunResult, directory: str | Path,
                    prefix: str = "") -> dict[str, str]:
    """Write every table from a single run. Returns ``{name: path}``."""

    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    written: dict[str, str] = {}

    tables: dict[str, pd.DataFrame | None] = {
        "time_series": result.time_series,
        "breeding_series": result.breeding_series,
        "dead_log": result.dead_log_df,
        "agent_sample": result.agent_samples,
    }

    from ..analysis.metrics import summarise_run
    from ..analysis.reports import metrics_to_frame
    summary = result.summary or summarise_run(result)
    tables["summary_metrics"] = metrics_to_frame(summary)[["metric", "value"]]

    # Environment trajectories are stored as arrays, not a frame.
    if result.env_trajectories:
        env = pd.DataFrame({k: v for k, v in result.env_trajectories.items()})
        env.insert(0, "step", range(len(env)))
        tables["environment_trajectories"] = env

    for name, frame in tables.items():
        path = write_csv(frame, directory / f"{prefix}{name}.csv")
        if path:
            written[name] = path
    return written


def export_replicate_csvs(replication_result, directory: str | Path
                          ) -> dict[str, str]:
    """Write per-replicate summaries and the aggregated table."""

    directory = Path(directory)
    written: dict[str, str] = {}

    path = write_csv(replication_result.summaries,
                     directory / "replicate_summary.csv")
    if path:
        written["replicate_summary"] = path

    path = write_csv(replication_result.aggregated,
                     directory / "replicate_aggregated.csv")
    if path:
        written["replicate_aggregated"] = path

    band = replication_result.time_series_band(columns=["population"])
    path = write_csv(band, directory / "replicate_population_band.csv")
    if path:
        written["replicate_population_band"] = path
    return written


def export_sweep_csvs(sweep_result, directory: str | Path) -> dict[str, str]:
    """Write the long-format sweep table and its aggregation."""

    directory = Path(directory)
    written: dict[str, str] = {}

    path = write_csv(sweep_result.summary_table(), directory / "sweep_runs.csv")
    if path:
        written["sweep_runs"] = path

    path = write_csv(sweep_result.aggregated_table(),
                     directory / "sweep_aggregated.csv")
    if path:
        written["sweep_aggregated"] = path

    for metric in ("final_population", "extinct", "mean_lrs_completed_lives"):
        curve = sweep_result.response_curve(metric)
        path = write_csv(curve, directory / f"sweep_response_{metric}.csv")
        if path:
            written[f"sweep_response_{metric}"] = path
    return written

"""Noisy, look-ahead-free observation of the environment.

Agents never see the true future. At step ``t`` an observation of variable ``v``
is ``true[v, t] + N(0, obs_noise[v])`` clipped to the variable's bounds. Only
information available strictly before the decision at ``t+1`` may inform a
forecast for ``t+1`` (enforced by the caller ordering in the simulation loop).
"""

from __future__ import annotations

import numpy as np

from ..config.models import EnvVariableConfig


def observe(env_configs: list[EnvVariableConfig], true_values: dict[str, float],
            rng: np.random.Generator) -> dict[str, float]:
    """Return one noisy observation per globally-observable variable."""

    obs: dict[str, float] = {}
    for cfg in env_configs:
        true_v = true_values[cfg.var_id]
        if not cfg.globally_observable or cfg.observation_noise <= 0:
            obs[cfg.var_id] = true_v
        else:
            noisy = true_v + rng.normal(0.0, cfg.observation_noise)
            obs[cfg.var_id] = float(np.clip(noisy, cfg.min_value, cfg.max_value))
    return obs


__all__ = ["observe"]

"""Generation of bounded environmental-variable trajectories.

Each environment variable is turned into a length-``total_steps`` array using its
configured stochastic process. All processes are clipped to ``[min, max]`` in a
transparent way. The whole trajectory is pre-generated per replication using the
dedicated ``environment`` random stream, so the environment is independent of
agent-side draws and fully reproducible.
"""

from __future__ import annotations

import numpy as np

from ..config.enums import EnvProcess
from ..config.models import EnvVariableConfig


def _clip(x: float, lo: float, hi: float) -> float:
    return float(min(max(x, lo), hi))


def generate_variable(cfg: EnvVariableConfig, total_steps: int,
                      rng: np.random.Generator) -> np.ndarray:
    """Return a bounded trajectory of length ``total_steps`` for one variable."""

    lo, hi = cfg.min_value, cfg.max_value
    out = np.empty(total_steps, dtype=float)

    if cfg.process == EnvProcess.CONSTANT:
        out[:] = _clip(cfg.initial_value, lo, hi)
        return out

    if cfg.process == EnvProcess.IMPORTED:
        series = np.asarray(cfg.imported_series, dtype=float)
        if series.size == 0:
            out[:] = _clip(cfg.initial_value, lo, hi)
            return out
        # Pad by holding the last value; truncate if longer.
        if series.size >= total_steps:
            out[:] = series[:total_steps]
        else:
            out[:series.size] = series
            out[series.size:] = series[-1]
        return np.clip(out, lo, hi)

    if cfg.process == EnvProcess.SEASONAL:
        t = np.arange(total_steps)
        phase = 2.0 * np.pi * t / max(1, cfg.seasonal_period_steps)
        out[:] = np.clip(cfg.mean + cfg.seasonal_amplitude * np.sin(phase), lo, hi)
        return out

    if cfg.process == EnvProcess.REGIME_SWITCHING:
        regimes = np.asarray(cfg.regime_values, dtype=float)
        idx = 0
        for t in range(total_steps):
            out[t] = _clip(regimes[idx], lo, hi)
            if rng.random() < cfg.regime_switch_prob:
                idx = int(rng.integers(len(regimes)))
        return out

    # AR(1) family (RANDOM_WALK, AR1, AR1_SEASONAL, RARE_SHOCKS).
    persistence = cfg.persistence
    if cfg.process == EnvProcess.RANDOM_WALK:
        persistence = 1.0  # random walk = AR(1) with unit persistence, then clip
    x = cfg.initial_value
    shock_remaining = 0
    shock_value = 0.0
    for t in range(total_steps):
        seasonal = 0.0
        if cfg.process == EnvProcess.AR1_SEASONAL:
            seasonal = cfg.seasonal_amplitude * np.sin(
                2.0 * np.pi * t / max(1, cfg.seasonal_period_steps))
        innovation = rng.normal(0.0, cfg.volatility)
        x = cfg.mean + persistence * (x - cfg.mean) + innovation + seasonal
        if cfg.process == EnvProcess.RARE_SHOCKS:
            if shock_remaining > 0:
                x += shock_value
                shock_remaining -= 1
            elif rng.random() < cfg.shock_probability:
                shock_value = cfg.shock_magnitude
                shock_remaining = max(0, cfg.shock_duration_steps - 1)
                x += shock_value
        x = _clip(x, lo, hi)
        out[t] = x
    return out


def generate_environment(env_configs: list[EnvVariableConfig], total_steps: int,
                         rng: np.random.Generator) -> dict[str, np.ndarray]:
    """Generate trajectories for all variables using one shared env stream."""

    trajectories: dict[str, np.ndarray] = {}
    for cfg in env_configs:
        # Derive a deterministic child generator per variable from the shared
        # environment stream. Order-dependent (on env_configs order) but stable.
        seed = int(rng.integers(0, 2 ** 63 - 1))
        child = np.random.default_rng(seed)
        trajectories[cfg.var_id] = generate_variable(cfg, total_steps, child)
    return trajectories


__all__ = ["generate_variable", "generate_environment"]

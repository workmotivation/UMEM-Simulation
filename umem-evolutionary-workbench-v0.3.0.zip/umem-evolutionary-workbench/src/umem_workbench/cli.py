"""Command-line interface for headless and batch use.

Examples
--------
List the built-in presets::

    umem-workbench presets

Run a preset and write a full export bundle::

    umem-workbench run --preset stable_abundant --replications 10 \\
        --output ./results

Run a scenario file and print the report only::

    umem-workbench run --scenario my_scenario.json --report-only

Benchmark the shipped presets::

    umem-workbench benchmark
"""

from __future__ import annotations

import argparse
import sys
import time
from collections.abc import Sequence
from pathlib import Path

from .config.enums import ExperimentMode
from .config.presets import PRESET_DESCRIPTIONS, PRESET_IDS, load_preset
from .config.serialization import config_hash, load_scenario_json, save_scenario_json
from .config.validation import Severity, validate_scenario
from .version import __version__

__all__ = ["main", "build_parser"]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="umem-workbench",
        description="UMEM Evolutionary Simulation Workbench. An abstract "
                    "theoretical model; parameters are illustrative and not "
                    "empirically calibrated.")
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("presets", help="list the built-in presets")

    run = sub.add_parser("run", help="run an experiment")
    source = run.add_mutually_exclusive_group(required=True)
    source.add_argument("--preset", choices=PRESET_IDS,
                        help="run a built-in preset")
    source.add_argument("--scenario", type=Path,
                        help="run a scenario JSON file")
    run.add_argument("--replications", type=int, default=1,
                     help="number of independent replications (default: 1)")
    run.add_argument("--seasons", type=int,
                     help="override the number of seasons")
    run.add_argument("--seed", type=int, help="override the master seed")
    run.add_argument("--workers", type=int, default=1,
                     help="parallel worker processes (default: 1)")
    run.add_argument("--output", type=Path,
                     help="directory for the export bundle")
    run.add_argument("--report-only", action="store_true",
                     help="print the report without writing any files")
    run.add_argument("--quiet", action="store_true",
                     help="suppress progress output")

    validate = sub.add_parser("validate", help="validate a scenario file")
    validate.add_argument("scenario", type=Path)

    export = sub.add_parser("export-presets",
                            help="write the built-in presets as JSON files")
    export.add_argument("directory", type=Path)

    dd = sub.add_parser("data-dictionary",
                        help="emit the configuration data dictionary")
    dd.add_argument("--format", choices=["json", "markdown", "csv"],
                    default="json")
    dd.add_argument("--output", type=Path, help="write to a file instead of stdout")

    ag = sub.add_parser("ai-guides", help="write the two external-AI guide files")
    ag.add_argument("directory", type=Path)

    ai = sub.add_parser("ai-import", help="validate an externally produced scenario JSON (preview only)")
    ai.add_argument("file", type=Path)
    ai.add_argument("--feedback", action="store_true", help="print repair feedback for the AI")

    ad = sub.add_parser("describe", help="print the deterministic experiment description")
    ad.add_argument("--preset", choices=PRESET_IDS)
    ad.add_argument("--scenario", type=Path)

    bench = sub.add_parser("benchmark",
                           help="time the shipped presets on this machine")
    bench.add_argument("--seasons", type=int, default=10,
                       help="seasons per benchmark run (default: 10)")
    bench.add_argument("--replications", type=int, default=3,
                       help="replications per preset (default: 3)")
    return parser


def _cmd_presets() -> int:
    for preset_id in PRESET_IDS:
        print(f"{preset_id}")
        print(f"    {PRESET_DESCRIPTIONS.get(preset_id, '')}")
    return 0


def _load(args: argparse.Namespace):
    scenario = (load_preset(args.preset) if args.preset
                else load_scenario_json(args.scenario))
    if args.seasons is not None:
        scenario.lifecycle.total_seasons = args.seasons
    if args.seed is not None:
        scenario.master_seed = args.seed
    if args.replications > 1:
        scenario.experiment.replications = args.replications
        scenario.experiment.mode = ExperimentMode.REPLICATIONS
    scenario.experiment.max_workers = max(1, args.workers)
    return scenario


def _cmd_run(args: argparse.Namespace) -> int:
    from .experiments import run_experiment

    scenario = _load(args)
    report = validate_scenario(scenario)
    errors = [i for i in report.issues if i.severity == Severity.ERROR]
    if errors:
        print("Scenario cannot be run:", file=sys.stderr)
        for issue in errors:
            print(f"  ERROR {issue.code}: {issue.message}", file=sys.stderr)
        return 2

    for issue in report.issues:
        if issue.severity != Severity.ERROR and not args.quiet:
            print(f"  {issue.severity.name} {issue.code}: {issue.message}",
                  file=sys.stderr)

    def _progress(fraction: float, message: str) -> None:
        if not args.quiet:
            print(f"\r  {fraction * 100:5.1f}%  {message[:60]:<60}",
                  end="", file=sys.stderr, flush=True)

    started = time.time()
    outcome = run_experiment(scenario, progress=_progress,
                             parallel=args.workers > 1,
                             max_workers=args.workers)
    if not args.quiet:
        print(file=sys.stderr)

    print(outcome.report_text())
    if not args.quiet:
        print(f"Elapsed: {time.time() - started:.1f}s", file=sys.stderr)

    if args.report_only or not args.output:
        return 0

    from .export import export_bundle
    payload = outcome.payload
    replication = payload if hasattr(payload, "runs") else None
    sweep = payload if hasattr(payload, "cells") else None
    path = export_bundle(args.output, outcome.runs[0],
                         replication_result=replication, sweep_result=sweep)
    print(f"Bundle written to: {path}", file=sys.stderr)
    return 0


def _cmd_validate(args: argparse.Namespace) -> int:
    scenario = load_scenario_json(args.scenario)
    report = validate_scenario(scenario)
    print(f"Scenario     : {scenario.name}")
    print(f"Config hash  : {config_hash(scenario)}")
    print(f"Runnable     : {'yes' if report.can_run else 'no'}")
    if not report.issues:
        print("No validation issues.")
    for issue in report.issues:
        print(f"  [{issue.severity.name}] {issue.code}: {issue.message}")
    return 0 if report.can_run else 1


def _cmd_export_presets(args: argparse.Namespace) -> int:
    args.directory.mkdir(parents=True, exist_ok=True)
    for preset_id in PRESET_IDS:
        path = args.directory / f"{preset_id}.json"
        save_scenario_json(load_preset(preset_id), path)
        print(f"wrote {path}")
    return 0


def _cmd_data_dictionary(args: argparse.Namespace) -> int:
    from .config.data_dictionary import to_csv, to_json, to_markdown

    render = {"json": to_json, "markdown": to_markdown, "csv": to_csv}[args.format]
    text = render()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
        print(f"wrote {args.output}", file=sys.stderr)
    else:
        sys.stdout.write(text)
    return 0


def _cmd_ai_guides(args: argparse.Namespace) -> int:
    from .ai_assist import report_interpretation_guide, scenario_design_guide
    args.directory.mkdir(parents=True, exist_ok=True)
    for name, fn in (("AI_SCENARIO_DESIGN_GUIDE.md", scenario_design_guide),
                     ("AI_REPORT_INTERPRETATION_GUIDE.md", report_interpretation_guide)):
        (args.directory / name).write_text(fn(), encoding="utf-8")
        print(f"wrote {args.directory / name}", file=sys.stderr)
    return 0


def _cmd_ai_import(args: argparse.Namespace) -> int:
    from .ai_assist import import_scenario_text, validation_feedback_for_ai
    text = args.file.read_text(encoding="utf-8")
    res = import_scenario_text(text)
    if args.feedback:
        print(validation_feedback_for_ai(res))
    else:
        print(f"result: {'ACCEPTED' if res.ok else 'REJECTED'}  errors={len(res.errors)} warnings={len(res.warnings)}")
        for i in res.issues:
            print(f"  [{i.severity}] {i.stage} {i.path}: {i.message}")
        if res.ok:
            print(f"config hash: {res.config_hash}")
    return 0 if res.ok else 1


def _cmd_describe(args: argparse.Namespace) -> int:
    from .ai_assist import describe_scenario
    scenario = load_preset(args.preset) if args.preset else load_scenario_json(args.scenario)
    print(describe_scenario(scenario).markdown())
    return 0


def _cmd_benchmark(args: argparse.Namespace) -> int:
    """Time each preset. Reports measured wall-clock on *this* machine only."""

    from .experiments import run_replications

    print(f"UMEM Workbench {__version__} benchmark")
    print(f"{args.replications} replication(s) x {args.seasons} seasons "
          f"per preset, single process.\n")
    print(f"{'preset':<28}{'agents':>8}{'steps':>10}{'seconds':>10}"
          f"{'steps/s':>12}")
    print("-" * 68)

    for preset_id in PRESET_IDS:
        scenario = load_preset(preset_id)
        scenario.lifecycle.total_seasons = args.seasons
        started = time.time()
        batch = run_replications(scenario, args.replications)
        elapsed = time.time() - started

        steps = (scenario.lifecycle.steps_per_season * args.seasons
                 * args.replications)
        rate = steps / elapsed if elapsed > 0 else float("nan")
        mean_pop = (sum(r.time_series["population"].mean()
                        for r in batch.runs) / max(1, len(batch.runs)))
        print(f"{preset_id:<28}{mean_pop:>8.0f}{steps:>10,}"
              f"{elapsed:>10.2f}{rate:>12,.0f}")

    print("\nTimings are measured on this machine and are not a performance "
          "claim for any other hardware.")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    handlers = {
        "presets": lambda: _cmd_presets(),
        "run": lambda: _cmd_run(args),
        "validate": lambda: _cmd_validate(args),
        "export-presets": lambda: _cmd_export_presets(args),
        "benchmark": lambda: _cmd_benchmark(args),
        "data-dictionary": lambda: _cmd_data_dictionary(args),
        "ai-guides": lambda: _cmd_ai_guides(args),
        "ai-import": lambda: _cmd_ai_import(args),
        "describe": lambda: _cmd_describe(args),
    }
    try:
        return handlers[args.command]()
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

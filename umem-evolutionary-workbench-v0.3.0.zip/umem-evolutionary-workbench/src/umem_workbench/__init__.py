"""UMEM Evolutionary Simulation Workbench.

An evolutionary model of *unconscious motivational propensity* (UMEM). The
package simulates how heritable energy- and time-allocation propensities can
evolve in abstract biological agents that have finite lives, homeostatic needs,
environmental uncertainty, survival hazards, reproduction and optional limited
cognition.

The model is theoretical and abstract. Default parameter values are illustrative
starting points for exploration, **not** empirically calibrated estimates for any
real species, and results depend on assumptions and random seeds. Nothing here
establishes consciousness, subjective motivation, or biological causation in
humans.

Public entry points
-------------------
* :func:`umem_workbench.config.presets.load_preset` -- load a named preset.
* :class:`umem_workbench.config.models.ScenarioConfig` -- the full validated
  scenario schema.
* :func:`umem_workbench.experiments.single_run.run_single` -- run one trajectory.
* :func:`umem_workbench.experiments.replications.run_replications` -- replicated
  experiment.
* :func:`umem_workbench.experiments.parameter_sweep.run_sweep` -- parameter sweep.
"""

from __future__ import annotations

from .version import SCHEMA_VERSION, __version__

__all__ = ["__version__", "SCHEMA_VERSION"]

"""Legacy AOM 2.1 reference model, retained for continuity (section 27)."""

from .aom_adapter import (
                          LEGACY_DIFFERENCES,
                          AOMParameters,
                          AOMResult,
                          compare_cognition,
                          generate_env_random_walk,
                          run_aom,
)

__all__ = ["run_aom", "AOMParameters", "AOMResult", "generate_env_random_walk",
           "compare_cognition", "LEGACY_DIFFERENCES"]

"""Legacy AOM 2.1 reference model (Master Prompt section 27).

This module reimplements the *original* generational model that preceded the
life-history engine, so that published results remain reproducible and the two
frameworks can be compared directly.

How the legacy model differs from the main engine
-------------------------------------------------
These differences are substantive, not cosmetic, and they are the reason the
legacy model lives in its own module rather than being expressed as a scenario:

===========================  ====================================  ==========================================
Aspect                       Legacy AOM 2.1                        Life-history engine
===========================  ====================================  ==========================================
Time                         Discrete non-overlapping generations  Time steps within seasons within lifetimes
Fitness                      An **imposed score**: the weighted     **Realised lifetime reproductive
                             sum of successful task values, plus   success**. Nothing is scored; births and
                             noise                                 deaths simply happen
Selection                    Truncation: the top ``num_parents``   No truncation. Whoever survives and meets
                             by fitness become the parent pool     the breeding thresholds reproduces
Death                        No mortality model; a generation      Seven attributed hazard sources acting
                             simply ends                           per time step
Internal state               None                                  Energy, health, reproductive capital,
                                                                   status, with homeostatic feedback
Energy                       A fixed budget split across tasks in  Earned and spent per action, with basal
                             proportion to motivation              metabolism and starvation
Inheritance                  Additive Gaussian mutation on a       Per-trait recombination plus
                             single random parent                  multiplicative lognormal mutation
===========================  ====================================  ==========================================

The imposed-fitness design is exactly what the main engine was built to avoid,
because a fitness function fixes in advance what counts as success and
therefore cannot show misallocation *emerging* from ecology. The legacy model
is retained for continuity and comparison, not as a recommended design.

Numerical fidelity
------------------
The per-agent loop of the original script is vectorised here. The sequence of
mathematical operations is preserved, but the order of draws from the random
number generator is not, so results are **statistically equivalent rather than
bit-identical** to the original script for a given seed. Set
``faithful_rng=True`` to reproduce the original draw order exactly at a
substantial cost in speed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

__all__ = [
    "AOMParameters",
    "AOMResult",
    "generate_env_random_walk",
    "run_aom",
    "compare_cognition",
    "LEGACY_DIFFERENCES",
]

LEGACY_DIFFERENCES = [
    "Fitness is an imposed weighted score, not realised reproductive success.",
    "Selection is truncation on that score; the main engine has no truncation.",
    "Generations are non-overlapping; there is no age, lifespan, or mortality.",
    "Agents have no internal physiological state and no homeostasis.",
    "Energy is a fixed budget divided by motivation, not earned and spent.",
    "Inheritance is additive Gaussian mutation from one random parent.",
]


@dataclass
class AOMParameters:
    """Parameters of the legacy model, with the original defaults."""

    num_generations: int = 100
    num_types: int = 3
    population: int = 200
    tasks_per_agent: int = 50
    e_total: float = 100.0
    mutation_std: float = 0.1
    fitness_noise_std: float = 0.1
    success_noise_std: float = 0.5
    difficulty_low: float = 0.5
    difficulty_high: float = 1.5
    num_parents: int = 40
    cog_noise_std: float = 0.3
    cog_strength: float = 2.5
    cog_memory_weight: float = 0.7
    cog_smoothing: float = 1.0
    min_alpha: float = 0.01
    task_type_probs: list[float] | None = None
    # Success logit coefficients from the original: sigmoid(a*e - b*d + noise).
    energy_coefficient: float = 1.0
    difficulty_coefficient: float = 1.0

    def __post_init__(self) -> None:
        if self.num_parents > self.population:
            raise ValueError("num_parents cannot exceed population")
        if self.num_types < 1:
            raise ValueError("num_types must be >= 1")


@dataclass
class AOMResult:
    """Output of a legacy run."""

    mean_alpha_history: np.ndarray          # (generations, num_types)
    mean_fitness_history: np.ndarray        # (generations,)
    success_share_history: np.ndarray       # (generations, num_types)
    env_history: np.ndarray                 # (generations, num_types)
    with_cognition: bool
    seed: int
    parameters: AOMParameters

    def to_frame(self) -> pd.DataFrame:
        """Tidy frame with one row per generation."""

        n_gen, n_types = self.mean_alpha_history.shape
        data: dict[str, Any] = {"generation": np.arange(n_gen)}
        for k in range(n_types):
            data[f"mean_alpha_task{k + 1}"] = self.mean_alpha_history[:, k]
            data[f"env_weight_task{k + 1}"] = self.env_history[:, k]
            data[f"success_share_task{k + 1}"] = self.success_share_history[:, k]
        data["mean_fitness"] = self.mean_fitness_history
        data["with_cognition"] = self.with_cognition
        return pd.DataFrame(data)


def generate_env_random_walk(num_generations: int = 100,
                             num_types: int = 2,
                             init_w: list[float] | None = None,
                             step_std: float = 0.05,
                             min_val: float = 0.01,
                             rng: np.random.Generator | None = None
                             ) -> np.ndarray:
    """Random-walk environmental weights, renormalised to sum to one.

    Only the first ``num_types`` weights are generated. In the reference setup
    the third task's weight is held at zero, which is what makes it
    survival-irrelevant.
    """

    rng = rng or np.random.default_rng()
    if init_w is None:
        w = np.ones(num_types) / num_types
    else:
        w = np.asarray(init_w, dtype=float)
        w = np.clip(w, min_val, None)
        w = w / w.sum()

    history = np.zeros((num_generations, num_types))
    for g in range(num_generations):
        history[g] = w
        w = w + rng.normal(0.0, step_std, size=num_types)
        w = np.clip(w, min_val, None)
        w = w / w.sum()
    return history


def _draw_success(energies: np.ndarray, difficulties: np.ndarray,
                  params: AOMParameters, rng: np.random.Generator) -> np.ndarray:
    logits = (params.energy_coefficient * energies
              - params.difficulty_coefficient * difficulties
              + rng.normal(0.0, params.success_noise_std, size=energies.shape))
    # Numerically stable logistic.
    p_success = np.where(logits >= 0,
                         1.0 / (1.0 + np.exp(-np.clip(logits, -700, 700))),
                         np.exp(np.clip(logits, -700, 700))
                         / (1.0 + np.exp(np.clip(logits, -700, 700))))
    return (rng.random(size=energies.shape) < p_success).astype(np.int64)


def run_aom(env_history: np.ndarray,
            with_cognition: bool = False,
            params: AOMParameters | None = None,
            seed: int = 0,
            faithful_rng: bool = False,
            progress: Any | None = None) -> AOMResult:
    """Run the legacy generational model.

    Parameters
    ----------
    env_history
        Array of shape ``(num_generations, num_types)`` giving the true
        environmental weight of each task type in each generation. A weight of
        zero makes that task type survival-irrelevant.
    with_cognition
        Enable the intergenerational experience system. The cognitive system
        never observes the true environment; it only sees which task types the
        previous two generations' selected parents succeeded at.
    faithful_rng
        Reproduce the original script's per-agent draw order exactly. Much
        slower, and only needed to match published numbers bit-for-bit.
    """

    params = params or AOMParameters()
    rng = np.random.default_rng(seed)

    env_history = np.asarray(env_history, dtype=float)
    n_gen = min(params.num_generations, env_history.shape[0])
    n_types = params.num_types
    pop = params.population
    n_tasks = params.tasks_per_agent

    if env_history.shape[1] < n_types:
        # The reference generates weights only for the relevant task types and
        # pads the irrelevant ones with zero.
        padded = np.zeros((env_history.shape[0], n_types))
        padded[:, :env_history.shape[1]] = env_history
        env_history = padded

    probs = (np.asarray(params.task_type_probs, dtype=float)
             if params.task_type_probs is not None
             else np.ones(n_types) / n_types)
    probs = probs / probs.sum()

    alphas = rng.gamma(shape=1.0, scale=1.0, size=(pop, n_types))

    mean_alpha_history = np.zeros((n_gen, n_types))
    mean_fitness_history = np.zeros(n_gen)
    success_share_history = np.zeros((n_gen, n_types))

    prev_exp_1 = np.ones(n_types) / n_types
    prev_exp_2 = np.ones(n_types) / n_types

    for gen in range(n_gen):
        w_env = env_history[gen]

        # --- cognition: subjective judgement from recent parental success ---
        if with_cognition:
            base_exp = (params.cog_memory_weight * prev_exp_1
                        + (1.0 - params.cog_memory_weight) * prev_exp_2)
            hat_m = base_exp + rng.normal(0.0, params.cog_noise_std, size=n_types)
            hat_m = np.clip(hat_m, 0.0, None)
            total = hat_m.sum()
            hat_m = (np.ones(n_types) / n_types) if total == 0 else hat_m / total
            alpha_eff = alphas * (1.0 + params.cog_strength * hat_m)
        else:
            alpha_eff = alphas

        if faithful_rng:
            fitness = np.zeros(pop)
            success_counts = np.zeros((pop, n_types))
            for p in range(pop):
                task_types = rng.choice(n_types, size=n_tasks, p=probs)
                prefs = alpha_eff[p][task_types]
                total_pref = prefs.sum()
                energies = (np.full(n_tasks, params.e_total / n_tasks)
                            if total_pref <= 0
                            else params.e_total * prefs / total_pref)
                difficulties = rng.uniform(params.difficulty_low,
                                           params.difficulty_high, size=n_tasks)
                successes = _draw_success(energies, difficulties, params, rng)
                success_counts[p] = np.bincount(task_types[successes == 1],
                                                minlength=n_types)
                fitness[p] = (np.sum(w_env[task_types] * successes)
                              + rng.normal(0.0, params.fitness_noise_std))
        else:
            # Vectorised over the whole population.
            task_types = rng.choice(n_types, size=(pop, n_tasks), p=probs)
            prefs = np.take_along_axis(alpha_eff, task_types, axis=1)
            total_pref = prefs.sum(axis=1, keepdims=True)
            energies = np.where(
                total_pref > 0,
                params.e_total * prefs / np.where(total_pref > 0, total_pref, 1.0),
                params.e_total / n_tasks)
            difficulties = rng.uniform(params.difficulty_low,
                                       params.difficulty_high,
                                       size=(pop, n_tasks))
            successes = _draw_success(energies, difficulties, params, rng)

            # Per-agent success counts by task type.
            success_counts = np.zeros((pop, n_types))
            np.add.at(success_counts,
                      (np.repeat(np.arange(pop), n_tasks), task_types.ravel()),
                      successes.ravel())

            fitness = (np.sum(w_env[task_types] * successes, axis=1)
                       + rng.normal(0.0, params.fitness_noise_std, size=pop))

        # --- truncation selection on the imposed fitness score ---
        parent_idx = np.argsort(fitness)[-params.num_parents:]
        parents = alphas[parent_idx]

        if with_cognition:
            parent_success = success_counts[parent_idx].sum(axis=0)
            parent_exp = parent_success + params.cog_smoothing
            parent_exp = parent_exp / parent_exp.sum()
            prev_exp_2 = prev_exp_1.copy()
            prev_exp_1 = parent_exp

        # --- reproduction: one random parent plus additive Gaussian mutation ---
        chosen = rng.integers(0, params.num_parents, size=pop)
        children = (parents[chosen]
                    + rng.normal(0.0, params.mutation_std, size=(pop, n_types)))
        alphas = np.clip(children, params.min_alpha, None)

        mean_alpha_history[gen] = alphas.mean(axis=0)
        mean_fitness_history[gen] = float(fitness.mean())
        totals = success_counts.sum()
        success_share_history[gen] = (success_counts.sum(axis=0) / totals
                                      if totals > 0 else 0.0)

        if progress is not None and gen % max(1, n_gen // 100) == 0:
            progress((gen + 1) / n_gen, f"generation {gen + 1}/{n_gen}")

    return AOMResult(
        mean_alpha_history=mean_alpha_history,
        mean_fitness_history=mean_fitness_history,
        success_share_history=success_share_history,
        env_history=env_history[:n_gen],
        with_cognition=with_cognition,
        seed=seed,
        parameters=params,
    )


def compare_cognition(num_generations: int = 200,
                      params: AOMParameters | None = None,
                      seed: int = 0,
                      env_step_std: float = 0.05) -> pd.DataFrame:
    """Run the reference comparison: identical environment, cognition on vs off.

    Both arms see exactly the same environmental trajectory, so any difference
    in the survival-irrelevant task's motivation is attributable to cognition
    rather than to environmental luck.
    """

    params = params or AOMParameters()
    params.num_generations = num_generations

    env_rng = np.random.default_rng(seed)
    # Only the survival-relevant types get weights; the last stays at zero.
    relevant = max(1, params.num_types - 1)
    env = generate_env_random_walk(num_generations, relevant,
                                   step_std=env_step_std, rng=env_rng)
    full = np.zeros((num_generations, params.num_types))
    full[:, :relevant] = env

    without = run_aom(full, with_cognition=False, params=params, seed=seed)
    with_cog = run_aom(full, with_cognition=True, params=params, seed=seed)
    return pd.concat([without.to_frame(), with_cog.to_frame()],
                     ignore_index=True)

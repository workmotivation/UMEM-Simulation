"""Streamlit interface for the UMEM Evolutionary Simulation Workbench.

Launch with::

    streamlit run streamlit_app.py

The interface offers a Simple mode (a small set of clearly labelled controls)
and an Advanced mode (every configuration field), backed by the same
:class:`WorkbenchState` as the desktop application.
"""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import streamlit as st

from ..analysis.plotting import (
    plot_death_causes,
    plot_domain_propensities,
    plot_environment,
    plot_forecast_error,
    plot_lifespan_distribution,
    plot_lrs_distribution,
    plot_nonfunctional_behaviour,
    plot_population,
    plot_replicate_band,
    plot_task_allocation,
)
from ..config.enums import ExperimentMode
from ..config.models import SweepParameter
from ..config.presets import PRESET_DESCRIPTIONS, PRESET_IDS
from ..config.serialization import (
    scenario_from_dict,
    scenario_from_json,
    scenario_to_dict,
    scenario_to_json,
)
from ..ui_common.help_text import (
    ABOUT_TEXT,
    DISCLAIMER_SHORT,
    DISCLAIMERS,
    METRIC_HELP,
    SECTION_HELP,
    SIMPLE_MODE_HELP,
)
from ..ui_common.labels import (
    SECTION_LABELS,
    inactive_applicabilities,
    model_field_meta,
)
from ..ui_common.presets import (
    SimpleSettings,
    apply_simple_settings,
    describe_mapping,
    read_simple_settings,
)
from ..ui_common.view_models import WorkbenchState
from ..version import __version__
from .widgets.editors import (
    domain_editor,
    environment_editor,
    task_editor,
)
from .widgets.forms import issue_table, model_form, validation_badges

APP_TITLE = "UMEM Evolutionary Simulation Workbench"


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------
def get_state() -> WorkbenchState:
    if "workbench" not in st.session_state:
        st.session_state.workbench = WorkbenchState()
    return st.session_state.workbench


def _sync(scenario) -> None:
    get_state().update_scenario(scenario)


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
def sidebar() -> str:
    state = get_state()
    st.sidebar.title(APP_TITLE)
    st.sidebar.caption(f"version {__version__}")

    page = st.sidebar.radio(
        "Section",
        ["Simple mode", "Advanced mode", "Scenario manager",
         "AI-assisted setup", "Environment preview", "Run", "Results",
         "Interpret results with AI", "Exports", "About"],
        key="nav_page")

    st.sidebar.divider()
    st.sidebar.markdown(f"**Scenario:** {state.display_name}")
    st.sidebar.code(state.config_hash[:16], language=None)
    if state.is_custom:
        st.sidebar.info("This scenario has been edited and is no longer the "
                        "unmodified preset.")

    report = state.validate()
    if not report.can_run:
        st.sidebar.error("Scenario has blocking errors; see Advanced mode.")
    st.sidebar.divider()
    st.sidebar.caption(DISCLAIMER_SHORT)
    return page


# ---------------------------------------------------------------------------
# Simple mode
# ---------------------------------------------------------------------------
def page_simple() -> None:
    state = get_state()
    st.header("Simple mode")
    st.caption(SIMPLE_MODE_HELP)

    current = read_simple_settings(state.scenario)

    preset_labels = {pid: pid.replace("_", " ").title() for pid in PRESET_IDS}
    chosen = st.selectbox(
        "Preset scenario", PRESET_IDS,
        index=(PRESET_IDS.index(state.scenario.preset_origin)
               if state.scenario.preset_origin in PRESET_IDS else 0),
        format_func=lambda p: preset_labels[p],
        help="Loads a complete configuration. Editing any control afterwards "
             "marks the scenario as Custom.")
    st.info(PRESET_DESCRIPTIONS.get(chosen, ""))
    if st.button("Load this preset", key="simple_load_preset"):
        state.load_preset(chosen)
        st.rerun()

    st.divider()
    st.subheader("Environment")
    col1, col2, col3 = st.columns(3)
    with col1:
        resource = st.slider(
            "Resource abundance", 0.05, 1.0,
            float(current.resource_abundance or 0.5), 0.05,
            help="Long-run mean of food-like variables. Predator variables are "
                 "not affected.")
    with col2:
        volatility = st.slider(
            "Environmental volatility", 0.0, 0.5,
            float(current.environmental_volatility or 0.05), 0.01,
            help="Innovation standard deviation of every environmental "
                 "variable.")
    with col3:
        predation = st.slider(
            "Predation pressure", 0.0, 1.0,
            float(current.predation_pressure or 0.3), 0.05,
            help="Predator variable mean and the base predation hazard.")

    st.subheader("Population and life history")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        initial_pop = st.number_input(
            "Initial population (agents)", 10, 5000,
            int(current.initial_population or 200), 10)
    with col2:
        capacity = st.number_input(
            "Carrying capacity (agents)", 10, 10000,
            int(current.carrying_capacity or 500), 10)
    with col3:
        lifespan = st.slider(
            "Average lifespan (seasons)", 2, 30,
            int(current.average_lifespan or 12), 1,
            help="Adjusts senescence and the lifespan ceiling together.")
    with col4:
        maturity = st.number_input(
            "Maturity age (seasons)", 0, 15,
            int(current.maturity_age or 2), 1)

    col1, col2, col3 = st.columns(3)
    with col1:
        fertility = st.slider(
            "Fertility (offspring per event)", 0.0, 8.0,
            float(current.fertility or 1.5), 0.1)
    with col2:
        mutation = st.slider(
            "Mutation strength (legacy model only)", 0.0, 0.5,
            float(current.mutation_strength or 0.1), 0.01,
            help="Applies only when the inheritance model is set to Legacy. "
                 "Under the polygenic model use 'Mutation level' below.")
    with col3:
        seasons = st.number_input(
            "Number of seasons", 1, 500,
            int(current.total_seasons or 30), 1)

    st.subheader("Reproduction")
    st.caption(
        "Continuous reproduction treats every time step as an opportunity to "
        "breed, so births are spread through the season. Season-end batching "
        "is kept only for compatibility with results produced before this "
        "version.")
    col1, col2, col3 = st.columns(3)
    with col1:
        repro_mode = st.selectbox(
            "Reproduction mode", ["sexual", "asexual"],
            index=["sexual", "asexual"].index(current.reproduction_mode or "sexual"),
            help="Sexual needs one Type-A and one Type-B agent per event. "
                 "Type A and B are neutral reproductive types, not sexes.")
    with col2:
        timing_opts = ["distributed", "season_end_legacy"]
        timing_labels = {"distributed": "Continuous (recommended)",
                         "season_end_legacy": "Season-end (compatibility mode)"}
        timing = st.selectbox(
            "Reproduction timing", timing_opts,
            index=timing_opts.index(current.reproduction_timing or "distributed"),
            format_func=lambda x: timing_labels[x],
            help="Season-end reproduction makes the whole population breed on "
                 "one step per season, which produces a saw-toothed population "
                 "curve. It is not recommended for new work.")
    with col3:
        repro_rate = st.slider(
            "Reproductive rate (events/agent/season)", 0.0, 10.0,
            float(current.reproductive_rate or 1.7), 0.1,
            help="A rate, not a probability: changing the number of steps per "
                 "season does not change it.")

    asexual = repro_mode == "asexual"
    col1, col2 = st.columns(2)
    with col1:
        mating_opts = ["random", "pair_bonded", "competitive"]
        mating_labels = {
            "random": "Random mixing (promiscuity)",
            "pair_bonded": "Pair bonding (social monogamy)",
            "competitive": "Competitive (reproductive skew)"}
        mating = st.selectbox(
            "Mating mode", mating_opts,
            index=mating_opts.index(current.mating_mode or "random"),
            format_func=lambda x: mating_labels[x],
            disabled=asexual,
            help="Not applicable under asexual reproduction."
                 if asexual else
                 "Random mixing is the scientifically neutral default. Pair "
                 "bonding forms exclusive persistent pairs. Competitive "
                 "concentrates reproductive success among higher-quality "
                 "agents.")
    with col2:
        choosiness = st.number_input(
            "Choosiness (candidates inspected)", 1, 100,
            int(current.mate_choice_k or 1), 1,
            disabled=asexual or mating == "random",
            help="1 is unbiased random mating. Larger values mean an agent "
                 "inspects more candidates and takes the best, concentrating "
                 "reproductive success.")
    if asexual:
        st.caption("Mating settings are inactive: asexual reproduction needs "
                   "no partner.")

    st.subheader("Inheritance")
    st.caption(
        "Propensities are modelled as polygenic quantitative traits, not as "
        "identified single genes. Ordinary variation between siblings "
        "(segregation) is configured separately from the rare introduction of "
        "new variation (mutation).")
    col1, col2, col3 = st.columns(3)
    with col1:
        inh_opts = ["polygenic_additive", "legacy"]
        inh_labels = {"polygenic_additive": "Polygenic additive (recommended)",
                      "legacy": "Legacy (compatibility mode)"}
        inheritance_model = st.selectbox(
            "Inheritance model", inh_opts,
            index=inh_opts.index(current.inheritance_model or "polygenic_additive"),
            format_func=lambda x: inh_labels[x],
            help="Polygenic additive uses the infinitesimal model, the "
                 "standard approximation to many small-effect genetic loci.")
    with col2:
        sib_opts = ["low", "standard", "high"]
        sibling = st.selectbox(
            "Sibling genetic variation", sib_opts,
            index=sib_opts.index(current.sibling_variation or "standard"),
            disabled=asexual,
            help="How much full siblings differ. At 'standard' the founder "
                 "genetic variance stays in equilibrium. Asexual offspring "
                 "have no segregation.")
    with col3:
        mut_opts = ["none", "conservative", "accelerated"]
        mutation_level = st.selectbox(
            "Mutation level", mut_opts,
            index=mut_opts.index(current.mutation_level or "conservative"),
            help="Effective simulation parameters, not human per-base "
                 "mutation rates.")

    st.subheader("Starting population")
    founder_opts = ["uniform", "stable", "all_newborn_legacy"]
    founder_labels = {"uniform": "Spread evenly over the lifespan",
                      "stable": "Approximate stable age structure",
                      "all_newborn_legacy": "All start at age zero (legacy)"}
    founder = st.selectbox(
        "Founder ages", founder_opts,
        index=founder_opts.index(current.founder_age_distribution or "uniform"),
        format_func=lambda x: founder_labels[x],
        help="A dispersed founder cohort avoids an initial birth pulse and the "
             "matching die-off one lifespan later.")

    st.subheader("Mechanisms")
    col1, col2, col3 = st.columns(3)
    with col1:
        cognition = st.selectbox(
            "Cognition mode", ["none", "experience", "forecast", "both"],
            index=["none", "experience", "forecast", "both"].index(
                current.cognition_mode or "none"),
            help="Switches cognitive modules without touching unrelated "
                 "parameters.")
    with col2:
        homeostasis = st.checkbox(
            "Homeostasis enabled", value=bool(current.homeostasis_enabled),
            help="Internal urgencies (hunger, threat, reproductive "
                 "readiness). This is physiology, not cognition.")
    with col3:
        nonfunctional = st.checkbox(
            "Costly nonfunctional behaviour",
            value=bool(current.nonfunctional_enabled),
            help="Enables the two demonstration tasks with no modelled "
                 "benefit.")

    st.subheader("Experiment")
    col1, col2 = st.columns(2)
    with col1:
        replications = st.number_input(
            "Number of replications", 1, 200,
            int(current.replications or 1), 1,
            help="Independent repeats differing only in RNG substream.")
    with col2:
        seed = st.number_input(
            "Master seed", 0, 2 ** 31 - 2, int(current.master_seed or 12345), 1,
            help="The same seed always reproduces the same results.")

    settings = SimpleSettings(
        resource_abundance=resource, environmental_volatility=volatility,
        predation_pressure=predation, initial_population=initial_pop,
        carrying_capacity=capacity, average_lifespan=lifespan,
        maturity_age=maturity, fertility=fertility, mutation_strength=mutation,
        cognition_mode=cognition, homeostasis_enabled=homeostasis,
        nonfunctional_enabled=nonfunctional, total_seasons=seasons,
        replications=replications, master_seed=seed,
        reproduction_mode=repro_mode, reproduction_timing=timing,
        mating_mode=mating, mate_choice_k=choosiness,
        reproductive_rate=repro_rate,
        founder_age_distribution=founder,
        inheritance_model=inheritance_model,
        sibling_variation=sibling, mutation_level=mutation_level)

    if st.button("Apply these settings", type="primary", key="simple_apply"):
        _sync(apply_simple_settings(state.scenario, settings))
        st.success("Settings applied. Advanced mode now shows the resulting "
                   "values.")
        # The sidebar is rendered before this callback runs, so without an
        # explicit rerun the scenario name and Custom badge would stay stale
        # until the user's next interaction.
        st.rerun()

    with st.expander("How these controls map to advanced parameters"):
        st.caption(
            "Every simple control declares exactly which parameters it "
            "changes. Nothing is hidden, only bundled.")
        st.dataframe(pd.DataFrame(describe_mapping()), width="stretch",
                     hide_index=True)


# ---------------------------------------------------------------------------
# Advanced mode
# ---------------------------------------------------------------------------
def page_advanced() -> None:
    state = get_state()
    st.header("Advanced mode")
    st.caption("Every configuration field. Editing any value marks the "
               "scenario as Custom.")

    report = state.validate()
    validation_badges(report)
    with st.expander("Validation report", expanded=not report.can_run):
        issue_table(report)

    tabs = st.tabs(["Population", "Life cycle", "Mortality", "Reproduction",
                    "Inheritance", "Homeostasis", "Cognition", "Choice",
                    "Output", "Tasks", "Environment", "Domains"])

    simple_sections = [
        ("population", tabs[0]), ("lifecycle", tabs[1]), ("mortality", tabs[2]),
        ("reproduction", tabs[3]), ("inheritance", tabs[4]),
        ("homeostasis", tabs[5]), ("cognition", tabs[6]), ("choice", tabs[7]),
        ("output", tabs[8]),
    ]
    for section, tab in simple_sections:
        with tab:
            st.subheader(SECTION_LABELS.get(section, section.title()))
            if section in SECTION_HELP:
                st.caption(SECTION_HELP[section])
            sub_model = getattr(state.scenario, section)
            inactive = inactive_applicabilities(state.scenario)
            updates = model_form(sub_model, key_prefix=f"adv_{section}",
                                 inactive=inactive)
            if st.button("Apply", key=f"apply_{section}"):
                data = scenario_to_dict(state.scenario)
                metas = model_field_meta(sub_model)
                for name, value in updates.items():
                    if metas[name].applicability in inactive:
                        continue   # never write back a disabled field
                    data[section][name] = (value.value if hasattr(value, "value")
                                           else value)
                _sync(scenario_from_dict(data))
                st.success(f"{SECTION_LABELS.get(section, section)} updated.")
                st.rerun()

    with tabs[9]:
        st.caption(SECTION_HELP["tasks"])
        updated = task_editor(state.scenario)
        if st.button("Apply task changes", key="apply_tasks"):
            _sync(updated)
            st.success("Task library updated.")
            st.rerun()

    with tabs[10]:
        st.caption(SECTION_HELP["environment"])
        updated = environment_editor(state.scenario)
        if st.button("Apply environment changes", key="apply_env"):
            _sync(updated)
            st.success("Environment updated.")
            st.rerun()

    with tabs[11]:
        st.caption(SECTION_HELP["domains"])
        domain_editor(state.scenario)


# ---------------------------------------------------------------------------
# Scenario manager
# ---------------------------------------------------------------------------
def page_scenario_manager() -> None:
    state = get_state()
    st.header("Scenario manager")

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Identity")
        name = st.text_input("Scenario name", value=state.scenario.name)
        description = st.text_area("Description",
                                   value=state.scenario.description or "",
                                   height=120)
        if st.button("Update name and description"):
            data = scenario_to_dict(state.scenario)
            data["name"] = name
            data["description"] = description
            # Cosmetic fields are excluded from the configuration hash, so this
            # deliberately does not mark the scenario as Custom.
            state.scenario = scenario_from_dict(data)
            st.success("Updated. The configuration hash is unchanged, because "
                       "names and descriptions are not part of it.")

        st.metric("Configuration hash", state.config_hash[:16])

    with col2:
        st.subheader("Save and load")
        st.download_button(
            "Download scenario JSON",
            data=scenario_to_json(state.scenario),
            file_name=f"{(state.scenario.name or 'scenario').replace(' ', '_')}.json",
            mime="application/json")

        uploaded = st.file_uploader("Load scenario JSON", type=["json"])
        if uploaded is not None and st.button("Load uploaded scenario"):
            try:
                text = uploaded.read().decode("utf-8")
                state.scenario = scenario_from_json(text)
                state.is_custom = not state._matches_declared_preset()
                state.outcome = None
                st.success("Scenario loaded.")
                st.rerun()
            except Exception as exc:
                st.error(f"Could not load scenario: {exc}")

    st.divider()
    conditions_panel(state.scenario, key="mgr_cond")
    st.subheader("View changes against the preset")
    diff = state.diff_against_preset()
    if not diff:
        st.success("This scenario matches its preset exactly.")
    else:
        st.caption(f"{len(diff)} parameter(s) differ from "
                   f"'{state.scenario.preset_origin}'.")
        st.dataframe(pd.DataFrame(diff), width="stretch", hide_index=True)


# ---------------------------------------------------------------------------
# Environment preview
# ---------------------------------------------------------------------------
def page_environment_preview() -> None:
    state = get_state()
    st.header("Environment preview")
    st.caption(
        "Generates the environmental trajectories for the current scenario and "
        "seed without running the population. Use it to check that a process "
        "behaves as intended before committing to a full run.")

    from ..engine.randomness import RandomStreams
    from ..environment.processes import generate_environment

    seasons = st.slider("Seasons to preview", 1, 100,
                        min(20, state.scenario.lifecycle.total_seasons))
    streams = RandomStreams.create(state.scenario.master_seed, 0)
    steps = state.scenario.lifecycle.steps_per_season * seasons

    try:
        env = generate_environment(state.scenario.environment, steps,
                                   streams.stream("environment"))
    except Exception as exc:
        st.error(f"Could not generate environment: {exc}")
        return

    frame = pd.DataFrame({k: np.asarray(v) for k, v in env.items()})
    frame.insert(0, "step", range(len(frame)))
    st.line_chart(frame.set_index("step"), height=340)

    st.subheader("Descriptive statistics")
    st.dataframe(frame.drop(columns=["step"]).describe().T.round(4),
                 width="stretch")


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------
def page_run() -> None:
    state = get_state()
    st.header("Run")
    conditions_panel(state.scenario, key="run_cond")

    report = state.validate()
    validation_badges(report)
    if not report.can_run:
        st.error("Fix the blocking errors in Advanced mode before running.")
        issue_table(report)
        return

    st.subheader("Experiment mode")
    mode = st.radio("Mode", [m.value for m in ExperimentMode],
                    index=[m.value for m in ExperimentMode].index(
                        state.scenario.experiment.mode.value),
                    horizontal=True)

    col1, col2 = st.columns(2)
    with col1:
        replications = st.number_input(
            "Replications", 1, 500, state.scenario.experiment.replications, 1)
    with col2:
        workers = st.number_input(
            "Parallel workers", 1, 32, state.scenario.experiment.max_workers, 1,
            help="Independent replications run in separate processes. "
                 "Determinism is preserved regardless of worker count.")

    sweep_params: list[SweepParameter] = []
    if mode == ExperimentMode.SWEEP.value:
        st.subheader("Sweep parameters")
        st.caption("Up to three scalar parameters, addressed by dotted path, "
                   "for example `mortality.base_predation_hazard`.")
        n_params = st.number_input("Number of parameters", 1, 3, 1, 1)
        for i in range(int(n_params)):
            cols = st.columns([3, 3])
            with cols[0]:
                path = st.text_input(f"Path {i + 1}",
                                     value="mortality.base_predation_hazard",
                                     key=f"sweep_path_{i}")
            with cols[1]:
                raw = st.text_input(f"Values {i + 1} (comma separated)",
                                    value="0.001, 0.002, 0.004",
                                    key=f"sweep_vals_{i}")
            try:
                values = [float(v) for v in raw.split(",") if v.strip()]
                if path and values:
                    sweep_params.append(SweepParameter(path=path, values=values))
            except ValueError:
                st.warning(f"Could not parse values for parameter {i + 1}.")

        crn = st.checkbox(
            "Use common random numbers across cells", value=False,
            help="Every cell sees the same environmental draws, which removes "
                 "environmental variance from between-cell comparisons. The "
                 "resulting estimates are paired and must be analysed as such.")
    else:
        crn = False

    data = scenario_to_dict(state.scenario)
    data["experiment"]["mode"] = mode
    data["experiment"]["replications"] = int(replications)
    data["experiment"]["max_workers"] = int(workers)
    data["experiment"]["common_random_numbers"] = bool(crn)
    if sweep_params:
        data["experiment"]["sweep_parameters"] = [
            p.model_dump(mode="json") for p in sweep_params]
    state.scenario = scenario_from_dict(data)

    st.divider()
    st.subheader("Workload estimate")
    pre = state.preflight()
    col1, col2, col3 = st.columns(3)
    col1.metric("Sweep cells", pre["n_sweep_cells"])
    col2.metric("Runs per cell", pre["n_replications_per_cell"])
    col3.metric("Total runs", pre["total_runs"])
    workload = pre["workload"]
    st.caption(f"Approximately {getattr(workload, 'total_steps', 0):,} agent "
               f"time steps per run. This is a rough estimate, not a guarantee.")

    if pre["exceeds_max_combinations"]:
        st.warning(
            f"This sweep has {pre['n_sweep_cells']} combinations, above the "
            f"configured maximum of {pre['max_combinations']}.")

    if st.button("Run experiment", type="primary", key="run_button"):
        progress_bar = st.progress(0.0)
        status = st.empty()

        def on_progress(fraction: float, message: str) -> None:
            progress_bar.progress(min(1.0, max(0.0, fraction)))
            status.caption(message)

        try:
            with st.spinner("Running..."):
                outcome = state.run(on_progress=on_progress,
                                    parallel=int(workers) > 1,
                                    max_workers=int(workers))
            progress_bar.progress(1.0)
            if outcome.cancelled:
                st.warning("Run cancelled; partial results are available.")
            else:
                st.success(f"Completed {len(outcome.runs)} run(s).")
            st.info("Open the Results section to inspect the output.")
        except Exception as exc:
            st.error(f"Run failed: {exc}")


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------
def _metric_row(summary: dict[str, Any], keys: list[tuple[str, str]]) -> None:
    cols = st.columns(len(keys))
    for col, (key, label) in zip(cols, keys):
        value = summary.get(key)
        if isinstance(value, float):
            text = "n/a" if not np.isfinite(value) else f"{value:,.4g}"
        elif isinstance(value, bool):
            text = "yes" if value else "no"
        elif value is None:
            text = "n/a"
        else:
            text = f"{value:,}" if isinstance(value, int) else str(value)
        col.metric(label, text, help=METRIC_HELP.get(key))


def page_results() -> None:
    state = get_state()
    st.header("Results")

    run = state.primary_run
    if run is None:
        st.info("No results yet. Configure a scenario and run it.")
        return

    from ..analysis.metrics import summarise_run
    summary = run.summary or summarise_run(run)

    if run.cancelled:
        st.warning("This run was cancelled; results are partial.")

    tabs = st.tabs(["Population", "Survival", "Reproduction",
                    "Motivation and behaviour", "Environment and cognition",
                    "Misallocation", "Evolution and diversity",
                    "Replications", "Full report"])

    with tabs[0]:
        _metric_row(summary, [("final_population", "Final population"),
                              ("peak_population", "Peak"),
                              ("min_population", "Minimum"),
                              ("extinct", "Extinct")])
        st.pyplot(plot_population(run), width="stretch")
        st.pyplot(plot_death_causes(run), width="stretch")

    with tabs[1]:
        _metric_row(summary, [("mean_lifespan_seasons", "Mean lifespan"),
                              ("median_lifespan_seasons", "Median lifespan"),
                              ("frac_reaching_maturity", "Reached maturity"),
                              ("n_deaths", "Completed lives")])
        st.pyplot(plot_lifespan_distribution(run), width="stretch")

    with tabs[2]:
        _metric_row(summary, [
            ("mean_lrs_completed_lives", "Mean LRS"),
            ("frac_zero_lrs", "Left no offspring"),
            ("opportunity_for_selection_I", "Opportunity for selection"),
            ("realised_juvenile_survival", "Juvenile survival")])
        st.caption("Fitness here is realised lifetime reproductive success, an "
                   "outcome of the simulation rather than a score imposed on "
                   "agents.")
        st.pyplot(plot_lrs_distribution(run), width="stretch")

    with tabs[3]:
        st.caption("Inherited propensities are tendencies; realised allocation "
                   "also reflects homeostasis, eligibility, and cognition.")
        st.pyplot(plot_domain_propensities(run), width="stretch")
        st.pyplot(plot_task_allocation(run, "timealloc"), width="stretch")
        st.pyplot(plot_task_allocation(run, "energyalloc"), width="stretch")

    with tabs[4]:
        st.pyplot(plot_environment(run), width="stretch")
        st.pyplot(plot_forecast_error(run), width="stretch")

    with tabs[5]:
        _metric_row(summary, [
            ("final_nonfunctional_action_rate", "Nonfunctional actions"),
            ("final_nonfunctional_time_share", "Nonfunctional time"),
            ("final_nonfunctional_energy_share", "Nonfunctional energy"),
            ("experience_mismatch_nonbeneficial", "Experience mismatch")])
        st.pyplot(plot_nonfunctional_behaviour(run), width="stretch")
        st.caption(
            "The cognitive amplification ratio requires a matched "
            "no-cognition baseline run of the same scenario; it is computed in "
            "the analysis API rather than from a single run.")

    with tabs[6]:
        _metric_row(summary, [
            ("final_n_lineages", "Surviving lineages"),
            ("peak_n_lineages", "Peak lineages"),
            ("variance_retained_fraction", "Variance retained"),
            ("final_mean_domain_variance", "Final domain variance")])

    with tabs[7]:
        runs = state.runs
        if len(runs) < 2:
            st.info("Run in replications mode to see between-run variation.")
        else:
            from ..analysis.aggregation import aggregate_time_series, extinction_rate
            ext = extinction_rate(runs)
            col1, col2, col3 = st.columns(3)
            col1.metric("Replications", ext["n_runs"])
            col2.metric("Extinct", ext["n_extinct"])
            col3.metric("Extinction rate", f"{ext['extinction_rate']:.3f}",
                        help=METRIC_HELP["extinction_rate"])
            band = aggregate_time_series(runs, columns=["population"])
            st.pyplot(plot_replicate_band(band, "population"), width="stretch")
            st.dataframe(state.summary_frame(), width="stretch")

    with tabs[8]:
        st.text(state.report_text())


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------
def page_exports() -> None:
    state = get_state()
    st.header("Exports")

    run = state.primary_run
    if run is None:
        st.info("No results to export yet.")
        return

    col1, col2 = st.columns(2)
    with col1:
        formats = st.multiselect("Figure formats", ["png", "svg", "pdf"],
                                 default=["png"])
        dpi = st.select_slider("Figure resolution (DPI)",
                               options=[100, 150, 200, 300, 600], value=300)
    with col2:
        include_excel = st.checkbox("Include Excel workbook", value=True)
        include_csv = st.checkbox("Include raw CSV tables", value=True)
        include_figs = st.checkbox("Include figures", value=True)

    st.caption(
        "The bundle contains the scenario JSON, run metadata, an Excel "
        "workbook, CSV tables, figures, a warning log, and short "
        "reproducibility instructions.")

    if st.button("Build export bundle", type="primary"):
        try:
            with st.spinner("Building bundle..."):
                directory = tempfile.mkdtemp(prefix="umem_export_")
                path = state.export_bundle(
                    directory, figure_formats=tuple(formats or ["png"]),
                    figure_dpi=int(dpi), include_excel=include_excel,
                    include_raw_csv=include_csv, include_figures=include_figs,
                    allow_unsafe_directory=True)
            with open(path, "rb") as handle:
                st.download_button("Download bundle (ZIP)", data=handle.read(),
                                   file_name=Path(path).name,
                                   mime="application/zip")
            st.success("Bundle ready.")
        except Exception as exc:
            st.error(f"Export failed: {exc}")

    st.divider()
    st.subheader("Quick downloads")
    if run.time_series is not None and len(run.time_series):
        st.download_button(
            "Time series CSV",
            data=run.time_series.to_csv(index=False).encode("utf-8-sig"),
            file_name="time_series.csv", mime="text/csv")
    summary_frame = state.summary_frame()
    if len(summary_frame):
        st.download_button(
            "Summary metrics CSV",
            data=summary_frame.to_csv(index=False).encode("utf-8-sig"),
            file_name="summary_metrics.csv", mime="text/csv")




# ---------------------------------------------------------------------------
# Experiment conditions panel (shared)
# ---------------------------------------------------------------------------
def conditions_panel(scenario, title: str = "Experiment conditions (currently applied)",
                     key: str = "cond") -> None:
    """Deterministic, locally rendered description of a scenario."""

    from ..ai_assist import describe_scenario
    desc = describe_scenario(scenario)
    with st.expander(title, expanded=False):
        st.markdown(desc.prose())
        if desc.unusual_settings:
            st.markdown("**Notes on unusual or custom settings**")
            for n in desc.unusual_settings:
                st.markdown(f"- {n}")
        with st.expander("Complete specification (active settings)"):
            st.dataframe(pd.DataFrame(desc.specification)[["path", "value", "label"]],
                         width="stretch", hide_index=True)
            if desc.inactive_fields:
                st.caption("Inactive settings (ignored under the current mechanisms):")
                st.dataframe(pd.DataFrame(desc.inactive_fields)[["path", "value", "reason"]],
                             width="stretch", hide_index=True)
            if desc.uncovered_paths:
                st.warning("Parameters without a narrative rule: " + ", ".join(desc.uncovered_paths))
        st.download_button("Download description (Markdown)", desc.markdown().encode("utf-8"),
                           file_name="EXPERIMENT_CONDITIONS.md", mime="text/markdown",
                           key=f"{key}_dl")


# ---------------------------------------------------------------------------
# AI-assisted setup
# ---------------------------------------------------------------------------
def page_ai_setup() -> None:
    from ..ai_assist import (
        diff_scenarios,
        scenario_design_guide,
        starter_message_design,
        validation_feedback_for_ai,
    )
    from ..config.serialization import scenario_to_dict, scenario_to_json

    state = get_state()
    st.header("AI-assisted setup")
    st.info("UMEM does not connect to any AI service and sends nothing anywhere. You download "
            "a guide, upload it to an AI tool of your own choosing, describe your research "
            "question, and bring the JSON it produces back here. UMEM validates it locally; "
            "nothing changes until you press Apply.")

    st.subheader("1. Download the guide")
    col1, col2 = st.columns(2)
    with col1:
        st.download_button("Download AI_SCENARIO_DESIGN_GUIDE.md",
                           scenario_design_guide().encode("utf-8"),
                           file_name="AI_SCENARIO_DESIGN_GUIDE.md", mime="text/markdown")
    with col2:
        st.download_button("Download current scenario JSON (optional, to revise it)",
                           scenario_to_json(state.scenario).encode("utf-8"),
                           file_name="current_scenario.json", mime="application/json")
    st.caption("Starter message to paste into your AI tool together with the guide:")
    st.code(starter_message_design(), language=None)

    conditions_panel(state.scenario, key="ai_setup_current")

    st.subheader("2. Bring back the scenario JSON")
    uploaded = st.file_uploader("Upload scenario JSON", type=["json", "txt", "md"],
                                key="ai_import_file")
    pasted = st.text_area("…or paste the JSON (raw, or one ```json block)", height=160,
                          key="ai_import_text")
    text = None
    if uploaded is not None:
        text = uploaded.read().decode("utf-8", errors="replace")
    elif pasted.strip():
        text = pasted

    if text is None:
        st.session_state.pop("ai_import_result", None)
        return

    if st.button("Validate and preview", type="primary", key="ai_validate"):
        st.session_state["ai_import_result"] = state.preview_import(text)
        st.session_state["ai_import_raw"] = text

    result = st.session_state.get("ai_import_result")
    if result is None:
        return

    st.subheader("3. Review")
    if result.ok:
        st.success(f"Valid scenario. Configuration hash `{result.config_hash[:16]}…` — "
                   f"{len(result.warnings)} warning(s). Nothing has been applied yet.")
    else:
        st.error(f"Rejected: {len(result.errors)} blocking error(s). The current scenario is unchanged.")
    for i in result.errors:
        st.error(f"[{i.stage}] `{i.path or 'document'}`: {i.message}" + (f" — allowed: {i.allowed}" if i.allowed else ""))
    for i in result.warnings:
        st.warning(f"[{i.stage}] `{i.path}`: {i.message}")
    if result.migration_changes:
        with st.expander(f"Migration applied ({len(result.migration_changes)} change(s))"):
            st.dataframe(pd.DataFrame(result.migration_changes).astype(str), width="stretch", hide_index=True)

    include = st.checkbox("Include my submitted JSON in the feedback", value=False, key="ai_fb_include")
    st.download_button("Download validation feedback for the AI",
                       validation_feedback_for_ai(result, include_submitted=include,
                                                  original_text=st.session_state.get("ai_import_raw", "")).encode("utf-8"),
                       file_name="UMEM_validation_feedback.txt", mime="text/plain")

    if result.ok and result.scenario is not None:
        st.markdown("#### Proposed experiment (not yet applied)")
        conditions_panel(result.scenario, title="Proposed experiment conditions", key="ai_setup_proposed")
        changes = diff_scenarios(scenario_to_dict(state.scenario), result.effective)
        st.markdown(f"#### Changes versus the currently applied scenario ({len(changes)})")
        if changes:
            frame = pd.DataFrame(changes)[["path", "before", "after", "kind"]].astype(str)
            st.dataframe(frame, width="stretch", hide_index=True)
        else:
            st.caption("No scientific differences; applying will not change the configuration hash.")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Apply this scenario", type="primary", key="ai_apply"):
                state.apply_import(result)
                st.session_state.pop("ai_import_result", None)
                st.success("Applied. Existing results were cleared; running is a separate action on the Run page.")
                st.rerun()
        with col2:
            if st.button("Discard", key="ai_discard"):
                st.session_state.pop("ai_import_result", None)
                st.rerun()


# ---------------------------------------------------------------------------
# Interpret results with AI
# ---------------------------------------------------------------------------
def page_ai_interpret() -> None:
    from ..ai_assist import report_interpretation_guide, starter_message_interpret

    state = get_state()
    st.header("Interpret results with AI")
    st.info("Download the generic interpretation guide and this experiment's report, upload both "
            "to an AI tool of your choosing, and ask questions. UMEM sends nothing anywhere.")
    st.download_button("Download AI_REPORT_INTERPRETATION_GUIDE.md",
                       report_interpretation_guide().encode("utf-8"),
                       file_name="AI_REPORT_INTERPRETATION_GUIDE.md", mime="text/markdown")

    if state.outcome is None:
        st.warning("No results yet. Run an experiment first; the report is generated from actual results.")
        return

    if state.outcome.cancelled or any(r.cancelled for r in state.runs):
        st.warning("This experiment was cancelled; the report will be labelled partial.")

    appendix = st.checkbox("Also generate full time-series appendix parts (larger files)", value=False)
    bundle = state.ai_report(include_time_series_appendix=appendix)
    total = sum(bundle.size_estimate.values())
    st.caption("Estimated sizes: " + ", ".join(f"{k} ≈ {v/1024:.0f} kB" for k, v in bundle.size_estimate.items())
               + f" (total ≈ {total/1024:.0f} kB). The report summarises time series per season; full tables are in the export bundle.")
    st.download_button("Download AI_REPORT.md", bundle.report_markdown.encode("utf-8"),
                       file_name="AI_REPORT.md", mime="text/markdown", type="primary")
    for name, text in bundle.appendices.items():
        st.download_button(f"Download {name}", text.encode("utf-8"), file_name=name, mime="text/markdown", key=f"apx_{name}")
    st.caption("Starter message:")
    st.code(starter_message_interpret(), language=None)
    with st.expander("Preview report"):
        st.markdown(bundle.report_markdown)


# ---------------------------------------------------------------------------
# About
# ---------------------------------------------------------------------------
def page_about() -> None:
    st.header("About")
    st.markdown(ABOUT_TEXT)
    st.divider()
    st.subheader("Scientific caveats")
    for title, body in DISCLAIMERS:
        with st.expander(title, expanded=False):
            st.write(body)
    st.divider()
    st.caption(f"UMEM Evolutionary Simulation Workbench, version {__version__}. "
               f"Released under the MIT licence.")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
PAGES = {
    "Simple mode": page_simple,
    "Advanced mode": page_advanced,
    "Scenario manager": page_scenario_manager,
    "AI-assisted setup": page_ai_setup,
    "Interpret results with AI": page_ai_interpret,
    "Environment preview": page_environment_preview,
    "Run": page_run,
    "Results": page_results,
    "Exports": page_exports,
    "About": page_about,
}


def main() -> None:
    st.set_page_config(page_title=APP_TITLE, layout="wide",
                       initial_sidebar_state="expanded")
    page = sidebar()
    PAGES[page]()


if __name__ == "__main__":
    main()

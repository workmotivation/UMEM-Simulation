"""Streamlit form widgets generated from configuration model metadata.

Every widget is derived from the Pydantic field definition, so labels, help
text, units, and safe ranges come from one source of truth and a newly added
configuration field automatically gets a correctly labelled control.
"""

from __future__ import annotations

import enum
from collections.abc import Sequence
from typing import Any

import streamlit as st
from pydantic import BaseModel

from ...ui_common.labels import FieldMeta, model_field_meta

__all__ = ["model_form", "render_field", "validation_badges", "issue_table"]


def _accepts_none(annotation: Any) -> bool:
    """True when a field's type annotation permits None (i.e. Optional[...])."""

    import typing
    if annotation is None:
        return True
    if annotation is type(None):
        return True
    origin = typing.get_origin(annotation)
    if origin is typing.Union:
        return type(None) in typing.get_args(annotation)
    # PEP 604 unions (str | None) report types.UnionType as their origin.
    try:
        import types as _types
        if isinstance(annotation, _types.UnionType):
            return type(None) in typing.get_args(annotation)
    except (ImportError, AttributeError):  # pragma: no cover
        pass
    return False


def _widget_key(prefix: str, name: str) -> str:
    return f"{prefix}__{name}" if prefix else name


def render_field(model: BaseModel, name: str, meta: FieldMeta,
                 key_prefix: str = "", disabled: bool = False) -> Any:
    """Render one field and return the (possibly edited) value."""

    current = getattr(model, name)
    key = _widget_key(key_prefix, name)
    label = meta.label_with_unit
    help_text = meta.help or None

    # Enums -> selectbox of their values.
    if isinstance(current, enum.Enum):
        options = [e.value for e in type(current)]
        chosen = st.selectbox(label, options, index=options.index(current.value),
                              help=help_text, key=key, disabled=disabled)
        return type(current)(chosen)

    if isinstance(current, bool):
        return st.checkbox(label, value=current, help=help_text, key=key,
                           disabled=disabled)

    if isinstance(current, int):
        lo = int(meta.ui_min) if meta.ui_min is not None else None
        hi = int(meta.ui_max) if meta.ui_max is not None else None
        return int(st.number_input(
            label, value=int(current),
            min_value=lo, max_value=hi, step=1,
            help=help_text, key=key, disabled=disabled))

    if isinstance(current, float):
        lo, hi = meta.ui_min, meta.ui_max
        # A bounded field with a sensible span gets a slider; otherwise a
        # number box, so an unbounded value is never silently clamped.
        if lo is not None and hi is not None and hi > lo:
            span = float(hi) - float(lo)
            step = max(span / 200.0, 1e-6)
            value = min(max(float(current), float(lo)), float(hi))
            return float(st.slider(
                label, min_value=float(lo), max_value=float(hi), value=value,
                step=step, help=help_text, key=key, disabled=disabled))
        return float(st.number_input(
            label, value=float(current), help=help_text, key=key,
            disabled=disabled, format="%.6f"))

    if current is None or isinstance(current, str):
        text = st.text_input(label, value="" if current is None else str(current),
                             help=help_text, key=key, disabled=disabled)
        # Only collapse an empty box to None when the field actually accepts
        # None. A required str field with an empty default must stay "", or
        # validation rejects it.
        if text == "":
            return None if _accepts_none(meta.annotation) else ""
        return text

    # Lists and nested models are handled by dedicated editors.
    return current


def model_form(model: BaseModel, *, key_prefix: str = "",
               skip: Sequence[str] = (), columns: int = 2,
               disabled: bool = False,
               inactive: set[str] | None = None) -> dict[str, Any]:
    """Render every scalar field of ``model``; return ``{name: new_value}``.

    Fields whose ``applicability`` tag is in ``inactive`` are rendered
    disabled with an explanatory caption, so an ignored legacy field cannot be
    mistaken for an active parameter.
    """

    metas = model_field_meta(model)
    updates: dict[str, Any] = {}
    inactive = inactive or set()

    scalar_names = []
    for name in metas:
        if name in skip:
            continue
        value = getattr(model, name)
        if isinstance(value, (list, dict, BaseModel)):
            continue
        scalar_names.append(name)

    def _one(name: str) -> None:
        meta = metas[name]
        off = disabled or meta.applicability in inactive
        updates[name] = render_field(model, name, meta, key_prefix, off)
        if meta.applicability in inactive:
            st.caption(f"Inactive under the current mechanisms "
                       f"({meta.applicability.replace('_', ' ')}).")

    if columns > 1:
        cols = st.columns(columns)
        for i, name in enumerate(scalar_names):
            with cols[i % columns]:
                _one(name)
    else:
        for name in scalar_names:
            _one(name)
    return updates


def validation_badges(report) -> None:
    """Show error / warning / theory counts as coloured metrics."""

    from ...ui_common.view_models import severity_counts
    counts = severity_counts(report)
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Errors", counts.get("ERROR", 0))
    col2.metric("Warnings", counts.get("WARNING", 0))
    col3.metric("Theory notes", counts.get("THEORY", 0))
    col4.metric("Runnable", "yes" if report.can_run else "no")


def issue_table(report) -> None:
    """List validation issues grouped by severity."""

    if not report.issues:
        st.success("No validation issues.")
        return

    import pandas as pd
    rows = [{"severity": i.severity.name, "code": i.code,
             "message": i.message} for i in report.issues]
    frame = pd.DataFrame(rows)

    for severity, renderer in (("ERROR", st.error), ("WARNING", st.warning),
                               ("THEORY", st.info)):
        block = frame[frame["severity"] == severity]
        if not len(block):
            continue
        renderer(f"{len(block)} {severity.lower()} item(s)")
        st.dataframe(block[["code", "message"]], width="stretch",
                     hide_index=True)

"""Editors for the list-valued configuration sections (tasks, environment).

These need bespoke handling because they are lists of nested models with
identifiers, not flat scalar fields.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

from ...config.enums import (
    EffectCondition,
    EffectTarget,
    EffectType,
)
from ...config.models import (
    ScenarioConfig,
    TaskConfig,
    TaskEffectRule,
)
from ...config.serialization import scenario_from_dict, scenario_to_dict
from .forms import model_form

__all__ = ["task_editor", "environment_editor", "domain_editor",
           "task_overview_table", "effects_editor"]


def task_overview_table(scenario: ScenarioConfig) -> pd.DataFrame:
    """A compact read-only overview of the task library."""

    from ...analysis.misallocation import role_consistency_report
    consistency = {r["task_id"]: r["inconsistent"]
                   for r in role_consistency_report(scenario)}
    rows = []
    for task in scenario.tasks:
        rows.append({
            "enabled": task.enabled,
            "task_id": task.task_id,
            "name": task.name,
            "domain": task.domain,
            "role": task.role.value,
            "energy_cost": task.energy_cost,
            "base_success": task.base_success,
            "env_driver": task.success_env_driver or "",
            "predation_x": task.predation_multiplier,
            "effects": len(task.effects),
            "direct_benefit": task.has_direct_benefit(),
            "role_conflict": consistency.get(task.task_id, False),
        })
    return pd.DataFrame(rows)


def effects_editor(task: TaskConfig, key_prefix: str) -> list[TaskEffectRule]:
    """Edit the effect rules of one task."""

    st.caption(
        "Effect rules determine what a task actually does. The validator "
        "compares them against the declared role, so a task labelled "
        "'nonfunctional' that grants energy will be flagged.")

    effects: list[TaskEffectRule] = []
    n_current = len(task.effects)
    n_rules = st.number_input("Number of effect rules", min_value=0,
                              max_value=10, value=n_current, step=1,
                              key=f"{key_prefix}__n_effects")

    for i in range(int(n_rules)):
        base = task.effects[i] if i < n_current else TaskEffectRule(
            target=EffectTarget.ENERGY, effect_type=EffectType.ADDITIVE,
            base_value=1.0, condition=EffectCondition.ON_SUCCESS)
        with st.expander(f"Rule {i + 1}: {base.target.value} "
                         f"{base.effect_type.value} {base.base_value:g}",
                         expanded=False):
            cols = st.columns(4)
            with cols[0]:
                target = st.selectbox(
                    "Target", [e.value for e in EffectTarget],
                    index=[e.value for e in EffectTarget].index(base.target.value),
                    key=f"{key_prefix}__eff{i}_target")
            with cols[1]:
                etype = st.selectbox(
                    "Type", [e.value for e in EffectType],
                    index=[e.value for e in EffectType].index(base.effect_type.value),
                    key=f"{key_prefix}__eff{i}_type")
            with cols[2]:
                value = st.number_input(
                    "Value", value=float(base.base_value),
                    key=f"{key_prefix}__eff{i}_value", format="%.4f")
            with cols[3]:
                cond = st.selectbox(
                    "Condition", [e.value for e in EffectCondition],
                    index=[e.value for e in EffectCondition].index(base.condition.value),
                    key=f"{key_prefix}__eff{i}_cond")

            data = base.model_dump()
            data.update({"target": target, "effect_type": etype,
                         "base_value": value, "condition": cond})
            effects.append(TaskEffectRule(**data))
    return effects


def task_editor(scenario: ScenarioConfig) -> ScenarioConfig:
    """Full task library editor. Returns a possibly-updated scenario."""

    st.subheader("Task library")
    st.dataframe(task_overview_table(scenario), width="stretch",
                 hide_index=True)

    conflicts = task_overview_table(scenario)
    if conflicts["role_conflict"].any():
        st.warning(
            "One or more tasks declare a role that disagrees with their effect "
            "rules. A task with no direct benefit should be labelled neutral or "
            "nonfunctional, and vice versa.")

    task_ids = [t.task_id for t in scenario.tasks]
    if not task_ids:
        st.info("No tasks defined.")
        return scenario

    chosen = st.selectbox("Edit task", task_ids, key="task_editor__chosen")
    index = task_ids.index(chosen)
    task = scenario.tasks[index]

    updates = model_form(task, key_prefix=f"task_{chosen}",
                         skip=("task_id",), columns=3)
    effects = effects_editor(task, key_prefix=f"task_{chosen}")

    data = scenario_to_dict(scenario)
    task_data = data["tasks"][index]
    for name, value in updates.items():
        task_data[name] = (value.value if hasattr(value, "value") else value)
    task_data["effects"] = [e.model_dump(mode="json") for e in effects]
    return scenario_from_dict(data)


def domain_editor(scenario: ScenarioConfig) -> ScenarioConfig:
    st.subheader("Motivational domains")
    rows = [{"domain_id": d.domain_id, "name": d.name,
             "init_mean": d.init_mean, "init_var": d.init_var,
             "tasks": sum(1 for t in scenario.tasks if t.domain == d.domain_id)}
            for d in scenario.domains]
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)
    st.caption(
        "Each agent inherits one propensity per domain plus one per task "
        "within its domain, giving the hierarchical structure described in the "
        "model reference.")
    return scenario


def environment_editor(scenario: ScenarioConfig) -> ScenarioConfig:
    """Editor for environmental variables, with a live preview."""

    st.subheader("Environmental variables")
    var_ids = [v.var_id for v in scenario.environment]
    if not var_ids:
        st.info("No environmental variables defined.")
        return scenario

    rows = [{"var_id": v.var_id, "name": v.name, "process": v.process.value,
             "mean": v.mean, "volatility": v.volatility,
             "persistence": v.persistence,
             "shock_prob": v.shock_probability,
             "obs_noise": v.observation_noise}
            for v in scenario.environment]
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)

    chosen = st.selectbox("Edit variable", var_ids, key="env_editor__chosen")
    index = var_ids.index(chosen)
    variable = scenario.environment[index]

    updates = model_form(variable, key_prefix=f"env_{chosen}",
                         skip=("var_id",), columns=3)

    data = scenario_to_dict(scenario)
    for name, value in updates.items():
        data["environment"][index][name] = (
            value.value if hasattr(value, "value") else value)
    return scenario_from_dict(data)

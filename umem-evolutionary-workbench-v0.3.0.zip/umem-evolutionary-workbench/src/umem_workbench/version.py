"""Version and schema-version constants for the UMEM Evolutionary Simulation Workbench.

``__version__`` tracks the application release. ``SCHEMA_VERSION`` tracks the
configuration-file schema and is stored inside every scenario so that older
files can be detected and migrated (see :mod:`umem_workbench.config.migrations`).
"""

from __future__ import annotations

#: Human-facing application version (semantic versioning).
__version__: str = "0.3.0"

#: Configuration-schema version. Bump this whenever the on-disk scenario schema
#: changes in a way that requires a migration step.
SCHEMA_VERSION: int = 2

__all__ = ["__version__", "SCHEMA_VERSION"]

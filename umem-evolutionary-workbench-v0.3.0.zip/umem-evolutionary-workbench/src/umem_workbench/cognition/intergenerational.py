"""Internal cognition A: intergenerational experience.

Agents are nudged toward the task distribution of *successful* agents from the
previous one or two cohorts. Crucially, memory-eligible neutral or nonfunctional
tasks can enter this memory if they co-occurred with successful agents, which is
the primary route by which cognition can *misallocate* effort. The memory never
observes the true environment or the true objective contribution of a task.
"""

from __future__ import annotations

import numpy as np

from ..config.enums import SuccessDefinition
from ..config.models import ScenarioConfig
from ..engine.compiled import CompiledScenario


class IntergenerationalMemory:
    """Two-cohort success-distribution memory over tasks."""

    def __init__(self, cs: CompiledScenario):
        T = cs.n_tasks
        uniform = np.ones(T) / max(1, T)
        self.prev1 = uniform.copy()
        self.prev2 = uniform.copy()
        self.memory_eligible = cs.memory_eligible.copy()
        self.last_memory = np.zeros(T)

    def modulation(self, scenario: ScenarioConfig,
                   rng: np.random.Generator) -> np.ndarray:
        """Per-task additive logit shift from experience (length T)."""

        cog = scenario.cognition
        if not cog.experience_enabled:
            self.last_memory = np.zeros_like(self.prev1)
            return self.last_memory
        w = cog.experience_weight_recent
        base = w * self.prev1 + (1.0 - w) * self.prev2
        if cog.experience_noise_sd > 0:
            base = base + rng.normal(0.0, cog.experience_noise_sd, size=base.shape)
        base = np.clip(base, 0.0, None)
        base = base * self.memory_eligible  # only eligible tasks enter memory
        s = base.sum()
        if s > 0:
            base = base / s
        self.last_memory = base
        return cog.experience_strength * base

    def update_from_cohort(self, scenario: ScenarioConfig, cs: CompiledScenario,
                           action_counts: np.ndarray, success_counts: np.ndarray,
                           successful_mask: np.ndarray) -> None:
        """Fold the just-finished cohort's success distribution into memory.

        ``action_counts`` / ``success_counts`` are ``(n_agents, T)`` seasonal
        tallies; ``successful_mask`` selects the agents that count as successful
        under the configured definition.
        """

        cog = scenario.cognition
        if not cog.experience_enabled:
            return
        if not successful_mask.any():
            dist = np.ones(cs.n_tasks) / max(1, cs.n_tasks)
        else:
            # Distribution over the actions taken by successful agents.
            tally = action_counts[successful_mask].sum(axis=0).astype(float)
            tally = tally * cs.memory_eligible
            tally = tally + cog.experience_smoothing
            dist = tally / tally.sum()
        self.prev2 = self.prev1
        self.prev1 = dist


def successful_agents(scenario: ScenarioConfig, lifetime_offspring_delta: np.ndarray,
                      survived: np.ndarray) -> np.ndarray:
    """Boolean mask of successful agents for the just-finished cohort."""

    definition = scenario.cognition.experience_success_definition
    if definition == SuccessDefinition.SURVIVED:
        return survived
    if definition in (SuccessDefinition.REPRODUCED,
                      SuccessDefinition.SURVIVING_OFFSPRING):
        return lifetime_offspring_delta > 0
    # TOP_QUANTILE_LRS
    if lifetime_offspring_delta.max(initial=0) <= 0:
        return np.zeros_like(survived)
    q = 1.0 - scenario.cognition.experience_top_quantile
    thresh = np.quantile(lifetime_offspring_delta, q)
    return lifetime_offspring_delta >= max(thresh, 1)


__all__ = ["IntergenerationalMemory", "successful_agents"]

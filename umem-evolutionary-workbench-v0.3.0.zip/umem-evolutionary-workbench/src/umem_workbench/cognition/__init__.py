"""Internal cognition modules (A: experience, B: forecasting, C: learning).

Homeostasis is a non-conscious physiological modulation layer and lives in
``engine.choice`` rather than here, matching the Master Prompt's stipulation that
homeostasis is *not* cognition.
"""

from __future__ import annotations

from . import forecasting, individual_learning, intergenerational

__all__ = ["intergenerational", "forecasting", "individual_learning"]

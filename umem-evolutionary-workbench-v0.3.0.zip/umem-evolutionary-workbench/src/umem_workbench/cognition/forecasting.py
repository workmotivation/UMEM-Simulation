"""Internal cognition B: noisy environmental forecasting.

A population-level exponentially-weighted forecast is maintained per environment
variable from noisy observations only::

    forecast[t+1] = memory * forecast[t] + (1 - memory) * observed[t]

The forecast uses only information available before the decision it informs (no
look-ahead). The resulting per-task logit shift favours tasks whose success
improves when their linked driver is forecast to be high. Using a shared
population forecast (rather than per-agent) is a documented simplification that
keeps the module transparent and cheap.
"""

from __future__ import annotations

import numpy as np

from ..config.models import ScenarioConfig
from ..engine.compiled import CompiledScenario


class EnvironmentForecast:
    """Population-level EWMA forecast for each environment variable."""

    def __init__(self, cs: CompiledScenario, scenario: ScenarioConfig):
        self.env_ids = cs.env_ids
        self.means = np.array([e.mean for e in scenario.environment]) \
            if scenario.environment else np.zeros(0)
        # Initialise forecast at each variable's initial value.
        self.forecast = np.array([e.initial_value for e in scenario.environment]) \
            if scenario.environment else np.zeros(0)
        self.last_forecast_error = np.zeros(len(self.env_ids))

    def update(self, observed: dict[str, float], scenario: ScenarioConfig,
               true_values: dict[str, float]) -> None:
        """Update the forecast from a noisy observation (call once per step)."""

        if not scenario.cognition.forecast_enabled or self.forecast.size == 0:
            return
        lam = scenario.cognition.forecast_memory
        for i, vid in enumerate(self.env_ids):
            obs = observed[vid]
            self.forecast[i] = lam * self.forecast[i] + (1.0 - lam) * obs
            self.last_forecast_error[i] = self.forecast[i] - true_values[vid]

    def modulation(self, cs: CompiledScenario,
                   scenario: ScenarioConfig) -> np.ndarray:
        """Per-task additive logit shift from the current forecast (length T)."""

        T = cs.n_tasks
        if not scenario.cognition.forecast_enabled or self.forecast.size == 0:
            return np.zeros(T)
        strength = scenario.cognition.forecast_strength
        surprise = self.forecast - self.means  # deviation from long-run mean
        mod = np.zeros(T)
        for k in range(T):
            ei = int(cs.success_env_idx[k])
            if ei >= 0:
                mod[k] = strength * cs.success_env_sens[k] * surprise[ei]
        return mod


__all__ = ["EnvironmentForecast"]

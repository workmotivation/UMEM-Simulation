"""Optional internal cognition C: individual reinforcement learning.

A transparent exponentially-weighted update on each agent's own experienced task
outcomes. No neural network or opaque RL library is used. Disabled by default in
the principal presets. The learned preference (stored on the agent pool as
``indiv_pref``) is added to the choice logits, scaled by
``individual_learning_strength``.
"""

from __future__ import annotations

import numpy as np

from ..config.models import ScenarioConfig
from ..engine.state import AgentPool


def update_individual_preferences(pool: AgentPool, scenario: ScenarioConfig,
                                  chosen: np.ndarray, success: np.ndarray) -> None:
    """EWMA update of per-agent task preference from own outcomes.

    Reward is centred: success -> +0.5, failure -> -0.5, so the baseline drift is
    zero and only differential outcomes move the preference.
    """

    cog = scenario.cognition
    if not cog.individual_learning_enabled:
        return
    lr = cog.individual_learning_rate
    acted = chosen >= 0
    if not acted.any():
        return
    rows = np.where(acted)[0]
    cols = chosen[acted]
    reward = np.where(success[acted], 0.5, -0.5)
    current = pool.indiv_pref[rows, cols]
    pool.indiv_pref[rows, cols] = (1.0 - lr) * current + lr * reward


__all__ = ["update_individual_preferences"]

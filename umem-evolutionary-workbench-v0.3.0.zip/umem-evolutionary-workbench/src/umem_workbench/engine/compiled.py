"""Precomputed, array-friendly view of a scenario for the hot simulation loop.

Turning the validated :class:`ScenarioConfig` into flat NumPy arrays once, up
front, keeps the per-step engine vectorised and free of per-task Python branching.
Nothing here changes scientific behaviour; it is purely a performance/clarity
representation.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..config.enums import (
    EffectCondition,
    EffectTarget,
    EffectType,
    SexRestriction,
    TaskRole,
)
from ..config.models import ScenarioConfig

_ROLE_CODE = {TaskRole.FUNCTIONAL: 0, TaskRole.LOW_COST_NEUTRAL: 1,
              TaskRole.COSTLY_NONFUNCTIONAL: 2}
_SEX_CODE = {SexRestriction.ANY: -1, SexRestriction.TYPE_A: 0,
             SexRestriction.TYPE_B: 1}
_COND_CODE = {EffectCondition.ALWAYS: 0, EffectCondition.ON_SUCCESS: 1,
              EffectCondition.ON_FAILURE: 2}
_TARGET_CODE = {t: i for i, t in enumerate(EffectTarget)}
_TYPE_CODE = {t: i for i, t in enumerate(EffectType)}

# Reverse maps used by the engine.
TARGET_ENERGY = _TARGET_CODE[EffectTarget.ENERGY]
TARGET_HEALTH = _TARGET_CODE[EffectTarget.HEALTH]
TARGET_REPRO = _TARGET_CODE[EffectTarget.REPRO_CAPITAL]
TARGET_STATUS = _TARGET_CODE[EffectTarget.STATUS]
TARGET_HAZARD = _TARGET_CODE[EffectTarget.HAZARD]
TARGET_OBS = _TARGET_CODE[EffectTarget.OBSERVATION_QUALITY]

TYPE_ADDITIVE = _TYPE_CODE[EffectType.ADDITIVE]
TYPE_MULT = _TYPE_CODE[EffectType.MULTIPLICATIVE]
TYPE_PROB = _TYPE_CODE[EffectType.PROBABILITY_MODIFIER]
TYPE_REPLACE = _TYPE_CODE[EffectType.BOUNDED_REPLACEMENT]


def _logit(p: float) -> float:
    p = min(max(p, 1e-4), 1.0 - 1e-4)
    return float(np.log(p / (1.0 - p)))


@dataclass
class CompiledScenario:
    scenario: ScenarioConfig
    env_ids: list[str]
    env_index: dict[str, int]

    # Per-task arrays (length T = number of tasks, incl. disabled).
    task_ids: list[str]
    energy_cost: np.ndarray
    time_cost: np.ndarray
    base_success_logit: np.ndarray
    outcome_noise: np.ndarray
    success_env_idx: np.ndarray
    success_env_sens: np.ndarray
    predation_mult: np.ndarray
    min_age_steps: np.ndarray
    max_age_steps: np.ndarray
    require_mature: np.ndarray
    sex_restriction: np.ndarray
    enabled: np.ndarray
    role: np.ndarray
    memory_eligible: np.ndarray
    task_domain: np.ndarray
    ch_food: np.ndarray
    ch_safety: np.ndarray
    ch_repro: np.ndarray

    # Flat effect-rule arrays (length R).
    eff_task_idx: np.ndarray
    eff_target: np.ndarray
    eff_type: np.ndarray
    eff_base: np.ndarray
    eff_condition: np.ndarray
    eff_env_idx: np.ndarray
    eff_env_sens: np.ndarray
    eff_noise: np.ndarray
    eff_min_age: np.ndarray
    eff_require_mature: np.ndarray
    eff_sex: np.ndarray

    predation_env_idx: int
    mate_env_idx: int

    @property
    def n_tasks(self) -> int:
        return len(self.task_ids)


def compile_scenario(scenario: ScenarioConfig) -> CompiledScenario:
    env_ids = [e.var_id for e in scenario.environment]
    env_index = {v: i for i, v in enumerate(env_ids)}

    def env_i(name):
        return env_index.get(name, -1) if name else -1

    tasks = scenario.tasks
    T = len(tasks)
    energy_cost = np.array([t.energy_cost for t in tasks])
    time_cost = np.array([t.time_cost for t in tasks])
    base_success_logit = np.array([_logit(t.base_success) for t in tasks])
    outcome_noise = np.array([t.outcome_noise for t in tasks])
    success_env_idx = np.array([env_i(t.success_env_driver) for t in tasks],
                               dtype=np.int64)
    success_env_sens = np.array([t.success_env_sensitivity for t in tasks])
    predation_mult = np.array([t.predation_multiplier for t in tasks])
    min_age_steps = np.array([t.min_age_steps for t in tasks], dtype=np.int64)
    max_age_steps = np.array(
        [t.max_age_steps if t.max_age_steps is not None else -1 for t in tasks],
        dtype=np.int64)
    require_mature = np.array([t.require_mature for t in tasks], dtype=bool)
    sex_restriction = np.array([_SEX_CODE[t.sex_restriction] for t in tasks],
                               dtype=np.int64)
    enabled = np.array([t.enabled for t in tasks], dtype=bool)
    role = np.array([_ROLE_CODE[t.role] for t in tasks], dtype=np.int64)
    memory_eligible = np.array([t.memory_eligible for t in tasks], dtype=bool)
    domain_index = {d.domain_id: i for i, d in enumerate(scenario.domains)}
    task_domain = np.array([domain_index[t.domain] for t in tasks], dtype=np.int64)

    # Homeostatic channels derived from effects (robust to custom domain names).
    ch_food = np.zeros(T, dtype=bool)
    ch_safety = np.zeros(T, dtype=bool)
    ch_repro = np.zeros(T, dtype=bool)
    for i, t in enumerate(tasks):
        if t.predation_multiplier < 1.0:
            ch_safety[i] = True
        for r in t.effects:
            if r.target == EffectTarget.ENERGY and r.base_value > 0:
                ch_food[i] = True
            if r.target == EffectTarget.REPRO_CAPITAL and r.base_value > 0:
                ch_repro[i] = True

    # Flatten effect rules.
    eff_task_idx, eff_target, eff_type, eff_base = [], [], [], []
    eff_condition, eff_env_idx, eff_env_sens, eff_noise = [], [], [], []
    eff_min_age, eff_require_mature, eff_sex = [], [], []
    for i, t in enumerate(tasks):
        for r in t.effects:
            eff_task_idx.append(i)
            eff_target.append(_TARGET_CODE[r.target])
            eff_type.append(_TYPE_CODE[r.effect_type])
            eff_base.append(r.base_value)
            eff_condition.append(_COND_CODE[r.condition])
            eff_env_idx.append(env_i(r.env_driver))
            eff_env_sens.append(r.env_sensitivity)
            eff_noise.append(r.noise_std)
            eff_min_age.append(r.min_age_steps)
            eff_require_mature.append(r.require_mature)
            eff_sex.append(_SEX_CODE[r.sex_restriction])

    def to_arr(x, dt=np.float64):
        return np.array(x, dtype=dt) if x else np.empty(0, dt)

    return CompiledScenario(
        scenario=scenario, env_ids=env_ids, env_index=env_index,
        task_ids=[t.task_id for t in tasks],
        energy_cost=energy_cost, time_cost=time_cost,
        base_success_logit=base_success_logit, outcome_noise=outcome_noise,
        success_env_idx=success_env_idx, success_env_sens=success_env_sens,
        predation_mult=predation_mult, min_age_steps=min_age_steps,
        max_age_steps=max_age_steps, require_mature=require_mature,
        sex_restriction=sex_restriction, enabled=enabled, role=role,
        memory_eligible=memory_eligible, task_domain=task_domain,
        ch_food=ch_food, ch_safety=ch_safety, ch_repro=ch_repro,
        eff_task_idx=to_arr(eff_task_idx, np.int64),
        eff_target=to_arr(eff_target, np.int64),
        eff_type=to_arr(eff_type, np.int64),
        eff_base=to_arr(eff_base),
        eff_condition=to_arr(eff_condition, np.int64),
        eff_env_idx=to_arr(eff_env_idx, np.int64),
        eff_env_sens=to_arr(eff_env_sens),
        eff_noise=to_arr(eff_noise),
        eff_min_age=to_arr(eff_min_age, np.int64),
        eff_require_mature=to_arr(eff_require_mature, bool),
        eff_sex=to_arr(eff_sex, np.int64),
        predation_env_idx=env_i(scenario.mortality.predation_env_driver),
        mate_env_idx=env_i(scenario.reproduction.mate_availability_driver),
    )


__all__ = [
    "CompiledScenario", "compile_scenario",
    "TARGET_ENERGY", "TARGET_HEALTH", "TARGET_REPRO", "TARGET_STATUS",
    "TARGET_HAZARD", "TARGET_OBS",
    "TYPE_ADDITIVE", "TYPE_MULT", "TYPE_PROB", "TYPE_REPLACE",
]

"""Run result container and the aggregating time-series recorder.

The recorder keeps memory bounded by storing aggregated snapshots at a
configurable interval (plus per-interval birth/death tallies), rather than full
agent state every step. An optional reproducible agent sample can be stored for
distributional views.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from .compiled import CompiledScenario
from .events import DEATH_CAUSE_LABELS, DeathCause
from .state import AgentPool, DeadLog


@dataclass
class RunResult:
    run_id: str
    config_hash: str
    scenario_dict: dict[str, Any]
    app_version: str
    schema_version: int
    master_seed: int
    replication_index: int
    seed_metadata: dict[str, list[int]]
    start_time: str
    end_time: str
    cancelled: bool
    warnings: list[str]
    env_trajectories: dict[str, np.ndarray]
    time_series: pd.DataFrame
    breeding_series: pd.DataFrame
    dead_log_df: pd.DataFrame
    agent_samples: pd.DataFrame
    extinct: bool
    final_population: int
    summary: dict[str, Any] = field(default_factory=dict)


class Recorder:
    """Accumulates aggregated snapshots and per-interval tallies."""

    def __init__(self, cs: CompiledScenario, scenario, store_sample: bool,
                 sample_size: int):
        self.cs = cs
        self.scenario = scenario
        self.store_sample = store_sample
        self.sample_size = sample_size
        self.rows: list[dict[str, Any]] = []
        self.breeding_rows: list[dict[str, Any]] = []
        self.sample_rows: list[dict[str, Any]] = []
        # Per-interval accumulators.
        self._births = 0
        self._deaths_by_cause = np.zeros(len(DeathCause), dtype=np.int64)

    def note_births(self, n: int) -> None:
        self._births += int(n)

    def note_deaths(self, cause_array: np.ndarray, dead_mask: np.ndarray) -> None:
        if dead_mask.any():
            causes = cause_array[dead_mask]
            for c in causes:
                self._deaths_by_cause[int(c)] += 1

    def _reset_interval(self) -> None:
        self._births = 0
        self._deaths_by_cause[:] = 0

    def record_snapshot(self, step: int, season: int, pool: AgentPool,
                        probs: np.ndarray, chosen: np.ndarray, env_now: np.ndarray,
                        obs: dict[str, float], forecast, memory: np.ndarray,
                        energy_cost_now: np.ndarray, rng_sample: np.random.Generator
                        ) -> None:
        cs = self.cs
        sc = self.scenario
        n = pool.n
        row: dict[str, Any] = {"step": step, "season": season, "population": n}

        row["births_interval"] = self._births
        row["deaths_interval"] = int(self._deaths_by_cause.sum())
        for cause in DeathCause:
            if cause == DeathCause.ALIVE:
                continue
            row[f"deaths_{DEATH_CAUSE_LABELS[cause]}"] = int(self._deaths_by_cause[int(cause)])

        if n > 0:
            row["mean_energy"] = float(pool.energy.mean())
            row["median_energy"] = float(np.median(pool.energy))
            row["mean_health"] = float(pool.health.mean())
            row["median_health"] = float(np.median(pool.health))
            row["mean_repro_capital"] = float(pool.repro_capital.mean())
            row["mean_status"] = float(pool.status.mean())
            row["mean_age_steps"] = float(pool.age_steps.mean())
            row["frac_mature"] = float(pool.reached_maturity.mean())
            row["n_lineages"] = int(np.unique(pool.lineage_id).size)
            # Inherited propensities (means and variances).
            for di, d in enumerate(sc.domains):
                row[f"domprop_{d.domain_id}"] = float(pool.domain_prop[:, di].mean())
                row[f"domvar_{d.domain_id}"] = float(pool.domain_prop[:, di].var())
            for ti, t in enumerate(sc.tasks):
                row[f"taskprop_{t.task_id}"] = float(pool.task_prop[:, ti].mean())
        else:
            # Extinct snapshot: fill NaNs for aggregate fields.
            for key in ("mean_energy", "median_energy", "mean_health", "median_health",
                        "mean_repro_capital", "mean_status", "mean_age_steps",
                        "frac_mature"):
                row[key] = np.nan
            row["n_lineages"] = 0
            for d in sc.domains:
                row[f"domprop_{d.domain_id}"] = np.nan
                row[f"domvar_{d.domain_id}"] = np.nan
            for t in sc.tasks:
                row[f"taskprop_{t.task_id}"] = np.nan

        # Effective preference, frequency, allocation (instantaneous).
        acted = chosen >= 0
        n_acted = int(acted.sum())
        freq = np.zeros(cs.n_tasks)
        eff = np.zeros(cs.n_tasks)
        if n > 0 and probs.size:
            eff = probs.mean(axis=0)
        if n_acted > 0:
            counts = np.bincount(chosen[acted], minlength=cs.n_tasks).astype(float)
            freq = counts / n_acted
        time_weights = freq * cs.time_cost
        energy_weights = freq * cs.energy_cost
        t_share = time_weights / time_weights.sum() if time_weights.sum() > 0 else time_weights
        e_share = energy_weights / energy_weights.sum() if energy_weights.sum() > 0 else energy_weights
        for ti, t in enumerate(sc.tasks):
            row[f"effpref_{t.task_id}"] = float(eff[ti])
            row[f"freq_{t.task_id}"] = float(freq[ti])
            row[f"timealloc_{t.task_id}"] = float(t_share[ti])
            row[f"energyalloc_{t.task_id}"] = float(e_share[ti])

        # Nonfunctional / neutral misallocation (roles: 1 neutral, 2 costly nonfunc).
        costly = cs.role == 2
        neutral = cs.role == 1
        row["nonfunc_action_rate"] = float(freq[costly].sum())
        row["neutral_action_rate"] = float(freq[neutral].sum())
        row["nonfunc_time_share"] = float(t_share[costly].sum())
        row["nonfunc_energy_share"] = float(e_share[costly].sum())

        # Environment, observation, forecast, forecast error, experience memory.
        for ei, vid in enumerate(cs.env_ids):
            row[f"env_{vid}"] = float(env_now[ei])
            row[f"obs_{vid}"] = float(obs.get(vid, env_now[ei]))
            if forecast is not None and forecast.forecast.size:
                row[f"forecast_{vid}"] = float(forecast.forecast[ei])
                row[f"forecast_err_{vid}"] = float(forecast.last_forecast_error[ei])
        for ti, t in enumerate(sc.tasks):
            if cs.memory_eligible[ti]:
                row[f"exp_{t.task_id}"] = float(memory[ti]) if memory.size else 0.0

        self.rows.append(row)

        # Optional reproducible agent sample.
        if self.store_sample and n > 0:
            m = min(self.sample_size, n)
            idx = rng_sample.choice(n, size=m, replace=False)
            for j in idx:
                srow = {"step": step, "season": season,
                        "agent_id": int(pool.agent_id[j]),
                        "lineage_id": int(pool.lineage_id[j]),
                        "sex": int(pool.sex[j]),
                        "age_steps": int(pool.age_steps[j]),
                        "energy": float(pool.energy[j]),
                        "health": float(pool.health[j]),
                        "repro_capital": float(pool.repro_capital[j]),
                        "lifetime_offspring": int(pool.lifetime_offspring[j])}
                for di, d in enumerate(sc.domains):
                    srow[f"domprop_{d.domain_id}"] = float(pool.domain_prop[j, di])
                self.sample_rows.append(srow)

        self._reset_interval()

    def record_breeding(self, season: int, outcome) -> None:
        self.breeding_rows.append({
            "season": season,
            "n_eligible": outcome.n_eligible,
            "n_pairs": outcome.n_pairs,
            "n_events_with_offspring": outcome.n_events_with_offspring,
            "n_offspring_pre_survival": outcome.n_offspring_pre_survival,
            "n_offspring_survived": outcome.n_offspring_survived,
        })

    def record_distributed(self, step: int, season: int, selection,
                           outcome) -> None:
        """Record one step of distributed reproduction (ADR-003).

        One row per step rather than per season, so that the distribution of
        births across the season is visible in the exports and the season-linked
        artifact can be checked directly rather than inferred.
        """

        self.breeding_rows.append({
            "step": step,
            "season": season,
            "n_eligible": selection.n_eligible,
            "n_attempts": selection.n_attempts,
            "n_pairs": selection.n_events,
            "n_failed_no_partner": selection.n_failed_no_partner,
            "n_events_with_offspring": (
                outcome.n_events_with_offspring if outcome else 0),
            "n_offspring_pre_survival": (
                outcome.n_offspring_pre_survival if outcome else 0),
            "n_offspring_survived": (
                outcome.n_offspring_survived if outcome else 0),
            "n_active_bonds": selection.n_active_bonds,
            "n_bonds_formed_step": selection.n_bonds_formed_step,
            "n_bonds_dissolved_step": selection.n_bonds_dissolved_step,
            "n_bonds_dissolved_by_death_step":
                selection.n_bonds_dissolved_by_death_step,
            "n_bonds_dissolved_stochastic_step":
                selection.n_bonds_dissolved_stochastic_step,
            "cumulative_bonds_formed": selection.cumulative_bonds_formed,
            "cumulative_bonds_dissolved": selection.cumulative_bonds_dissolved,
            "n_mutation_events": (
                outcome.offspring.n_mutation_events
                if outcome is not None and outcome.offspring is not None else 0),
        })

    def finalize(self, dead_log: DeadLog) -> tuple[pd.DataFrame, pd.DataFrame,
                                                    pd.DataFrame, pd.DataFrame]:
        ts = pd.DataFrame(self.rows)
        breeding = pd.DataFrame(self.breeding_rows)
        dead_df = pd.DataFrame({
            "age_steps": dead_log.age_steps,
            "born_season": dead_log.born_season,
            "death_season": dead_log.death_season,
            "cause": [DEATH_CAUSE_LABELS[DeathCause(c)] for c in dead_log.cause],
            "lifetime_offspring": dead_log.lifetime_offspring,
            "sex": dead_log.sex,
            "lineage_id": dead_log.lineage_id,
            "reached_maturity": dead_log.reached_maturity,
        })
        sample_df = pd.DataFrame(self.sample_rows)
        return ts, breeding, dead_df, sample_df


__all__ = ["RunResult", "Recorder"]

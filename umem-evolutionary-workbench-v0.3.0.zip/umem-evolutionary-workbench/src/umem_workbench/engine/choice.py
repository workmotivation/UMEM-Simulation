"""Homeostatic urgencies, task eligibility, and probabilistic action choice.

The choice policy is additive in logit space (Master Prompt section 8.4)::

    logit[i,k] = log(domain_prop + eps) + log(task_prop + eps)
               + homeostatic_modulation
               + intergenerational_experience_modulation
               + individual_learning_modulation
               + environmental_forecast_modulation
               + decision_noise

Logits of ineligible tasks are set to ``-inf`` and converted with a numerically
stable, temperature-controlled softmax. Homeostasis is a non-conscious modulation
layer and can act even when every cognitive module is off.
"""

from __future__ import annotations

import numpy as np

from ..config.models import ScenarioConfig
from .compiled import CompiledScenario
from .state import AgentPool

_EPS = 1e-6


def homeostatic_urgencies(pool: AgentPool, scenario: ScenarioConfig,
                          perceived_threat: float) -> tuple[np.ndarray, np.ndarray,
                                                            np.ndarray]:
    """Return (food, safety, reproduction) urgencies per living agent in [0,1]."""

    lc = scenario.lifecycle
    n = pool.n
    hc = scenario.homeostasis
    if not hc.enabled:
        z = np.zeros(n)
        return z, z.copy(), z.copy()

    food = np.clip(1.0 - pool.energy / max(lc.energy_max, _EPS), 0.0, 1.0) \
        if hc.hunger_enabled else np.zeros(n)

    if hc.safety_enabled:
        low_health = np.clip(1.0 - pool.health / max(lc.health_max, _EPS), 0.0, 1.0)
        safety = np.clip(0.5 * low_health + 0.5 * perceived_threat, 0.0, 1.0)
    else:
        safety = np.zeros(n)

    if hc.reproduction_enabled:
        rc = scenario.reproduction
        e_gate = np.clip(pool.energy / max(rc.energy_threshold, _EPS), 0.0, 1.0)
        h_gate = np.clip(pool.health / max(rc.health_threshold, _EPS), 0.0, 1.0)
        repro = pool.reached_maturity.astype(float) * e_gate * h_gate
    else:
        repro = np.zeros(n)

    return food, safety, repro


def eligibility_mask(pool: AgentPool, cs: CompiledScenario) -> np.ndarray:
    """Boolean (n_agents, n_tasks) mask of which tasks each agent may perform."""

    n = pool.n
    T = cs.n_tasks
    age = pool.age_steps[:, None]           # (n,1)
    mature = pool.reached_maturity[:, None]  # (n,1)
    sex = pool.sex[:, None]                  # (n,1)

    mask = np.broadcast_to(cs.enabled, (n, T)).copy()
    mask &= age >= cs.min_age_steps[None, :]
    has_max = cs.max_age_steps[None, :] >= 0
    mask &= ~(has_max & (age > cs.max_age_steps[None, :]))
    mask &= ~(cs.require_mature[None, :] & ~mature)
    sex_ok = (cs.sex_restriction[None, :] == -1) | \
             (cs.sex_restriction[None, :] == sex)
    mask &= sex_ok
    return mask


def choice_logits(pool: AgentPool, cs: CompiledScenario, scenario: ScenarioConfig,
                  food_urg: np.ndarray, safety_urg: np.ndarray, repro_urg: np.ndarray,
                  experience_mod: np.ndarray, forecast_mod: np.ndarray,
                  rng: np.random.Generator) -> np.ndarray:
    """Assemble the (n_agents, n_tasks) choice logits (before eligibility mask)."""

    n = pool.n
    T = cs.n_tasks
    hc = scenario.homeostasis

    # Inherited baseline: log(domain) + log(task).
    dom_for_task = pool.domain_prop[:, cs.task_domain]        # (n,T)
    inherited = np.log(dom_for_task + _EPS) + np.log(pool.task_prop + _EPS)

    logits = inherited

    if hc.enabled:
        if hc.hunger_enabled:
            logits = logits + (hc.hunger_strength * food_urg)[:, None] * cs.ch_food[None, :]
        if hc.safety_enabled:
            logits = logits + (hc.safety_strength * safety_urg)[:, None] * cs.ch_safety[None, :]
        if hc.reproduction_enabled:
            logits = logits + (hc.reproduction_strength * repro_urg)[:, None] * cs.ch_repro[None, :]

    # Intergenerational experience & forecast are per-task (population-level) shifts.
    logits = logits + experience_mod[None, :] + forecast_mod[None, :]

    # Individual learning (per-agent).
    if scenario.cognition.individual_learning_enabled:
        logits = logits + scenario.cognition.individual_learning_strength * pool.indiv_pref

    # Decision noise.
    if scenario.choice.decision_noise_sd > 0:
        logits = logits + rng.normal(0.0, scenario.choice.decision_noise_sd, size=(n, T))

    return logits


def softmax_choice(logits: np.ndarray, mask: np.ndarray, temperature: float,
                   rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    """Return (chosen_task_index, probabilities).

    Ineligible tasks get zero probability. Agents with no eligible task get a
    sentinel index of -1 (the caller applies the resting fallback).
    """

    n, T = logits.shape
    masked = np.where(mask, logits / max(temperature, _EPS), -np.inf)
    # Numerically stable softmax across tasks.
    row_max = np.max(np.where(np.isfinite(masked), masked, -np.inf), axis=1,
                     keepdims=True)
    row_max = np.where(np.isfinite(row_max), row_max, 0.0)
    exp = np.exp(masked - row_max)
    exp[~np.isfinite(exp)] = 0.0
    denom = exp.sum(axis=1, keepdims=True)
    has_choice = denom[:, 0] > 0
    probs = np.zeros_like(exp)
    probs[has_choice] = exp[has_choice] / denom[has_choice]

    chosen = np.full(n, -1, dtype=np.int64)
    if has_choice.any():
        # Vectorised categorical sampling via inverse-CDF.
        cdf = np.cumsum(probs[has_choice], axis=1)
        u = rng.random(has_choice.sum())[:, None]
        idx = (u > cdf).sum(axis=1)
        idx = np.clip(idx, 0, T - 1)
        chosen[has_choice] = idx
    return chosen, probs


def task_success(pool: AgentPool, cs: CompiledScenario, chosen: np.ndarray,
                 env_now: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Stochastic success/failure of each agent's chosen task.

    ``p_success = sigmoid(base_logit + success_env_sensitivity * env_driver
                          + noise)``. Agents with no chosen task (index -1)
    return ``False``.
    """

    n = pool.n
    out = np.zeros(n, dtype=bool)
    valid = chosen >= 0
    if not valid.any():
        return out
    idx = chosen[valid]
    logit = cs.base_success_logit[idx].copy()
    env_i = cs.success_env_idx[idx]
    sens = cs.success_env_sens[idx]
    has_env = env_i >= 0
    if has_env.any():
        env_vals = env_now[np.where(has_env, env_i, 0)]
        logit = logit + np.where(has_env, sens * env_vals, 0.0)
    noise_sd = cs.outcome_noise[idx]
    logit = logit + rng.normal(0.0, 1.0, size=idx.shape[0]) * noise_sd
    p = 1.0 / (1.0 + np.exp(-logit))
    out[valid] = rng.random(idx.shape[0]) < p
    return out


__all__ = [
    "homeostatic_urgencies", "eligibility_mask", "choice_logits", "softmax_choice",
    "task_success",
]

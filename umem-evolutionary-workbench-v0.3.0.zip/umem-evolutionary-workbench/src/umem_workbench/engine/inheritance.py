"""Offspring propensity construction.

Two inheritance models are available, selected by ``inheritance.model``.

``polygenic_additive`` (default for new scenarios)
    Fisher's infinitesimal model on the centred latent scale of ADR-001.
    Sexual offspring take the mid-parent latent value plus an independent
    Gaussian segregation term; asexual offspring are clonal copies. Mutation is
    a separate, rare event. See docs/design/ADR-002.

``legacy`` (v0.1.0 behaviour, retained for old scenarios)
    Per-trait parental selection or blending on the positive scale, followed by
    multiplicative log-normal mutation. Preserved unchanged so that scenarios
    written before schema 2 keep their original scientific meaning.

Segregation and mutation are deliberately distinct. Segregation is the ordinary
reshuffling of existing variation and happens at every sexual reproductive
event; mutation is the rare introduction of novel variation. Conflating them --
as v0.1.0 did with a single ``mutation_log_sd`` -- makes it impossible to ask
what happens when new variation is unavailable.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..config.enums import InheritanceModel, MutationTarget
from ..config.models import InheritanceConfig
from .latent import LATENT_DTYPE, centre


# ---------------------------------------------------------------------------
# Legacy model (v0.1.0). Behaviour unchanged.
# ---------------------------------------------------------------------------
def recombine_and_mutate(pa: np.ndarray, pb: np.ndarray, cfg: InheritanceConfig,
                         rng: np.random.Generator) -> np.ndarray:
    """Combine two parental trait matrices ``(m, k)`` into offspring traits.

    Parameters
    ----------
    pa, pb : parent-A and parent-B trait arrays, both shape ``(m, k)`` where
        ``m`` is the number of offspring and ``k`` the number of traits.
    """

    m, k = pa.shape
    if cfg.recombination_per_trait:
        take_a = rng.random((m, k)) < 0.5
        child = np.where(take_a, pa, pb)
    else:
        a = cfg.blend_alpha
        child = a * pa + (1.0 - a) * pb

    # Multiplicative log-normal mutation on a per-trait Bernoulli mask.
    if cfg.mutation_log_sd > 0 and cfg.mutation_probability > 0:
        mutate = rng.random((m, k)) < cfg.mutation_probability
        factors = np.ones((m, k))
        n_mut = int(mutate.sum())
        if n_mut:
            factors[mutate] = rng.lognormal(0.0, cfg.mutation_log_sd, size=n_mut)
        child = child * factors

    return np.maximum(child, cfg.min_propensity)


# ---------------------------------------------------------------------------
# Polygenic additive model (ADR-002)
# ---------------------------------------------------------------------------
@dataclass
class MutationTally:
    """Counts of effective mutation events, reported per breeding record."""

    domain_events: int = 0
    task_events: int = 0

    @property
    def total(self) -> int:
        return self.domain_events + self.task_events


def segregation_sd(founder_variance: np.ndarray | float,
                   multiplier: float) -> np.ndarray:
    """Standard deviation of the segregation term.

    The Mendelian sampling variance of an offspring is ``0.5 * sigma_A^2`` in
    the absence of inbreeding (Lynch & Walsh 1998, ch. 7), so

        sigma^2_seg = s * V0 / 2

    where ``V0`` is the additive variance of the **configured** founder
    distribution -- not the realised founder sample, which would make
    inheritance depend on the master seed -- and ``s`` is the user-facing
    sibling-variation multiplier.

    This makes the model self-stabilising. Under neutrality the per-component
    variance of centred latent vectors obeys ``W' = W/2 + sigma^2 (k-1)/k``.
    Substituting the centred founder variance ``W0 = V0 (k-1)/k`` shows that
    ``sigma^2 = V0/2`` is exactly the fixed point, the centring factors
    cancelling. The configured founder variance is therefore the equilibrium:
    variance neither inflates nor decays as an artifact, so any observed
    departure from it is informative rather than a modelling side effect.
    """

    v0 = np.asarray(founder_variance, dtype=LATENT_DTYPE)
    return np.sqrt(np.maximum(v0, 0.0) * max(float(multiplier), 0.0) / 2.0)


def infinitesimal_offspring(ga: np.ndarray, gb: np.ndarray,
                            seg_sd: np.ndarray | float,
                            rng: np.random.Generator) -> np.ndarray:
    """Sexual offspring latent values: mid-parent plus segregation.

    ``g_child = (g_A + g_B) / 2 + eps_seg``, with ``eps_seg`` drawn
    independently for every offspring and every component, then re-centred.

    The formula is symmetric in its two parents, so relabelling which parent is
    A and which is B cannot change the offspring distribution. Independent draws
    per offspring mean full siblings differ even without mutation.

    Parameters
    ----------
    ga, gb : centred parental latent arrays, shape ``(m, k)``.
    seg_sd : segregation standard deviation, scalar or broadcastable to ``(k,)``.
    """

    ga = np.asarray(ga, dtype=LATENT_DTYPE)
    gb = np.asarray(gb, dtype=LATENT_DTYPE)
    mid = 0.5 * (ga + gb)

    sd = np.asarray(seg_sd, dtype=LATENT_DTYPE)
    if np.all(sd <= 0.0):
        return centre(mid)
    noise = rng.normal(0.0, 1.0, size=mid.shape) * sd
    return centre(mid + noise)


def clonal_offspring(gp: np.ndarray) -> np.ndarray:
    """Asexual offspring latent values: an exact copy of the parent.

    No mid-parent averaging and no segregation term. With mutation disabled the
    heritable component is a clone; expressed behaviour can still differ through
    environment, homeostasis, cognition and action-selection noise.
    """

    return centre(np.asarray(gp, dtype=LATENT_DTYPE))


def apply_mutation(g: np.ndarray, cfg: InheritanceConfig,
                   rng: np.random.Generator, *,
                   layer: str) -> tuple[np.ndarray, int]:
    """Apply rare, zero-mean, symmetric mutation to latent values.

    Each offspring independently experiences an effective mutation event with
    probability ``mutation_probability_per_offspring``. When it does, one
    uniformly chosen component receives an additive ``N(0, sigma^2)`` increment
    with ``sigma = mutation_effect_sd_latent`` in absolute latent units.

    Absolute units matter: were the effect defined as a fraction of the founder
    standard deviation, a scenario with ``init_distribution = equal`` (founder
    variance zero) would silently have no mutation at all.

    The effect is symmetric and zero-mean, so no motivational domain or task
    receives a built-in directional advantage.

    Parameters
    ----------
    g : centred latent array ``(m, k)``; not modified in place.
    layer : ``"domain"`` or ``"task"``, checked against ``mutation_target``.

    Returns
    -------
    (mutated latent array, number of mutation events)
    """

    g = np.asarray(g, dtype=LATENT_DTYPE)
    target = cfg.mutation_target
    if target != MutationTarget.BOTH and target.value != layer:
        return g, 0

    p = float(cfg.mutation_probability_per_offspring)
    sd = float(cfg.mutation_effect_sd_latent)
    if g.ndim != 2:
        raise ValueError("apply_mutation expects a 2-D (m, k) array")
    m, k = g.shape
    if p <= 0.0 or sd <= 0.0 or m == 0 or k == 0:
        return g, 0

    hit = rng.random(m) < p
    n_events = int(hit.sum())
    if n_events == 0:
        return g, 0

    out = g.copy()
    rows = np.where(hit)[0]
    cols = rng.integers(0, k, size=n_events)
    out[rows, cols] += rng.normal(0.0, sd, size=n_events)
    return centre(out), n_events


def build_offspring_latent(ga: np.ndarray, gb: np.ndarray | None,
                           cfg: InheritanceConfig,
                           founder_variance: np.ndarray | float,
                           rng: np.random.Generator, *,
                           layer: str,
                           tally: MutationTally | None = None) -> np.ndarray:
    """Full polygenic pipeline for one layer. ``gb is None`` selects asexual."""

    if gb is None:
        child = clonal_offspring(ga)
    else:
        sd = segregation_sd(founder_variance, cfg.segregation_multiplier)
        child = infinitesimal_offspring(ga, gb, sd, rng)

    child, n_events = apply_mutation(child, cfg, rng, layer=layer)
    if tally is not None:
        if layer == "domain":
            tally.domain_events += n_events
        else:
            tally.task_events += n_events
    return child


def uses_polygenic(cfg: InheritanceConfig) -> bool:
    """True when the polygenic additive model is selected."""

    return cfg.model == InheritanceModel.POLYGENIC_ADDITIVE


__all__ = [
    "recombine_and_mutate",
    "infinitesimal_offspring",
    "clonal_offspring",
    "apply_mutation",
    "build_offspring_latent",
    "segregation_sd",
    "uses_polygenic",
    "MutationTally",
]

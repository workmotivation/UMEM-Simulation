"""The core discrete-time, finite-life simulation loop.

Implements the operation order of Master Prompt section 14. Newborns are appended
at the end of the breeding step and therefore first act on the following step
(the documented "newborns act next step" rule). Gestation delay, when nonzero,
defers offspring materialisation via a pending-birth queue.
"""

from __future__ import annotations

import datetime as _dt
import uuid
from collections.abc import Callable

import numpy as np

from ..cognition.forecasting import EnvironmentForecast
from ..cognition.individual_learning import update_individual_preferences
from ..cognition.intergenerational import IntergenerationalMemory, successful_agents
from ..config.enums import ReproductionTiming
from ..config.models import ScenarioConfig
from ..config.serialization import config_hash, scenario_to_dict
from ..environment.observations import observe
from ..environment.processes import generate_environment
from ..tasks.effects import apply_effects
from ..version import SCHEMA_VERSION, __version__
from . import choice as choice_mod
from .compiled import compile_scenario
from .distributed_reproduction import PairBonds, distributed_breed
from .randomness import RandomStreams
from .reproduction import breed, produce_offspring
from .results import Recorder, RunResult
from .state import AgentPool

CancelFn = Callable[[], bool] | None
ProgressFn = Callable[[dict], None] | None


def run_simulation(scenario: ScenarioConfig, replication_index: int = 0,
                   streams: RandomStreams | None = None,
                   cancel: CancelFn = None, progress: ProgressFn = None,
                   warnings: list[str] | None = None) -> RunResult:
    """Run one full trajectory and return a :class:`RunResult`."""

    warnings = list(warnings or [])
    start_time = _dt.datetime.now().isoformat(timespec="seconds")
    if streams is None:
        streams = RandomStreams.create(scenario.master_seed, replication_index)

    cs = compile_scenario(scenario)
    lc = scenario.lifecycle
    total_steps = lc.steps_per_season * lc.total_seasons
    n_env = len(cs.env_ids)

    # 1. Pre-generate the whole environment (dedicated stream).
    env_stream = streams.stream("environment")
    trajectories = generate_environment(scenario.environment, total_steps, env_stream)
    env_matrix = (np.stack([trajectories[v] for v in cs.env_ids], axis=1)
                  if n_env else np.zeros((total_steps, 0)))

    # Initialise population.
    pool = AgentPool(scenario)
    pool.initialise(streams.stream("initial_population"))

    forecast = EnvironmentForecast(cs, scenario)
    memory = IntergenerationalMemory(cs)
    recorder = Recorder(cs, scenario, scenario.output.store_agent_sample,
                        scenario.output.agent_sample_size)

    # Per-cohort (per-season) tallies aligned to pool slots.
    action_counts = np.zeros((pool.n, cs.n_tasks))
    success_counts = np.zeros((pool.n, cs.n_tasks))
    pending_births: list[tuple[int, object]] = []  # (due_step, OffspringSpec)
    # Pair bonds persist across steps; keyed by agent id so that compaction of
    # the population arrays after deaths cannot corrupt them (ADR-005).
    bonds = PairBonds()
    distributed = (scenario.reproduction.timing
                   == ReproductionTiming.DISTRIBUTED)
    mutation_events_total = 0

    rng_choice = streams.stream("task_choice")
    rng_outcome = streams.stream("task_outcome")
    rng_mort = streams.stream("mortality")
    rng_mate = streams.stream("mate_choice")
    rng_fert = streams.stream("fertility")
    rng_inh = streams.stream("inheritance")
    rng_obs = streams.stream("observation")
    rng_cog = streams.stream("cognition")

    from .mortality import step_mortality  # local import avoids cycle at import time

    record_interval = scenario.output.record_interval_steps
    experience_mod = np.zeros(cs.n_tasks)
    cancelled = False
    extinct = False

    for t in range(total_steps):
        if cancel is not None and cancel():
            cancelled = True
            warnings.append(f"Run cancelled by user at step {t}.")
            break

        season = t // lc.steps_per_season
        step_in_season = t % lc.steps_per_season
        is_season_end = step_in_season == lc.steps_per_season - 1
        env_now = env_matrix[t] if n_env else np.zeros(0)

        # Flush any pending (gestation-delayed) births due now.
        if pending_births:
            still = []
            for due, spec in pending_births:
                if due <= t:
                    action_counts, success_counts = _append(
                        pool, spec, scenario, action_counts, success_counts, season)
                    recorder.note_births(spec.sex.shape[0])
                else:
                    still.append((due, spec))
            pending_births = still

        if pool.n == 0:
            extinct = True
            # Record a final extinct snapshot then stop.
            recorder.record_snapshot(
                t, season, pool, np.zeros((0, cs.n_tasks)),
                np.zeros(0, np.int64), env_now, {}, forecast,
                memory.last_memory, cs.energy_cost, rng_cog)
            break

        # 2. Noisy observations (no look-ahead) + 3. forecast/memory update.
        true_vals = {vid: float(env_now[i]) for i, vid in enumerate(cs.env_ids)}
        obs = observe(scenario.environment, true_vals, rng_obs)
        forecast.update(obs, scenario, true_vals)
        if step_in_season == 0:
            experience_mod = memory.modulation(scenario, rng_cog)
        forecast_mod = forecast.modulation(cs, scenario)

        # 4. Homeostatic urgencies.
        pred_threat = obs.get(scenario.mortality.predation_env_driver, 0.0) \
            if scenario.mortality.predation_env_driver else 0.0
        food_u, safety_u, repro_u = choice_mod.homeostatic_urgencies(
            pool, scenario, float(pred_threat))

        # 5-6. Eligibility and logits.
        mask = choice_mod.eligibility_mask(pool, cs)
        logits = choice_mod.choice_logits(
            pool, cs, scenario, food_u, safety_u, repro_u,
            experience_mod, forecast_mod, rng_choice)

        # 7. Draw action(s) and apply 8-11 for each.
        hazard_mult = np.ones(pool.n)
        hazard_add = np.zeros(pool.n)
        last_chosen = np.full(pool.n, -1, dtype=np.int64)
        last_probs = np.zeros((pool.n, cs.n_tasks))
        for _a in range(lc.actions_per_step):
            chosen, probs = choice_mod.softmax_choice(
                logits, mask, scenario.choice.softmax_temperature, rng_choice)
            last_chosen, last_probs = chosen, probs
            acted = chosen >= 0
            # 8. costs: task energy cost + resting fallback.
            pool.energy[acted] -= cs.energy_cost[chosen[acted]]
            pool.energy[~acted] -= lc.rest_energy_cost
            pool.lifetime_actions[acted] += 1
            # tally actions for experience memory.
            if acted.any():
                np.add.at(action_counts, (np.where(acted)[0], chosen[acted]), 1)
            # 9. success.
            success = choice_mod.task_success(pool, cs, chosen, env_now, rng_outcome)
            if acted.any():
                sc_idx = np.where(acted & success)[0]
                if sc_idx.size:
                    np.add.at(success_counts, (sc_idx, chosen[sc_idx]), 1)
            # 10. effects.
            hm, ha, _obsq = apply_effects(pool, cs, chosen, success, env_now,
                                          rng_outcome)
            hazard_mult *= hm
            hazard_add += ha
            # 10b. exposure from the chosen task itself. A task's
            # predation_multiplier is the behavioural exposure it entails --
            # sheltering is safer than open foraging -- and is independent of
            # whether the task succeeded. Agents that could not act at all are
            # left at their baseline exposure.
            if acted.any():
                np.multiply(hazard_mult, np.where(acted,
                                                  cs.predation_mult[chosen],
                                                  1.0),
                            out=hazard_mult)
            # optional individual learning.
            update_individual_preferences(pool, scenario, chosen, success)

        # 8b. baseline metabolism once per step.
        pool.energy -= lc.basal_metabolism
        np.clip(pool.energy, 0.0, lc.energy_max, out=pool.energy)
        # starvation somatic penalty.
        starving = pool.energy <= 0.0
        pool.health[starving] -= lc.health_starvation_penalty
        np.clip(pool.health, 0.0, lc.health_max, out=pool.health)

        # 11-12. hazards, deaths, cause, removal.
        dead_mask, cause = step_mortality(
            pool, cs, scenario, env_now, hazard_mult, hazard_add,
            season, pool.n, rng_mort)
        recorder.note_deaths(cause, dead_mask)
        if dead_mask.any():
            keep = ~dead_mask
            pool.remove_dead(dead_mask, cause, death_season=season)
            action_counts = action_counts[keep]
            success_counts = success_counts[keep]

        # 12b. age + maturity update.
        pool.age_steps += 1
        age_seasons = pool.age_steps // max(1, lc.steps_per_season)
        newly_mature = (age_seasons >= lc.maturity_seasons) & ~pool.reached_maturity
        pool.reached_maturity[newly_mature] = True

        # 13-15b. distributed reproduction: every step is an opportunity.
        if distributed and pool.n > 0:
            lo_before = pool.lifetime_offspring.copy()
            sel = distributed_breed(pool, scenario, t, bonds, rng_mate)
            if sel.parent_a_slots.size:
                outcome = produce_offspring(
                    pool, scenario, sel.parent_a_slots, sel.parent_b_slots,
                    pool.n, season, t, rng_fert, rng_inh)
                if outcome.offspring is not None:
                    action_counts, success_counts = _append(
                        pool, outcome.offspring, scenario,
                        action_counts, success_counts, season)
                    recorder.note_births(outcome.offspring.sex.shape[0])
                    mutation_events_total += outcome.offspring.n_mutation_events
                recorder.record_distributed(t, season, sel, outcome)
            else:
                recorder.record_distributed(t, season, sel, None)
            delta = pool.lifetime_offspring[:lo_before.size] - lo_before
            _pending_success = delta

        # 17. record at interval (or at final step).
        if pool.n == 0:
            extinct = True
        if (t % record_interval == 0) or (t == total_steps - 1) or pool.n == 0:
            recorder.record_snapshot(
                t, season, pool, last_probs, last_chosen, env_now, obs,
                forecast, memory.last_memory, cs.energy_cost, rng_cog)

        # 13-15. breeding at season boundary (after actions/mortality).
        if is_season_end and pool.n > 0 and not distributed:
            survived = np.ones(pool.n, dtype=bool)
            lo_before = pool.lifetime_offspring.copy()
            outcome = breed(pool, scenario, season, pool.n,
                            rng_mate, rng_fert, rng_inh)
            recorder.record_breeding(season, outcome)
            delta = pool.lifetime_offspring - lo_before
            succ_mask = successful_agents(scenario, delta, survived)
            memory.update_from_cohort(scenario, cs, action_counts,
                                      success_counts, succ_mask)
            # reset seasonal tallies for the survivors (cohort turnover).
            action_counts[:] = 0.0
            success_counts[:] = 0.0
            # materialise offspring (respecting gestation delay).
            if outcome.offspring is not None:
                if scenario.reproduction.gestation_delay_steps <= 0:
                    action_counts, success_counts = _append(
                        pool, outcome.offspring, scenario,
                        action_counts, success_counts, season)
                    recorder.note_births(outcome.offspring.sex.shape[0])
                else:
                    due = t + scenario.reproduction.gestation_delay_steps
                    pending_births.append((due, outcome.offspring))

        if extinct:
            break

        if progress is not None and (t % record_interval == 0):
            progress({"step": t, "total_steps": total_steps, "season": season,
                      "population": pool.n, "replication": replication_index})

    # Materialise any still-pending births at end (so they count as born).
    for _due, spec in pending_births:
        action_counts, success_counts = _append(
            pool, spec, scenario, action_counts, success_counts, lc.total_seasons - 1)
        recorder.note_births(spec.sex.shape[0])

    # Closing snapshot. The in-loop snapshot is taken before season-end
    # breeding, so without this the newborns of the final breeding event -- and
    # any pending births materialised above -- would never appear in the time
    # series, and the last recorded population would disagree with
    # final_population. The row is stamped one step past the end so it is
    # clearly the end-of-run state rather than a duplicate of the last step.
    if not cancelled:
        recorder.record_snapshot(
            total_steps, max(0, lc.total_seasons - 1), pool, last_probs,
            last_chosen, env_now, obs, forecast, memory.last_memory,
            cs.energy_cost, rng_cog)

    end_time = _dt.datetime.now().isoformat(timespec="seconds")
    ts_df, breeding_df, dead_df, sample_df = recorder.finalize(pool.dead_log)

    result = RunResult(
        run_id=str(uuid.uuid4()),
        config_hash=config_hash(scenario),
        scenario_dict=scenario_to_dict(scenario),
        app_version=__version__, schema_version=SCHEMA_VERSION,
        master_seed=scenario.master_seed, replication_index=replication_index,
        seed_metadata=streams.seed_metadata,
        start_time=start_time, end_time=end_time,
        cancelled=cancelled, warnings=warnings,
        env_trajectories={v: trajectories[v] for v in cs.env_ids},
        time_series=ts_df, breeding_series=breeding_df,
        dead_log_df=dead_df, agent_samples=sample_df,
        extinct=extinct or pool.n == 0, final_population=pool.n,
    )
    return result


def _append(pool: AgentPool, spec, scenario, action_counts, success_counts, season: int):
    """Append offspring and extend the seasonal tally side-arrays."""

    lc = scenario.lifecycle
    pool.append_offspring(
        sex=spec.sex,
        parent_a=_ids_to_slots_or_neg(spec.parent_a_id),
        parent_b=_ids_to_slots_or_neg(spec.parent_b_id),
        lineage=spec.lineage,
        domain_prop=spec.domain_prop, task_prop=spec.task_prop,
        domain_latent=spec.domain_latent, task_latent=spec.task_latent,
        born_season=season, lc_energy=lc.initial_energy, lc_health=lc.initial_health,
        lc_repro=lc.initial_repro_capital, lc_status=lc.initial_status)
    m = spec.sex.shape[0]
    action_counts = np.concatenate(
        [action_counts, np.zeros((m, action_counts.shape[1]))], axis=0)
    success_counts = np.concatenate(
        [success_counts, np.zeros((m, success_counts.shape[1]))], axis=0)
    return action_counts, success_counts


def _ids_to_slots_or_neg(ids: np.ndarray) -> np.ndarray:
    """Parent IDs are stored as global agent IDs (not slots) for lineage records."""

    return ids.astype(np.int64)


__all__ = ["run_simulation"]

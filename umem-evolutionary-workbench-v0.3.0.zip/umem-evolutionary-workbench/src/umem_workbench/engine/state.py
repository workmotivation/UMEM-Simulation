"""Vectorised agent state (structure-of-arrays) and population initialisation.

Living agents are stored as parallel NumPy arrays indexed by slot. This scales
far better than millions of Python objects. When agents die, their compact
records are moved to :class:`DeadLog` so that lifespan and lifetime-reproductive-
success (LRS) distributions can be reconstructed without keeping full state.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config.enums import (
    AgeHazardShape,
    FounderAgeDistribution,
    InheritanceModel,
    InitDistribution,
)
from ..config.models import ScenarioConfig
from .latent import (
    LATENT_DTYPE,
    lognormal_moment_match,
    sample_founder_latent,
    softmax,
)


@dataclass
class DeadLog:
    """Append-only compact records of dead agents for post-hoc analysis."""

    age_steps: list[int] = field(default_factory=list)
    born_season: list[int] = field(default_factory=list)
    death_season: list[int] = field(default_factory=list)
    cause: list[int] = field(default_factory=list)
    lifetime_offspring: list[int] = field(default_factory=list)
    sex: list[int] = field(default_factory=list)
    lineage_id: list[int] = field(default_factory=list)
    reached_maturity: list[bool] = field(default_factory=list)

    def add_many(self, age_steps, born_season, death_season, cause,
                 lifetime_offspring, sex, lineage_id, reached_maturity) -> None:
        self.age_steps.extend(int(x) for x in age_steps)
        self.born_season.extend(int(x) for x in born_season)
        self.death_season.extend(int(x) for x in death_season)
        self.cause.extend(int(x) for x in cause)
        self.lifetime_offspring.extend(int(x) for x in lifetime_offspring)
        self.sex.extend(int(x) for x in sex)
        self.lineage_id.extend(int(x) for x in lineage_id)
        self.reached_maturity.extend(bool(x) for x in reached_maturity)

    def __len__(self) -> int:
        return len(self.age_steps)


class AgentPool:
    """Mutable structure-of-arrays holding the living population."""

    def __init__(self, scenario: ScenarioConfig):
        self.scenario = scenario
        self.n_domains = len(scenario.domains)
        self.n_tasks = len(scenario.tasks)
        self.domain_index = {d.domain_id: i for i, d in enumerate(scenario.domains)}
        self.task_index = {t.task_id: i for i, t in enumerate(scenario.tasks)}
        # task -> domain slot
        self.task_domain = np.array(
            [self.domain_index[t.domain] for t in scenario.tasks], dtype=np.int64)

        self._next_agent_id = 0
        self._next_lineage_id = 0
        self.dead_log = DeadLog()

        # Core arrays (allocated in initialise()).
        self.agent_id = np.empty(0, dtype=np.int64)
        self.lineage_id = np.empty(0, dtype=np.int64)
        self.parent_a = np.empty(0, dtype=np.int64)
        self.parent_b = np.empty(0, dtype=np.int64)
        self.sex = np.empty(0, dtype=np.int8)
        self.age_steps = np.empty(0, dtype=np.int64)
        self.born_season = np.empty(0, dtype=np.int64)
        self.last_bred_season = np.empty(0, dtype=np.int64)
        self.energy = np.empty(0, dtype=np.float64)
        self.health = np.empty(0, dtype=np.float64)
        self.repro_capital = np.empty(0, dtype=np.float64)
        self.status = np.empty(0, dtype=np.float64)
        self.lifetime_actions = np.empty(0, dtype=np.int64)
        self.lifetime_offspring = np.empty(0, dtype=np.int64)
        self.reached_maturity = np.empty(0, dtype=bool)
        self.domain_prop = np.empty((0, self.n_domains), dtype=np.float64)
        self.task_prop = np.empty((0, self.n_tasks), dtype=np.float64)
        # Heritable genetic component under the polygenic model (ADR-001).
        # ``*_prop`` then holds the *expressed* proportions, softmax(latent),
        # so the choice policy -- which consumes log(prop) -- needs no change:
        # log(softmax(g)) is exactly the log-proportion it wants.
        self.domain_latent = np.empty((0, self.n_domains), dtype=LATENT_DTYPE)
        self.task_latent = np.empty((0, self.n_tasks), dtype=LATENT_DTYPE)
        # Founder additive variance per layer, anchoring segregation (ADR-002).
        self.domain_v0, self.task_v0 = self._founder_variances()
        self.indiv_pref = np.empty((0, self.n_tasks), dtype=np.float64)

    # -- ids --------------------------------------------------------------
    def _founder_ages(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Founder ages in steps, per ``population.founder_age_distribution``.

        Founder age synchrony is an early transient rather than the cause of
        persistent population sawtoothing (see the jaggedness diagnostic), but a
        dispersed founder cohort removes the initial pulse and the matching
        max-age cull one lifespan later. See ADR-006.
        """

        lc = self.scenario.lifecycle
        sps = max(1, lc.steps_per_season)
        span = max(1, lc.max_lifespan_seasons * sps)
        mode = self.scenario.population.founder_age_distribution

        if mode == FounderAgeDistribution.ALL_NEWBORN_LEGACY:
            # Consumes no random numbers, so legacy scenarios reproduce exactly.
            return np.zeros(n, dtype=np.int64)

        if mode == FounderAgeDistribution.UNIFORM:
            return rng.integers(0, span, size=n).astype(np.int64)

        # STABLE: an approximate stable age distribution built from the
        # configured baseline hazards. Starvation, crowding and task exposure
        # are ignored because they depend on the simulation itself, so this is
        # explicitly an approximation (documented in ADR-006).
        mort = self.scenario.mortality
        n_ages = max(1, lc.max_lifespan_seasons)
        survivorship = np.ones(n_ages, dtype=float)
        running = 1.0
        for a in range(n_ages):
            if mort.age_hazard_shape == AgeHazardShape.GOMPERTZ:
                h_age = mort.age_hazard_scale * np.exp(mort.age_hazard_rate * a)
            else:
                num = mort.age_hazard_scale * np.exp(mort.age_hazard_rate * a)
                h_age = num / (1.0 + num)
            h_pred = mort.base_predation_hazard
            h_juv = mort.juvenile_extra_hazard if a < lc.maturity_seasons else 0.0
            per_step = 1.0 - min(1.0, h_age + h_pred + mort.background_hazard + h_juv)
            survivorship[a] = running
            running *= max(0.0, per_step) ** sps

        total = survivorship.sum()
        weights = (survivorship / total if total > 0
                   else np.full(n_ages, 1.0 / n_ages))
        seasons = rng.choice(n_ages, size=n, p=weights)
        offset = rng.integers(0, sps, size=n)
        return np.minimum(seasons * sps + offset, span - 1).astype(np.int64)

    # -- polygenic helpers -------------------------------------------------
    def uses_polygenic(self) -> bool:
        return (self.scenario.inheritance.model
                == InheritanceModel.POLYGENIC_ADDITIVE)

    def _founder_variances(self) -> tuple[np.ndarray, np.ndarray]:
        """Latent founder variance V0 for each layer, by moment matching.

        Derived from the configured positive-scale ``init_mean`` / ``init_var``
        so that no new founder-distribution field is needed (ADR-001). The task
        layer uses the same defaults the legacy initialiser used (mean 1,
        variance 0.5), giving V0 = log(1.5).
        """

        sc = self.scenario
        if sc.population.init_distribution == InitDistribution.EQUAL:
            return (np.zeros(self.n_domains), np.zeros(self.n_tasks))
        dom_mean = np.array([d.init_mean for d in sc.domains], dtype=float)
        dom_var = np.array([d.init_var for d in sc.domains], dtype=float)
        _, dom_v0 = lognormal_moment_match(dom_mean, dom_var)
        _, task_v0 = lognormal_moment_match(np.ones(self.n_tasks),
                                            np.full(self.n_tasks, 0.5))
        return dom_v0, task_v0

    def express_task_latent(self, task_latent: np.ndarray) -> np.ndarray:
        """Softmax the task layer **within each domain** separately.

        Tasks compete inside their own motivational domain, so each domain is
        its own normalisation layer (ADR-001). A single global softmax over all
        tasks would let an unrelated domain's tasks dilute one another.
        """

        task_latent = np.asarray(task_latent, dtype=LATENT_DTYPE)
        out = np.empty_like(task_latent)
        for d in range(self.n_domains):
            cols = np.where(self.task_domain == d)[0]
            if cols.size:
                out[:, cols] = softmax(task_latent[:, cols])
        return out

    def _express(self, domain_latent: np.ndarray, task_latent: np.ndarray
                 ) -> tuple[np.ndarray, np.ndarray]:
        return softmax(domain_latent), self.express_task_latent(task_latent)

    def _alloc_ids(self, n: int) -> np.ndarray:
        ids = np.arange(self._next_agent_id, self._next_agent_id + n, dtype=np.int64)
        self._next_agent_id += n
        return ids

    def _alloc_lineages(self, n: int) -> np.ndarray:
        ids = np.arange(self._next_lineage_id, self._next_lineage_id + n,
                        dtype=np.int64)
        self._next_lineage_id += n
        return ids

    @property
    def n(self) -> int:
        return self.agent_id.shape[0]

    # -- initialisation ---------------------------------------------------
    def initialise(self, rng_init: np.random.Generator) -> None:
        sc = self.scenario
        n = sc.population.initial_population
        lc = sc.lifecycle

        self.agent_id = self._alloc_ids(n)
        self.lineage_id = self._alloc_lineages(n)  # founders are their own lineage
        self.parent_a = np.full(n, -1, dtype=np.int64)
        self.parent_b = np.full(n, -1, dtype=np.int64)

        # Sex / reproductive type.
        p_a = sc.population.sex_ratio_type_a
        self.sex = (rng_init.random(n) >= p_a).astype(np.int8)  # 0=A, 1=B

        self.age_steps = self._founder_ages(n, rng_init)
        self.born_season = -(self.age_steps // max(1, lc.steps_per_season))
        self.last_bred_season = np.full(n, -1, dtype=np.int64)
        # Step index of the last *successful* reproduction, for the refractory
        # period under distributed timing. -1 means "never bred".
        self.last_repro_step = np.full(n, -1, dtype=np.int64)
        self.energy = np.full(n, lc.initial_energy, dtype=np.float64)
        self.health = np.full(n, lc.initial_health, dtype=np.float64)
        self.repro_capital = np.full(n, lc.initial_repro_capital, dtype=np.float64)
        self.status = np.full(n, lc.initial_status, dtype=np.float64)
        self.lifetime_actions = np.zeros(n, dtype=np.int64)
        self.lifetime_offspring = np.zeros(n, dtype=np.int64)
        self.reached_maturity = (
            self.age_steps // max(1, lc.steps_per_season)) >= lc.maturity_seasons
        # Stagger the refractory phase of founders that are already mature, so
        # that a shared cooldown cannot resynchronise their first reproduction.
        refr = int(round(sc.reproduction.refractory_seasons * lc.steps_per_season))
        if refr > 0:
            self.last_repro_step = np.where(
                self.reached_maturity,
                -rng_init.integers(1, refr + 1, size=n), -1).astype(np.int64)

        if self.uses_polygenic():
            # Latent founders; expressed proportions are derived from them.
            dom_mu, _ = lognormal_moment_match(
                np.array([d.init_mean for d in sc.domains], dtype=float),
                np.array([d.init_var for d in sc.domains], dtype=float))
            task_mu, _ = lognormal_moment_match(np.ones(self.n_tasks),
                                                np.full(self.n_tasks, 0.5))
            self.domain_latent = sample_founder_latent(
                n, dom_mu, self.domain_v0, rng_init)
            self.task_latent = sample_founder_latent(
                n, task_mu, self.task_v0, rng_init)
            self.domain_prop, self.task_prop = self._express(
                self.domain_latent, self.task_latent)
        else:
            self.domain_prop = self._init_propensity(
                n, self.n_domains, rng_init, is_domain=True)
            self.task_prop = self._init_propensity(
                n, self.n_tasks, rng_init, is_domain=False)
            self.domain_latent = np.empty((n, self.n_domains), LATENT_DTYPE)
            self.task_latent = np.empty((n, self.n_tasks), LATENT_DTYPE)
        self.indiv_pref = np.zeros((n, self.n_tasks), dtype=np.float64)

    def _init_propensity(self, n: int, k: int, rng: np.random.Generator,
                         is_domain: bool) -> np.ndarray:
        sc = self.scenario
        dist = sc.population.init_distribution
        floor = sc.inheritance.min_propensity
        if is_domain:
            means = np.array([d.init_mean for d in sc.domains], dtype=float)
            variances = np.array([d.init_var for d in sc.domains], dtype=float)
        else:
            means = np.ones(k)
            variances = np.full(k, 0.5)

        if dist == InitDistribution.EQUAL:
            arr = np.tile(means, (n, 1))
        elif dist == InitDistribution.GAMMA:
            # gamma with matched mean; shape/scale from mean & variance.
            variances = np.maximum(variances, 1e-6)
            shape = np.maximum(means ** 2 / variances, 1e-3)
            scale = variances / np.maximum(means, 1e-6)
            arr = rng.gamma(shape=shape, scale=scale, size=(n, k))
        elif dist == InitDistribution.LOGNORMAL:
            variances = np.maximum(variances, 1e-6)
            sigma2 = np.log(1.0 + variances / np.maximum(means ** 2, 1e-6))
            mu = np.log(np.maximum(means, 1e-6)) - 0.5 * sigma2
            arr = rng.lognormal(mean=mu, sigma=np.sqrt(sigma2), size=(n, k))
        else:  # FROM_FILE handled elsewhere; fall back to equal for safety.
            arr = np.tile(means, (n, 1))
        return np.maximum(arr, floor)

    # -- growth / death ---------------------------------------------------
    def append_offspring(self, *, sex, parent_a, parent_b, lineage, domain_prop,
                         task_prop, born_season: int, lc_energy: float,
                         domain_latent=None, task_latent=None,
                         lc_health: float, lc_repro: float,
                         lc_status: float) -> np.ndarray:
        """Append newborn agents; return their new agent IDs."""

        m = sex.shape[0]
        if m == 0:
            return np.empty(0, dtype=np.int64)
        new_ids = self._alloc_ids(m)
        self.agent_id = np.concatenate([self.agent_id, new_ids])
        self.lineage_id = np.concatenate([self.lineage_id, lineage])
        self.parent_a = np.concatenate([self.parent_a, parent_a])
        self.parent_b = np.concatenate([self.parent_b, parent_b])
        self.sex = np.concatenate([self.sex, sex.astype(np.int8)])
        self.age_steps = np.concatenate([self.age_steps, np.zeros(m, np.int64)])
        self.born_season = np.concatenate(
            [self.born_season, np.full(m, born_season, np.int64)])
        self.last_bred_season = np.concatenate(
            [self.last_bred_season, np.full(m, -1, np.int64)])
        self.last_repro_step = np.concatenate(
            [self.last_repro_step, np.full(m, -1, np.int64)])
        self.energy = np.concatenate([self.energy, np.full(m, lc_energy)])
        self.health = np.concatenate([self.health, np.full(m, lc_health)])
        self.repro_capital = np.concatenate([self.repro_capital, np.full(m, lc_repro)])
        self.status = np.concatenate([self.status, np.full(m, lc_status)])
        self.lifetime_actions = np.concatenate(
            [self.lifetime_actions, np.zeros(m, np.int64)])
        self.lifetime_offspring = np.concatenate(
            [self.lifetime_offspring, np.zeros(m, np.int64)])
        self.reached_maturity = np.concatenate(
            [self.reached_maturity, np.zeros(m, bool)])
        if domain_latent is None:
            domain_latent = np.zeros((m, self.n_domains), LATENT_DTYPE)
        if task_latent is None:
            task_latent = np.zeros((m, self.n_tasks), LATENT_DTYPE)
        self.domain_latent = np.concatenate([self.domain_latent, domain_latent], axis=0)
        self.task_latent = np.concatenate([self.task_latent, task_latent], axis=0)
        self.domain_prop = np.concatenate([self.domain_prop, domain_prop], axis=0)
        self.task_prop = np.concatenate([self.task_prop, task_prop], axis=0)
        self.indiv_pref = np.concatenate(
            [self.indiv_pref, np.zeros((m, self.n_tasks))], axis=0)
        return new_ids

    def remove_dead(self, dead_mask: np.ndarray, cause: np.ndarray,
                    death_season: int) -> int:
        """Log dead agents and keep only survivors. Returns number removed."""

        if not dead_mask.any():
            return 0
        self.dead_log.add_many(
            age_steps=self.age_steps[dead_mask],
            born_season=self.born_season[dead_mask],
            death_season=np.full(int(dead_mask.sum()), death_season),
            cause=cause[dead_mask],
            lifetime_offspring=self.lifetime_offspring[dead_mask],
            sex=self.sex[dead_mask],
            lineage_id=self.lineage_id[dead_mask],
            reached_maturity=self.reached_maturity[dead_mask],
        )
        keep = ~dead_mask
        self._apply_mask(keep)
        return int(dead_mask.sum())

    def _apply_mask(self, keep: np.ndarray) -> None:
        self.agent_id = self.agent_id[keep]
        self.lineage_id = self.lineage_id[keep]
        self.parent_a = self.parent_a[keep]
        self.parent_b = self.parent_b[keep]
        self.sex = self.sex[keep]
        self.age_steps = self.age_steps[keep]
        self.born_season = self.born_season[keep]
        self.last_bred_season = self.last_bred_season[keep]
        self.last_repro_step = self.last_repro_step[keep]
        self.energy = self.energy[keep]
        self.health = self.health[keep]
        self.repro_capital = self.repro_capital[keep]
        self.status = self.status[keep]
        self.lifetime_actions = self.lifetime_actions[keep]
        self.lifetime_offspring = self.lifetime_offspring[keep]
        self.reached_maturity = self.reached_maturity[keep]
        self.domain_prop = self.domain_prop[keep]
        self.task_prop = self.task_prop[keep]
        self.domain_latent = self.domain_latent[keep]
        self.task_latent = self.task_latent[keep]
        self.indiv_pref = self.indiv_pref[keep]


__all__ = ["AgentPool", "DeadLog"]

"""Reproducible, independent random streams.

Every stochastic subsystem draws from its *own* generator, spawned from a single
master :class:`numpy.random.SeedSequence`. This makes replicated and parallel
runs reproducible regardless of process scheduling: the (master_seed,
replication_index) pair fully determines every draw.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

# Named streams. Order here defines the SeedSequence child order, so appending
# new names is safe but reordering would change historical results.
STREAM_NAMES = (
    "environment",
    "initial_population",
    "task_choice",
    "task_outcome",
    "mortality",
    "mate_choice",
    "fertility",
    "inheritance",
    "observation",
    "cognition",
)


@dataclass
class RandomStreams:
    """A bundle of independent NumPy generators, one per subsystem."""

    master_seed: int
    replication_index: int = 0
    generators: dict[str, np.random.Generator] = field(default_factory=dict)
    seed_metadata: dict[str, list[int]] = field(default_factory=dict)

    @classmethod
    def create(cls, master_seed: int, replication_index: int = 0) -> RandomStreams:
        # entropy = master seed folded with replication index for independence.
        root = np.random.SeedSequence([int(master_seed), int(replication_index)])
        children = root.spawn(len(STREAM_NAMES))
        gens: dict[str, np.random.Generator] = {}
        meta: dict[str, list[int]] = {}
        for name, child in zip(STREAM_NAMES, children):
            gens[name] = np.random.default_rng(child)
            # Record enough to reconstruct: the child's entropy state.
            meta[name] = [int(x) for x in np.asarray(child.generate_state(4))]
        return cls(master_seed=master_seed, replication_index=replication_index,
                   generators=gens, seed_metadata=meta)

    def stream(self, name: str) -> np.random.Generator:
        if name not in self.generators:
            raise KeyError(f"Unknown random stream '{name}'")
        return self.generators[name]

    def preview_stream(self) -> np.random.Generator:
        """A throwaway generator for environment previews.

        Derived from the master seed but on a distinct high branch so it never
        consumes or perturbs the real run's streams.
        """

        root = np.random.SeedSequence([int(self.master_seed), 987654321])
        return np.random.default_rng(root)


__all__ = ["RandomStreams", "STREAM_NAMES"]

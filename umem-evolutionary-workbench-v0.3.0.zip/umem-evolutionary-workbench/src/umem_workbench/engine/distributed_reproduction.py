"""Distributed reproduction: eligibility, pair bonds, and per-step breeding.

See docs/design/ADR-003 (timing), ADR-004 (mate choice), ADR-005 (mating modes).

**Eligibility and mate choice are separate concerns.** Eligibility asks who is
*capable* of reproducing — mature, in condition, out of refractory period.
Mate choice asks which of those capable agents actually *gets* a reproductive
opportunity. Conflating the two makes it impossible to tell a demographic
constraint from a sexual-selection effect.

Timing follows the non-Wright-Fisher convention: every time step is an
opportunity to reproduce, and season boundaries carry no reproductive meaning.
The per-step hazard is derived from a per-season rate so that changing
``steps_per_season`` does not change expected reproductive intensity.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config.enums import MateChoiceCriterion, MatingMode, ReproductionMode
from ..config.models import ScenarioConfig
from .mate_choice import choose_partners, mate_quality
from .state import AgentPool

__all__ = [
    "step_hazard_from_rate",
    "refractory_steps",
    "eligible_mask",
    "PairBonds",
    "DistributedBreedingOutcome",
    "distributed_breed",
]


# ---------------------------------------------------------------------------
# Unit-time conversions (ADR-003)
# ---------------------------------------------------------------------------
def step_hazard_from_rate(rate_per_season: float, steps_per_season: int) -> float:
    """Convert a per-season **rate** to a per-step probability.

    ``h = 1 - exp(-lambda / S)``. This is the standard rate-to-probability
    conversion and keeps the expected number of events per season equal to
    ``lambda`` regardless of the time resolution.

    The complementary-probability form ``1 - (1 - p)^(1/S)`` in the original
    specification applies to a per-season *probability*. It is not used here:
    eligible agents in v0.1.0 bred with certainty at each season end, so that
    formula would degenerate to ``h = 1`` and reintroduce synchrony at the end
    of every refractory period.
    """

    s = max(1, int(steps_per_season))
    lam = max(0.0, float(rate_per_season))
    if lam == 0.0:
        return 0.0
    return float(1.0 - np.exp(-lam / s))


def refractory_steps(scenario: ScenarioConfig) -> int:
    """Refractory period in steps. The user-facing unit is seasons."""

    return int(round(scenario.reproduction.refractory_seasons
                     * scenario.lifecycle.steps_per_season))


# ---------------------------------------------------------------------------
# Eligibility
# ---------------------------------------------------------------------------
def eligible_mask(pool: AgentPool, scenario: ScenarioConfig,
                  current_step: int) -> np.ndarray:
    """Who is *capable* of reproducing this step.

    Deliberately excludes anything about partner availability or competition:
    those belong to mate choice.
    """

    rc = scenario.reproduction
    ready = (pool.reached_maturity
             & (pool.energy >= rc.energy_threshold)
             & (pool.health >= rc.health_threshold)
             & (pool.repro_capital >= rc.repro_capital_threshold))

    refr = refractory_steps(scenario)
    if refr > 0:
        never_bred = pool.last_repro_step < 0
        elapsed = current_step - pool.last_repro_step
        ready &= never_bred | (elapsed >= refr)
    return ready


# ---------------------------------------------------------------------------
# Pair bonds (ADR-005)
# ---------------------------------------------------------------------------
@dataclass
class PairBonds:
    """Persistent one-to-one bonds, keyed by **agent id**, not slot.

    Slots are invalidated whenever the population array is compacted after
    deaths, so storing slots here would silently corrupt bonds. Agent ids are
    stable for life.
    """

    partner_of: dict[int, int] = field(default_factory=dict)
    #: Cumulative totals over the whole run.
    formed: int = 0
    dissolved: int = 0
    #: Events during the *current* step; reset by :meth:`begin_step`.
    formed_step: int = 0
    dissolved_step: int = 0
    dissolved_step_by_death: int = 0
    dissolved_step_stochastic: int = 0

    def begin_step(self) -> None:
        """Reset the per-step event counters. Call once at the start of a step.

        Recording cumulative totals into every per-step row and then summing the
        column overcounts by a factor of roughly the number of steps; that bug
        motivated this separation. Per-step counts are what belong in a
        per-step row.
        """

        self.formed_step = 0
        self.dissolved_step = 0
        self.dissolved_step_by_death = 0
        self.dissolved_step_stochastic = 0

    @property
    def n_bonds(self) -> int:
        return len(self.partner_of) // 2

    def bond(self, a_id: int, b_id: int) -> None:
        self.partner_of[int(a_id)] = int(b_id)
        self.partner_of[int(b_id)] = int(a_id)
        self.formed += 1
        self.formed_step += 1

    def dissolve(self, agent_id: int, *, count: bool = True) -> None:
        partner = self.partner_of.pop(int(agent_id), None)
        if partner is not None:
            self.partner_of.pop(int(partner), None)
            if count:
                self.dissolved += 1
                self.dissolved_step += 1
                self.dissolved_step_stochastic += 1

    def is_bonded(self, agent_id: int) -> bool:
        return int(agent_id) in self.partner_of

    def prune_dead(self, living_ids: np.ndarray) -> None:
        """Release bonds whose partner has died."""

        living = set(int(x) for x in living_ids)
        for agent_id in list(self.partner_of):
            if agent_id not in living:
                # Partner may already have been removed; do not double count.
                partner = self.partner_of.pop(agent_id, None)
                if partner is not None and int(partner) in self.partner_of:
                    self.partner_of.pop(int(partner), None)
                    self.dissolved += 1
                    self.dissolved_step += 1
                    self.dissolved_step_by_death += 1


# ---------------------------------------------------------------------------
# Breeding
# ---------------------------------------------------------------------------
@dataclass
class DistributedBreedingOutcome:
    """Result of one step's reproduction."""

    parent_a_slots: np.ndarray
    parent_b_slots: np.ndarray | None      # None under asexual reproduction
    n_eligible: int = 0
    n_attempts: int = 0
    n_events: int = 0
    n_failed_no_partner: int = 0
    # Pair-bond bookkeeping. *_step values are events during this step;
    # cumulative_* are running totals; n_active_bonds is the stock after this
    # step's bond updates. active = prior active + formed - dissolved.
    n_bonds_formed_step: int = 0
    n_bonds_dissolved_step: int = 0
    n_bonds_dissolved_by_death_step: int = 0
    n_bonds_dissolved_stochastic_step: int = 0
    cumulative_bonds_formed: int = 0
    cumulative_bonds_dissolved: int = 0
    n_active_bonds: int = 0


def _id_to_slot(pool: AgentPool) -> dict[int, int]:
    """Map stable agent ids to current array slots. Rebuilt once per step."""

    return {int(a): i for i, a in enumerate(pool.agent_id)}


def _update_bonds(pool: AgentPool, scenario: ScenarioConfig, bonds: PairBonds,
                  quality: np.ndarray, rng: np.random.Generator) -> None:
    """Dissolve, then form bonds. Bond formation requires maturity only."""

    rc = scenario.reproduction
    sps = scenario.lifecycle.steps_per_season

    bonds.prune_dead(pool.agent_id)

    # Stochastic dissolution.
    h_diss = step_hazard_from_rate(rc.bond_dissolution_per_season, sps)
    if h_diss > 0 and bonds.partner_of:
        pairs = {tuple(sorted((a, b))) for a, b in bonds.partner_of.items()}
        for a_id, _b_id in list(pairs):
            if rng.random() < h_diss:
                bonds.dissolve(a_id)

    # Formation among unpaired mature agents of complementary type.
    h_form = step_hazard_from_rate(rc.bond_formation_per_season, sps)
    if h_form <= 0:
        return

    mature = pool.reached_maturity
    unpaired = np.array([not bonds.is_bonded(a) for a in pool.agent_id])
    free = np.where(mature & unpaired)[0]
    if free.size < 2:
        return

    a_free = free[pool.sex[free] == 0]
    b_free = free[pool.sex[free] == 1]
    if a_free.size == 0 or b_free.size == 0:
        return

    initiators = a_free[rng.random(a_free.size) < h_form]
    if initiators.size == 0:
        return
    rng.shuffle(initiators)   # reshuffle every step: avoids storage bias

    choosers, partners = choose_partners(
        initiators, b_free, quality, rc.mate_choice_k,
        rc.mate_choice_criterion, rng, exclusive=True)
    for slot_a, slot_b in zip(choosers, partners, strict=True):
        bonds.bond(pool.agent_id[slot_a], pool.agent_id[slot_b])


def distributed_breed(pool: AgentPool, scenario: ScenarioConfig,
                      current_step: int, bonds: PairBonds,
                      rng_mate: np.random.Generator
                      ) -> DistributedBreedingOutcome:
    """Select this step's reproducing parents.

    Returns the chosen parent slots; producing offspring from them is the
    caller's job, so that offspring construction stays in one place regardless
    of timing mode.
    """

    rc = scenario.reproduction
    sps = scenario.lifecycle.steps_per_season
    empty = np.empty(0, dtype=np.int64)
    bonds.begin_step()

    # Bond dynamics run before the eligibility gate, because bond formation
    # requires maturity only (ADR-005): pairs may form while neither partner is
    # yet in condition to reproduce. Gating this on reproductive eligibility
    # would silently change that documented semantics.
    if (rc.mating_mode == MatingMode.PAIR_BONDED
            and scenario.reproduction.mode != ReproductionMode.ASEXUAL):
        _update_bonds(pool, scenario, bonds, mate_quality(pool, scenario), rng_mate)

    def _bond_fields() -> dict:
        return dict(n_bonds_formed_step=bonds.formed_step,
                    n_bonds_dissolved_step=bonds.dissolved_step,
                    n_bonds_dissolved_by_death_step=bonds.dissolved_step_by_death,
                    n_bonds_dissolved_stochastic_step=bonds.dissolved_step_stochastic,
                    cumulative_bonds_formed=bonds.formed,
                    cumulative_bonds_dissolved=bonds.dissolved,
                    n_active_bonds=bonds.n_bonds)

    ready = eligible_mask(pool, scenario, current_step)
    n_eligible = int(ready.sum())
    if n_eligible == 0:
        return DistributedBreedingOutcome(empty, empty, n_eligible=0,
                                          **_bond_fields())

    h_step = step_hazard_from_rate(rc.reproductive_event_rate, sps)
    if h_step <= 0:
        return DistributedBreedingOutcome(empty, empty, n_eligible=n_eligible,
                                          **_bond_fields())

    # ---------------- asexual ----------------
    if scenario.reproduction.mode == ReproductionMode.ASEXUAL:
        slots = np.where(ready)[0]
        attempt = slots[rng_mate.random(slots.size) < h_step]
        return DistributedBreedingOutcome(
            parent_a_slots=attempt, parent_b_slots=None,
            n_eligible=n_eligible, n_attempts=int(attempt.size),
            n_events=int(attempt.size))

    quality = mate_quality(pool, scenario)

    # ---------------- pair-bonded ----------------
    if rc.mating_mode == MatingMode.PAIR_BONDED:
        slot_of = _id_to_slot(pool)

        # One attempt per *pair*, not per agent, so the bonded rate matches the
        # configured per-agent rate rather than doubling it.
        pairs = sorted({tuple(sorted((int(a), int(b))))
                        for a, b in bonds.partner_of.items()})
        a_slots, b_slots = [], []
        n_attempts = 0
        for a_id, b_id in pairs:
            sa, sb = slot_of.get(a_id), slot_of.get(b_id)
            if sa is None or sb is None or not (ready[sa] and ready[sb]):
                continue
            n_attempts += 1
            if rng_mate.random() < h_step:
                if pool.sex[sa] == 0:
                    a_slots.append(sa)
                    b_slots.append(sb)
                else:
                    a_slots.append(sb)
                    b_slots.append(sa)
        return DistributedBreedingOutcome(
            parent_a_slots=np.asarray(a_slots, dtype=np.int64),
            parent_b_slots=np.asarray(b_slots, dtype=np.int64),
            n_eligible=n_eligible, n_attempts=n_attempts,
            n_events=len(a_slots), **_bond_fields())

    # ---------------- random / competitive ----------------
    # Both reproductive types may initiate, each drawing from the whole eligible
    # pool of the other type. Halving the initiation hazard keeps the expected
    # number of events per agent per season equal to the configured rate.
    elig = np.where(ready)[0]
    a_pool = elig[pool.sex[elig] == 0]
    b_pool = elig[pool.sex[elig] == 1]
    if a_pool.size == 0 or b_pool.size == 0:
        n_attempts = int((rng_mate.random(elig.size) < h_step).sum())
        return DistributedBreedingOutcome(
            empty, empty, n_eligible=n_eligible, n_attempts=n_attempts,
            n_failed_no_partner=n_attempts, n_active_bonds=bonds.n_bonds)

    h_init = h_step / 2.0
    init_a = a_pool[rng_mate.random(a_pool.size) < h_init]
    init_b = b_pool[rng_mate.random(b_pool.size) < h_init]

    k = 1 if rc.mating_mode == MatingMode.RANDOM else rc.mate_choice_k
    criterion = (MateChoiceCriterion.PARTNER_QUALITY
                 if rc.mating_mode == MatingMode.RANDOM
                 else rc.mate_choice_criterion)

    initiators = np.concatenate([init_a, init_b])
    n_attempts = int(initiators.size)
    if n_attempts == 0:
        return DistributedBreedingOutcome(empty, empty, n_eligible=n_eligible,
                                          n_active_bonds=bonds.n_bonds)
    rng_mate.shuffle(initiators)   # reshuffle every step (Geffen & Scholz 2017)

    # Each side chooses from the complementary pool; an agent already committed
    # this step is not available again.
    used = np.zeros(pool.n, dtype=bool)
    a_slots, b_slots = [], []
    failed = 0
    for chooser in initiators:
        is_a = pool.sex[chooser] == 0
        pool_other = b_pool if is_a else a_pool
        available = pool_other[~used[pool_other]]
        if used[chooser] or available.size == 0:
            failed += 1
            continue
        _, partner = choose_partners(
            np.array([chooser]), available, quality, k, criterion,
            rng_mate, exclusive=True)
        if partner.size == 0:
            failed += 1
            continue
        mate = int(partner[0])
        used[chooser] = True
        used[mate] = True
        if is_a:
            a_slots.append(int(chooser))
            b_slots.append(mate)
        else:
            a_slots.append(mate)
            b_slots.append(int(chooser))

    return DistributedBreedingOutcome(
        parent_a_slots=np.asarray(a_slots, dtype=np.int64),
        parent_b_slots=np.asarray(b_slots, dtype=np.int64),
        n_eligible=n_eligible, n_attempts=n_attempts,
        n_events=len(a_slots), n_failed_no_partner=failed,
        n_active_bonds=bonds.n_bonds)

"""Scientific simulation engine: state, environment, choice, mortality,
reproduction, inheritance, cognition, and the main loop."""

from __future__ import annotations

from .randomness import RandomStreams
from .simulation import run_simulation

__all__ = ["run_simulation", "RandomStreams"]

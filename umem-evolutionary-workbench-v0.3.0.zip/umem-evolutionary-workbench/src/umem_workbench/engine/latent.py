"""Latent representation of heritable propensities (see docs/design/ADR-001).

Heritable propensities are stored as **centred latent vectors** on the
unconstrained real line and expressed as proportions through a softmax. Two
reasons, both explained in full in ADR-001:

* Fisher's infinitesimal model (ADR-002) averages parental values and adds
  Gaussian noise. That requires an unconstrained scale; applied to strictly
  positive quantities it would need truncation, which biases the mean.
* Task choice depends only on differences of log-propensities, so the overall
  scale of a layer is unidentifiable. Centring (``sum(g) == 0``) removes that
  redundant degree of freedom, which makes reported genetic variance meaningful.

The transform is behaviour-preserving: because the choice policy is additive in
log-odds and passed through a softmax, the constant removed by centring cancels
exactly.

Conventions
-----------
A "layer" is one set of competing propensities: the motivational domains, or the
tasks within one domain. Every function here operates on the **last axis** and
accepts either a single vector ``(k,)`` or a batch ``(n, k)``.
"""

from __future__ import annotations

import numpy as np

__all__ = [
    "centre",
    "softmax",
    "log_softmax",
    "latent_from_positive",
    "positive_from_latent",
    "lognormal_moment_match",
    "sample_founder_latent",
    "LATENT_DTYPE",
]

#: All latent arrays use float64; the softmax and the variance bookkeeping are
#: sensitive enough that float32 would show up in the reproducibility tests.
LATENT_DTYPE = np.float64


def centre(g: np.ndarray) -> np.ndarray:
    """Return ``g`` shifted so each layer sums to zero along the last axis."""

    g = np.asarray(g, dtype=LATENT_DTYPE)
    return g - g.mean(axis=-1, keepdims=True)


def log_softmax(g: np.ndarray) -> np.ndarray:
    """Numerically stable ``log(softmax(g))`` along the last axis.

    This, not :func:`softmax`, is what the choice policy consumes: the policy is
    additive in log-odds, so it wants log-proportions directly and taking a log
    of an exponentiated value would lose precision for strongly negative
    components.
    """

    g = np.asarray(g, dtype=LATENT_DTYPE)
    shifted = g - g.max(axis=-1, keepdims=True)
    return shifted - np.log(np.exp(shifted).sum(axis=-1, keepdims=True))


def softmax(g: np.ndarray) -> np.ndarray:
    """Expressed proportions: positive, summing to one along the last axis."""

    return np.exp(log_softmax(g))


def latent_from_positive(prop: np.ndarray, floor: float) -> np.ndarray:
    """Convert legacy positive propensities to centred latent values.

    Used for migration and whenever the legacy and polygenic representations
    must interoperate. ``floor`` (``inheritance.min_propensity``) keeps the
    logarithm finite: a legacy propensity of exactly zero maps to
    ``log(floor)``, never to ``-inf``. Non-finite inputs are treated as the
    floor rather than propagating NaN into the population state.
    """

    prop = np.asarray(prop, dtype=LATENT_DTYPE)
    floor = max(float(floor), np.finfo(LATENT_DTYPE).tiny)
    safe = np.where(np.isfinite(prop), prop, floor)
    safe = np.maximum(safe, floor)
    return centre(np.log(safe))


def positive_from_latent(g: np.ndarray, scale: float = 1.0) -> np.ndarray:
    """Convert latent values back to positive propensities.

    Provided for reporting and for the legacy interoperation path. ``scale``
    multiplies the resulting proportions; the default of 1.0 returns the
    proportions themselves. Behaviour does not depend on ``scale``.
    """

    return softmax(g) * float(scale)


def lognormal_moment_match(mean: np.ndarray, var: np.ndarray
                           ) -> tuple[np.ndarray, np.ndarray]:
    """Log-normal moment matching: positive ``(mean, var)`` -> latent ``(mu, V)``.

    Founder propensities are configured on the positive scale as a mean and a
    variance (``DomainConfig.init_mean`` / ``init_var``). A log-normal variate
    with those moments has log-scale parameters

    .. math::
        V = \\log(1 + \\mathrm{var} / \\mathrm{mean}^2), \\quad
        \\mu = \\log(\\mathrm{mean}) - V/2

    Using this rather than inventing separate latent founder parameters means no
    new configuration field is needed and existing scenarios keep their intended
    founder spread.

    ``V`` is the founder additive variance ``V0`` that anchors the segregation
    variance in ADR-002. Zero configured variance yields ``V = 0``, which is
    legal: with no variation in the base population there is nothing to
    segregate. The validator flags that case.
    """

    mean = np.asarray(mean, dtype=LATENT_DTYPE)
    var = np.asarray(var, dtype=LATENT_DTYPE)
    safe_mean = np.maximum(mean, np.finfo(LATENT_DTYPE).tiny)
    v = np.log1p(np.maximum(var, 0.0) / safe_mean ** 2)
    mu = np.log(safe_mean) - v / 2.0
    return mu, v


def sample_founder_latent(n: int, mu: np.ndarray, v: np.ndarray,
                          rng: np.random.Generator) -> np.ndarray:
    """Draw ``n`` centred founder latent vectors from ``N(mu, v)`` per component.

    Returns shape ``(n, k)``. Components are drawn independently — founders have
    no genetic covariance between propensities — and each row is then centred.
    """

    mu = np.asarray(mu, dtype=LATENT_DTYPE)
    v = np.asarray(v, dtype=LATENT_DTYPE)
    sd = np.sqrt(np.maximum(v, 0.0))
    draws = rng.normal(loc=mu, scale=sd, size=(int(n), mu.shape[-1]))
    return centre(draws)

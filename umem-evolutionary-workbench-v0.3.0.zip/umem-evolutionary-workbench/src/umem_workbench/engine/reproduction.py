"""Reproduction at breeding boundaries: eligibility, mating, fertility, offspring.

Evolutionary fitness is realised lifetime reproductive success, not an imposed
score. This module records survival- and mating-selection components separately
by returning per-event diagnostics alongside the offspring specification.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..config.enums import FertilityDistribution, MateSelection, ReproductionMode
from ..config.models import ScenarioConfig
from .inheritance import build_offspring_latent, recombine_and_mutate
from .state import AgentPool


@dataclass
class OffspringSpec:
    sex: np.ndarray
    parent_a_id: np.ndarray
    parent_b_id: np.ndarray
    lineage: np.ndarray
    domain_prop: np.ndarray
    task_prop: np.ndarray
    # Heritable latent values under the polygenic model; None under legacy.
    domain_latent: np.ndarray | None = None
    task_latent: np.ndarray | None = None
    n_mutation_events: int = 0


@dataclass
class BreedingOutcome:
    offspring: OffspringSpec | None
    n_eligible: int = 0
    n_pairs: int = 0
    n_events_with_offspring: int = 0
    n_offspring_pre_survival: int = 0
    n_offspring_survived: int = 0


def _draw_fertility(rc, n_events: int, rng: np.random.Generator) -> np.ndarray:
    dist = rc.fertility_distribution
    cap = rc.max_offspring_per_event
    if dist == FertilityDistribution.FIXED:
        out = np.full(n_events, int(round(rc.fertility_mean)))
    elif dist == FertilityDistribution.POISSON:
        out = rng.poisson(rc.fertility_mean, size=n_events)
    elif dist == FertilityDistribution.BINOMIAL:
        out = rng.binomial(cap, rc.fertility_binomial_p, size=n_events)
    else:  # DISCRETE
        pmf = np.asarray(rc.fertility_discrete_pmf, dtype=float)
        out = rng.choice(len(pmf), size=n_events, p=pmf)
    return np.clip(out, 0, cap).astype(np.int64)


def _select_pairs(pool: AgentPool, elig_a: np.ndarray, elig_b: np.ndarray,
                  scenario: ScenarioConfig, rng: np.random.Generator
                  ) -> tuple[np.ndarray, np.ndarray]:
    """Return arrays of paired slot indices (a_slots, b_slots)."""

    a_idx = np.where(elig_a)[0]
    b_idx = np.where(elig_b)[0]
    n_pairs = min(a_idx.size, b_idx.size)
    if n_pairs == 0:
        return np.empty(0, np.int64), np.empty(0, np.int64)

    mode = scenario.reproduction.mate_selection
    quality = pool.repro_capital + pool.status

    if mode == MateSelection.RANDOM:
        rng.shuffle(a_idx)
        rng.shuffle(b_idx)
        return a_idx[:n_pairs], b_idx[:n_pairs]

    if mode == MateSelection.WEIGHTED_CAPITAL:
        rng.shuffle(a_idx)
        w = quality[b_idx].astype(float)
        w = np.maximum(w, 1e-6)
        # Sample distinct B partners weighted by quality (without replacement).
        chosen_b = _weighted_sample_without_replacement(b_idx, w, n_pairs, rng)
        return a_idx[:n_pairs], chosen_b

    if mode == MateSelection.COMPETITIVE:
        a_sorted = a_idx[np.argsort(-quality[a_idx])]
        b_sorted = b_idx[np.argsort(-quality[b_idx])]
        return a_sorted[:n_pairs], b_sorted[:n_pairs]

    # ASSORTATIVE by first-domain propensity.
    a_key = pool.domain_prop[a_idx, 0]
    b_key = pool.domain_prop[b_idx, 0]
    a_sorted = a_idx[np.argsort(a_key)]
    b_sorted = b_idx[np.argsort(b_key)]
    return a_sorted[:n_pairs], b_sorted[:n_pairs]


def _weighted_sample_without_replacement(items: np.ndarray, weights: np.ndarray,
                                         k: int, rng: np.random.Generator
                                         ) -> np.ndarray:
    """Efficient weighted sampling without replacement (Gumbel-top-k)."""

    keys = np.log(weights) - np.log(-np.log(rng.random(weights.shape[0]) + 1e-12))
    order = np.argsort(-keys)
    return items[order[:k]]


def breed(pool: AgentPool, scenario: ScenarioConfig, current_season: int,
          population: int, rng_mate: np.random.Generator,
          rng_fert: np.random.Generator, rng_inh: np.random.Generator
          ) -> BreedingOutcome:
    """Run one breeding event for the whole population."""

    rc = scenario.reproduction

    ready = (pool.reached_maturity
             & (pool.energy >= rc.energy_threshold)
             & (pool.health >= rc.health_threshold)
             & (pool.repro_capital >= rc.repro_capital_threshold))
    # Respect breeding interval.
    interval_ok = (pool.last_bred_season < 0) | \
                  (current_season - pool.last_bred_season >= rc.breeding_every_seasons)
    ready &= interval_ok

    n_eligible = int(ready.sum())
    if n_eligible == 0:
        return BreedingOutcome(offspring=None, n_eligible=0)

    if scenario.reproduction.mode == ReproductionMode.ASEXUAL:
        a_slots = np.where(ready)[0]
        b_slots = a_slots  # clone: single parent used twice
    else:
        elig_a = ready & (pool.sex == 0)
        elig_b = ready & (pool.sex == 1)
        a_slots, b_slots = _select_pairs(pool, elig_a, elig_b, scenario, rng_mate)

    n_pairs = a_slots.size
    if n_pairs == 0:
        return BreedingOutcome(offspring=None, n_eligible=n_eligible, n_pairs=0)

    counts = _draw_fertility(rc, n_pairs, rng_fert)
    total_pre = int(counts.sum())

    # Carrying-capacity / hard-cap birth limitation (explicit, recorded).
    room = max(0, scenario.population.max_population - population)
    # Build per-offspring parent slot arrays.
    parent_a_slot = np.repeat(a_slots, counts)
    parent_b_slot = np.repeat(b_slots, counts)
    if parent_a_slot.size > room:
        keep = rng_fert.permutation(parent_a_slot.size)[:room]
        keep.sort()
        parent_a_slot = parent_a_slot[keep]
        parent_b_slot = parent_b_slot[keep]

    # Juvenile survival applied at birth, with optional soft density-dependent
    # recruitment (Beverton-Holt): survival declines as pop approaches K. This
    # is an explicit, recorded regulation mechanism, not silent culling.
    eff_survival = rc.juvenile_survival
    if rc.density_dependent_recruitment:
        k = max(1, scenario.population.carrying_capacity)
        eff_survival = eff_survival / (1.0 + rc.recruitment_strength * population / k)
    survive = rng_fert.random(parent_a_slot.size) < eff_survival
    parent_a_slot = parent_a_slot[survive]
    parent_b_slot = parent_b_slot[survive]
    n_surv = parent_a_slot.size

    # Apply reproduction costs to the parents that actually bred.
    bred_a = np.unique(a_slots)
    bred_b = np.unique(b_slots)
    pool.energy[bred_a] = np.maximum(0.0, pool.energy[bred_a] - rc.repro_energy_cost)
    pool.health[bred_a] = np.maximum(0.0, pool.health[bred_a] - rc.repro_health_cost)
    if scenario.reproduction.mode != ReproductionMode.ASEXUAL:
        pool.energy[bred_b] = np.maximum(0.0, pool.energy[bred_b] - rc.repro_energy_cost)
        pool.health[bred_b] = np.maximum(0.0, pool.health[bred_b] - rc.repro_health_cost)
    pool.repro_capital[bred_a] = 0.0
    pool.last_bred_season[bred_a] = current_season
    pool.last_bred_season[bred_b] = current_season

    if n_surv == 0:
        return BreedingOutcome(offspring=None, n_eligible=n_eligible,
                               n_pairs=n_pairs, n_offspring_pre_survival=total_pre)

    # Attribute surviving offspring to parents (lifetime reproductive success).
    np.add.at(pool.lifetime_offspring, parent_a_slot, 1)
    if scenario.reproduction.mode != ReproductionMode.ASEXUAL:
        np.add.at(pool.lifetime_offspring, parent_b_slot, 1)

    # Offspring propensities. The polygenic model inherits on the latent scale
    # and derives expressed proportions from it (ADR-001, ADR-002); the legacy
    # model recombines the positive propensities directly.
    dom_latent = task_latent = None
    n_mut = 0
    if pool.uses_polygenic():
        from .inheritance import MutationTally
        tally = MutationTally()
        dom_latent = build_offspring_latent(
            pool.domain_latent[parent_a_slot], pool.domain_latent[parent_b_slot],
            scenario.inheritance, pool.domain_v0, rng_inh,
            layer="domain", tally=tally)
        task_latent = build_offspring_latent(
            pool.task_latent[parent_a_slot], pool.task_latent[parent_b_slot],
            scenario.inheritance, pool.task_v0, rng_inh,
            layer="task", tally=tally)
        n_mut = tally.total
        dom_child, task_child = pool._express(dom_latent, task_latent)
    else:
        dom_child = recombine_and_mutate(
            pool.domain_prop[parent_a_slot], pool.domain_prop[parent_b_slot],
            scenario.inheritance, rng_inh)
        task_child = recombine_and_mutate(
            pool.task_prop[parent_a_slot], pool.task_prop[parent_b_slot],
            scenario.inheritance, rng_inh)

    sex = (rng_inh.random(n_surv) >= scenario.population.sex_ratio_type_a).astype(np.int8)
    lineage = pool.lineage_id[parent_a_slot].copy()  # maternal lineage

    spec = OffspringSpec(
        sex=sex,
        parent_a_id=pool.agent_id[parent_a_slot].copy(),
        parent_b_id=pool.agent_id[parent_b_slot].copy(),
        lineage=lineage,
        domain_prop=dom_child,
        task_prop=task_child,
        domain_latent=dom_latent,
        task_latent=task_latent,
        n_mutation_events=n_mut,
    )
    n_events_with = int((counts > 0).sum())
    return BreedingOutcome(
        offspring=spec, n_eligible=n_eligible, n_pairs=n_pairs,
        n_events_with_offspring=n_events_with,
        n_offspring_pre_survival=total_pre, n_offspring_survived=n_surv)


__all__ = ["OffspringSpec", "BreedingOutcome", "breed"]


# ---------------------------------------------------------------------------
# Shared offspring production (used by both timing modes)
# ---------------------------------------------------------------------------
def produce_offspring(pool: AgentPool, scenario: ScenarioConfig,
                      a_slots: np.ndarray, b_slots: np.ndarray | None,
                      population: int, current_season: int, current_step: int,
                      rng_fert: np.random.Generator,
                      rng_inh: np.random.Generator) -> BreedingOutcome:
    """Turn selected parents into offspring.

    Shared by season-end and distributed timing so that fertility, juvenile
    survival, density-dependent recruitment, parental costs and inheritance are
    defined in exactly one place; only the *selection* of parents differs
    between timing modes.

    ``b_slots is None`` selects asexual reproduction.
    """

    rc = scenario.reproduction
    asexual = b_slots is None
    n_events = int(a_slots.size)
    if n_events == 0:
        return BreedingOutcome(offspring=None, n_pairs=0)

    counts = _draw_fertility(rc, n_events, rng_fert)
    total_pre = int(counts.sum())

    room = max(0, scenario.population.max_population - population)
    parent_a_slot = np.repeat(a_slots, counts)
    parent_b_slot = (np.repeat(b_slots, counts) if not asexual
                     else parent_a_slot.copy())
    if parent_a_slot.size > room:
        keep = rng_fert.permutation(parent_a_slot.size)[:room]
        keep.sort()
        parent_a_slot = parent_a_slot[keep]
        parent_b_slot = parent_b_slot[keep]

    eff_survival = rc.juvenile_survival
    if rc.density_dependent_recruitment:
        k = max(1, scenario.population.carrying_capacity)
        eff_survival = eff_survival / (1.0 + rc.recruitment_strength * population / k)
    survive = rng_fert.random(parent_a_slot.size) < eff_survival
    parent_a_slot = parent_a_slot[survive]
    parent_b_slot = parent_b_slot[survive]
    n_surv = parent_a_slot.size

    # Parental costs are symmetric and fall on the agents that actually bred.
    # A failed attempt never reaches this function, so it costs nothing.
    bred_a = np.unique(a_slots)
    pool.energy[bred_a] = np.maximum(0.0, pool.energy[bred_a] - rc.repro_energy_cost)
    pool.health[bred_a] = np.maximum(0.0, pool.health[bred_a] - rc.repro_health_cost)
    pool.repro_capital[bred_a] = 0.0
    pool.last_bred_season[bred_a] = current_season
    pool.last_repro_step[bred_a] = current_step
    if not asexual:
        bred_b = np.unique(b_slots)
        pool.energy[bred_b] = np.maximum(0.0, pool.energy[bred_b] - rc.repro_energy_cost)
        pool.health[bred_b] = np.maximum(0.0, pool.health[bred_b] - rc.repro_health_cost)
        pool.repro_capital[bred_b] = 0.0
        pool.last_bred_season[bred_b] = current_season
        pool.last_repro_step[bred_b] = current_step

    if n_surv == 0:
        return BreedingOutcome(offspring=None, n_pairs=n_events,
                               n_offspring_pre_survival=total_pre)

    np.add.at(pool.lifetime_offspring, parent_a_slot, 1)
    if not asexual:
        np.add.at(pool.lifetime_offspring, parent_b_slot, 1)

    dom_latent = task_latent = None
    n_mut = 0
    if pool.uses_polygenic():
        from .inheritance import MutationTally, build_offspring_latent
        tally = MutationTally()
        gb_dom = None if asexual else pool.domain_latent[parent_b_slot]
        gb_task = None if asexual else pool.task_latent[parent_b_slot]
        dom_latent = build_offspring_latent(
            pool.domain_latent[parent_a_slot], gb_dom, scenario.inheritance,
            pool.domain_v0, rng_inh, layer="domain", tally=tally)
        task_latent = build_offspring_latent(
            pool.task_latent[parent_a_slot], gb_task, scenario.inheritance,
            pool.task_v0, rng_inh, layer="task", tally=tally)
        n_mut = tally.total
        dom_child, task_child = pool._express(dom_latent, task_latent)
    else:
        pb_dom = (pool.domain_prop[parent_a_slot] if asexual
                  else pool.domain_prop[parent_b_slot])
        pb_task = (pool.task_prop[parent_a_slot] if asexual
                   else pool.task_prop[parent_b_slot])
        dom_child = recombine_and_mutate(
            pool.domain_prop[parent_a_slot], pb_dom, scenario.inheritance, rng_inh)
        task_child = recombine_and_mutate(
            pool.task_prop[parent_a_slot], pb_task, scenario.inheritance, rng_inh)

    sex = (rng_inh.random(n_surv)
           >= scenario.population.sex_ratio_type_a).astype(np.int8)
    spec = OffspringSpec(
        sex=sex,
        parent_a_id=pool.agent_id[parent_a_slot].copy(),
        parent_b_id=pool.agent_id[parent_b_slot].copy(),
        lineage=pool.lineage_id[parent_a_slot].copy(),
        domain_prop=dom_child, task_prop=task_child,
        domain_latent=dom_latent, task_latent=task_latent,
        n_mutation_events=n_mut,
    )
    return BreedingOutcome(
        offspring=spec, n_pairs=n_events,
        n_events_with_offspring=int((counts > 0).sum()),
        n_offspring_pre_survival=total_pre, n_offspring_survived=n_surv)

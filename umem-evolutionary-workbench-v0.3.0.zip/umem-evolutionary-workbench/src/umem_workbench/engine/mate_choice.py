"""Mate choice by Random-k Pair Matching (see docs/design/ADR-004).

Implements the RKPM algorithm of Geffen & Scholz (2017, *JASSS* 20(4):8),
reimplemented from the published description; no code was copied.

The algorithm: shuffle the pool, then for each chooser inspect ``k`` randomly
drawn candidates and take the best one by a configured criterion. It runs in
linear time, is stochastic, and exposes a single tunable parameter. The expected
rank of the chosen partner among ``n`` candidates is ``n / (k + 1)``, so ``k``
moves the model continuously from unbiased random mating (``k = 1``) to strong
reproductive skew (large ``k``) without any change of mechanism.

Two departures from the published algorithm, both documented in ADR-004:

* The original ranks candidates by a *distance* function, which suits
  assortative matching. Reproductive skew instead needs a *directional*
  criterion, so the criterion is configurable
  (:class:`~umem_workbench.config.enums.MateChoiceCriterion`).
* The original scans the ``k`` array-adjacent agents after shuffling. Here the
  ``k`` candidates are drawn directly, which is equivalent in distribution and
  avoids any residual dependence on array position.

Reshuffling every step is not optional: the paper warns that a fixed processing
order lets agents near the front of the array accumulate systematically better
partners as matching is repeated.

Eligibility (who *can* reproduce) is kept strictly separate from mate choice
(who *gets to*); see :mod:`umem_workbench.engine.eligibility`.
"""

from __future__ import annotations

import numpy as np

from ..config.enums import MateChoiceCriterion
from ..config.models import ScenarioConfig
from .state import AgentPool

__all__ = [
    "mate_quality",
    "choose_partners",
    "PERMITTED_QUALITY_KEYS",
]

#: The only state variables that may contribute to mate quality. Fixed so that
#: configuration stays declarative and validated; no user expression is ever
#: evaluated.
PERMITTED_QUALITY_KEYS = ("repro_capital", "status", "health", "energy")


def mate_quality(pool: AgentPool, scenario: ScenarioConfig) -> np.ndarray:
    """Weighted sum over normalised state variables, one value per agent.

    Each contributing variable is scaled to ``[0, 1]`` by its configured maximum
    before weighting, so weights are comparable across variables with different
    natural ranges. The result is not normalised across agents: only its
    ordering matters to the choice rule.
    """

    lc = scenario.lifecycle
    weights = scenario.reproduction.mate_quality_weights
    maxima = {
        "repro_capital": max(lc.repro_capital_max, 1e-9),
        "status": max(lc.status_max, 1e-9),
        "health": max(lc.health_max, 1e-9),
        "energy": max(lc.energy_max, 1e-9),
    }

    quality = np.zeros(pool.n, dtype=np.float64)
    for key in PERMITTED_QUALITY_KEYS:
        w = float(weights.get(key, 0.0))
        if w == 0.0:
            continue
        quality += w * (getattr(pool, key) / maxima[key])
    return quality


def choose_partners(chooser_slots: np.ndarray,
                    candidate_slots: np.ndarray,
                    quality: np.ndarray,
                    k: int,
                    criterion: MateChoiceCriterion,
                    rng: np.random.Generator,
                    *,
                    exclusive: bool = True) -> tuple[np.ndarray, np.ndarray]:
    """Match choosers to candidates by RKPM.

    Parameters
    ----------
    chooser_slots
        Slots of the agents initiating a reproductive attempt, already shuffled
        by the caller.
    candidate_slots
        Slots of every agent that may be chosen. For sexual reproduction this is
        the whole eligible pool of the complementary reproductive type, not only
        those initiating: restricting candidates to simultaneous initiators
        collapses pairing and can drive the population extinct.
    quality
        Per-agent quality, indexed by slot (see :func:`mate_quality`).
    k
        Candidates inspected per choice. ``k = 1`` gives unbiased random mating.
    criterion
        Maximise the partner's quality, or minimise the quality difference.
    exclusive
        When true a candidate can be taken only once per matching event, so no
        agent is duplicated within a single step. Choosers are always used at
        most once.

    Returns
    -------
    ``(matched_choosers, matched_partners)`` -- equal-length slot arrays. A
    chooser that found no candidate is simply absent from the result.
    """

    chooser_slots = np.asarray(chooser_slots, dtype=np.int64)
    candidate_slots = np.asarray(candidate_slots, dtype=np.int64)
    if chooser_slots.size == 0 or candidate_slots.size == 0:
        empty = np.empty(0, dtype=np.int64)
        return empty, empty

    k = max(1, int(k))
    taken = np.zeros(candidate_slots.size, dtype=bool)
    matched_choosers: list[int] = []
    matched_partners: list[int] = []

    # Sequential because exclusivity makes each choice depend on the previous
    # ones. The per-chooser cost is O(k), so the whole event stays linear in the
    # number of choosers, matching the published algorithm's efficiency class.
    for chooser in chooser_slots:
        available = np.where(~taken)[0]
        if available.size == 0:
            break

        # Draw k candidates without replacement (all of them if the pool is
        # smaller than k).
        n_draw = min(k, available.size)
        picks = (available if n_draw == available.size
                 else rng.choice(available, size=n_draw, replace=False))

        cand = candidate_slots[picks]
        if criterion == MateChoiceCriterion.SIMILARITY:
            score = -np.abs(quality[cand] - quality[chooser])
        else:
            score = quality[cand]

        best = int(np.argmax(score))
        chosen_index = int(picks[best])
        matched_choosers.append(int(chooser))
        matched_partners.append(int(candidate_slots[chosen_index]))
        if exclusive:
            taken[chosen_index] = True

    return (np.asarray(matched_choosers, dtype=np.int64),
            np.asarray(matched_partners, dtype=np.int64))


def expected_partner_rank(n_candidates: int, k: int) -> float:
    """Expected rank of the chosen partner, ``n / (k + 1)``.

    Exposed for tests and documentation: it is the quantitative statement of
    what ``k`` buys, and lets the choosiness parameter be reasoned about rather
    than tuned blindly.
    """

    return float(n_candidates) / (max(1, int(k)) + 1)

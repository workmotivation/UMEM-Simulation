"""Engine-level event codes (causes of death, sex/type constants)."""

from __future__ import annotations

from enum import IntEnum


class DeathCause(IntEnum):
    """Recorded cause of death for every agent that dies."""

    ALIVE = 0
    STARVATION = 1
    HEALTH = 2          # somatic condition / injury reached zero
    PREDATION = 3
    AGE = 4             # senescence hazard or maximum lifespan
    BACKGROUND = 5
    DENSITY = 6         # density-dependent mortality
    JUVENILE = 7        # extra juvenile hazard


DEATH_CAUSE_LABELS = {
    DeathCause.ALIVE: "alive",
    DeathCause.STARVATION: "starvation",
    DeathCause.HEALTH: "health/injury",
    DeathCause.PREDATION: "predation",
    DeathCause.AGE: "age/senescence",
    DeathCause.BACKGROUND: "background",
    DeathCause.DENSITY: "density",
    DeathCause.JUVENILE: "juvenile",
}


class ReproType(IntEnum):
    """Reproductive type. For sexual reproduction, A and B are compatible."""

    TYPE_A = 0
    TYPE_B = 1


__all__ = ["DeathCause", "DEATH_CAUSE_LABELS", "ReproType"]

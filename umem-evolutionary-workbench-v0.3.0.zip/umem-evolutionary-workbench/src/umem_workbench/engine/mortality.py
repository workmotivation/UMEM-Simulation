"""Mortality: deterministic state deaths and bounded probabilistic hazards.

Survival emerges from state dynamics and hazards, never from a single imposed
fitness score. Every death is assigned a recorded cause. Age hazard uses a
bounded Gompertz or logistic senescence curve.
"""

from __future__ import annotations

import numpy as np

from ..config.enums import AgeHazardShape
from ..config.models import ScenarioConfig
from .compiled import CompiledScenario
from .events import DeathCause
from .state import AgentPool


def _age_hazard(age_seasons: np.ndarray, scenario: ScenarioConfig) -> np.ndarray:
    m = scenario.mortality
    if m.age_hazard_shape == AgeHazardShape.GOMPERTZ:
        h = m.age_hazard_scale * np.exp(m.age_hazard_rate * age_seasons)
    else:  # logistic
        num = m.age_hazard_scale * np.exp(m.age_hazard_rate * age_seasons)
        h = num / (1.0 + num)
    return np.clip(h, 0.0, 1.0)


def step_mortality(pool: AgentPool, cs: CompiledScenario, scenario: ScenarioConfig,
                   env_now: np.ndarray, hazard_mult: np.ndarray,
                   hazard_add: np.ndarray, current_season: int, population: int,
                   rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    """Return (dead_mask, cause_array) for the current step."""

    n = pool.n
    cause = np.full(n, int(DeathCause.ALIVE), dtype=np.int64)
    dead = np.zeros(n, dtype=bool)

    lc = scenario.lifecycle
    mort = scenario.mortality

    # --- deterministic state deaths ---
    state_dead = pool.health <= 0.0
    starving = pool.energy <= 0.0
    cause[state_dead & starving] = int(DeathCause.STARVATION)
    cause[state_dead & ~starving] = int(DeathCause.HEALTH)
    dead |= state_dead

    # --- maximum lifespan (deterministic age death) ---
    age_seasons = pool.age_steps // max(1, lc.steps_per_season)
    max_life = age_seasons >= lc.max_lifespan_seasons
    newly = max_life & ~dead
    cause[newly] = int(DeathCause.AGE)
    dead |= max_life

    survivors = ~dead
    if survivors.any():
        s = survivors
        # Predation hazard.
        pred_env = env_now[cs.predation_env_idx] if cs.predation_env_idx >= 0 else 0.0
        base_pred = mort.base_predation_hazard * (
            1.0 + mort.predation_env_sensitivity * pred_env)
        h_pred = np.clip(base_pred * hazard_mult + hazard_add, 0.0, 1.0)
        # Age hazard.
        h_age = _age_hazard(age_seasons.astype(float), scenario)
        # Background hazard.
        h_bg = np.full(n, mort.background_hazard)
        # Juvenile extra hazard (before maturity).
        juv = ~pool.reached_maturity
        h_juv = np.where(juv, mort.juvenile_extra_hazard, 0.0)
        # Density hazard as population approaches / exceeds carrying capacity.
        # The hazard is zero while the population sits comfortably below K and
        # rises linearly once it passes ``density_onset_fraction`` of K. Scaling
        # it from zero population instead would penalise small populations and
        # create an extinction ratchet that prevents demographic recovery.
        k = max(1, scenario.population.carrying_capacity)
        crowding = population / k - mort.density_onset_fraction
        dens_base = mort.density_hazard_strength * 0.01 * max(0.0, crowding)
        if mort.density_affects_juveniles_only:
            h_dens = np.where(juv, dens_base, 0.0)
        else:
            h_dens = np.full(n, dens_base)

        comps = np.stack([h_pred, h_age, h_bg, h_juv, h_dens], axis=1)  # (n,5)
        comps = np.clip(comps, 0.0, 1.0)
        p_survive = np.prod(1.0 - comps, axis=1)
        p_death = 1.0 - p_survive

        draw = rng.random(n)
        newly_dead = s & (draw < p_death)
        if newly_dead.any():
            # Attribute cause proportional to component hazards.
            comp_causes = np.array([
                int(DeathCause.PREDATION), int(DeathCause.AGE),
                int(DeathCause.BACKGROUND), int(DeathCause.JUVENILE),
                int(DeathCause.DENSITY)])
            idx = np.where(newly_dead)[0]
            weights = comps[idx]
            wsum = weights.sum(axis=1, keepdims=True)
            wsum[wsum == 0] = 1.0
            probs = weights / wsum
            u = rng.random(idx.shape[0])[:, None]
            pick = (u > np.cumsum(probs, axis=1)).sum(axis=1)
            pick = np.clip(pick, 0, 4)
            cause[idx] = comp_causes[pick]
            dead |= newly_dead

    return dead, cause


__all__ = ["step_mortality"]

"""Field labels, units, and bounds derived from the configuration models.

The Pydantic models carry their own UI metadata in ``json_schema_extra`` (label,
help, unit, ui_min, ui_max). Reading it here rather than maintaining a parallel
dictionary means a new configuration field cannot silently appear in the UI
without a label, and a renamed field cannot leave a stale label behind.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel
from pydantic.fields import FieldInfo

__all__ = [
    "FieldMeta",
    "field_meta",
    "model_field_meta",
    "label_for",
    "help_for",
    "unit_for",
    "bounds_for",
    "prettify",
    "inactive_applicabilities",
    "SECTION_LABELS",
]

#: Human-readable names for the top-level configuration sections.
SECTION_LABELS: dict[str, str] = {
    "domains": "Motivational domains",
    "tasks": "Task library",
    "environment": "Environment",
    "population": "Population",
    "lifecycle": "Life cycle",
    "mortality": "Mortality and hazards",
    "reproduction": "Reproduction",
    "inheritance": "Inheritance and mutation",
    "homeostasis": "Homeostasis (internal state)",
    "cognition": "Cognition (A / B / C)",
    "choice": "Decision policy",
    "experiment": "Experiment",
    "output": "Output and recording",
}


def inactive_applicabilities(scenario) -> set[str]:
    """Applicability tags that do **not** apply under this scenario's mechanisms.

    Interfaces disable fields carrying these tags so a user cannot mistake an
    ignored legacy field for an active parameter.
    """

    rep = scenario.reproduction
    inh = scenario.inheritance
    distributed = rep.timing.value == "distributed"
    asexual = rep.mode.value == "asexual"
    polygenic = inh.model.value == "polygenic_additive"
    inactive = set()
    inactive.add("legacy_timing_only" if distributed else "distributed_only")
    inactive.add("legacy_inheritance_only" if polygenic else "polygenic_only")
    if asexual:
        inactive.update({"sexual_only", "pair_bond_only", "competitive_only"})
    else:
        inactive.add("asexual_only")
        if rep.mating_mode.value != "pair_bonded":
            inactive.add("pair_bond_only")
        if rep.mating_mode.value != "competitive":
            inactive.add("competitive_only")
    return inactive


def prettify(name: str) -> str:
    """Fallback label: ``base_predation_hazard`` -> ``Base predation hazard``."""

    return name.replace("_", " ").strip().capitalize()


class FieldMeta:
    """Presentation metadata for a single configuration field."""

    __slots__ = ("name", "label", "help", "unit", "ui_min", "ui_max",
                 "default", "annotation", "applicability", "deprecated",
                 "added_in_schema")

    def __init__(self, name: str, info: FieldInfo) -> None:
        extra: dict[str, Any] = {}
        raw = getattr(info, "json_schema_extra", None)
        if isinstance(raw, dict):
            # The ui() helper nests its payload under a "ui" key so it does not
            # collide with genuine JSON-schema keywords in the same dict.
            nested = raw.get("ui")
            extra = nested if isinstance(nested, dict) else raw

        self.name = name
        self.label = extra.get("label") or prettify(name)
        self.help = extra.get("help") or ""
        self.unit = extra.get("unit") or ""
        self.ui_min = extra.get("ui_min")
        self.ui_max = extra.get("ui_max")
        self.default = info.default
        self.annotation = info.annotation
        self.applicability = extra.get("applicability") or "all"
        self.deprecated = extra.get("deprecated") or ""
        self.added_in_schema = int(extra.get("added_in_schema") or 1)

    @property
    def label_with_unit(self) -> str:
        return f"{self.label} ({self.unit})" if self.unit else self.label

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"FieldMeta({self.name!r}, label={self.label!r})"


def model_field_meta(model: type[BaseModel] | BaseModel) -> dict[str, FieldMeta]:
    """Return ``{field_name: FieldMeta}`` for a model class or instance."""

    cls = model if isinstance(model, type) else type(model)
    return {name: FieldMeta(name, info)
            for name, info in cls.model_fields.items()}


def field_meta(model: type[BaseModel] | BaseModel, name: str
               ) -> FieldMeta | None:
    cls = model if isinstance(model, type) else type(model)
    info = cls.model_fields.get(name)
    return FieldMeta(name, info) if info is not None else None


def label_for(model: type[BaseModel] | BaseModel, name: str) -> str:
    meta = field_meta(model, name)
    return meta.label if meta else prettify(name)


def help_for(model: type[BaseModel] | BaseModel, name: str) -> str:
    meta = field_meta(model, name)
    return meta.help if meta else ""


def unit_for(model: type[BaseModel] | BaseModel, name: str) -> str:
    meta = field_meta(model, name)
    return meta.unit if meta else ""


def bounds_for(model: type[BaseModel] | BaseModel, name: str
               ) -> tuple[float | None, float | None]:
    meta = field_meta(model, name)
    return (meta.ui_min, meta.ui_max) if meta else (None, None)

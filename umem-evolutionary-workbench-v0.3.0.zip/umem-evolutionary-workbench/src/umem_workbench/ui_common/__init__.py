"""Shared, toolkit-independent UI support: labels, help text, state, presets."""

from .help_text import (
                        ABOUT_TEXT,
                        COGNITION_HELP,
                        DISCLAIMER_SHORT,
                        DISCLAIMERS,
                        METRIC_HELP,
                        SECTION_HELP,
                        SIMPLE_MODE_HELP,
)
from .labels import (
                        SECTION_LABELS,
                        FieldMeta,
                        bounds_for,
                        field_meta,
                        help_for,
                        label_for,
                        model_field_meta,
                        prettify,
                        unit_for,
)
from .presets import (
                        NONFUNCTIONAL_DEMO_TASKS,
                        SIMPLE_CONTROLS,
                        SimpleControl,
                        SimpleSettings,
                        apply_simple_settings,
                        describe_mapping,
                        diff_against_preset,
                        read_simple_settings,
)
from .view_models import RunProgress, WorkbenchState, preset_choices, severity_counts

__all__ = [
    "FieldMeta", "model_field_meta", "field_meta", "label_for", "help_for",
    "unit_for", "bounds_for", "prettify", "SECTION_LABELS",
    "ABOUT_TEXT", "DISCLAIMERS", "DISCLAIMER_SHORT", "SECTION_HELP",
    "METRIC_HELP", "SIMPLE_MODE_HELP", "COGNITION_HELP",
    "SimpleControl", "SIMPLE_CONTROLS", "SimpleSettings",
    "apply_simple_settings", "read_simple_settings", "describe_mapping",
    "diff_against_preset", "NONFUNCTIONAL_DEMO_TASKS",
    "WorkbenchState", "RunProgress", "preset_choices", "severity_counts",
]

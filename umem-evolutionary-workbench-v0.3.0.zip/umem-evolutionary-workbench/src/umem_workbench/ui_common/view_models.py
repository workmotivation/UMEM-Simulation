"""UI-agnostic application state (Master Prompt section 16).

Both the Streamlit and the desktop interface drive the same
:class:`WorkbenchState`, so scenario editing, validation, running, and export
behave identically in each. Nothing in this module imports a GUI toolkit.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from ..config.models import ScenarioConfig
from ..config.presets import PRESET_DESCRIPTIONS, PRESET_IDS, load_preset
from ..config.serialization import (
    config_hash,
    load_scenario_json,
    save_scenario_json,
)
from ..config.validation import ValidationReport, validate_scenario
from ..engine.results import RunResult
from ..experiments import (
    CancellationToken,
    ExperimentOutcome,
    preflight,
    run_experiment,
)

__all__ = [
    "RunProgress",
    "WorkbenchState",
    "preset_choices",
    "severity_counts",
]


def preset_choices() -> list[tuple[str, str]]:
    """``[(preset_id, description)]`` for a dropdown."""

    return [(pid, PRESET_DESCRIPTIONS.get(pid, pid)) for pid in PRESET_IDS]


def severity_counts(report: ValidationReport) -> dict[str, int]:
    counts = {"ERROR": 0, "WARNING": 0, "THEORY": 0}
    for issue in report.issues:
        counts[issue.severity.name] = counts.get(issue.severity.name, 0) + 1
    return counts


@dataclass
class RunProgress:
    """Progress state for a run monitor."""

    fraction: float = 0.0
    message: str = ""
    running: bool = False
    finished: bool = False
    error: str | None = None

    def update(self, fraction: float, message: str) -> None:
        self.fraction = max(0.0, min(1.0, float(fraction)))
        self.message = message


@dataclass
class WorkbenchState:
    """Everything an interface needs to hold between interactions."""

    scenario: ScenarioConfig = field(
        default_factory=lambda: load_preset("stable_abundant"))
    is_custom: bool = False
    outcome: ExperimentOutcome | None = None
    progress: RunProgress = field(default_factory=RunProgress)
    cancel_token: CancellationToken | None = None
    last_error: str | None = None

    # ---------------- scenario management ----------------
    def load_preset(self, preset_id: str) -> None:
        self.scenario = load_preset(preset_id)
        self.is_custom = False
        self.outcome = None

    def load_from_file(self, path: str) -> None:
        self.scenario = load_scenario_json(path)
        # A file may or may not descend from a preset; treat it as custom
        # unless it declares an origin and still matches that preset exactly.
        self.is_custom = not self._matches_declared_preset()
        self.outcome = None

    def save_to_file(self, path: str) -> None:
        save_scenario_json(self.scenario, path)

    def _matches_declared_preset(self) -> bool:
        origin = self.scenario.preset_origin
        if not origin:
            return False
        try:
            return config_hash(load_preset(origin)) == config_hash(self.scenario)
        except KeyError:
            return False

    def update_scenario(self, updated: ScenarioConfig,
                        mark_custom: bool = True) -> None:
        """Replace the scenario, flagging it as Custom when it has diverged.

        The specification requires that editing an advanced value stops the
        scenario being presented as a preset. The check is against the
        configuration hash, so a purely cosmetic rename does not trigger it.
        """

        self.scenario = updated
        if mark_custom and not self._matches_declared_preset():
            self.is_custom = True
        self.outcome = None

    @property
    def display_name(self) -> str:
        base = self.scenario.name or "Untitled scenario"
        return f"{base} (Custom)" if self.is_custom else base

    @property
    def config_hash(self) -> str:
        return config_hash(self.scenario)

    def diff_against_preset(self) -> list[dict[str, Any]]:
        from .presets import diff_against_preset
        return diff_against_preset(self.scenario)

    # ---------------- validation ----------------
    def validate(self) -> ValidationReport:
        return validate_scenario(self.scenario)

    def preflight(self) -> dict[str, Any]:
        return preflight(self.scenario)

    # ---------------- running ----------------
    def run(self, *, on_progress: Callable[[float, str], None] | None = None,
            parallel: bool | None = None,
            max_workers: int | None = None) -> ExperimentOutcome:
        """Run the configured experiment synchronously.

        GUI callers should invoke this on a worker thread so the interface
        stays responsive; the cancellation token makes that safe.
        """

        self.cancel_token = CancellationToken()
        self.progress = RunProgress(running=True, message="starting")
        self.last_error = None

        def _progress(frac: float, msg: str) -> None:
            self.progress.update(frac, msg)
            if on_progress is not None:
                on_progress(frac, msg)

        try:
            outcome = run_experiment(
                self.scenario, cancel=self.cancel_token, progress=_progress,
                parallel=parallel, max_workers=max_workers)
        except Exception as exc:
            self.progress.running = False
            self.progress.finished = True
            self.progress.error = str(exc)
            self.last_error = str(exc)
            raise
        finally:
            self.progress.running = False

        self.progress.finished = True
        self.progress.fraction = 1.0
        self.outcome = outcome
        return outcome

    def cancel(self, reason: str = "cancelled by user") -> None:
        if self.cancel_token is not None:
            self.cancel_token.cancel(reason)

    # ---------------- results access ----------------
    @property
    def runs(self) -> list[RunResult]:
        return self.outcome.runs if self.outcome else []

    @property
    def primary_run(self) -> RunResult | None:
        runs = self.runs
        return runs[0] if runs else None

    def summary_frame(self) -> pd.DataFrame:
        from ..analysis.aggregation import summary_table
        runs = self.runs
        return summary_table(runs) if runs else pd.DataFrame()

    def report_text(self) -> str:
        return self.outcome.report_text() if self.outcome else "No results yet."

    # ---------------- external-AI assistance (offline) ----------------
    def experiment_description(self):
        from ..ai_assist import describe_scenario
        return describe_scenario(self.scenario)

    def ai_report(self, include_time_series_appendix: bool = False):
        from ..ai_assist import build_ai_report
        if self.outcome is None:
            raise RuntimeError("no results yet")
        return build_ai_report(self.outcome,
                               include_time_series_appendix=include_time_series_appendix)

    def preview_import(self, text: str):
        """Stage an external scenario. Never changes the active scenario."""

        from ..ai_assist import import_scenario_text
        return import_scenario_text(text)

    def apply_import(self, result) -> None:
        """Apply a previously previewed, valid import (explicit user action)."""

        if result is None or not result.ok or result.scenario is None:
            raise ValueError("cannot apply an import that did not pass validation")
        self.update_scenario(result.scenario)

    def export_bundle(self, directory: str, **kwargs) -> str:
        from ..export import export_bundle
        run = self.primary_run
        if run is None:
            raise RuntimeError("nothing to export: no run has completed")

        payload = self.outcome.payload if self.outcome else None
        rep = sweep = None
        if payload is not None:
            if hasattr(payload, "cells"):
                sweep = payload
            elif hasattr(payload, "runs"):
                rep = payload
        return export_bundle(directory, run, replication_result=rep,
                             sweep_result=sweep, outcome=self.outcome, **kwargs)

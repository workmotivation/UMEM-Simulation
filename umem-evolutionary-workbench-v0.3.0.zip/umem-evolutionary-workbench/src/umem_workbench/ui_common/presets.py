"""Simple-mode controls and their explicit mapping to advanced parameters
(Master Prompt sections 16.1 and 23).

Design rule from the specification: *never let a simple slider ambiguously
modify many hidden values without showing the mapping*. Every control below
declares exactly which configuration paths it touches and how, and
:func:`describe_mapping` renders that declaration for display in the UI.
:func:`diff_against_preset` implements the required "View changes" function.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..config.models import ScenarioConfig
from ..config.presets import load_preset
from ..config.serialization import scenario_from_dict, scenario_to_dict

__all__ = [
    "SimpleControl",
    "SIMPLE_CONTROLS",
    "SimpleSettings",
    "apply_simple_settings",
    "read_simple_settings",
    "describe_mapping",
    "diff_against_preset",
    "NONFUNCTIONAL_DEMO_TASKS",
]

#: The two demonstration tasks toggled by the "neutral behaviour" control.
NONFUNCTIONAL_DEMO_TASKS = ("neutral_idle", "costly_dance")


@dataclass(frozen=True)
class SimpleControl:
    """A simple-mode control and the advanced parameters it drives."""

    key: str
    label: str
    help: str
    kind: str                      # "slider" | "number" | "select" | "checkbox"
    affects: tuple[str, ...]       # human-readable description of each target
    minimum: float | None = None
    maximum: float | None = None
    step: float | None = None
    options: tuple[str, ...] = ()
    unit: str = ""


SIMPLE_CONTROLS: tuple[SimpleControl, ...] = (
    SimpleControl(
        "resource_abundance", "Resource abundance",
        "Scales the long-run mean of food-like environmental variables. "
        "Predator variables are deliberately left untouched.",
        "slider", ("environment.<food vars>.mean",
                   "environment.<food vars>.initial_value"),
        minimum=0.05, maximum=1.0, step=0.05),
    SimpleControl(
        "environmental_volatility", "Environmental volatility",
        "Scales the innovation standard deviation of every environmental "
        "variable, and optionally the shock probability. Both components stay "
        "visible and editable in Advanced mode.",
        "slider", ("environment.*.volatility",
                   "environment.*.shock_probability (optional)"),
        minimum=0.0, maximum=0.5, step=0.01),
    SimpleControl(
        "predation_pressure", "Predation pressure",
        "Adjusts the predator variable's mean together with the base predation "
        "hazard, so perceived and realised danger move together.",
        "slider", ("environment.predator.mean",
                   "mortality.base_predation_hazard"),
        minimum=0.0, maximum=1.0, step=0.05),
    SimpleControl(
        "initial_population", "Initial population",
        "Number of agents at the start of the run.",
        "number", ("population.initial_population",),
        minimum=10, maximum=5000, step=10, unit="agents"),
    SimpleControl(
        "carrying_capacity", "Carrying capacity",
        "Population level at which crowding effects become significant.",
        "number", ("population.carrying_capacity",),
        minimum=10, maximum=10000, step=10, unit="agents"),
    SimpleControl(
        "average_lifespan", "Average lifespan",
        "Adjusts senescence and the hard lifespan ceiling together so they "
        "stay mutually consistent.",
        "slider", ("lifecycle.max_lifespan_seasons",
                   "mortality.age_hazard_scale", "mortality.age_hazard_rate"),
        minimum=2, maximum=30, step=1, unit="seasons"),
    SimpleControl(
        "maturity_age", "Maturity age",
        "Age at which agents become able to reproduce. Capped at the maximum "
        "lifespan.",
        "number", ("lifecycle.maturity_seasons",),
        minimum=0, maximum=15, step=1, unit="seasons"),
    SimpleControl(
        "fertility", "Fertility / offspring rate",
        "Mean of the configured offspring distribution. The distribution "
        "family and its per-event cap are preserved.",
        "slider", ("reproduction.fertility_mean",),
        minimum=0.0, maximum=8.0, step=0.1, unit="offspring/event"),
    SimpleControl(
        "mutation_strength", "Mutation strength",
        "Magnitude of heritable mutation (lognormal sd). Mutation probability "
        "is left alone, because changing both at once would confound rate with "
        "size of effect.",
        "slider", ("inheritance.mutation_log_sd",),
        minimum=0.0, maximum=0.5, step=0.01),
    SimpleControl(
        "cognition_mode", "Cognition mode",
        "Switches cognitive modules on or off without touching any unrelated "
        "parameter.",
        "select", ("cognition.experience_enabled", "cognition.forecast_enabled"),
        options=("none", "experience", "forecast", "both")),
    SimpleControl(
        "homeostasis_enabled", "Homeostasis",
        "Internal state urgencies (hunger, threat, reproductive readiness). "
        "This is physiological regulation, not cognition.",
        "checkbox", ("homeostasis.enabled",)),
    SimpleControl(
        "nonfunctional_enabled", "Costly nonfunctional behaviour",
        "Enables the two demonstration tasks with no modelled benefit: a "
        "low-cost neutral one and a costly nonfunctional one.",
        "checkbox", tuple(f"tasks.{t}.enabled" for t in NONFUNCTIONAL_DEMO_TASKS)),
    SimpleControl(
        "total_seasons", "Number of seasons",
        "Length of the run.",
        "number", ("lifecycle.total_seasons",),
        minimum=1, maximum=500, step=1, unit="seasons"),
    SimpleControl(
        "replications", "Number of replications",
        "Independent repeats of the same scenario, differing only in RNG "
        "substream.",
        "number", ("experiment.replications", "experiment.mode"),
        minimum=1, maximum=200, step=1, unit="runs"),
    SimpleControl(
        "reproduction_mode", "Reproduction mode",
        "Sexual reproduction needs one Type-A and one Type-B agent per event; "
        "asexual needs none and produces clonal offspring.",
        "select", ("reproduction.mode",), options=("sexual", "asexual")),
    SimpleControl(
        "reproduction_timing", "Reproduction timing",
        "Continuous reproduction treats every time step as an opportunity to "
        "breed. Season-end is a compatibility mode reproducing the old "
        "behaviour; it makes population size pulse once per season.",
        "select", ("reproduction.timing",),
        options=("distributed", "season_end_legacy")),
    SimpleControl(
        "mating_mode", "Mating mode",
        "Random mixing (promiscuity), pair bonding (social monogamy), or "
        "competitive (polygyny-like reproductive skew). Ignored under asexual "
        "reproduction.",
        "select", ("reproduction.mating_mode",),
        options=("random", "pair_bonded", "competitive")),
    SimpleControl(
        "mate_choice_k", "Choosiness (k)",
        "How many candidates an agent inspects before choosing a mate. 1 is "
        "unbiased random mating; larger values concentrate reproductive "
        "success among higher-quality agents.",
        "number", ("reproduction.mate_choice_k",),
        minimum=1, maximum=100, step=1, unit="candidates"),
    SimpleControl(
        "reproductive_rate", "Reproductive rate",
        "Expected reproductive events per eligible agent per season. A rate, "
        "so changing the number of steps per season does not change it.",
        "slider", ("reproduction.reproductive_event_rate",),
        minimum=0.0, maximum=10.0, step=0.1, unit="events/agent/season"),
    SimpleControl(
        "founder_age_distribution", "Founder ages",
        "Whether the starting population all begins at age zero (legacy), is "
        "spread evenly over the lifespan, or approximates a stable age "
        "structure.",
        "select", ("population.founder_age_distribution",),
        options=("all_newborn_legacy", "uniform", "stable")),
    SimpleControl(
        "inheritance_model", "Inheritance model",
        "Polygenic additive uses Fisher's infinitesimal model on a latent "
        "scale. Legacy is the pre-schema-2 mechanism, kept for compatibility.",
        "select", ("inheritance.model",),
        options=("polygenic_additive", "legacy")),
    SimpleControl(
        "sibling_variation", "Sibling genetic variation",
        "How much full siblings differ through Mendelian segregation. At "
        "'standard' the founder genetic variance is the equilibrium.",
        "select", ("inheritance.sibling_variation",),
        options=("low", "standard", "high")),
    SimpleControl(
        "mutation_level", "Mutation level",
        "Rare introduction of new genetic variation, separate from "
        "segregation. These are effective simulation parameters, not human "
        "per-base mutation rates.",
        "select", ("inheritance.mutation_level",),
        options=("none", "conservative", "accelerated")),
    SimpleControl(
        "master_seed", "Master seed",
        "Every random stream derives from this seed, so the same seed "
        "reproduces the same results.",
        "number", ("master_seed",), minimum=0, maximum=2 ** 31 - 2, step=1),
)


@dataclass
class SimpleSettings:
    """The current values of the simple-mode controls."""

    resource_abundance: float | None = None
    environmental_volatility: float | None = None
    predation_pressure: float | None = None
    initial_population: int | None = None
    carrying_capacity: int | None = None
    average_lifespan: int | None = None
    maturity_age: int | None = None
    fertility: float | None = None
    mutation_strength: float | None = None
    cognition_mode: str | None = None
    homeostasis_enabled: bool | None = None
    nonfunctional_enabled: bool | None = None
    total_seasons: int | None = None
    replications: int | None = None
    master_seed: int | None = None
    volatility_scales_shocks: bool = False
    # --- schema 2: reproduction and inheritance ---
    reproduction_mode: str | None = None        # sexual | asexual
    reproduction_timing: str | None = None      # distributed | season_end_legacy
    mating_mode: str | None = None              # random | pair_bonded | competitive
    mate_choice_k: int | None = None
    reproductive_rate: float | None = None
    founder_age_distribution: str | None = None
    inheritance_model: str | None = None
    sibling_variation: str | None = None        # low | standard | high
    mutation_level: str | None = None           # none | conservative | accelerated


def _is_food_like(var: dict[str, Any]) -> bool:
    """Food-like variables are resources; predator variables are not.

    Identified by id/name rather than position so a custom environment with
    differently ordered variables still behaves sensibly.
    """

    ident = f"{var.get('var_id', '')} {var.get('name', '')}".lower()
    if any(word in ident for word in ("predator", "predation", "threat", "danger")):
        return False
    return any(word in ident for word in ("food", "resource", "forage", "prey"))


def _is_predator_like(var: dict[str, Any]) -> bool:
    ident = f"{var.get('var_id', '')} {var.get('name', '')}".lower()
    return any(word in ident for word in ("predator", "predation", "threat"))


def apply_simple_settings(scenario: ScenarioConfig,
                          settings: SimpleSettings) -> ScenarioConfig:
    """Return a new scenario with the simple-mode settings applied.

    Only settings that are not ``None`` are applied, so the function can be
    called with a partially populated :class:`SimpleSettings`.
    """

    data = scenario_to_dict(scenario)

    if settings.resource_abundance is not None:
        for var in data.get("environment", []):
            if _is_food_like(var):
                var["mean"] = float(settings.resource_abundance)
                var["initial_value"] = float(settings.resource_abundance)

    if settings.environmental_volatility is not None:
        for var in data.get("environment", []):
            var["volatility"] = float(settings.environmental_volatility)
            if settings.volatility_scales_shocks:
                # Map volatility onto shock probability on a modest scale so the
                # two components remain independently visible in Advanced mode.
                var["shock_probability"] = float(
                    min(0.25, settings.environmental_volatility * 0.4))

    if settings.predation_pressure is not None:
        pressure = float(settings.predation_pressure)
        for var in data.get("environment", []):
            if _is_predator_like(var):
                var["mean"] = pressure
                var["initial_value"] = pressure
        # Base hazard scales with pressure around the calibrated midpoint.
        data["mortality"]["base_predation_hazard"] = round(0.003 * pressure, 6)

    if settings.initial_population is not None:
        data["population"]["initial_population"] = int(settings.initial_population)
    if settings.carrying_capacity is not None:
        data["population"]["carrying_capacity"] = int(settings.carrying_capacity)

    if settings.average_lifespan is not None:
        span = max(2, int(settings.average_lifespan))
        data["lifecycle"]["max_lifespan_seasons"] = span
        # Senescence is tuned so the age hazard becomes material near the
        # ceiling rather than being independent of it.
        data["mortality"]["age_hazard_rate"] = round(1.5 / span, 4)
        data["mortality"]["age_hazard_scale"] = 0.0008
        if data["lifecycle"]["maturity_seasons"] > span:
            data["lifecycle"]["maturity_seasons"] = span

    if settings.maturity_age is not None:
        data["lifecycle"]["maturity_seasons"] = min(
            int(settings.maturity_age), data["lifecycle"]["max_lifespan_seasons"])

    if settings.fertility is not None:
        data["reproduction"]["fertility_mean"] = float(settings.fertility)

    if settings.mutation_strength is not None:
        data["inheritance"]["mutation_log_sd"] = float(settings.mutation_strength)

    if settings.cognition_mode is not None:
        mode = str(settings.cognition_mode).lower()
        data["cognition"]["experience_enabled"] = mode in ("experience", "both")
        data["cognition"]["forecast_enabled"] = mode in ("forecast", "both")

    if settings.homeostasis_enabled is not None:
        data["homeostasis"]["enabled"] = bool(settings.homeostasis_enabled)

    if settings.nonfunctional_enabled is not None:
        for task in data.get("tasks", []):
            if task.get("task_id") in NONFUNCTIONAL_DEMO_TASKS:
                task["enabled"] = bool(settings.nonfunctional_enabled)

    if settings.total_seasons is not None:
        data["lifecycle"]["total_seasons"] = int(settings.total_seasons)

    if settings.replications is not None:
        reps = int(settings.replications)
        data["experiment"]["replications"] = reps
        if data["experiment"]["mode"] != "sweep":
            data["experiment"]["mode"] = "replications" if reps > 1 else "single"

    if settings.reproduction_mode is not None:
        data["reproduction"]["mode"] = str(settings.reproduction_mode)
    if settings.reproduction_timing is not None:
        data["reproduction"]["timing"] = str(settings.reproduction_timing)
    if settings.mating_mode is not None:
        data["reproduction"]["mating_mode"] = str(settings.mating_mode)
    if settings.mate_choice_k is not None:
        data["reproduction"]["mate_choice_k"] = int(settings.mate_choice_k)
    if settings.reproductive_rate is not None:
        data["reproduction"]["reproductive_event_rate"] = float(
            settings.reproductive_rate)
    if settings.founder_age_distribution is not None:
        data["population"]["founder_age_distribution"] = str(
            settings.founder_age_distribution)
    if settings.inheritance_model is not None:
        data["inheritance"]["model"] = str(settings.inheritance_model)
    if settings.sibling_variation is not None:
        data["inheritance"]["sibling_variation"] = str(settings.sibling_variation)
    if settings.mutation_level is not None:
        data["inheritance"]["mutation_level"] = str(settings.mutation_level)

    if settings.master_seed is not None:
        data["master_seed"] = int(settings.master_seed)

    return scenario_from_dict(data)


def read_simple_settings(scenario: ScenarioConfig) -> SimpleSettings:
    """Infer simple-mode control values from a full scenario.

    Used to populate the simple controls when a scenario is loaded, so the two
    modes stay in sync.
    """

    data = scenario_to_dict(scenario)
    env = data.get("environment", [])

    food = [v for v in env if _is_food_like(v)]
    predator = [v for v in env if _is_predator_like(v)]
    vol = [float(v.get("volatility", 0.0)) for v in env]

    cog = data.get("cognition", {})
    mode = "none"
    if cog.get("experience_enabled") and cog.get("forecast_enabled"):
        mode = "both"
    elif cog.get("experience_enabled"):
        mode = "experience"
    elif cog.get("forecast_enabled"):
        mode = "forecast"

    nonfunc = [t for t in data.get("tasks", [])
               if t.get("task_id") in NONFUNCTIONAL_DEMO_TASKS]

    return SimpleSettings(
        resource_abundance=(float(food[0].get("mean")) if food else None),
        environmental_volatility=(sum(vol) / len(vol) if vol else None),
        predation_pressure=(float(predator[0].get("mean")) if predator else None),
        initial_population=data["population"]["initial_population"],
        carrying_capacity=data["population"]["carrying_capacity"],
        average_lifespan=data["lifecycle"]["max_lifespan_seasons"],
        maturity_age=data["lifecycle"]["maturity_seasons"],
        fertility=data["reproduction"]["fertility_mean"],
        mutation_strength=data["inheritance"]["mutation_log_sd"],
        cognition_mode=mode,
        homeostasis_enabled=data["homeostasis"]["enabled"],
        nonfunctional_enabled=(all(t.get("enabled", True) for t in nonfunc)
                               if nonfunc else None),
        total_seasons=data["lifecycle"]["total_seasons"],
        replications=data["experiment"]["replications"],
        master_seed=data["master_seed"],
        reproduction_mode=data["reproduction"]["mode"],
        reproduction_timing=data["reproduction"]["timing"],
        mating_mode=data["reproduction"]["mating_mode"],
        mate_choice_k=data["reproduction"]["mate_choice_k"],
        reproductive_rate=data["reproduction"]["reproductive_event_rate"],
        founder_age_distribution=data["population"]["founder_age_distribution"],
        inheritance_model=data["inheritance"]["model"],
        sibling_variation=data["inheritance"]["sibling_variation"],
        mutation_level=data["inheritance"]["mutation_level"],
    )


def describe_mapping() -> list[dict[str, Any]]:
    """Render the control -> parameter mapping for display in the UI."""

    return [{
        "control": c.label,
        "key": c.key,
        "type": c.kind,
        "affects": ", ".join(c.affects),
        "range": (f"{c.minimum:g} to {c.maximum:g}"
                  if c.minimum is not None and c.maximum is not None
                  else ("; ".join(c.options) if c.options else "on / off")),
        "unit": c.unit,
        "explanation": c.help,
    } for c in SIMPLE_CONTROLS]


def diff_against_preset(scenario: ScenarioConfig,
                        preset_id: str | None = None
                        ) -> list[dict[str, Any]]:
    """The "View changes" function: how this scenario differs from its preset.

    Returns one row per changed configuration path. Cosmetic fields (name,
    description, preset origin) are ignored, matching the configuration hash.
    """

    preset_id = preset_id or scenario.preset_origin
    if not preset_id:
        return []
    try:
        baseline = scenario_to_dict(load_preset(preset_id))
    except KeyError:
        return []

    current = scenario_to_dict(scenario)
    ignored = {"name", "description", "preset_origin"}

    def _walk(a: Any, b: Any, path: str = "") -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        if isinstance(a, dict) and isinstance(b, dict):
            for key in sorted(set(a) | set(b)):
                if not path and key in ignored:
                    continue
                sub = f"{path}.{key}" if path else str(key)
                rows.extend(_walk(a.get(key), b.get(key), sub))
        elif isinstance(a, list) and isinstance(b, list):
            if len(a) != len(b):
                rows.append({"path": path, "preset_value": f"{len(a)} items",
                             "current_value": f"{len(b)} items"})
            else:
                for i, (x, y) in enumerate(zip(a, b)):
                    ident = i
                    if isinstance(x, dict):
                        ident = (x.get("task_id") or x.get("domain_id")
                                 or x.get("var_id") or i)
                    rows.extend(_walk(x, y, f"{path}.{ident}"))
        elif a != b:
            rows.append({"path": path, "preset_value": a, "current_value": b})
        return rows

    return _walk(baseline, current)

"""Longer explanatory text for the interfaces (Master Prompt sections 16, 20).

Field-level help comes from the model metadata (see :mod:`labels`). This module
holds the conceptual text: what a screen is for, what the scientific caveats
are, and how to read the trickier metrics.
"""

from __future__ import annotations

__all__ = [
    "ABOUT_TEXT",
    "DISCLAIMER_SHORT",
    "DISCLAIMERS",
    "SECTION_HELP",
    "METRIC_HELP",
    "SIMPLE_MODE_HELP",
    "COGNITION_HELP",
]

DISCLAIMER_SHORT = (
    "Abstract theoretical model. Illustrative parameters, not empirically "
    "calibrated. No claims about consciousness or subjective experience."
)

DISCLAIMERS = [
    ("Theoretical model",
     "This is an abstract evolutionary model. Every default value is an "
     "illustrative demonstration setting chosen so the simulation behaves in a "
     "numerically usable way. None of them is calibrated to a real species, "
     "and no quantitative result here should be read as an empirical estimate."),
    ("The 'motivational gene' is a construct",
     "Agents carry heritable numbers that bias how they allocate behaviour. "
     "This is a functional modelling construct. It does not correspond to any "
     "identified genetic locus, and real motivational variation is polygenic, "
     "developmental, and environmentally contingent."),
    ("No claims about consciousness",
     "Nothing in this model represents subjective experience, felt desire, or "
     "awareness. 'Motivation' here means a propensity to allocate behaviour, "
     "and 'cognition' means specific information-processing mechanisms that "
     "are switched on or off explicitly."),
    ("Fitness is an outcome, not a target",
     "Agents are never scored against a survival or utility function. Fitness "
     "is realised lifetime reproductive success: how many surviving offspring "
     "an individual actually left. Selection is whatever falls out of birth "
     "and death in the simulated ecology."),
    ("Propensity is not allocation",
     "Recorded propensities are inherited tendencies. Realised time and energy "
     "allocation also reflects homeostatic urgency, task eligibility, and any "
     "cognition that is enabled. The two curves routinely diverge, and that "
     "divergence is itself an object of study."),
    ("Single runs prove nothing",
     "Results are stochastic. A single trajectory can show any pattern by "
     "chance. Use replicated runs and report uncertainty intervals."),
]

ABOUT_TEXT = """\
## UMEM Evolutionary Simulation Workbench

An open-source research tool for exploring how heritable, motivation-like
behavioural allocation propensities might evolve in abstract biological agents
with finite lives, internal homeostatic state, environmental uncertainty,
survival hazards, reproduction, and optional limited cognition.

### What the model does

Agents live for a finite number of seasons. In each time step an agent chooses
a task from a configurable library, weighted by its heritable propensities, its
homeostatic urgencies, and any cognitive mechanisms that are enabled. Tasks cost
energy and time, succeed or fail stochastically depending on the environment,
and have configurable effects on energy, health, reproductive capital,
observation quality, and hazard exposure. Agents die from starvation, injury,
predation, senescence, background hazard, crowding, or juvenile mortality.
Survivors that meet the reproductive thresholds breed, and offspring inherit
recombined and mutated propensities.

### What it is for

The tool is designed to make one question tractable: under what ecological
conditions does behaviour that has *no modelled benefit* nevertheless persist,
and when does adding cognition make that worse rather than better? It therefore
tracks nonfunctional and neutral behaviour explicitly, and reports several
transparent misallocation diagnostics rather than a single opaque index.

### What it is not

It is not a model of any particular species, not a claim about human
psychology, and not a simulation of conscious experience. It is a theoretical
sandbox whose value lies in the qualitative contrasts it can generate, not in
the absolute numbers it produces.
"""

SIMPLE_MODE_HELP = """\
Simple mode exposes a small number of high-level controls that adjust many
underlying parameters together. It is intended for teaching and first
exploration. Every simple-mode control maps onto explicit parameters that you
can inspect and override in Advanced mode; nothing is hidden, only bundled.
"""

COGNITION_HELP = """\
Three independent cognitive mechanisms can be enabled, alone or together.

**A - Intergenerational experience.** A population-level memory of which tasks
were associated with successful agents in recent cohorts, which then biases
choice. The association is *correlational*: a task can become well represented
simply because successful agents had the time to do it. This is the primary
route to cognitive misallocation in the model.

**B - Noisy environmental forecasting.** An exponentially weighted forecast of
each environmental variable, which shifts preference toward tasks whose success
depends on that variable. The forecast is built only from past noisy
observations; there is no look-ahead to the true future state.

**C - Individual learning (advanced).** Per-agent reinforcement from an agent's
own recent outcomes. Off by default, because it introduces within-lifetime
adaptation that can mask the evolutionary signal the model is designed to show.

With all three disabled the model is a pure evolutionary baseline: behaviour is
driven only by inherited propensity and homeostatic state.
"""

SECTION_HELP: dict[str, str] = {
    "domains":
        "Broad motivational categories (food, safety, reproduction, neutral). "
        "Each agent inherits one propensity per domain, and a second "
        "propensity for each task within a domain.",
    "tasks":
        "The behaviours agents can choose. A task's role label declares "
        "whether it is functional, low-cost neutral, or costly nonfunctional; "
        "its effect rules determine what it actually does. The validator warns "
        "when these disagree.",
    "environment":
        "Environmental variables evolve by a configurable stochastic process "
        "and drive task success, predation, and mate availability. Agents "
        "perceive them only through noisy observation.",
    "population":
        "Starting size, carrying capacity, and a hard population ceiling. "
        "Carrying capacity regulates crowding; the ceiling is a safety limit "
        "on memory use.",
    "lifecycle":
        "Time structure and metabolic accounting: steps per season, total "
        "seasons, maturity age, maximum lifespan, and per-step energy costs.",
    "mortality":
        "Hazard sources and their strengths. Hazards combine as independent "
        "competing risks, and the cause of each death is attributed in "
        "proportion to the contributing hazards.",
    "reproduction":
        "Breeding thresholds, mate selection, fertility distribution, and "
        "juvenile survival. Density-dependent recruitment softens juvenile "
        "survival as the population approaches carrying capacity.",
    "inheritance":
        "How offspring propensities derive from parents: per-trait parental "
        "selection or blending, plus multiplicative lognormal mutation.",
    "homeostasis":
        "Internal state urgencies (hunger, threat, reproductive readiness) "
        "that shift task preference. This is deliberately *not* cognition: it "
        "is unlearned physiological regulation and stays active even with all "
        "cognitive mechanisms disabled.",
    "cognition": COGNITION_HELP,
    "choice":
        "The decision policy that converts propensities, urgencies, and "
        "cognitive signals into task probabilities. Contributions are additive "
        "in log-odds and passed through a softmax.",
    "experiment":
        "Single run, replications, or a parameter sweep of up to three "
        "parameters.",
    "output":
        "Recording interval and optional individual-level sampling. Longer "
        "intervals reduce memory use at the cost of temporal resolution.",
}

METRIC_HELP: dict[str, str] = {
    "opportunity_for_selection_I":
        "Crow's index: variance in lifetime reproductive success divided by "
        "the square of its mean. It is an upper bound on the strength of "
        "selection, not a measure of selection actually acting on any trait.",
    "cognitive_amplification_ratio":
        "Nonfunctional behaviour with cognition enabled, divided by the same "
        "quantity in a matched no-cognition baseline. When the baseline is "
        "near zero the ratio is unstable, so the additive difference is "
        "reported alongside it and should be preferred in that case.",
    "experience_mismatch_total_abs":
        "How far the intergenerational memory's representation of each task "
        "departs from that task's configured objective contribution. Large "
        "values on tasks with no modelled benefit indicate that memory is "
        "crediting a causally inert behaviour.",
    "forecast_mae_mean":
        "Mean absolute error of the environmental forecast against the true "
        "state, averaged over variables. Distinct from observation error, "
        "which measures perception rather than anticipation.",
    "nonfunctional_persistence_ratio":
        "Final nonfunctional action rate divided by its initial value. Above "
        "one means costly pointless behaviour became more common over the run.",
    "variance_retained_fraction":
        "Remaining within-population variance in domain propensities relative "
        "to the start. Values near zero mean heritable variation has been "
        "exhausted and further selection cannot act.",
    "one_step_regret_proxy":
        "A local, single-step diagnostic only. It is not a fitness measure and "
        "must not be interpreted as one.",
    "extinction_rate":
        "Fraction of replications whose population reached zero, with a "
        "Wilson score interval. Wilson is used because extinction counts are "
        "often 0 or n, where a normal interval would imply false certainty.",
}

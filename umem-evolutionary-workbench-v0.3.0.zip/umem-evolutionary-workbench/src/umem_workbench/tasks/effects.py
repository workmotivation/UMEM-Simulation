"""Vectorised application of task effect rules to agent state.

Each effect rule fires for the agents that chose its task, if the rule's
success/failure condition and any age/maturity/sex gate are met. Effects can be
additive, multiplicative, a probability (logit) modifier, or a bounded
replacement, optionally scaled by a linked environment variable and perturbed by
noise. Hazard and observation-quality effects are accumulated and returned to the
caller rather than written to a state array.
"""

from __future__ import annotations

import numpy as np

from ..engine.compiled import (
    TARGET_ENERGY,
    TARGET_HAZARD,
    TARGET_HEALTH,
    TARGET_OBS,
    TARGET_REPRO,
    TARGET_STATUS,
    TYPE_ADDITIVE,
    TYPE_MULT,
    TYPE_PROB,
    TYPE_REPLACE,
    CompiledScenario,
)
from ..engine.state import AgentPool


def apply_effects(pool: AgentPool, cs: CompiledScenario, chosen: np.ndarray,
                  success: np.ndarray, env_now: np.ndarray,
                  rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Apply all effect rules for one action draw.

    Returns
    -------
    hazard_mult : per-agent multiplicative hazard modifier (default 1).
    hazard_add : per-agent additive hazard modifier (default 0).
    obs_quality : per-agent observation-quality bonus (default 0).
    """

    n = pool.n
    lc = pool.scenario.lifecycle
    hazard_mult = np.ones(n)
    hazard_add = np.zeros(n)
    obs_quality = np.zeros(n)

    R = cs.eff_task_idx.shape[0]
    for r in range(R):
        task_i = int(cs.eff_task_idx[r])
        sel = chosen == task_i
        if not sel.any():
            continue
        cond = int(cs.eff_condition[r])
        if cond == 1:      # on success
            sel = sel & success
        elif cond == 2:    # on failure
            sel = sel & ~success
        # Gating.
        if bool(cs.eff_require_mature[r]):
            sel = sel & pool.reached_maturity
        if cs.eff_min_age[r] > 0:
            sel = sel & (pool.age_steps >= cs.eff_min_age[r])
        srx = int(cs.eff_sex[r])
        if srx >= 0:
            sel = sel & (pool.sex == srx)
        if not sel.any():
            continue

        idx = np.where(sel)[0]
        env_i = int(cs.eff_env_idx[r])
        env_scale = 0.0
        if env_i >= 0:
            env_scale = cs.eff_env_sens[r] * env_now[env_i]
        value = cs.eff_base[r] + env_scale
        vals = np.full(idx.shape[0], value)
        if cs.eff_noise[r] > 0:
            vals = vals + rng.normal(0.0, cs.eff_noise[r], size=idx.shape[0])

        target = int(cs.eff_target[r])
        etype = int(cs.eff_type[r])
        _apply_to_target(pool, target, etype, idx, vals, lc,
                         hazard_mult, hazard_add, obs_quality)

    # Clip state variables to their bounds after all rules.
    np.clip(pool.energy, 0.0, lc.energy_max, out=pool.energy)
    np.clip(pool.health, 0.0, lc.health_max, out=pool.health)
    np.clip(pool.repro_capital, 0.0, lc.repro_capital_max, out=pool.repro_capital)
    np.clip(pool.status, 0.0, lc.status_max, out=pool.status)
    return hazard_mult, hazard_add, obs_quality


def _apply_to_target(pool, target, etype, idx, vals, lc,
                     hazard_mult, hazard_add, obs_quality) -> None:
    if target == TARGET_ENERGY:
        _combine(pool.energy, idx, vals, etype, lc.energy_max)
    elif target == TARGET_HEALTH:
        _combine(pool.health, idx, vals, etype, lc.health_max)
    elif target == TARGET_REPRO:
        _combine(pool.repro_capital, idx, vals, etype, lc.repro_capital_max)
    elif target == TARGET_STATUS:
        _combine(pool.status, idx, vals, etype, lc.status_max)
    elif target == TARGET_HAZARD:
        if etype == TYPE_MULT:
            hazard_mult[idx] *= np.maximum(vals, 0.0)
        else:  # additive / prob / replacement all treated additively on hazard
            hazard_add[idx] += vals
    elif target == TARGET_OBS:
        obs_quality[idx] += vals


def _combine(state: np.ndarray, idx: np.ndarray, vals: np.ndarray, etype: int,
             cap: float) -> None:
    if etype == TYPE_ADDITIVE:
        state[idx] += vals
    elif etype == TYPE_MULT:
        state[idx] *= vals
    elif etype == TYPE_PROB:
        # Interpret as additive nudge on a 0..cap state (documented simplification).
        state[idx] += vals
    elif etype == TYPE_REPLACE:
        state[idx] = np.clip(vals, 0.0, cap)


__all__ = ["apply_effects"]

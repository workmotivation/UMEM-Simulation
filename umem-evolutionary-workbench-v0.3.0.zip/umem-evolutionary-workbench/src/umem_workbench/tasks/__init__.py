"""Task library, effect application, and default tasks/domains."""

from __future__ import annotations

from . import defaults

__all__ = ["defaults"]

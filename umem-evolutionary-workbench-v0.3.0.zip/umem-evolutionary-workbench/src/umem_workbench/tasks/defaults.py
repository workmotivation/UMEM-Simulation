"""Illustrative default task library and domains (Master Prompt section 21).

These values are *starting points for exploration*, not empirical biological
estimates. State variables use a normalised 0--100 scale. Every coefficient is
editable in the UI and in scenario files. Defaults were sanity-checked with
smoke simulations so the principal presets neither go extinct immediately nor
explode uncontrollably; calibration adjustments are documented in
``docs/known_limitations`` and the CHANGELOG.
"""

from __future__ import annotations

from ..config.enums import (
    EffectCondition,
    EffectTarget,
    EffectType,
    TaskRole,
)
from ..config.models import DomainConfig, TaskConfig, TaskEffectRule

# Domain identifiers used throughout the default library.
DOMAIN_FOOD = "food"
DOMAIN_SAFETY = "safety"
DOMAIN_REPRODUCTION = "reproduction"
DOMAIN_NEUTRAL = "neutral"


def default_domains() -> list[DomainConfig]:
    return [
        DomainConfig(domain_id=DOMAIN_FOOD, name="Food",
                     init_mean=1.0, init_var=0.5),
        DomainConfig(domain_id=DOMAIN_SAFETY, name="Safety",
                     init_mean=1.0, init_var=0.5),
        DomainConfig(domain_id=DOMAIN_REPRODUCTION, name="Reproduction",
                     init_mean=1.0, init_var=0.5),
        DomainConfig(domain_id=DOMAIN_NEUTRAL, name="Neutral / other",
                     init_mean=1.0, init_var=0.5),
    ]


def _energy_gain(value: float, driver: str | None = None,
                 sensitivity: float = 0.0) -> TaskEffectRule:
    return TaskEffectRule(
        target=EffectTarget.ENERGY, effect_type=EffectType.ADDITIVE,
        base_value=value, condition=EffectCondition.ON_SUCCESS,
        env_driver=driver, env_sensitivity=sensitivity,
    )


def default_tasks(include_nonfunctional: bool = True) -> list[TaskConfig]:
    """Return the default illustrative task list.

    Parameters
    ----------
    include_nonfunctional : whether to include the two demonstration
        nonfunctional tasks (toggled by the Simple-mode "neutral behaviour"
        control).
    """

    tasks: list[TaskConfig] = [
        # ----- Food domain -----
        TaskConfig(
            task_id="safe_forage", name="Safe Foraging", domain=DOMAIN_FOOD,
            description="Moderate food gain, high success, low exposure.",
            energy_cost=1.0, base_success=0.20,
            success_env_driver="food", success_env_sensitivity=3.0,
            outcome_noise=0.3, predation_multiplier=0.9,
            role=TaskRole.FUNCTIONAL,
            effects=[_energy_gain(8.0)],
        ),
        TaskConfig(
            task_id="risky_forage", name="Risky Foraging", domain=DOMAIN_FOOD,
            description="High food gain, variable success, high exposure.",
            energy_cost=2.0, base_success=0.10,
            success_env_driver="food", success_env_sensitivity=3.0,
            outcome_noise=0.4, predation_multiplier=1.6,
            role=TaskRole.FUNCTIONAL,
            effects=[_energy_gain(18.0)],
        ),
        TaskConfig(
            task_id="scavenge", name="Exploration/Scavenging", domain=DOMAIN_FOOD,
            description="Rare high gain, high variance, substantial cost.",
            energy_cost=3.0, base_success=0.06,
            success_env_driver="food", success_env_sensitivity=2.0,
            outcome_noise=0.5, predation_multiplier=1.8,
            role=TaskRole.FUNCTIONAL,
            effects=[_energy_gain(25.0)],
        ),
        # ----- Safety domain -----
        TaskConfig(
            task_id="shelter", name="Shelter/Hide", domain=DOMAIN_SAFETY,
            description="Strong predation reduction, small recovery, no food.",
            energy_cost=1.0, base_success=0.95, outcome_noise=0.1,
            predation_multiplier=0.35, role=TaskRole.FUNCTIONAL,
            effects=[TaskEffectRule(target=EffectTarget.HEALTH,
                                    effect_type=EffectType.ADDITIVE,
                                    base_value=1.0,
                                    condition=EffectCondition.ON_SUCCESS)],
        ),
        TaskConfig(
            task_id="vigilance", name="Vigilance", domain=DOMAIN_SAFETY,
            description="Moderate predation reduction, better threat sensing.",
            energy_cost=1.5, base_success=0.9, outcome_noise=0.1,
            predation_multiplier=0.55, role=TaskRole.FUNCTIONAL,
            effects=[TaskEffectRule(target=EffectTarget.OBSERVATION_QUALITY,
                                    effect_type=EffectType.ADDITIVE,
                                    base_value=1.0,
                                    condition=EffectCondition.ON_SUCCESS)],
        ),
        TaskConfig(
            task_id="flee_defend", name="Flee/Defend", domain=DOMAIN_SAFETY,
            description="Strong attack-survival boost, injury risk.",
            energy_cost=4.0, base_success=0.7, outcome_noise=0.2,
            predation_multiplier=0.5, role=TaskRole.FUNCTIONAL,
            effects=[TaskEffectRule(target=EffectTarget.HEALTH,
                                    effect_type=EffectType.ADDITIVE,
                                    base_value=-4.0,
                                    condition=EffectCondition.ON_FAILURE)],
        ),
        # ----- Reproduction domain -----
        TaskConfig(
            task_id="mate_search", name="Mate Search", domain=DOMAIN_REPRODUCTION,
            description="Reproductive-capital gain linked to mate availability.",
            energy_cost=3.0, base_success=0.5,
            success_env_driver="mate", success_env_sensitivity=2.0,
            outcome_noise=0.3, predation_multiplier=1.1, require_mature=True,
            role=TaskRole.FUNCTIONAL,
            effects=[TaskEffectRule(target=EffectTarget.REPRO_CAPITAL,
                                    effect_type=EffectType.ADDITIVE,
                                    base_value=8.0,
                                    condition=EffectCondition.ON_SUCCESS,
                                    env_driver="mate", env_sensitivity=4.0)],
        ),
        TaskConfig(
            task_id="courtship", name="Courtship Display", domain=DOMAIN_REPRODUCTION,
            description="Larger capital gain, status-dependent, higher exposure.",
            energy_cost=5.0, base_success=0.45, outcome_noise=0.3,
            predation_multiplier=1.3, require_mature=True,
            role=TaskRole.FUNCTIONAL,
            effects=[TaskEffectRule(target=EffectTarget.REPRO_CAPITAL,
                                    effect_type=EffectType.ADDITIVE,
                                    base_value=14.0,
                                    condition=EffectCondition.ON_SUCCESS)],
        ),
        TaskConfig(
            task_id="territory", name="Territory/Nest Investment",
            domain=DOMAIN_REPRODUCTION,
            description="Persistent status/repro benefit, competition risk.",
            energy_cost=6.0, base_success=0.5, outcome_noise=0.3,
            predation_multiplier=1.1, require_mature=True,
            role=TaskRole.FUNCTIONAL,
            effects=[
                TaskEffectRule(target=EffectTarget.STATUS,
                               effect_type=EffectType.ADDITIVE, base_value=6.0,
                               condition=EffectCondition.ON_SUCCESS),
                TaskEffectRule(target=EffectTarget.HEALTH,
                               effect_type=EffectType.ADDITIVE, base_value=-3.0,
                               condition=EffectCondition.ON_FAILURE),
            ],
        ),
    ]

    if include_nonfunctional:
        tasks.extend([
            TaskConfig(
                task_id="neutral_idle", name="Low-Cost Neutral Behavior",
                domain=DOMAIN_NEUTRAL,
                description="No modelled benefit, minimal cost; persists by drift.",
                energy_cost=0.3, base_success=1.0, outcome_noise=0.0,
                predation_multiplier=1.0, role=TaskRole.LOW_COST_NEUTRAL,
                memory_eligible=True, effects=[],
            ),
            TaskConfig(
                task_id="costly_dance", name="Costly Dance-Like Behavior",
                domain=DOMAIN_NEUTRAL,
                description="No modelled benefit, meaningful cost; can be "
                            "amplified by cognition via successful-agent memory.",
                energy_cost=3.0, base_success=1.0, outcome_noise=0.0,
                predation_multiplier=1.05, role=TaskRole.COSTLY_NONFUNCTIONAL,
                memory_eligible=True, effects=[],
            ),
        ])

    return tasks


__all__ = [
    "DOMAIN_FOOD", "DOMAIN_SAFETY", "DOMAIN_REPRODUCTION", "DOMAIN_NEUTRAL",
    "default_domains", "default_tasks",
]

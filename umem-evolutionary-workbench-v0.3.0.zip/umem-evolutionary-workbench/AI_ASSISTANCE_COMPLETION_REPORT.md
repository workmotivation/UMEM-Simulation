# AI_ASSISTANCE_COMPLETION_REPORT.md

External-AI scenario design and results interpretation.

Version **0.3.0** · configuration schema **2** (unchanged) · 2026-09-09
Environment: Linux, Python 3.12, NumPy 2.4.4, Streamlit, PySide6 6.11.2

---

## 1. Status

Both workflows are implemented end to end and verified by running them, not only
by generating documents. The simulation engine is untouched: no equation,
default, or random-number consumption changed, and no preset was recalibrated.

| Deliverable | Status |
|---|---|
| Input workflow (guide → interview → JSON → import → preview → apply) | Complete, verified in web and desktop |
| Output workflow (guide + report → interpretation) | Complete, verified in web and desktop |
| Output-field registry and drift detection | Complete |
| Deterministic experiment description | Complete, zero uncovered parameters |
| Staged import with actionable errors | Complete, 10 adversarial cases |
| Report for single / replicated / sweep / extinct / cancelled / partial | Complete |
| Streamlit and PySide6 on shared services | Complete, both executed |
| Tests | 340 passed, 0 failed, 0 skipped (baseline 293) |
| No AI SDK, credential, network call or automatic upload | Verified by test |
| Windows/macOS packaging | **Unverified — never executed** |

This is not a documentation-only delivery: the import, validation, review,
narrative, report and UI features all exist and are tested.

---

## 2. Version and schema

Application version **0.2.1 → 0.3.0**. The configuration schema stays at **2**:
no scientific configuration field was added, renamed or removed, so existing
scenarios load unchanged and configuration hashes are unaffected.

Three new document-format versions are carried in every generated file:
`guide_format_version` 1.0, `report_format_version` 1.0,
`output_registry_format_version` 1.0, together with two deterministic
fingerprints — `parameter_dictionary_fingerprint` (inputs) and
`output_registry_fingerprint` (outputs). Cosmetic prose is excluded from the
dictionary fingerprint, so rewording help text does not look like a schema
change, and editing a guide cannot alter a scientific configuration hash.

---

## 3. Files

**New package `src/umem_workbench/ai_assist/`**

| Module | Purpose |
|---|---|
| `registry.py` | Output-field registry: six tables, each field with stable id, definition, measurement kind, unit, calculation, aggregation level, applicability, meaning of null, limitations, source files. Pattern fields (`domprop_<domain>`) expand against a concrete scenario. |
| `fingerprint.py` | Deterministic fingerprints and the identity header shared by guides and reports. |
| `narrative.py` | Rule-based experiment description. No language model, no network, deterministic. |
| `scenario_import.py` | Six-stage import, scenario diffing, AI repair feedback. |
| `guides.py` | Both guides, generated from the registries plus curated prose; embedded validated example; starter messages. |
| `report.py` | `AI_REPORT.md` builder and optional time-series appendix parts. |

**Modified**: `export/bundles.py` (bundle now carries the report and
interpretation guide), `ui_common/view_models.py` (`preview_import`,
`apply_import`, `experiment_description`, `ai_report`),
`ui_streamlit/app.py` (two pages plus a shared conditions panel),
`ui_desktop/app.py` (AI assistance tab), `cli.py` (`ai-guides`, `ai-import`,
`describe`), plus README, quick start, known limitations, changelog and a new
`docs/ai_assistance.md`.

**New tests**: `tests/unit/test_ai_assist.py` (40), additions to
`tests/ui_smoke/test_streamlit_app.py` (3) and `tests/ui_smoke/test_desktop_app.py` (2).

**Generated examples**: `docs/examples/ai_assist/` — both guides, a demonstration
report and a demonstration experiment description, each labelled a
demonstration and kept separate from user results.

---

## 4. Authoritative metadata

No second parameter registry was created. The design guide's parameter inventory
is generated from `config/data_dictionary.py`, which reads the Pydantic models
the engine and validator already use. The interpretation guide's output
dictionary is generated from the new output registry.

Drift detection: `test_registry_matches_real_exports` executes a run with
pair-bonding, cognition A and B, and agent sampling enabled, then asserts that
**every column of every exported table has a registry entry**. Undocumented
columns: **0** across `time_series` (111 columns), `breeding_series` (17),
`dead_log` (8), `agent_sample` (14) and `summary_metrics`. Changing an engine
field therefore cannot silently leave obsolete guide documentation.

Guide coverage is likewise asserted: **172 of 172** configuration parameters
appear in the design guide; **every** registry field id appears in the
interpretation guide. Missing coverage fails the build.

---

## 5. Input workflow

**Guide.** `AI_SCENARIO_DESIGN_GUIDE.md`, about 60 kB, self-contained: scientific
boundaries; the current model structure including reproduction timing and modes,
mating, eligibility, refractory period, founder ages, inheritance, segregation,
mutation, environment, tasks, cognition, replications, sweeps and recording; the
full parameter dictionary with units, constraints, applicability and legacy
marking; the declarative task/effect syntax and reference rules; an explicit list
of what the engine **cannot** represent; interview instructions; and the output
contract.

**Embedded example.** The complete `stable_abundant` scenario is emitted in full —
every domain, task, effect and environment variable, no ellipses, no dependency
on a preset file. It is validated at generation time, and the test suite extracts
the JSON *from the guide text* and confirms it imports with an identical
configuration hash and executes a short run.

**Import.** Six stages: extraction (raw JSON or exactly one fenced block;
multiple candidates rejected rather than guessed), syntax (`json.loads` only —
nothing is ever evaluated; `NaN`/`Infinity` rejected; depth and size limits),
version (newer schema → actionable error; older → explicit migration with every
change listed), schema (`extra="forbid"`, so unknown keys are errors), references
and scientific combinations (`validate_scenario`), workload.

Verified behaviour:

| Input | Result |
|---|---|
| Valid JSON, raw | accepted, hash preserved |
| Valid JSON in one fenced block, with surrounding chat text | accepted |
| Two fenced blocks | rejected: "Found 2 fenced code blocks… will not guess" |
| Truncated JSON | rejected at syntax stage with position |
| `NaN` constant | rejected: non-finite constant not allowed |
| Unknown key `bogus_field` | rejected: "UMEM rejects unrecognised keys rather than ignoring them" |
| `mating_mode: "harem"` | rejected with allowed values listed |
| `schema_version: 99` | rejected: names the supported range and the remedy |
| `gestation_delay_steps: 3` under distributed timing | rejected by the scientific-combination validator |
| `domain: "ghost"` | rejected: invalid reference |
| 2.1 MB input | rejected with the limit stated |
| schema 1 document | migrated; the three meaning-preserving changes shown |

**Review and apply.** A valid import is a proposal. The review shows the proposed
experiment's description, migration changes, and a path-by-path diff against the
current scenario. Verified: previewing leaves the configuration hash and existing
results untouched; an invalid import leaves both untouched and offers no Apply
button; applying marks the scenario Custom and clears results using the existing
behaviour; there is no automatic run, file overwrite or transmission.

**Repair loop.** "Download validation feedback for the AI" produces exact failing
paths, reasons, allowed values, relevant versions, and an instruction to change
only what is required and preserve everything else. The submitted JSON is
included only when the user ticks the box (asserted both ways). No source editing
is needed.

---

## 6. Deterministic experiment description

A local, rule-based renderer shared by manual setup, import preview and reports.
Nine sections: population and time; environment; available behaviours; survival
constraints; reproduction; inheritance and mutation; cognition; experiment
design; recording. It describes interactions the reader is likely to misread —
in particular that the reproductive event rate is an attempt rate, not a birth
rate, and that inherited propensity is not realised allocation.

**Accounting is complete.** Every configuration parameter is either mentioned in
prose, listed in the complete specification, or reported in a "parameters without
a narrative rule" list. Uncovered parameters across all ten presets: **0**.
Inactive fields are listed separately with the reason they are ignored.

**Verified semantics, not restated design intent.** The task required checking
whether mutation probability is per offspring globally or per layer. It is **per
layer, tested independently**: with `mutation_target = both`, an offspring is
tested once in the domain layer and once in the task layer, so it can carry two
events, and `mutation_events_per_offspring` can exceed the configured
probability. The description, both guides and the registry state this; the
previous design documents did not.

Determinism, section presence, change tracking and active/inactive marking are
all asserted by test.

---

## 7. Report coverage

`AI_REPORT.md` has stable anchors `[S1]`–`[S7]` and `[T1]`, `[T2]`, … so an
assistant can cite exactly where a number came from.

- **[S1] Identity and provenance**: versions, both fingerprints, expected guide
  version, experiment mode, runs requested/completed/failed, cancellation,
  partial and extinction flags, config hash, master seed, replication indices,
  run ids, timings, warnings.
- **[S2]** deterministic description and **[T1]/[T2]** complete effective and
  inactive configuration; **[T3]** active mechanisms.
- **[S3]** output dictionary for the fields used, plus an explicit list of what
  is unavailable **and why** (legacy timing does not track attempts; no bonds
  outside pair-bonded mode; legacy inheritance counts no mutation events;
  cognition A/B disabled).
- **[S4]** results: single runs labelled DESCRIPTIVE ONLY; replicated
  experiments get a per-run table plus mean, t-interval, sd, median and n, and a
  Wilson interval for extinction; sweeps keep cell identity with parameter
  values, per-cell configuration hashes, seed policy, sample sizes and per-cell
  uncertainty, with an explicit warning not to pool cells.
- **[S5]** definitions of denominators and observation windows: completed lives
  versus censored survivors, founders versus fully observed cohorts, realised
  births versus attempts, allocation versus propensity, aggregate versus
  individual, per-step versus per-season, recording intervals versus steps.
- **[S6]** manifest of every export file with purpose, format, row counts,
  coverage and whether its data appear in the report.
- **[S7]** an explicit statement of what is omitted.

All statistics reuse the existing tested functions; no new significance test,
interval or causal claim was introduced. Undefined values render as `null`,
never zero — asserted for `mean_pairs_per_step` under legacy timing. Extinct,
cancelled and partially failed experiments are reported, not hidden; a simulated
run failure produces `runs_requested 3 / runs_completed 2 / runs_failed 1`.

Size is bounded: about 30–40 kB for the experiments tested. Time series are
summarised per season with the aggregation method stated; full tables stay in the
bundle. Optional numbered appendix parts carry the full series, each labelled
with the run, the row range, the columns included and the columns omitted. The
report never claims completeness — without appendices it says so explicitly.

---

## 8. Interfaces

Both interfaces call the same services in `ai_assist` and `WorkbenchState`; no
scientific logic is duplicated.

**Streamlit**: new pages *AI-assisted setup* and *Interpret results with AI* in
the main navigation, plus a permanent "Experiment conditions" panel on the Run
and Scenario manager pages. Guides download before any run; the report button
requires results. Both pages state that UMEM sends nothing.

**Desktop**: an *AI assistance* tab with guide export, conditions view, paste or
load, validate/preview, apply, feedback export and report export; the report
button is disabled until results exist.

Verified end to end in **both**:

| Step | Streamlit | Desktop |
|---|---|---|
| Guide download available before any run | ✅ | ✅ |
| Example JSON pasted as a realistic AI reply (fenced, with chat text) | ✅ | ✅ |
| Preview leaves configuration hash unchanged | ✅ | ✅ |
| Malformed JSON rejected, Apply not offered | ✅ | ✅ |
| Apply changes scenario, marks Custom, clears results | ✅ | ✅ |
| Short simulation runs afterwards | ✅ | ✅ (worker thread) |
| Report generated and previewed | ✅ | ✅ |

The CLI additionally exposes `ai-guides`, `ai-import` (with `--feedback`) and
`describe` for reproducible testing; users never need it.

---

## 9. Verification

Baseline before editing: **293 passed**. After: **340 collected, 340 passed, 0
failed, 0 skipped** (137 s). `ruff check src tests scripts` passes.

Against the acceptance list:

1. **Embedded example** parses, validates and runs; the copy extracted from the
   guide text imports to an identical hash. ✅
2. **Export → import → apply** preserves the configuration hash when nothing
   changed; failed imports and discarded previews preserve state and results. ✅
3. **Unknown fields, invalid IDs, incompatible versions, malformed JSON, invalid
   scientific combinations, multiple fenced objects** all produce useful errors
   (table in §5). ✅
4. **Description** is deterministic, tracks changed parameters, distinguishes
   active from inactive settings, and covers every parameter. ✅
5. **Both guides** cover their registries completely and carry version
   fingerprints; missing coverage fails. ✅
6. **Reports** for single, replicated, sweep, extinct, cancelled and partly
   failed experiments have correct coverage and status; per-run numbers are
   asserted to agree with `analysis.summary_table`. ✅
7. **Partitioning** labels part number, row range, included and omitted columns;
   the report states what it omits and never labels truncated content complete. ✅
8. **Same-seed baseline unchanged.** A run before and after generating guides,
   descriptions, imports and reports produces an identical population series and
   configuration hash: these features consume no engine random numbers. ✅
9. **End-to-end UI flow** tested independently on web and desktop (§8). ✅
10. **No AI SDK, credential, network call or automatic upload**: a test scans
    every source file for `openai`, `anthropic`, `requests`, `httpx`,
    `urlopen`, `api_key`, and checks `pyproject.toml` for such dependencies. ✅

**Honest limit**: these are fixture tests of the interoperability contract. They
do not and cannot prove that any commercial AI follows the instructions in the
guides. `docs/ai_assistance.md` contains a short owner-run manual checklist for
testing both workflows with a real service, requiring no API or paid plan.

---

## 10. Platform verification

| Platform | Status |
|---|---|
| Linux, Python 3.12 — engine, CLI, Streamlit, exports | ✅ executed |
| Desktop (PySide6 6.11.2) under offscreen Qt | ✅ executed; not a substitute for a real display server |
| Windows executable (PyInstaller) | ❌ never executed |
| GitHub Actions workflows | ❌ never executed |
| macOS | ❌ never executed |

---

## 11. Known limitations

- Automated tests verify UMEM's side of the contract only (§9).
- Compatibility means plain UTF-8 text and standard JSON. No claim is made about
  any service's upload limits or competence.
- Guides are version-specific; mixing versions is detectable via fingerprints but
  not automatically repaired.
- `AI_REPORT.md` is not raw data. Individual agent records, completed-life
  records and per-interval time series stay in the bundle and are listed in the
  manifest.
- The importer accepts exactly one JSON object; it will not merge fragments or
  patch an existing scenario field-by-field.
- The desktop Advanced view remains a read-only configuration table.
- Release identity placeholders remain (`RELEASE_CHECKLIST.md`); the project is
  not publicly release-ready until the owner supplies them.

---

## 12. How to try it (plain language)

**Design an experiment**

1. Open *AI-assisted setup*, press **Download AI_SCENARIO_DESIGN_GUIDE.md**.
2. Start a new conversation with any AI chat tool, attach that file, paste the
   starter message shown on the page, and describe your research question in
   ordinary words.
3. It will ask you a few questions at a time, suggest defaults, summarise the
   design, and finally give you a block of JSON.
4. Copy that JSON back into the box in UMEM and press **Validate and preview**.
   You will see the experiment described in English and exactly what would
   change. Nothing has changed yet.
5. Press **Apply**, then go to **Run**.

If UMEM reports a problem, press **Download validation feedback for the AI**,
paste that file back into the conversation, and it will send you a corrected
version with your other settings untouched.

**Understand your results**

1. After running, open *Interpret results with AI*.
2. Download the two files offered.
3. Give both to a fresh AI conversation with the starter message, then ask
   questions — or ask for an academic-style draft of the results.

UMEM never contacts an AI service. You move the files, and you decide what to
apply. `docs/ai_assistance.md` has the full walkthrough and an owner checklist
for testing the workflows with a real assistant.

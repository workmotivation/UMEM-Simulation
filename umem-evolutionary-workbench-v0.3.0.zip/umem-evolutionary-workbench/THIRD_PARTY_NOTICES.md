# Third-party notices

This project bundles no third-party source code. It depends on the packages
listed below, each retrieved from the Python Package Index under its own
licence. This file is provided for convenience; the authoritative licence text
ships with each package.

## Required dependencies

| Package | Licence | Purpose |
|---|---|---|
| NumPy | BSD 3-Clause | Vectorised state arrays and all random number generation |
| pandas | BSD 3-Clause | Time series, results tables, CSV input and output |
| SciPy | BSD 3-Clause | Student-t critical values for confidence intervals |
| matplotlib | PSF-based (matplotlib licence) | Figure generation |
| Pydantic | MIT | Configuration models and validation |
| PyYAML | MIT | YAML scenario serialisation |
| openpyxl | MIT | Excel workbook export |

## Optional dependencies

| Package | Licence | Purpose |
|---|---|---|
| Streamlit | Apache 2.0 | Web interface |
| PySide6 (Qt for Python) | LGPL v3 | Desktop interface |
| XlsxWriter | BSD 2-Clause | Faster Excel writing |
| Pillow | MIT-CMU | Image metadata checks in the test suite |
| pytest | MIT | Test runner |
| PyInstaller | GPL v2 with a bootloader exception | Windows executable build |

### A note on PySide6 and LGPL

PySide6 is licensed under the LGPL v3. Distributing a bundled executable that
includes PySide6 carries obligations, in particular that recipients be able to
replace the LGPL components. If you distribute a frozen build of the desktop
application, review the Qt licensing terms first. The Streamlit interface and
the command-line interface have no such requirement, and the engine itself does
not depend on Qt at all.

### A note on PyInstaller

PyInstaller is GPL v2, but its bootloader carries an exception permitting the
distribution of proprietary and differently licensed applications built with it.
Using PyInstaller does not impose the GPL on this project's own MIT-licensed
code.

## Reference model

`legacy/reference_original/` contains the original AOM 2.1 research script,
preserved byte-for-byte for provenance. It is the prior work of this project's
authors and is covered by the same MIT licence as the rest of the repository. It
is archived unchanged and is never imported or executed by the application; the
reimplementation in `src/umem_workbench/legacy/aom_adapter.py` is what the
software actually runs.

"""Launcher for the PySide6 desktop application.

Run with::

    python desktop_app.py
"""

import sys
from pathlib import Path

_SRC = Path(__file__).resolve().parent / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from umem_workbench.ui_desktop.app import main

if __name__ == "__main__":
    raise SystemExit(main())

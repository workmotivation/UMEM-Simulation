# Release checklist (owner-supplied information)

The software is **functionally complete for the reproduction and inheritance
milestone**, but it must not be described as publicly release-ready while the
following placeholders remain. None of these block running or testing the
software; all require information only the project owner can supply.

## Identity placeholders to replace

| File | Placeholder | Replace with |
|---|---|---|
| `pyproject.toml` | `AUTHOR_NAME_HERE`, `author@example.com` | real author name and address (must stay a syntactically valid e-mail) |
| `pyproject.toml` | `ORGANISATION_HERE` (4 URLs) | GitHub organisation or user |
| `CITATION.cff` | `AUTHOR_GIVEN_NAME_HERE`, `AUTHOR_FAMILY_NAME_HERE`, `AUTHOR_EMAIL_HERE`, `AFFILIATION_HERE`, `ORCID_HERE`, `ORGANISATION_HERE` | as labelled |
| `LICENSE` | `AUTHOR_NAME_HERE` | copyright holder |
| `CODE_OF_CONDUCT.md` | `AUTHOR_EMAIL_HERE` | contact address |
| `README.md`, `CONTRIBUTING.md`, `docs/packaging.md` | `ORGANISATION_HERE` | repository URL |

## Before tagging a public release

- [ ] Replace every placeholder above.
- [ ] Decide the public version number (`0.2.0` is the internal milestone label).
- [ ] Run `python -m pytest` on the target platforms.
- [ ] Build and *launch* the Windows executable on a machine without Python
      (`docs/packaging.md`); it has never been executed in development.
- [ ] Confirm `CHANGELOG.md` describes the released state.
- [ ] Remove "First public release" wording from the 0.1.0 entry if 0.2.0 is
      the first public tag.

# Contributor Covenant Code of Conduct

## Our pledge

We as members, contributors, and leaders pledge to make participation in our
community a harassment-free experience for everyone, regardless of age, body
size, visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, religion, or sexual identity and
orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our standards

Examples of behaviour that contributes to a positive environment:

- demonstrating empathy and kindness toward other people;
- being respectful of differing opinions, viewpoints, and experiences;
- giving and gracefully accepting constructive feedback;
- accepting responsibility, apologising to those affected by our mistakes, and
  learning from the experience;
- focusing on what is best for the community as a whole.

Examples of unacceptable behaviour:

- sexualised language or imagery, and sexual attention or advances of any kind;
- trolling, insulting or derogatory comments, and personal or political attacks;
- public or private harassment;
- publishing others' private information without their explicit permission;
- other conduct which could reasonably be considered inappropriate in a
  professional setting.

## Scientific conduct

This project is a research tool, so two further expectations apply:

- **Do not overstate what the model shows.** Contributions to documentation,
  defaults, or figures must not imply that the model's abstract results are
  empirical findings about real organisms.
- **Do not remove uncertainty.** Confidence intervals, extinction rates,
  validation warnings, and stated limitations exist to prevent
  over-interpretation. Removing or weakening them requires clear justification.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behaviour may be
reported to the project maintainers at AUTHOR_EMAIL_HERE. All complaints will be
reviewed and investigated promptly and fairly. Maintainers are obliged to
respect the privacy and security of the reporter of any incident.

## Attribution

This Code of Conduct is adapted from the [Contributor
Covenant](https://www.contributor-covenant.org), version 2.1.

<#
.SYNOPSIS
    Run the automated test suite on Windows.
.EXAMPLE
    .\scripts\run_tests.ps1
    .\scripts\run_tests.ps1 -SkipUi
#>
[CmdletBinding()]
param(
    [switch]$SkipUi,
    [switch]$Coverage
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "UMEM Workbench - test suite" -ForegroundColor Cyan

if (-not (Test-Path ".venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv .venv
}
& .\.venv\Scripts\Activate.ps1

Write-Host "Installing test dependencies..." -ForegroundColor Yellow
python -m pip install --upgrade pip | Out-Null
python -m pip install -e ".[test]" | Out-Null

$pytestArgs = @()
if ($SkipUi)   { $pytestArgs += @("-m", "not ui") }
if ($Coverage) { $pytestArgs += @("--cov=umem_workbench", "--cov-report=term-missing") }

Write-Host "Running pytest..." -ForegroundColor Yellow
python -m pytest @pytestArgs
if ($LASTEXITCODE -ne 0) {
    Write-Host "Tests FAILED." -ForegroundColor Red
    exit $LASTEXITCODE
}
Write-Host "All tests passed." -ForegroundColor Green

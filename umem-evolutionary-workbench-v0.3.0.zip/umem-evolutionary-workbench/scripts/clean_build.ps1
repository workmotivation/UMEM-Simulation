<#
.SYNOPSIS
    Remove build artefacts, caches, and previous distributions.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$targets = @("build", "dist", ".pytest_cache", ".ruff_cache",
             "src\umem_workbench.egg-info", "umem_evolutionary_workbench.egg-info")

foreach ($target in $targets) {
    if (Test-Path $target) {
        Write-Host "Removing $target" -ForegroundColor Yellow
        Remove-Item -Recurse -Force $target
    }
}

Get-ChildItem -Path . -Include "__pycache__" -Recurse -Directory |
    ForEach-Object {
        Write-Host "Removing $($_.FullName)" -ForegroundColor DarkGray
        Remove-Item -Recurse -Force $_.FullName
    }

Write-Host "Clean complete." -ForegroundColor Green

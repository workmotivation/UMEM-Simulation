#!/usr/bin/env python3
"""Reproductive-intensity audit (completion prompt Part II, item 9).

Produces two distinct comparisons over multiple seeds, on raw dynamics with no
smoothing:

1. **Operational**: the shipped legacy and distributed presets as they are.
2. **Timing-isolation**: distributed rate calibrated *per preset* (never per
   seed) so realised births match legacy within a stated tolerance; the
   remaining contrast is then birth *timing*.

Also runs mechanism checks: double participation, half-hazard totals, and
per-eligible-agent event rates by mode.

    python scripts/audit_reproductive_intensity.py --seeds 8 --json out.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

_SRC = Path(__file__).resolve().parents[1] / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from umem_workbench.config.enums import (  # noqa: E402
    FounderAgeDistribution,
    InheritanceModel,
    ReproductionTiming,
)
from umem_workbench.config.presets import load_preset  # noqa: E402
from umem_workbench.experiments import run_single  # noqa: E402

PRESETS = ["stable_abundant", "scarce_low_fecundity", "volatile_high_fecundity"]


def scenario(preset, seed, *, legacy, rate=None, seasons=None):
    s = load_preset(preset)
    s.master_seed = seed
    s.output.record_interval_steps = 1
    s.output.store_agent_sample = False
    if seasons:
        s.lifecycle.total_seasons = seasons
    if legacy:
        s.reproduction.timing = ReproductionTiming.SEASON_END_LEGACY
        s.population.founder_age_distribution = FounderAgeDistribution.ALL_NEWBORN_LEGACY
        s.inheritance.model = InheritanceModel.LEGACY
    if rate is not None:
        s.reproduction.reproductive_event_rate = rate
    return s


def acf_season(ts, sps):
    d = np.diff(ts["population"].to_numpy(float))
    dd = d - d.mean()
    den = np.dot(dd, dd)
    return float(np.dot(dd[:-sps], dd[sps:]) / den) if den > 0 and len(dd) > sps else float("nan")


def run_metrics(s):
    r = run_single(s, 0)
    ts, bs = r.time_series, r.breeding_series
    sps = s.lifecycle.steps_per_season
    births = ts["births_interval"].to_numpy(float)
    phase = ts["step"].to_numpy() % sps
    by_phase = np.bincount(phase, weights=births, minlength=sps)
    p = by_phase[by_phase > 0] / by_phase.sum() if by_phase.sum() else np.array([1.0])
    entropy = float(-(p * np.log(p)).sum() / np.log(sps)) if by_phase.sum() else float("nan")
    elig_steps = float(bs["n_eligible"].sum()) if "n_eligible" in bs else float("nan")
    events = float(bs["n_pairs"].sum())
    return {
        "total_births": int(births.sum()),
        "total_events": int(events),
        "mean_population": float(ts["population"].mean()),
        "final_population": int(r.final_population),
        "extinct": bool(r.extinct),
        "acf_season": acf_season(ts, sps),
        "birth_phase_entropy": entropy,
        "share_steps_with_births": float((births > 0).mean()),
        # events per eligible agent-step: the realised per-step hazard
        "events_per_eligible_agent_step": events / elig_steps if elig_steps else float("nan"),
        "births_per_event": int(births.sum()) / events if events else float("nan"),
    }


def mean_ci(vals):
    v = np.array(vals, float)
    v = v[np.isfinite(v)]
    if v.size == 0:
        return {"mean": float("nan"), "lo": float("nan"), "hi": float("nan"), "n": 0}
    m = v.mean()
    sem = v.std(ddof=1) / np.sqrt(v.size) if v.size > 1 else 0.0
    return {"mean": float(m), "lo": float(m - 1.96 * sem), "hi": float(m + 1.96 * sem), "n": int(v.size)}


def summarise(rows):
    return {k: mean_ci([r[k] for r in rows]) for k in rows[0]}


def calibrate_rate(preset, seeds, target_births, seasons):
    """Preset-level rate matching legacy births; bisection on the seed mean."""

    def births_at(rate):
        return np.mean([run_metrics(scenario(preset, sd, legacy=False, rate=rate,
                                             seasons=seasons))["total_births"]
                        for sd in seeds])

    lo, hi = 0.2, 6.0
    for _ in range(9):
        mid = 0.5 * (lo + hi)
        if births_at(mid) < target_births:
            lo = mid
        else:
            hi = mid
    return round(0.5 * (lo + hi), 3)


def mechanism_checks(seed=1):
    """Answers to the specific audit questions, from one instrumented run."""

    from umem_workbench.engine.distributed_reproduction import (
        PairBonds,
        distributed_breed,
    )
    from umem_workbench.engine.randomness import RandomStreams
    from umem_workbench.engine.state import AgentPool

    out = {}
    s = load_preset("stable_abundant")
    s.reproduction.reproductive_event_rate = 4.0        # high, to stress it
    pool = AgentPool(s)
    streams = RandomStreams.create(seed, 0)
    pool.initialise(streams.stream("initial_population"))
    rng = streams.stream("mate_choice")
    dup = 0
    for t in range(200):
        sel = distributed_breed(pool, s, t, PairBonds(), rng)
        parents = np.concatenate([sel.parent_a_slots, sel.parent_b_slots])
        dup += int(len(parents) - len(np.unique(parents)))
    out["double_participation_events_in_200_steps"] = dup

    # Half-hazard check: both types initiate at h/2 -> expected events per
    # eligible agent per season ~= rate when pools are balanced.
    s2 = load_preset("stable_abundant")
    s2.lifecycle.total_seasons = 10
    s2.output.record_interval_steps = 1
    s2.reproduction.reproductive_event_rate = 1.0
    s2.reproduction.energy_threshold = 0.0
    s2.reproduction.health_threshold = 0.0
    s2.reproduction.repro_capital_threshold = 0.0
    r = run_single(s2, 0)
    bs = r.breeding_series
    sps = s2.lifecycle.steps_per_season
    events = bs["n_pairs"].sum()
    elig_agent_steps = bs["n_eligible"].sum()
    # each event involves 2 agents
    out["realised_events_per_eligible_agent_per_season_rate1"] = float(
        2 * events / elig_agent_steps * sps) if elig_agent_steps else float("nan")
    out["failed_match_rate_rate1"] = float(
        bs["n_failed_no_partner"].sum() / max(1, bs["n_attempts"].sum()))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seeds", type=int, default=8)
    ap.add_argument("--seasons", type=int, default=None)
    ap.add_argument("--json", type=Path)
    args = ap.parse_args()
    seeds = list(range(1, args.seeds + 1))
    report = {"mechanism_checks": mechanism_checks(), "operational": {}, "timing_isolation": {}}

    print("=== Mechanism checks ===")
    for k, v in report["mechanism_checks"].items():
        print(f"  {k}: {v}")

    print("\n=== 1. Operational comparison (shipped presets) ===")
    for preset in PRESETS:
        leg = summarise([run_metrics(scenario(preset, sd, legacy=True, seasons=args.seasons)) for sd in seeds])
        dis = summarise([run_metrics(scenario(preset, sd, legacy=False, seasons=args.seasons)) for sd in seeds])
        report["operational"][preset] = {"legacy": leg, "distributed": dis,
                                         "shipped_rate": load_preset(preset).reproduction.reproductive_event_rate}
        print(f"--- {preset} (shipped rate {report['operational'][preset]['shipped_rate']}) ---")
        for k in ("total_births", "total_events", "mean_population", "acf_season",
                  "birth_phase_entropy", "births_per_event", "events_per_eligible_agent_step"):
            print(f"  {k:32} legacy {leg[k]['mean']:9.3f}   distributed {dis[k]['mean']:9.3f}")

    print("\n=== 2. Timing-isolation comparison (rate calibrated per preset to legacy births) ===")
    for preset in PRESETS:
        target = report["operational"][preset]["legacy"]["total_births"]["mean"]
        rate = calibrate_rate(preset, seeds, target, args.seasons)
        dis = summarise([run_metrics(scenario(preset, sd, legacy=False, rate=rate, seasons=args.seasons)) for sd in seeds])
        leg = report["operational"][preset]["legacy"]
        report["timing_isolation"][preset] = {"calibrated_rate": rate, "legacy": leg, "distributed": dis}
        ratio = dis["total_births"]["mean"] / target
        print(f"--- {preset}: calibrated rate = {rate} (births ratio dist/legacy = {ratio:.3f}) ---")
        for k in ("total_births", "mean_population", "acf_season", "birth_phase_entropy",
                  "share_steps_with_births", "extinct"):
            print(f"  {k:32} legacy {leg[k]['mean']:9.3f} [{leg[k]['lo']:.3f},{leg[k]['hi']:.3f}]"
                  f"   distributed {dis[k]['mean']:9.3f} [{dis[k]['lo']:.3f},{dis[k]['hi']:.3f}]")

    if args.json:
        args.json.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"\nwritten to {args.json}")


if __name__ == "__main__":
    main()

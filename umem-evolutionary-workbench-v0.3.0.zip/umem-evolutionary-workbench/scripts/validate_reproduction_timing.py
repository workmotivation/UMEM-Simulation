#!/usr/bin/env python3
"""Empirical before/after validation of distributed reproduction (plan §14).

Compares matched legacy and distributed conditions on raw simulated population
dynamics. No smoothing, interpolation, or post-processing of any kind is applied
-- the point is to show the artifact was removed by changing the mechanism.

Usage::

    python scripts/validate_reproduction_timing.py --seeds 10 --json out.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

_SRC = Path(__file__).resolve().parents[1] / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from umem_workbench.config.enums import (  # noqa: E402
    FounderAgeDistribution,
    InheritanceModel,
    ReproductionTiming,
)
from umem_workbench.config.presets import load_preset  # noqa: E402
from umem_workbench.experiments import run_single  # noqa: E402

PRESETS = ["stable_abundant", "scarce_low_fecundity", "volatile_high_fecundity"]


def build(preset: str, seed: int, legacy: bool):
    s = load_preset(preset)
    s.master_seed = seed
    s.output.record_interval_steps = 1      # per-step, so nothing is aliased
    s.output.store_agent_sample = False
    if legacy:
        s.reproduction.timing = ReproductionTiming.SEASON_END_LEGACY
        s.population.founder_age_distribution = \
            FounderAgeDistribution.ALL_NEWBORN_LEGACY
        s.inheritance.model = InheritanceModel.LEGACY
    return s


def metrics(result, steps_per_season: int) -> dict:
    ts = result.time_series
    pop = ts["population"].to_numpy(float)
    births = ts["births_interval"].to_numpy(float)
    d = np.diff(pop)
    dd = d - d.mean()

    def acf(lag: int) -> float:
        if lag >= len(dd) - 1 or np.dot(dd, dd) == 0:
            return float("nan")
        return float(np.dot(dd[:-lag], dd[lag:]) / np.dot(dd, dd))

    # Birth-phase entropy: how evenly births fall across the season.
    phase = ts["step"].to_numpy() % steps_per_season
    by_phase = np.bincount(phase, weights=births, minlength=steps_per_season)
    total = by_phase.sum()
    if total > 0:
        p = by_phase[by_phase > 0] / total
        entropy = float(-(p * np.log(p)).sum() / np.log(steps_per_season))
    else:
        entropy = float("nan")

    season_pop = ts.groupby("season")["population"].last().to_numpy(float)
    sd = np.diff(season_pop)

    return {
        "acf_at_season_lag": acf(steps_per_season),
        "share_steps_with_births": float((births > 0).mean()),
        "share_steps_population_rises": float((d > 0).mean()),
        "birth_phase_entropy": entropy,
        "population_cv": float(pop.std() / max(pop.mean(), 1e-9)),
        "mean_abs_season_change": float(np.abs(sd).mean()) if len(sd) else np.nan,
        "total_births": int(births.sum()),
        "mean_population": float(pop.mean()),
        "final_population": int(result.final_population),
        "extinct": bool(result.extinct),
    }


def summarise(rows: list[dict]) -> dict:
    out = {}
    for key in rows[0]:
        vals = np.array([r[key] for r in rows], dtype=float)
        vals = vals[np.isfinite(vals)]
        if vals.size == 0:
            out[key] = {"mean": float("nan")}
            continue
        mean = float(vals.mean())
        sem = float(vals.std(ddof=1) / np.sqrt(vals.size)) if vals.size > 1 else 0.0
        out[key] = {"mean": mean, "ci_lo": mean - 1.96 * sem,
                    "ci_hi": mean + 1.96 * sem, "n": int(vals.size)}
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--seasons", type=int, default=None)
    ap.add_argument("--json", type=Path, default=None)
    args = ap.parse_args()

    report = {}
    print(f"Distributed vs legacy reproduction, {args.seeds} seeds per cell.")
    print("Raw simulated dynamics; no smoothing applied.\n")

    for preset in PRESETS:
        report[preset] = {}
        for label, legacy in (("legacy", True), ("distributed", False)):
            rows = []
            for seed in range(1, args.seeds + 1):
                s = build(preset, seed, legacy)
                if args.seasons:
                    s.lifecycle.total_seasons = args.seasons
                rows.append(metrics(run_single(s, 0),
                                    s.lifecycle.steps_per_season))
            report[preset][label] = summarise(rows)

        leg, dis = report[preset]["legacy"], report[preset]["distributed"]
        print(f"--- {preset} ---")
        print(f"{'metric':34}{'legacy':>12}{'distributed':>14}")
        for key, fmt in (("acf_at_season_lag", "{:.3f}"),
                         ("share_steps_with_births", "{:.3f}"),
                         ("share_steps_population_rises", "{:.3f}"),
                         ("birth_phase_entropy", "{:.3f}"),
                         ("population_cv", "{:.3f}"),
                         ("total_births", "{:.0f}"),
                         ("mean_population", "{:.0f}")):
            print(f"{key:34}{fmt.format(leg[key]['mean']):>12}"
                  f"{fmt.format(dis[key]['mean']):>14}")
        print()

    if args.json:
        args.json.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"Written to {args.json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

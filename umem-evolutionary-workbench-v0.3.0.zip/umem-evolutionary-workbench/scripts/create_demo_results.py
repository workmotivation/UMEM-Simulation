#!/usr/bin/env python3
"""Generate a demonstration result set for every shipped preset.

Produces one export bundle per preset plus a cognition-comparison bundle, so a
new user can inspect real output without waiting for a run to finish.

Usage::

    python scripts/create_demo_results.py --output ./demo_results
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from umem_workbench.config.presets import PRESET_IDS, load_preset  # noqa: E402
from umem_workbench.experiments import run_replications  # noqa: E402
from umem_workbench.export import export_bundle  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("./demo_results"))
    parser.add_argument("--replications", type=int, default=5)
    parser.add_argument("--seasons", type=int, default=20)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    started = time.time()

    for preset_id in PRESET_IDS:
        print(f"Running {preset_id} ...", flush=True)
        scenario = load_preset(preset_id)
        scenario.lifecycle.total_seasons = args.seasons
        batch = run_replications(scenario, args.replications)
        path = export_bundle(args.output, batch.runs[0],
                             replication_result=batch,
                             bundle_name=f"demo_{preset_id}",
                             allow_unsafe_directory=True)
        extinction = batch.extinction()
        print(f"  extinct {extinction['n_extinct']}/{extinction['n_runs']}  "
              f"-> {Path(path).name}")

    # A matched cognition comparison: the question the workbench exists for.
    print("Running cognition comparison ...", flush=True)
    for label, enabled in (("no_cognition", False), ("cognition_A", True)):
        scenario = load_preset("stable_abundant")
        scenario.lifecycle.total_seasons = args.seasons
        scenario.cognition.experience_enabled = enabled
        batch = run_replications(scenario, args.replications)
        export_bundle(args.output, batch.runs[0], replication_result=batch,
                      bundle_name=f"demo_comparison_{label}",
                      allow_unsafe_directory=True)
        print(f"  {label} complete")

    print(f"\nDone in {time.time() - started:.1f}s. Bundles in {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

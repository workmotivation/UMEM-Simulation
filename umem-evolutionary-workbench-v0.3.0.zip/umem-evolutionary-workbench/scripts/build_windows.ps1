<#
.SYNOPSIS
    Build the standalone Windows desktop executable with PyInstaller.
.DESCRIPTION
    Produces dist\UMEM-Workbench\UMEM-Workbench.exe.

    Note: PySide6 is LGPL v3. Review the Qt licensing terms before
    distributing a bundled build. See THIRD_PARTY_NOTICES.md.
.EXAMPLE
    .\scripts\build_windows.ps1
    .\scripts\build_windows.ps1 -SkipTests
#>
[CmdletBinding()]
param(
    [switch]$SkipTests,
    [switch]$Clean
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "UMEM Workbench - Windows build" -ForegroundColor Cyan

if ($Clean) { & "$PSScriptRoot\clean_build.ps1" }

if (-not (Test-Path ".venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv .venv
}
& .\.venv\Scripts\Activate.ps1

Write-Host "Installing build dependencies..." -ForegroundColor Yellow
python -m pip install --upgrade pip | Out-Null
python -m pip install -e ".[desktop,build,images]" | Out-Null

if (-not $SkipTests) {
    Write-Host "Running tests before building..." -ForegroundColor Yellow
    python -m pip install -e ".[test]" | Out-Null
    python -m pytest -m "not ui"
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Tests failed; aborting build." -ForegroundColor Red
        exit $LASTEXITCODE
    }
}

Write-Host "Running PyInstaller..." -ForegroundColor Yellow
python -m PyInstaller umem_workbench.spec --clean --noconfirm
if ($LASTEXITCODE -ne 0) {
    Write-Host "PyInstaller FAILED." -ForegroundColor Red
    exit $LASTEXITCODE
}

$exe = "dist\UMEM-Workbench\UMEM-Workbench.exe"
if (-not (Test-Path $exe)) {
    Write-Host "Expected executable not found at $exe" -ForegroundColor Red
    exit 1
}

$size = [math]::Round((Get-Item $exe).Length / 1MB, 1)
Write-Host "Build complete: $exe ($size MB)" -ForegroundColor Green
Write-Host "Launch it once and confirm the window opens before distributing." -ForegroundColor Yellow

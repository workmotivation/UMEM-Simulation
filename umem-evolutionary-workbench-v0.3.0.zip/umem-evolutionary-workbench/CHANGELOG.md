# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-09-09

External-AI scenario design and results interpretation. The simulation engine,
its equations, defaults and random-number consumption are unchanged; no presets
were recalibrated.

### Added

- **`ai_assist` package**: an output-field registry documenting every exported
  table and column; deterministic fingerprints of the parameter dictionary and
  output registry; a rule-based natural-language experiment description (no
  language model); a six-stage scenario importer; generators for both guides;
  and an experiment report builder.
- **`AI_SCENARIO_DESIGN_GUIDE.md`**, generated from the configuration
  dictionary: model structure, all 172 parameters with units, constraints and
  applicability, task/effect syntax, what the engine cannot represent, interview
  instructions, an explicit output contract, and one complete validated example
  scenario emitted in full.
- **`AI_REPORT_INTERPRETATION_GUIDE.md`**, generated from the output registry:
  every field UMEM can export, plus rules on separating observation from
  interpretation, respecting reported uncertainty, and not treating steps or
  agents as replications.
- **`AI_REPORT.md`** per experiment, with stable `[S*]`/`[T*]` citation anchors,
  identity and provenance, the deterministic description, effective
  configuration, an output dictionary for the fields used, summary tables by
  theme, per-run and per-cell tables with the existing uncertainty methods,
  denominator and observation-window definitions, and a manifest of every export
  file stating whether its data appear in the report.
- **Import workflow**: file upload or paste; raw JSON or exactly one fenced
  block; unknown keys, invalid references, non-finite constants, incompatible
  schema versions and invalid mechanism combinations all produce actionable
  errors. Migration of older schemas is applied with every change shown. A valid
  import is a proposal until Apply; invalid imports leave the scenario and
  results untouched.
- **Validation feedback for the AI**: exact failing paths, reasons, allowed
  values, and an instruction to preserve unaffected settings. The submitted JSON
  is included only if the user opts in.
- **Permanent "Experiment conditions" panel** in both interfaces, and a separate
  "Proposed" description during import review.
- **UI**: Streamlit pages *AI-assisted setup* and *Interpret results with AI*;
  a desktop *AI assistance* tab. Both drive the same services.
- **CLI**: `ai-guides`, `ai-import` (with `--feedback`), `describe`.
- The reproducibility bundle now also contains `AI_REPORT.md` and the
  interpretation guide.
- `docs/ai_assistance.md`, including an owner checklist for manually testing the
  two workflows with a real AI service, and generated examples in
  `docs/examples/ai_assist/`.

### Notes

UMEM makes no AI API calls and requires no credentials; everything works offline
after installation. Automated tests verify UMEM's side of the contract only —
they cannot prove a commercial AI follows the guides.

340 tests pass (from 293).

## [0.2.1] - 2026-09-08

Completion and correction pass for the reproduction and inheritance milestone.
No scientific mechanism was replaced; misleading outputs and gaps were fixed.
See `FINAL_COMPLETION_REPORT.md` for the full audit.

### Fixed

- **Gestation is no longer silently ignored.** A non-zero
  `reproduction.gestation_delay_steps` under distributed timing is now a
  blocking validation error rather than an accepted-and-discarded value. The
  field is retained for `season_end_legacy` only, and both interfaces disable it
  when continuous timing is active.
- **Pair-bond event counters were cumulative totals written into per-step rows**,
  so summing the column overcounted enormously (13,081 against a true 158 in a
  three-season run). Replaced with `n_bonds_formed_step` /
  `n_bonds_dissolved_step` plus explicitly named `cumulative_*` columns; the
  identity `active = prior + formed − dissolved` now holds on every step.
- **`mean_pairs_per_season` was a per-step mean** under distributed timing.
  Removed, not aliased. Replacements state their denominator explicitly
  (`mean_pairs_per_step`, `mean_total_pairs_per_season`,
  `mean_eligible_agents_per_step`, `mean_eligible_agent_steps_per_season`).
- **Pair bonds could not form while no agent was reproduction-eligible**,
  contradicting the documented "bond formation requires maturity only"
  semantics. Bond updating now runs before the eligibility gate.
- Schema-2 parameters were reported as schema-1 in the generated parameter
  reference.

### Changed

- `reproduction.expected_births_per_season` renamed **`reproductive_event_rate`**.
  The old name asserted a birth count, but the quantity is an attempt-event
  rate: births equal events x P(partner found) x fertility x juvenile survival.
  The old name is accepted on input and rewritten by migration.
- `ui()` metadata gains `applicability` and `deprecated`, so legacy-only and
  mode-specific fields are marked in the schema, the parameter reference, the
  data dictionary and both interfaces. Inactive fields render disabled with an
  explanation.
- New validation warnings for ignored legacy fields, irrelevant mating settings
  under asexual reproduction, pair-bond type imbalance, and zero segregation
  variance.

### Added

- `umem-workbench data-dictionary` and `config/data_dictionary.py`: 172
  parameters with type, bounds, unit, category, applicability, scientific
  interpretation, source ADR and schema version. `docs/parameter_reference.md`
  is generated from it, with a test asserting the shipped document matches.
- Analysis metrics: birth-phase entropy, LRS Gini, top-20% parent share,
  failed-match rate, bond and mutation summaries. Tested against synthetic data
  with known answers.
- Export metadata: a 20-field mechanism block in `metadata.json` and
  `Run_Metadata`, plus an `Inheritance_Config` worksheet.
- **Desktop interface parity**: reproduction mode, timing, event rate, mating
  mode, choosiness, founder ages, inheritance model, sibling variation and
  mutation level, with dynamic enabling. Verified by running the real window
  under offscreen Qt, not merely by compiling it.
- `scripts/audit_reproductive_intensity.py`, `RELEASE_CHECKLIST.md`, and the
  redesign plan and jaggedness diagnostic now shipped in `docs/design/`.

### Verified

293 tests (from 253), all passing. Streamlit serves HTTP 200; CLI runs in all
five reproduction modes; schema-1 migration verified end to end. With
reproductive intensity matched per preset, season-lag autocorrelation still
falls from 0.837–0.910 to 0.008–0.073, so birth *timing* rather than birth
*quantity* is the operative contrast.

**Not verified**: Windows/macOS packaging and the CI workflows have never been
executed.

## [0.2.0] - 2026-09-07

Reproduction and inheritance redesign. **Configuration schema 2.**

### Changed — scientific mechanisms

- **Reproduction is now continuous.** Every time step is an opportunity to
  reproduce, following the non-Wright-Fisher convention. Season-end batch
  reproduction remains available as `reproduction.timing = season_end_legacy`.
  This removes the season-period sawtooth documented in the jaggedness
  diagnostic: autocorrelation at one season falls from 0.84–0.91 to 0.04–0.09
  and birth-phase entropy rises from 0.000 to 0.995, measured on raw dynamics
  with no smoothing.
- **Inheritance uses Fisher's infinitesimal model** on a centred latent scale,
  with segregation variance `V0/2` anchored to the configured founder variance.
  Segregation and mutation are now separately configurable and separately
  reported. The v0.1.0 mechanism remains as `inheritance.model = legacy`.
- **Founders start with a dispersed age structure** (`uniform` by default;
  `stable` and `all_newborn_legacy` also available).
- **Mate choice** by Random-k Pair Matching, with one choosiness parameter `k`
  spanning random mating to strong reproductive skew.
- **Three mating modes**: `random` (promiscuity), `pair_bonded` (social
  monogamy), `competitive` (polygyny-like skew), plus asexual reproduction.
- Default mate-quality weights now lead with `status` rather than reproductive
  capital: capital is reset on breeding, so weighting it *equalises* rather than
  concentrates reproductive success.
- All presets recalibrated for the new mechanisms; 0/12 extinction across seeds.

### Added

- Six new presets: `pair_bonded_humanlike`, `competitive_skew`,
  `asexual_clonal`, and legacy-mechanics variants of the three scientific
  presets.
- `docs/design/` architecture decision records (ADR-001 to ADR-007) and
  `docs/references.md`.
- `scripts/validate_reproduction_timing.py` for before/after jaggedness
  validation.
- Simple-mode controls for reproduction mode, timing, mating mode, choosiness,
  reproductive rate, founder ages, inheritance model, sibling variation and
  mutation level.
- Per-step breeding records including attempts, failed matches, active bonds,
  bond formation and dissolution, and mutation events.

### Migration

Scenarios written under schema 1 migrate automatically and are set to
`season_end_legacy` timing, `all_newborn_legacy` founder ages, and `legacy`
inheritance, so their scientific meaning is preserved. New scenarios use the new
defaults. Schema 1 and schema 2 configuration hashes are not comparable.

### Fixed

- Population accounting: births are recorded in the step in which they occur,
  and a closing snapshot ensures the final row matches `final_population`.

## [0.1.0] - 2026-07-23

First public release.

### Added

- **Simulation engine.** Finite-lifetime, discrete-time model with nested time
  steps, seasons, and lifetimes; hierarchical heritable propensities over
  motivational domains and tasks; homeostatic internal state; a declarative
  task-effect rule system with no user code execution; eight environmental
  process types with noisy observation; seven attributed mortality sources;
  sexual and asexual reproduction with four mate-selection modes; recombination
  and multiplicative lognormal mutation.
- **Cognition.** Three independently switchable mechanisms: intergenerational
  success memory (A), noisy environmental forecasting (B), and individual
  reinforcement learning (C, off by default).
- **Experiments.** Single runs, replicated experiments, and parameter sweeps of
  up to three parameters, with process-based parallelism, cooperative
  cancellation, and optional common random numbers across sweep cells.
- **Analysis.** Descriptive metrics including realised lifetime reproductive
  success and Crow's opportunity for selection; all six specified cognitive
  misallocation metrics; replicate aggregation with t-based confidence
  intervals and Wilson intervals for extinction rates; a colourblind-safe
  figure set.
- **Exports.** Formatted Excel workbooks, CSV tables, PNG/SVG/PDF figures at up
  to 300 DPI, and a complete ZIP reproducibility bundle.
- **Interfaces.** A Streamlit web interface with Simple and Advanced modes, a
  PySide6 desktop application with a background worker thread, and a
  command-line interface for headless and batch use.
- **Legacy support.** A faithful reimplementation of the AOM 2.1 generational
  model for continuity, with its differences from the main engine documented.
- **Tests.** 145 automated tests spanning configuration, reproducibility,
  scientific mechanisms, regression, exports, and the web interface.

### Notes on calibration

Preset constants were selected by seed sweeps so that each scenario produces a
usable demographic trajectory. They are numerical demonstration settings and are
not empirically derived life-history parameters.

"""Launcher for the Streamlit interface.

Run with::

    streamlit run streamlit_app.py
"""

import sys
from pathlib import Path

# Support running straight from a source checkout without installing.
_SRC = Path(__file__).resolve().parent / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from umem_workbench.ui_streamlit.app import main

main()
